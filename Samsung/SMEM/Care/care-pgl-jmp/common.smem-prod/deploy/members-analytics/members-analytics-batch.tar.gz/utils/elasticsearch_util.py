#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import elasticsearch
from config.loader import load_config

API_SUCCESS_INDEX = 'logstash-api_successlog-*'
USAGELOG_INDEX = 'usagelog-*'
KAFKA_USAGELOG_INDEX = 'kafka-usagelog-*'

__MAX_BRANCH = 500
__MAX_MODEL = 10000
__MAX_SCROLL_SIZE = 5000


class _ProxyConnection(elasticsearch.RequestsHttpConnection):
    def __init__(self, *args, **kwargs):
        proxies = kwargs.pop('proxies', {})
        super(_ProxyConnection, self).__init__(*args, **kwargs)
        self.session.proxies = proxies


def get_connection():

    config = load_config().get('elasticsearch')

    host = config.get('host')
    port = int(config.get('port'))

    if config.get('proxy') is not None:
        es_connection = elasticsearch.Elasticsearch(
            [{'host': host, 'port': port}],
            connection_class=_ProxyConnection,
            proxies={'http': config.get('proxy')},
            timeout=60
        )
    else:
        es_connection = elasticsearch.Elasticsearch(
            [{'host': host, 'port': port}],
            timeout=30
        )

    return es_connection


def get_search_result(es_connection, index, request_body):
    return es_connection.search(index=index, body=request_body)


def set_search_scroll(es_connection, index, request_body, scroll_time='1m'):
    return es_connection.search(index=index,
                                scroll=scroll_time,
                                size=__MAX_SCROLL_SIZE,
                                body=request_body)


def get_search_scroll_result(es_connection, sid, scroll_time='1m'):
    return es_connection.scroll(scroll_id=sid, scroll=scroll_time)


def disable_unused_log():
    import logging

    # disable HTTP call logs of elasticsearch
    logging.getLogger('elasticsearch').disabled = True
    logging.getLogger("urllib3.connectionpool").disabled = True
    logging.getLogger('urllib3.util.retry').disabled = True
