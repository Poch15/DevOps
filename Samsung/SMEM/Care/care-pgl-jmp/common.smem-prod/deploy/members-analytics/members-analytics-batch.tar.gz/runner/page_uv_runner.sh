#!/bin/bash

BASE_PYTHON_PATH='/home/common/members-analytics/members-analytics-batch'
source ${BASE_PYTHON_PATH}/.venv/bin/activate
export PYTHONPATH=${BASE_PYTHON_PATH}/page_uv

export cur_date="$(date +%Y-%m-%d)"
python3 /home/common/members-analytics/members-analytics-batch/page_uv/job/page_uv/page_uv_job.py $cur_date