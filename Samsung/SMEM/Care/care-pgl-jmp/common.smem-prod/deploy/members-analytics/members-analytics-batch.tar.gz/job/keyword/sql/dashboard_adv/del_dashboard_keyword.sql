DELETE FROM v3_dash_keyword_adv where period = '{period}';
DELETE FROM v3_dash_keyword_adv_rank where period = '{period}';