SELECT datetime::DATE as date, '{branch_name}' as branch_name, keyword, sum(cnt) as cnt
FROM tbl_v2_keyword
  WHERE
    datetime >= '{start_date}'
    AND
    datetime < '{end_date}'::TIMESTAMP + INTERVAL '1' DAY
    AND
    branch_id IN {branch_ids}
    AND
    keyword IN {keywords}
GROUP BY date, keyword
ORDER BY date