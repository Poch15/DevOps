#!/usr/bin/python3
# -*- coding: utf-8 -*-

from common.base.base_batch_job import BaseBatchJob
from common.logger import func_logger, Logger
from utils import args_util, file_util
from common.base.reader import MysqlReader
from common.base.writer import PostgresqlWriter
from datetime import datetime, timedelta


BRANCH_INDIA = 6
read_sql = file_util.load_sql_in_cur_dir('sql', 'ext_qna_day_for_tat.sql')
write_sql = file_util.load_sql_in_cur_dir('sql', 'ins_qna_tat.sql')


class FeedbackTatBatchJob(BaseBatchJob):
    def __init__(self, _start_dt, _end_dt):
        BaseBatchJob.__init__(self, _start_dt, _end_dt)

        self.reader = MysqlReader(read_sql)
        self.writer = PostgresqlWriter(write_sql)

        self.timezone_dic = {}
        self.result_rows = []
        self.statistics_dic = {}
        self.fb_tat_list = []

    @func_logger
    def do_read(self):
        self.get_timezone_dict()
        self.result_rows = self.reader.read(param=self.date)

    def get_timezone_dict(self):
        # 1. retrieve the list of branch_id and timezone and make timezone map (branch_id:timezone)

        sql = file_util.load_file(__file__, 'sql/ext_timezone.sql')
        timezone_list = self.reader.read(sql=sql)
        for timezone in timezone_list:
            branch_id, tz = timezone
            self.timezone_dic[branch_id] = int(tz)

    @func_logger
    def do_process(self):
        # 2. calculate the timediff between qna-open and qna-closed

        for row in self.result_rows:
            qna_dt, qna_ans_dt, branch_id, dvc_model, prd_cat = row

            qna_dt = datetime.strptime(qna_dt, "%Y-%m-%d %H:%M:%S") + timedelta(hours=self.timezone_dic[branch_id])
            qna_ans_dt = datetime.strptime(qna_ans_dt, "%Y-%m-%d %H:%M:%S") + timedelta(hours=self.timezone_dic[branch_id])
            if branch_id == BRANCH_INDIA:
                timediff = timediff_include_weekends(qna_dt, qna_ans_dt)
            else:
                timediff = timediff_exclude_weekends(qna_dt, qna_ans_dt)

            qna_dt = qna_dt.strftime("%Y-%m-%d %H:00:00")
            value = self.statistics_dic.get((qna_dt, branch_id, prd_cat, dvc_model), (0, 0))
            tot_cnt, tot_second = value
            if tot_cnt == 0:
                self.statistics_dic[(qna_dt, branch_id, prd_cat, dvc_model)] = (1, int(timediff))
            else:
                self.statistics_dic[(qna_dt, branch_id, prd_cat, dvc_model)] = (tot_cnt + 1, tot_second + int(timediff))

        for key in self.statistics_dic.keys():
            qna_dt, branch_id, prd_cat, dvc_model = key
            tot_cnt, tot_second = self.statistics_dic.get((qna_dt, branch_id, prd_cat, dvc_model))
            self.fb_tat_list.append((qna_dt, branch_id, prd_cat, dvc_model, tot_cnt, tot_second))

    @func_logger
    def do_write(self):
        self.writer.write(self.fb_tat_list)


def _adjust_hour(t, start, end):
    return max(start, min(end, t))


def _get_time_part(dt):
    return dt - dt.replace(hour=0, minute=0, second=0)


def timediff_exclude_weekends(_start_dt, _end_dt, start_bs_hour=timedelta(hours=0), end_bs_hour=timedelta(hours=24)):
    extra = [
        [1, 2, 3, 4, 5, 5, 5],
        [5, 1, 2, 3, 4, 4, 4],
        [4, 5, 1, 2, 3, 3, 3],
        [3, 4, 5, 1, 2, 2, 2],
        [2, 3, 4, 5, 1, 1, 1],
        [1, 2, 3, 4, 5, 0, 0],
        [1, 2, 3, 4, 5, 5, 0]
    ]

    zero = timedelta(0)
    assert(zero <= start_bs_hour <= end_bs_hour <= timedelta(1))
    working_hours = end_bs_hour - start_bs_hour
    days = (_end_dt.date() - _start_dt.date()).days
    weeks = days // 7

    weekdays = weeks * 5 + extra[_start_dt.weekday()][_end_dt.weekday()]
    total = working_hours * weekdays

    if _start_dt.weekday() < 5:
        total -= _adjust_hour(_get_time_part(_start_dt) - start_bs_hour, zero, working_hours)
    if _end_dt.weekday() < 5:
        total -= _adjust_hour(end_bs_hour - _get_time_part(_end_dt), zero, working_hours)

    return total.total_seconds()


def timediff_include_weekends(_start_dt, _end_dt):
    result = _end_dt - _start_dt
    total = max(result.total_seconds(), 0)
    return total


if __name__ == '__main__':
    logger = Logger('feedback_tat_adv_job.py')
    logger.start_batch()

    try:
        start_dt, end_dt = args_util.parse_sys_argv('date', 2)
        FeedbackTatBatchJob(start_dt, end_dt).execute()

        logger.end_batch()

    except Exception as e:
        logger.error(str(e))
