SELECT branch_id, branch_name
FROM branch
ORDER BY branch_id