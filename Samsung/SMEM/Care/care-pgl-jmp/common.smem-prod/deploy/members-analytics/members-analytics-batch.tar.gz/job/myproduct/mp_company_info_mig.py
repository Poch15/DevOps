#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from common.base.base_batch_job import BaseBatchJob
from common.logger import func_logger, Logger
from utils import file_util
from common.base.reader import MysqlReader
from common.base.writer import PostgresqlWriter

read_sql = file_util.load_sql_in_cur_dir('sql', 'migration/ext_mp_company_info.sql')
write_sql = file_util.load_sql_in_cur_dir('sql', 'migration/ins_mp_company_info.sql')


class MpCompanyInfo(BaseBatchJob):

    def __init__(self, _start_dt, _end_dt):
        BaseBatchJob.__init__(self, _start_dt, _end_dt)
        self.reader = MysqlReader(read_sql)
        self.writer = PostgresqlWriter(write_sql)

        self.mp_list = list()

    @func_logger
    def do_read(self):
        self.mp_list = self.reader.read()

    @func_logger
    def do_process(self):
        None

    @func_logger
    def do_write(self):
        self.writer.write(self.mp_list)


if __name__ == '__main__':
    logger = Logger(__file__)
    logger.start_batch()

    try:
        MpCompanyInfo('2019-12-05', '2019-12-06').execute()

        logger.end_batch()

    except Exception as e:
        logger.error(str(e))

