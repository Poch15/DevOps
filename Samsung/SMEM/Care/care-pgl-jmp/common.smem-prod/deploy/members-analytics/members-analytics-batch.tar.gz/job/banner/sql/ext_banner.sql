SELECT date_trunc('day', timestamp)::date as date, branch_id, model, extra_info ->> 'BannerID' as banner_id, event_target_id, count(*) as cnt
FROM uldata2
WHERE
createdatetime >= '{start_dt}'
AND
createdatetime < '{end_dt}'
AND
page_id = 'SEP1'
AND
type = 'event'
AND
event_target_id IN ('EEP3', 'EEP333')
AND
extra_info IS NOT NULL
AND
extra_info ->> 'BannerID' != ''
GROUP BY date, event_target_id, branch_id, model, banner_id