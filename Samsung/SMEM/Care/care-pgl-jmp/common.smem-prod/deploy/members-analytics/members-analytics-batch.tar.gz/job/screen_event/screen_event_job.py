#!/usr/bin/python3
# -*- coding: utf-8 -*-

from pandas import DataFrame
from datetime import datetime

from common.base.base_batch_job import BaseBatchJob
from common.base.es_query import ElasticSearchQuery
from common.logger import func_logger, Logger
from utils import args_util, file_util
from common.base.reader import ElasticSearchReader
from common.base.writer import PostgresqlWriter


write_sql = file_util.load_sql_in_cur_dir('sql', 'ins_screen_event.sql')


class ScreenEventJob(BaseBatchJob):
    def __init__(self, _start_dt, _end_dt):
        BaseBatchJob.__init__(self, _start_dt, _end_dt)

        self.reader = ElasticSearchReader(es_query=ScreenEventESQuery())
        self.writer = PostgresqlWriter(write_sql)

        self.ret_rows = list()
        self.event_list = list()

    @func_logger
    def do_read(self):
        self.ret_rows = self.reader.read(self.date.get('start_dt'), self.date.get('end_dt'))

    @func_logger
    def do_process(self):
        df = DataFrame(self.ret_rows, columns=['date', 'branch_id', 'screen_id', 'event_id', 'cnt'])
        summary_df = df.groupby(['date', 'branch_id', 'screen_id', 'event_id'])['cnt'].sum()
        for index, count in zip(summary_df.index, summary_df.values):
            date, branch_id, screen_id, event_id = index
            self.event_list.append((date, branch_id, screen_id, event_id, int(count)))

    @func_logger
    def do_write(self):
        self.writer.write(self.event_list)


class ScreenEventESQuery(ElasticSearchQuery):
    @staticmethod
    def convert_list(_scroll_result):
        result_list = list()
        for _data in _scroll_result['hits']['hits']:
            branch_id = _data['_source'].get('branchId', None)
            page_id = _data['_source'].get('pageId', None)
            event_target_id = _data['_source'].get('eventTargetId', None)
            timestamp = _data['_source'].get('timestamp', None)

            timestamp = datetime.strptime(timestamp, "%Y-%m-%dT%H:%M:%S.%fZ").date()

            result_list.append((timestamp, int(branch_id), page_id, event_target_id, 1))

        return result_list

    @staticmethod
    def query(_start_dt, _end_dt, _param):
        return {
            "query": {
                "bool": {
                    "must": [
                        {
                            "exists": {
                                "field": "eventTargetId.keyword"
                            }
                        },
                        {
                            "match_phrase": {
                                "type.keyword": {
                                    "query": "event"
                                }
                            }
                        },
                        {
                            "range": {
                                "createTime": {
                                    "gte": _start_dt,
                                    "lt": _end_dt
                                }
                            }
                        }
                    ]
                }
            },
            "_source": ['timestamp', 'branchId', 'pageId', 'eventTargetId']
        }


if __name__ == '__main__':
    logger = Logger(__file__)
    logger.start_batch()

    try:
        start_dt, end_dt = args_util.parse_sys_argv('date', 2)
        ScreenEventJob(start_dt, end_dt).execute()
        logger.end_batch()
    except Exception as e:
        logger.error(str(e))
