from common.base.base_batch_job import BaseBatchJob
from common.logger import func_logger, Logger
from common.base.reader import PostgresqlReader
from common.base.writer import PostgresqlWriter
from utils import file_util, date_util
from datetime import datetime, timedelta


class FeedbackDashboardBatchJob(BaseBatchJob):
    def __init__(self, _start_dt, _end_dt):
        BaseBatchJob.__init__(self, _start_dt, _end_dt)

        self.end_dt = _end_dt
        self.reader = PostgresqlReader()
        self.writer = PostgresqlWriter()

        self.weekly_overview_data_list = []
        self.total_count_data_list = []

        self.logger = Logger(__file__)
        self.logger.start_batch()

    def __del__(self):
        BaseBatchJob.__del__(self)
        self.logger.end_batch()

    @func_logger
    def do_read(self):
        today = datetime.strptime(self.end_dt, '%Y-%m-%d')
        end_weekday = date_util.get_last_saturday(today)
        start_weekday = end_weekday - timedelta(days=90)

        sql = file_util.load_file(__file__, 'sql/dashboard/ext_dashboard_overview.sql')
        params = {'start_dt': start_weekday, 'end_dt': end_weekday}
        self.weekly_overview_data_list = self.reader.read(sql, params)

        sql = file_util.load_file(__file__, 'sql/dashboard/ext_dashboard_total_count.sql')
        self.total_count_data_list = self.reader.read(sql)

    @func_logger
    def do_process(self):
        pass

    @func_logger
    def do_write(self):
        # Delete
        sql = file_util.load_file(__file__, 'sql/dashboard/del_dashboard_feedback.sql')
        self.writer.query(sql)

        # Insert overview counts
        sql = file_util.load_file(__file__, 'sql/dashboard/ins_dashboard_overview.sql')
        self.writer.write(self.weekly_overview_data_list, sql)

        # Insert total counts
        sql = file_util.load_file(__file__, 'sql/dashboard/ins_dashboard_total_count.sql')
        self.writer.write(self.total_count_data_list, sql)
