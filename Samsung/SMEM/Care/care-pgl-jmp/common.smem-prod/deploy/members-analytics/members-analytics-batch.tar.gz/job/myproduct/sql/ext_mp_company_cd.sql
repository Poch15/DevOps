SELECT company_cd
FROM mp_gcic_product
WHERE guid = '{guid}' AND prd_id = {prd_id}