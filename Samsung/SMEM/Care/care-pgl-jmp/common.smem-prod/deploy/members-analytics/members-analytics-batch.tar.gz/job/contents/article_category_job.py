#!/usr/bin/python3
# -*- coding: utf-8 -*-


from common.base.base_batch_job import BaseBatchJob
from common.base.es_query import ElasticSearchQuery
from common.logger import func_logger, Logger
from utils import file_util
from common.base.reader import ElasticSearchReader
from common.base.writer import PostgresqlWriter
from datetime import datetime
from pandas import DataFrame


class ArticleCategoryBatchJob(BaseBatchJob):
    def __init__(self, _start_dt, _end_dt):
        BaseBatchJob.__init__(self, _start_dt, _end_dt)

        self.reader = ElasticSearchReader(es_query=ArticleCategoryESQuery())
        self.writer = PostgresqlWriter()

        self.ret_rows = list()
        self.summary_list = list()

        self.logger = Logger(__file__)
        self.logger.start_batch()

    def __del__(self):
        BaseBatchJob.__del__(self)
        self.logger.end_batch()

    @func_logger
    def do_read(self):
        self.ret_rows = self.reader.read(self.date.get('start_dt'), self.date.get('end_dt'))

    @func_logger
    def do_process(self):
        df = DataFrame(self.ret_rows, columns=['date', 'branch_id', 'model', 'category', 'cnt'])
        summary_df = df.groupby(['date', 'branch_id', 'model', 'category'])['cnt'].sum()
        for index, count in zip(summary_df.index, summary_df.values):
            date, branch_id, model, category = index
            self.summary_list.append((date, branch_id, model, category, int(count)))

    @func_logger
    def do_write(self):
        ins_add_sql = file_util.load_file(__file__, 'sql/article/ins_article_category.sql')
        self.writer.write(self.summary_list, ins_add_sql)


class ArticleCategoryESQuery(ElasticSearchQuery):
    @staticmethod
    def convert_list(_scroll_result):
        result_list = list()
        for _data in _scroll_result['hits']['hits']:
            branch_id = _data['_source'].get('branchId', None)
            model = _data['_source'].get('model', None)
            extra_info = _data['_source'].get('extraInfo', None)
            timestamp = _data['_source'].get('timestamp', None)

            timestamp = datetime.strptime(timestamp, "%Y-%m-%dT%H:%M:%S.%fZ").date()
            category = extra_info.get('filter', None)

            if category is not None:
                result_list.append((timestamp, int(branch_id), model, category, 1))

        return result_list

    @staticmethod
    def query(_start_dt, _end_dt, _param):
        return {
            "size": 5000,
            "query": {
                "bool": {
                    "must": [
                        {
                            "match_phrase": {
                                "type.keyword": {
                                    "query": "event"
                                }
                            }
                        },
                        {
                            "match_phrase": {
                                "pageId.keyword": {
                                    "query": "SNT1"
                                }
                            }
                        },
                        {
                            "bool": {
                                "should": [
                                    {
                                        "match_phrase": {
                                            "eventTargetId.keyword": "ENT3"
                                        }
                                    },
                                    {
                                        "match_phrase": {
                                            "eventTargetId.keyword": "ENT14"
                                        }
                                    }
                                ],
                                "minimum_should_match": 1
                            }
                        },
                        {
                            "exists": {
                                "field": "extraInfo.filter"
                            }
                        },
                        {
                            "range": {
                                "createTime": {
                                    "gte": _start_dt,
                                    "lt": _end_dt
                                }
                            }
                        }
                    ]
                }
            },
            "_source": ['timestamp', 'branchId', 'model', 'extraInfo']
        }
