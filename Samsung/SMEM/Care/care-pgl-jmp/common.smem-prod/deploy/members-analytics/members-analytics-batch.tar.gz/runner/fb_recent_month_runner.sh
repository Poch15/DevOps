#!/bin/bash

BASE_PYTHON_PATH='/home/common/members-analytics/members-analytics-batch'
source ${BASE_PYTHON_PATH}/.venv/bin/activate
export PYTHONPATH=${BASE_PYTHON_PATH}/fb_recent_month

export cur_datetime="$(date +%Y-%m-%dT%H:%M:%S)"
python3 /home/common/members-analytics/members-analytics-batch/fb_recent_month/job/fb_recent_month/fb_recent_month_job.py $cur_datetime