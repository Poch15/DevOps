SELECT date, {source} as source, '{branch_name}' as branch_name, keyword_idx, sum(cnt) as cnt, '{period}' as period
FROM v3_keyword
  WHERE
    date >= '{start_date}'
  AND
    date < '{end_date}'
  AND
    source = {source}
  AND
    branch_id IN {branch_ids}
  AND
    keyword_idx IN {keyword_idx_list}
GROUP BY date, keyword_idx
ORDER BY date