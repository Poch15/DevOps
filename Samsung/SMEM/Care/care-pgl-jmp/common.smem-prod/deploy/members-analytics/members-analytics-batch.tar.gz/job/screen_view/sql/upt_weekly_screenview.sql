ON CONFLICT ON CONSTRAINT v3_screenview_weekly_unique
DO UPDATE SET cnt = v3_screenview_weekly.cnt + EXCLUDED.cnt;