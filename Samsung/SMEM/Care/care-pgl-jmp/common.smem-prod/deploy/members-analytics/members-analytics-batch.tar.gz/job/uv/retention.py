#!/usr/bin/python3
# -*- coding: utf-8 -*-

from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta
from common.base.base_batch_job import BaseBatchJob
from common.logger import func_logger, Logger
from common.base.writer import PostgresqlWriter
from utils import file_util, date_util, s3_util, args_util
from config.loader import load_config
from io import StringIO
import pandas as pd
import botocore


class RetentionJob(BaseBatchJob):
    def __init__(self, _start_dt, _end_dt):
        BaseBatchJob.__init__(self, _start_dt, _end_dt)

        self.s3_client = None
        self.bucket_name = None

        self.weekly_ret_date = None
        self.monthly_ret_date = None

        self.writer = PostgresqlWriter()
        self.start_dt = _start_dt
        self.end_dt = _end_dt

    @func_logger
    def do_read(self):
        aws_config = load_config().get('aws')

        self.bucket_name = aws_config.get('s3').get('bucket')
        self.s3_client = s3_util.get_client()
        s3_util.disable_unused_log()

    @staticmethod
    def __get_s3_obj_path(dt):
        file_name = 'uniqueuser_{0}_{1}_{2}.csv'.format(
            dt.strftime("%Y"), dt.strftime("%m"), dt.strftime("%d"))

        s3_obj_path = "{0}/{1}/{2}/{3}".format(
            "uv/unique_user",
            "year=" + str(dt.year),
            "month=" + str(dt.month),
            file_name)

        return s3_obj_path

    @staticmethod
    def __get_unique_monthly_from_s3_obj_path(dt):
        file_name = 'uniqueuser_monthly_{0}_{1}.csv'.format(dt.strftime("%Y"), dt.strftime("%m"))

        s3_obj_path = "{0}/{1}/{2}".format(
            "uv/unique_user_monthly",
            "year=" + str(dt.year),
            file_name)

        return s3_obj_path

    @func_logger
    def do_process(self):
        self.__do_process_daily()

        # saturday
        if self.start_dt.weekday() == 5:
            self.__do_process_weekly()

        # last day of month
        if (self.start_dt + timedelta(days=1)).day == 1:
            self.__do_process_monthly()

    @func_logger
    def __do_process_daily(self):
        daily_summary_list = list()

        base_dt = ret_dt = self.start_dt
        end_base_dt = base_dt - timedelta(days=14)

        ret_df = self.__get_unique_guid_branch_dataframe(ret_dt, ret_dt)

        while base_dt >= end_base_dt:
            base_df = self.__get_unique_guid_branch_dataframe(base_dt, base_dt)

            merge_df = pd.merge(base_df, ret_df, how='inner', on=['members_id', 'branch_id'])
            cnt_by_country = merge_df.groupby('branch_id')['members_id'].count()

            for index, item in cnt_by_country.iteritems():
                daily_summary_list.append((base_dt, ret_dt, int(index), int(item)))

            base_dt = base_dt - timedelta(days=1)

        # write daily retention
        ins_retention_sql = file_util.load_file(__file__, 'sql/retention/ins_retention_daily.sql')
        self.writer.write(daily_summary_list, ins_retention_sql)

    @func_logger
    def __do_process_weekly(self):
        weekly_summary_list = list()

        base_end_dt = ret_end_dt = self.start_dt

        base_start_dt = ret_start_dt = date_util.get_last_sunday(ret_end_dt)
        finish_base_start_dt = base_start_dt - timedelta(weeks=14)
        self.weekly_ret_date = ret_start_dt

        ret_df = self.__get_unique_guid_branch_dataframe(ret_start_dt, ret_end_dt)
        while base_start_dt >= finish_base_start_dt:
            if base_start_dt == ret_start_dt:
                base_df = ret_df
            else:
                base_df = self.__get_unique_guid_branch_dataframe(base_start_dt, base_end_dt)

            merge_df = pd.merge(base_df, ret_df, how='inner', on=['members_id', 'branch_id'])
            cnt_by_country = merge_df.groupby('branch_id')['members_id'].count()

            for index, item in cnt_by_country.iteritems():
                weekly_summary_list.append((base_start_dt, ret_start_dt, int(index), int(item)))

            base_start_dt = base_start_dt - timedelta(days=7)
            base_end_dt = base_start_dt + timedelta(days=6)

        # delete and write weekly retention
        del_retention_weekly_sql = file_util.load_file(__file__, 'sql/retention/del_retention_weekly.sql')
        ins_retention_weekly_sql = file_util.load_file(__file__, 'sql/retention/ins_retention_weekly.sql')

        params = {'ret_date': self.weekly_ret_date}
        self.writer.query(del_retention_weekly_sql, params)
        self.writer.write(weekly_summary_list, ins_retention_weekly_sql)

    @func_logger
    def __do_process_monthly(self):
        monthly_summary_list = list()

        ret_end_dt = self.start_dt

        base_start_dt = ret_start_dt = date_util.get_first_day_month(ret_end_dt)
        finish_base_start_dt = base_start_dt - relativedelta(months=14)
        self.monthly_ret_date = ret_start_dt

        ret_df = self.__get_unique_guid_branch_dataframe(ret_start_dt, ret_end_dt)

        self.__upload_unique_monthly_data_to_s3(ret_df)

        while base_start_dt >= finish_base_start_dt:
            if base_start_dt == ret_start_dt:
                base_df = ret_df
            else:
                del base_df
                base_df = self.__get_unique_monthly_guid(base_start_dt)

            merge_df = pd.merge(base_df, ret_df, how='inner', on=['members_id', 'branch_id'])
            cnt_by_country = merge_df.groupby('branch_id')['members_id'].count()

            for index, item in cnt_by_country.iteritems():
                monthly_summary_list.append((base_start_dt, ret_start_dt, int(index), int(item)))

            base_start_dt = base_start_dt - relativedelta(months=1)

        # delete and write monthly retention
        del_retention_monthly_sql = file_util.load_file(__file__, 'sql/retention/del_retention_monthly.sql')
        ins_retention_monthly_sql = file_util.load_file(__file__, 'sql/retention/ins_retention_monthly.sql')

        params = {'ret_date': self.monthly_ret_date}
        self.writer.query(del_retention_monthly_sql, params)
        self.writer.write(monthly_summary_list, ins_retention_monthly_sql)

    def __get_unique_guid_branch_dataframe(self, _std_dt, _end_dt):
        ret_df = pd.DataFrame(columns=['members_id', 'branch_id'])
        cur_dt = _std_dt
        while cur_dt <= _end_dt:
            try:
                key = RetentionJob.__get_s3_obj_path(cur_dt)
                obj = self.s3_client.get_object(Bucket=self.bucket_name, Key=key)
                df_origin = pd.read_csv(obj['Body'])
                df = df_origin[['members_id', 'branch_id']].drop_duplicates()

                ret_df = ret_df.append(df)
                ret_df.drop_duplicates(inplace=True)
            except botocore.exceptions.ClientError:
                print("S3 key does not exist! ", " KEY : ", key)
                break

            cur_dt += timedelta(days=1)

        return ret_df

    def __get_unique_monthly_guid(self, _std_dt):
        ret_df = pd.DataFrame(columns=['members_id', 'branch_id'])

        try:
            key = RetentionJob.__get_unique_monthly_from_s3_obj_path(_std_dt)
            obj = self.s3_client.get_object(Bucket=self.bucket_name, Key=key)
            df_origin = pd.read_csv(obj['Body'])
            df = df_origin[['members_id', 'branch_id']].drop_duplicates()

            ret_df = ret_df.append(df)
            ret_df.drop_duplicates(inplace=True)
        except botocore.exceptions.ClientError:
            print("S3 key does not exist! ", " KEY : ", key)

        return ret_df

    @func_logger
    def __upload_unique_monthly_data_to_s3(self, _monthly_df):
        file_name = 'uniqueuser_monthly_{0}_{1}.csv'.format(self.start_dt.strftime("%Y"), self.start_dt.strftime("%m"))

        csv_buffer = StringIO()
        _monthly_df.to_csv(csv_buffer, sep=",", index=False)

        aws_config = load_config().get('aws')
        s3_client = s3_util.get_client()

        bucket_name = aws_config.get('s3').get('bucket')

        s3_obj_path = "{0}/{1}/{2}".format(
            "uv/unique_user_monthly",
            "year=" + str(self.start_dt.year),
            file_name)

        s3_util.put_object(s3_client, bucket_name, csv_buffer.getvalue(), s3_obj_path)

    @func_logger
    def do_write(self):
        pass
