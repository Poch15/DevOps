SELECT keyword, SUM(cnt) as count
FROM
  (
    SELECT keyword, cnt
    FROM tbl_v2_keyword
      WHERE
        datetime >= '{start_date}'
      AND
        datetime < '{end_date}'::timestamp + INTERVAL '1' DAY
      AND
        branch_id IN {branch_ids}
  ) AS A
GROUP BY keyword
ORDER BY COUNT DESC, keyword
LIMIT 10 OFFSET 0