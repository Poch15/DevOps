SELECT B.keyword, B.id, A.cnt1
FROM v3_keyword_dict as B
INNER JOIN
(
    SELECT keyword_idx, sum(cnt) as cnt1
    FROM v3_keyword
      WHERE
        date >= '{start_date}'
      AND
        date < '{end_date}'
      AND 
        source = {source}
      AND
        branch_id IN {branch_ids}
    GROUP BY keyword_idx
    ORDER BY cnt1 desc
    LIMIT 100
) AS A 
ON B.id = A.keyword_idx