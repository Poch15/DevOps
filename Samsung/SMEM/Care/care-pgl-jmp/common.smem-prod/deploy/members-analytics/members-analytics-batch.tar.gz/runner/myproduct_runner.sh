#!/bin/bash

BASE_PYTHON_PATH='/home/common/members-analytics/members-analytics-batch'
source ${BASE_PYTHON_PATH}/.venv/bin/activate
export PYTHONPATH=${BASE_PYTHON_PATH}/myproduct

export from="$(date --date="1 days ago" +%Y-%m-%d)"
export to="$(date +%Y-%m-%d)"
python3 /home/common/members-analytics/members-analytics-batch/myproduct/job/myproduct/myproduct_job.py $from $to