#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import abc
import psycopg2 as postgresdb
import pymysql as mysqldb
from config.loader import load_config
from config.credential import Credential


class DBManager(metaclass=abc.ABCMeta):
    """ DB Manager connecting database and execute query """

    def __init__(self):
        self.db_conn = None
        self.db_cur = None
        self.credential = Credential()

    def query_with_results(self, query, params=None):
        if params is None:
            params = {}

        self.db_cur.execute(query.format(**params))
        return self.db_cur.fetchall()

    def query_with_commit(self, query, params=None):
        if params is None:
            params = {}

        self.db_cur.execute(query.format(**params))
        self.db_conn.commit()

    def close(self):
        self.db_cur.close()
        self.db_conn.close()

    @abc.abstractmethod
    def insert_bulk(self, insert_query, param_list, update_query=''):
        pass


class MysqlManager(DBManager):

    def __init__(self):
        super().__init__()
        config = load_config().get('mysql')

        self.db_conn = mysqldb.connect(
            port=int(config['port']),
            host=config['host'],
            user=self.credential.get_mysql_user(),
            passwd=self.credential.get_mysql_password(),
            db=config['db'])

        self.db_cur = self.db_conn.cursor()

    def insert_bulk(self, insert_query, param_list, update_query=''):
        if len(param_list) > 0:
            param_text = ','.join(str(row) for row in param_list)
            self.db_cur.execute(insert_query + param_text + update_query)
        self.db_conn.commit()


class PostgresqlManager(DBManager):

    def __init__(self, env=None):
        super().__init__()
        if env is None:
            env = 'postgresql'
        config = load_config().get(env)
        self.db_conn = postgresdb.connect(
            port=int(config['port']),
            host=config['host'],
            user=self.credential.get_postgresql_user(),
            password=self.credential.get_postgresql_password(),
            dbname=config['db'])

        self.db_cur = self.db_conn.cursor()

    def get_cursor(self):
        return self.db_cur

    def insert_bulk(self, insert_query, param_list, update_query=''):
        if len(param_list) > 0:
            format_str = '(' + ('%s,' * len(param_list[0]))[:-1] + ')'

            param_text = ','.join(
                self.db_cur.mogrify(format_str, row).decode('utf-8') for row in param_list)
            self.db_cur.execute(insert_query + param_text + update_query)

        self.db_conn.commit()
