#!/usr/bin/python3
# -*- coding: utf-8 -*-

import hashlib
import base64
from Crypto.Cipher import AES

MEMBERS_CRYPTO_KEY = 'E456D5BDAVCDEF4F'


def __pad(string):
    return string + (16 - len(string) % 16) * chr(16 - len(string) % 16).encode()


def __unpad(string):
    return string[:-ord(string[len(string) - 1:])]


def __java_string_hashcode(s):
    h = 0
    for c in s:
        h = (31 * h + ord(c)) & 0xFFFFFFFF
    return ((h + 0x80000000) & 0xFFFFFFFF) - 0x80000000


def __digits(val, digit):
    hi = 1 << (digit * 4)
    return hex(hi | (val & (hi - 1)))[3:3+digit]


def __uuid(msb, lsb):
    return (__digits(msb >> 32, 8) + "-" +
            __digits(msb >> 16, 4) + "-" +
            __digits(msb, 4) + "-" +
            __digits(lsb >> 48, 4) + "-" +
            __digits(lsb, 12))


def hash_imei(original_imei):
    msb = 0
    lsb = (__java_string_hashcode(original_imei) << 32 | 0)
    return __uuid(msb, lsb)[19:28]


def encode_sha256(input_string):
    sha256 = hashlib.sha256()
    sha256.update(input_string)
    digest = sha256.digest()
    return base64.encodebytes(digest).replace("=", "")


def encrypt_aes128(plain_text, key=MEMBERS_CRYPTO_KEY):
    plain_text = __pad(plain_text.encode())
    aes128 = AES.new(key.encode(), AES.MODE_CBC, key.encode())
    encrypt_text = aes128.encrypt(plain_text)
    return base64.encodebytes(encrypt_text)


def decrypt_aes128(encrypt_text, key=MEMBERS_CRYPTO_KEY):
    encrypt_text = base64.decodebytes(encrypt_text)
    aes128 = AES.new(key.encode(), AES.MODE_CBC, key.encode())
    decrypt_text = aes128.decrypt(encrypt_text)
    decrypt_text = decrypt_text.decode()
    return __unpad(decrypt_text)
