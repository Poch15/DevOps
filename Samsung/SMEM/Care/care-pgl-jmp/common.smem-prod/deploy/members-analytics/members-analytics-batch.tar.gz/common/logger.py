#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import time
import logging
import os
from config.loader import load_config
from collections import Iterable


def func_logger(func):

    def _wrapper(*args, **kwargs):
        _start = time.time()
        result = func(*args, **kwargs)
        exec_time = " (execution time : " + str(
            round(time.time() - _start, 2)) + ") "
        if isinstance(result, Iterable):
            return_data = " (return length : " + str(len(result)) + ") "
        elif result is None:
            return_data = ""
        else:
            return_data = " (return : " + str(result) + ") "

        logging.info(func.__name__ + exec_time + return_data)

        return result

    return _wrapper


class Logger:
    def __init__(self, __file):
        self.start_time = time.time()
        self.job_file = os.path.basename(__file)
        self.logger = logging.getLogger()

        logfile_name = '{0}.log'.format(self.job_file.rpartition('.')[0])
        logfile_dir = load_config().get('log').get('path')
        if not os.path.exists(logfile_dir):
            os.makedirs(logfile_dir)
        logfile_path = os.path.join(logfile_dir, logfile_name)

        file_handler = logging.FileHandler(logfile_path)
        formatter = logging.Formatter(
            '%(asctime)s %(levelname)s - %(message)s')
        file_handler.setFormatter(formatter)

        self.logger.addHandler(file_handler)
        self.logger.setLevel(logging.DEBUG)

    def info(self, message):
        self.logger.info(message)

    def error(self, message):
        self.logger.error(message)

    def debug(self, message):
        self.logger.debug(message)

    def warn(self, message):
        self.logger.warning(message)

    def start_batch(self):
        self.info('Start Batch (' + self.job_file + ')')

    def end_batch(self):
        self.execute_time()
        self.info('End Batch')

    def execute_time(self):
        exec_time = ' (total execution time: ' + str(
            round(time.time() - self.start_time, 2)) + ')'
        self.info("Successfully finished " + self.job_file + exec_time)
