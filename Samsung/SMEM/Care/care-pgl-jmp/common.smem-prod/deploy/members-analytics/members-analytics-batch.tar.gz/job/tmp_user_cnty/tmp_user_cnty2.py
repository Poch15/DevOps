#!/usr/bin/python3
# -*- coding: utf-8 -*-

from common.base.base_batch_job import BaseBatchJob
from common.logger import func_logger, Logger
from utils import file_util
from common.base.reader import MysqlReader
from common.base.writer import PostgresqlWriter


class CountryUpdater(BaseBatchJob):
    def __init__(self, _start_dt, _end_dt):
        BaseBatchJob.__init__(self, _start_dt, _end_dt)
        self.start_dt = _start_dt
        self.end_dt = _end_dt
        self.csc_cnty_list = []
        self.mcc_cnty_list = []

        self.reader = MysqlReader()
        self.writer = PostgresqlWriter()

    @func_logger
    def do_read(self):
        csc_country_sql = file_util.load_file(__file__, 'sql/ext_csc_country.sql')
        mcc_country_sql = file_util.load_file(__file__, 'sql/ext_mcc_country.sql')
        self.csc_cnty_list = self.reader.read(csc_country_sql)
        self.mcc_cnty_list = self.reader.read(mcc_country_sql)

    @func_logger
    def do_process(self):
        pass

    @func_logger
    def do_write(self):
        upt_csc_cnty_sql = file_util.load_file(__file__, 'sql/upt_csc_country.sql')
        upt_mcc_cnty_sql = file_util.load_file(__file__, 'sql/upt_mcc_country.sql')

        for row in self.csc_cnty_list:
            csc, cnty = row
            params = {'csc_country': cnty, 'csc': csc}
            self.writer.query(upt_csc_cnty_sql, params)

        for row in self.mcc_cnty_list:
            mcc, cnty = row
            params = {'mcc_country': cnty, 'mcc': mcc}
            self.writer.query(upt_mcc_cnty_sql, params)


if __name__ == '__main__':
    logger = Logger(__file__)
    logger.start_batch()

    try:
        CountryUpdater('2019-01-01', '2019-01-02').execute()
        logger.end_batch()

    except Exception as e:
        logger.error(str(e))
