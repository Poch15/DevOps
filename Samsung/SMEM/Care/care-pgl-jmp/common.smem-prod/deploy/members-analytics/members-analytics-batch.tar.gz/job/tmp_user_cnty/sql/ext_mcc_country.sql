SELECT mcc, cnty_cd
FROM mcc