INSERT INTO tbl_v2_fb_recent_month(fb_id, crt_dt, mdf_dt, branch_id, main_type, sub_type,
 beta_prj_id, fb_status, deleted, app_id, cat_id) VALUES