#!/usr/bin/python3
# -*- coding: utf-8 -*-

from datetime import datetime, timedelta
from common.base.base_batch_job import BaseBatchJob
from common.logger import func_logger, Logger
from utils import args_util, file_util, cryptosecurity, s3_util
from common.base.writer import PostgresqlWriter
from job.uv.uv_date_utils import UvDateUtil
from job.uv.uv_drilldown_job import UvDrillDownJob
from job.uv.retention import RetentionJob
from io import StringIO
from config.loader import load_config
import job.uv.helper as helper
import pandas as pd


class UvJob(BaseBatchJob):
    def __init__(self, _start_dt, _end_dt):
        BaseBatchJob.__init__(self, _start_dt, _end_dt)
        self.uv_date_util = UvDateUtil(_end_dt)
        self.start_dt = _start_dt
        self.end_dt = _end_dt

        self.daily_uv_df = None
        self.daily_uv_list = []
        self.summary_list = []
        self.summary_dvc_list = []

        self.writer = PostgresqlWriter()

    @func_logger
    def do_read(self):
        last_access_list = helper.get_raw_data(self.start_dt, self.end_dt, 'UV')
        for last_access in last_access_list:
            members_id, guid, branch_id, model, serial, country, dt = last_access
            encrypt_serial = cryptosecurity.encrypt_aes128(serial).decode().rstrip('\n')
            self.daily_uv_list.append((members_id, guid, branch_id, model, encrypt_serial, country, dt))

    @func_logger
    def do_process(self):
        self.__delete_last_month_access_log()

        self.daily_uv_df = pd.DataFrame(data=self.daily_uv_list,
                                        columns=['members_id', 'guid', 'branch_id', 'model', 'serial', 'country', 'dt'])

        # summary daily uv
        summary_uv_df = self.daily_uv_df.drop_duplicates(['members_id', 'branch_id']).groupby('branch_id').count()
        for index, count in zip(summary_uv_df.index, summary_uv_df.values):
            self.summary_list.append((self.start_dt, int(index), int(count[0])))

        # summary daily uv device
        summary_uv_dvc_df = self.daily_uv_df.drop_duplicates(['members_id', 'branch_id', 'model', 'serial']). \
            groupby(['branch_id', 'model']).count()
        for index, count in zip(summary_uv_dvc_df.index, summary_uv_dvc_df.values):
            self.summary_dvc_list.append((self.start_dt, int(index[0]), index[1], int(count[0])))

    @func_logger
    def do_write(self):
        # write summary daily uv
        ins_uv_sql = file_util.load_file(__file__, 'sql/ins_daily_uv.sql')
        self.writer.write(self.summary_list, ins_uv_sql)

        # write summary daily uv device
        ins_uv_dvc_sql = file_util.load_file(__file__, 'sql/ins_daily_uv_dvc.sql')
        self.writer.write(self.summary_dvc_list, ins_uv_dvc_sql)

        # write recent hour log
        uv_list = self.daily_uv_df.drop(['guid', 'country'], axis=1).drop_duplicates().values.tolist()

        ins_log_sql = file_util.load_file(__file__, 'sql/ins_access_log.sql')
        upt_log_sql = file_util.load_file(__file__, 'sql/upt_access_log.sql')
        self.writer.write(uv_list, ins_log_sql, upt_log_sql)

        # calculate weekly, monthly uv
        self.__calc_uv(self.end_dt)

        # write daily unique data to s3
        self.__upload_unique_raw_data_to_s3()

    @func_logger
    def __delete_last_month_access_log(self):
        if self.uv_date_util.is_delete_datetime():
            start_datetime, end_datetime = self.uv_date_util.get_uv_delete_start_end_datetime()
            params = {'start_datetime': start_datetime, 'end_datetime': end_datetime}

            del_sql = file_util.load_file(__file__, 'sql/del_access_log.sql')
            self.writer.query(del_sql, params)

    @func_logger
    def __calc_uv(self, _cur_dt):
        """
            calculate daily unique visitor, weekly unique visitor, monthly unique visitor functions
            by calling postgres function
        """
        params = {'cur_datetime': _cur_dt}
        uv_sql = file_util.load_file(__file__, 'sql/calc_uv.sql')
        self.writer.query(uv_sql, params)

    @func_logger
    def __upload_unique_raw_data_to_s3(self):
        file_name = 'uniqueuser_{0}_{1}_{2}.csv'.format(
            self.start_dt.strftime("%Y"), self.start_dt.strftime("%m"), self.start_dt.strftime("%d"))

        df = self.daily_uv_df
        df.drop('dt', axis=1, inplace=True)

        csv_buffer = StringIO()
        df.to_csv(csv_buffer, sep=",", index=False)

        aws_config = load_config().get('aws')
        s3_client = s3_util.get_client()

        bucket_name = aws_config.get('s3').get('bucket')

        s3_obj_path = "{0}/{1}/{2}/{3}".format(
            "uv/unique_user",
            "year=" + str(self.start_dt.year),
            "month=" + str(self.start_dt.month),
            file_name)

        s3_util.put_object(s3_client, bucket_name, csv_buffer.getvalue(), s3_obj_path)


if __name__ == '__main__':
    logger = Logger(__file__)
    logger.start_batch()

    try:
        str_cur_date = args_util.parse_sys_argv('date', 1)
        _cur_datetime = datetime.strptime(str_cur_date, '%Y-%m-%d')
        end_dt = _cur_datetime.replace(hour=0, minute=0, second=0, microsecond=0, tzinfo=None)
        start_dt = end_dt - timedelta(days=1)

        UvJob(start_dt, end_dt).execute()
        logger.end_batch()

        UvDrillDownJob(start_dt, end_dt).execute()
        RetentionJob(start_dt, end_dt).execute()

    except Exception as e:
        logger.error(str(e))
