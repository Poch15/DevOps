#!/usr/bin/python3
# -*- coding: utf-8 -*-

from datetime import datetime, timedelta


def get_last_saturday(today):
    if today.isoweekday() == 6:
        last_saturday = today
    else:
        last_saturday = today - timedelta(days=(today.isoweekday() % 7 + 1))

    return last_saturday


def get_last_sunday(today):
    if today.isoweekday() == 7:
        last_sunday = today
    else:
        last_sunday = today - timedelta(days=(today.isoweekday() % 7))
    return last_sunday


def get_first_day_month(today):
    return today.replace(day=1)
