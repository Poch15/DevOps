INSERT INTO v3_diagnosis_auto_detail
  (datetime, branch_id, model, cat_id, result, cnt)
VALUES