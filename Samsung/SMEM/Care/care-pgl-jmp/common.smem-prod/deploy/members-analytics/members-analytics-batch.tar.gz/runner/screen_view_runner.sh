#!/bin/bash

BASE_PYTHON_PATH='/home/common/members-analytics/members-analytics-batch'
source ${BASE_PYTHON_PATH}/.venv/bin/activate
export PYTHONPATH=${BASE_PYTHON_PATH}/screen_view

export from="$(date --date="1 days ago" +%Y-%m-%d)"
export to="$(date +%Y-%m-%d)"
python3 /home/common/members-analytics/members-analytics-batch/screen_view/job/screen_view/screen_view_job.py $from $to