SELECT DATE_TRUNC('day', crt_dt)::DATE AS date, article_id, branch_id,
SUM(CASE WHEN hist_type = 0 THEN 1 ELSE 0 END) AS add_cnt,
SUM(CASE WHEN hist_type = 1 THEN 1 ELSE 0 END) AS del_cnt
FROM src_article_like_hist
WHERE
crt_dt >= '{start_dt}'
AND
crt_dt < '{end_dt}'
GROUP BY date, article_id, branch_id