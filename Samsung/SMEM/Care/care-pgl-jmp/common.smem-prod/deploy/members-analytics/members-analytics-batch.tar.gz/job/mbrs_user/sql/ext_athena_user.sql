SELECT user_id, branch_id, mcc, csc, min(createdatetime) as min_crt_dt
from {0}
where year = {1} and month = {2} and day = {3} and user_id is not null
group by user_id, branch_id, mcc, csc
order by min_crt_dt