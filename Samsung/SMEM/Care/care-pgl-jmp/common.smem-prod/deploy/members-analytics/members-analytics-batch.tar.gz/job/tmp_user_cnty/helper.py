#!/usr/bin/python3
# -*- coding: utf-8 -*-

import time
from datetime import timedelta

from utils import elasticsearch_util


def get_raw_data(_start_dt, _end_dt):
    elasticsearch_util.disable_unused_log()
    es_connection = elasticsearch_util.get_connection()

    index = elasticsearch_util.API_SUCCESS_INDEX
    request_body = __get_api_access_log_query_body(_start_dt, _end_dt)

    scroll_info = elasticsearch_util.set_search_scroll(es_connection, index, request_body)
    ud_list = __get_raw_data_scroll(es_connection, scroll_info)

    # fill current datetime in hourly uv

    return ud_list


def __get_raw_data_scroll(_es_connection, scroll_info):

    sid = scroll_info['_scroll_id']
    scroll_size = scroll_info['hits']['total']
    ret_set = set()

    # get all scroll
    while scroll_size > 0:
        scroll_result = elasticsearch_util.get_search_scroll_result(_es_connection, sid)

        # Update the scroll ID
        sid = scroll_result['_scroll_id']
        # Get the number of results that we returned in the last scroll
        scroll_size = len(scroll_result['hits']['hits'])
        if scroll_size < 0:
            continue

        ret_set = ret_set.union(__convert_set(scroll_result))

    return list(ret_set)


def __convert_set(scroll_result):

    ud_set = set()
    for _data in scroll_result['hits']['hits']:
        guid = _data['_source'].get('guid', None)
        csc = _data['_source'].get('cscCode', None)
        mcc = _data['_source'].get('mccCode', None)
        country = _data['_source'].get('country', None)

        if not guid or not csc or not mcc or not country:
            continue

        ud_set.add((guid, csc, mcc, country))

    return ud_set


def __get_api_access_log_query_body(start_datetime, end_datetime):
    return {
        "query": {
            "bool": {
                "must": [
                    {"exists": {"field": "guid"}},
                    {"exists": {"field": "cscCode"}},
                    {"exists": {"field": "mccCode"}},
                    {"exists": {"field": "country"}},
                    {"match_phrase": {"apiUri.keyword": {"query": "GET /configuration"}}}
                ],
                "must_not": [
                    {"term": {"guid": ""}},
                    {"term": {"cscCode": ""}},
                    {"term": {"mccCode": ""}}
                ],
                "filter": [
                    {
                        "range": {
                            "@timestamp": {
                                "gte": start_datetime,
                                "lt": end_datetime
                            }
                        }
                    }
                ]
            }
        },
        "_source": ['guid', 'cscCode', 'mccCode', 'country']
    }


def __datetime_to_unixtimestamp(_datetime):
    utc_offset = (-1) * (time.timezone / 3600)
    _datetime = _datetime + timedelta(hours=utc_offset)
    return (time.mktime(_datetime.timetuple()) * 1000) + int(_datetime.time().microsecond)
