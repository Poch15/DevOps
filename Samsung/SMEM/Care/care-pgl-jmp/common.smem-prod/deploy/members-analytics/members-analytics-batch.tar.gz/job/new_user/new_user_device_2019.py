#!/usr/bin/python3
# -*- coding: utf-8 -*-

from common.base.base_batch_job import BaseBatchJob
from common.base.reader import MysqlReader
from common.base.writer import PostgresqlWriter
from common.logger import func_logger, Logger
from utils import args_util, file_util
from job.new_user.user_partition import UserPartition
from datetime import datetime, timedelta

from pandas import DataFrame

read_sql1 = file_util.load_sql_in_cur_dir('sql', 'ext_new_user_device1.sql')
read_sql2 = file_util.load_sql_in_cur_dir('sql', 'ext_new_user_device2.sql')
write_sql = file_util.load_sql_in_cur_dir('sql', 'ins_new_user_device_2019.sql')


class NewUserDeviceBatchJob(BaseBatchJob):

    def __init__(self, _start_dt, _end_dt):
        BaseBatchJob.__init__(self, _start_dt, _end_dt)

        self.reader1 = MysqlReader(read_sql1)
        self.reader2 = MysqlReader(read_sql2)
        self.writer = PostgresqlWriter(write_sql)

        self.summary_list = []

    @func_logger
    def do_read(self):
        params = self.date.copy()

        for i in range(UserPartition.START, UserPartition.END):
            params.update({'part_name': UserPartition.get_partition_name(i)})
            result = self.reader1.read(param=params)
            self.summary_list.extend(result)

        for i in range(UserPartition.START, UserPartition.END):
            params.update({'part_name': UserPartition.get_partition_name(i)})
            result = self.reader2.read(param=params)
            self.summary_list.extend(result)

    @func_logger
    def do_process(self):
        summary_df = DataFrame(
            data=self.summary_list,
            columns=['dt', 'branch_id', 'model', 'cnt']
        )

        result = summary_df.groupby(['dt', 'branch_id', 'model']).sum()

        total_summary_list = []
        for index, cnt in zip(result.index, result.values):
            total_summary_list.append(
                (str(index[0]), int(index[1]), str(index[2]), int(cnt)))

        self.summary_list = total_summary_list

    @func_logger
    def do_write(self):
        self.writer.write(self.summary_list)


if __name__ == '__main__':
    logger = Logger(__file__)
    logger.start_batch()

    try:
        # start_datetime <= batch < end_datetime
        start_datetime = datetime(2019, 1, 1, 0, 0, 0, 0, None)
        end_datetime = datetime(2020, 1, 1, 0, 0, 0, 0, None)

        print(str(start_datetime) + "  /  " + str(end_datetime))

        cur_datetime = start_datetime
        while cur_datetime < end_datetime:
            str_cur_datetime = cur_datetime.strftime('%Y-%m-%dT%H:%M:%S')
            str_end_datetime = (cur_datetime + timedelta(days=1)).strftime('%Y-%m-%dT%H:%M:%S')

            NewUserDeviceBatchJob(str_cur_datetime, str_end_datetime).execute()
            print(str(cur_datetime) + '  complete')

            cur_datetime = cur_datetime + timedelta(days=1)

        logger.end_batch()

    except Exception as e:
        logger.error(str(e))
