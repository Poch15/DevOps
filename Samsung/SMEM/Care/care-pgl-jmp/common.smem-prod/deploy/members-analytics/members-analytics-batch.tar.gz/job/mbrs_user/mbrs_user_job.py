#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from common.logger import Logger
from utils import s3_util
from config.loader import load_config
from common.db_manager import MysqlManager
from utils import args_util, file_util, athena_util
import datetime
import time
import csv

ext_mbrs_user_sql = file_util.load_sql_in_cur_dir('sql', 'ext_mbrs_user.sql')
ext_athena_sql = file_util.load_sql_in_cur_dir('sql', 'ext_athena_user.sql')


def run_query(query, context, bucket_name, log_path):
    athena_response = athena_client.start_query_execution(
        QueryString=query,
        QueryExecutionContext=context,
        ResultConfiguration={
            'OutputLocation': 's3://' + bucket_name + log_path
        }
    )
    logger.info('Execution ID : ' + athena_response['QueryExecutionId'])
    return athena_response


if __name__ == '__main__':
    logger = Logger(__file__)
    try:
        start_dt, end_dt = args_util.parse_sys_argv('date', 2)
        start_date = datetime.datetime.strptime(start_dt, "%Y-%m-%d").date()
        logger.info("extract mbrs_user date : {0}".format(str(start_dt)))

        aws_config = load_config().get('aws')
        s3_client = s3_util.get_client()
        bucket_name = aws_config.get('s3').get('bucket')

        athena_client = athena_util.get_client()
        log_path = aws_config.get('athena').get('log')
        db = aws_config.get('athena').get('db')
        table = aws_config.get('athena').get('table')

        ext_athena_sql = ext_athena_sql.format(table, start_date.year, start_date.month, start_date.day)
        context = {'Database': db}

        response = run_query(ext_athena_sql, context, bucket_name, log_path)

        query_execution_id = response['QueryExecutionId']
        athena_result = athena_client.get_query_execution(QueryExecutionId=query_execution_id)

        query_status = athena_result['QueryExecution']['Status']['State']

        while query_status == 'QUEUED' or query_status == 'RUNNING' or query_status is None:
            query_status = \
                athena_client.get_query_execution(QueryExecutionId=query_execution_id)['QueryExecution']['Status'][
                    'State']
            if query_status == 'FAILED' or query_status == 'CANCELLED':
                raise Exception('Athena query failed or was cancelled')
            time.sleep(10)

        if query_status == 'SUCCEEDED':
            logger.info("Athena query ID : {0}".format(query_execution_id))

        s3_key = 'backup/v2_usagelog/athena_query_log/' + query_execution_id + '.csv'

        obj = s3_client.get_object(Bucket=bucket_name, Key=s3_key)
        obj_rows = obj['Body'].read().decode("utf-8").split('\n')

        logger.info("mysql start")
        mysql_db = MysqlManager()
        param = {'start_dt': start_dt, 'end_dt': end_dt}
        mbrs_user_list = mysql_db.query_with_results(ext_mbrs_user_sql, param)
        logger.info("mysql end time")
        mbrs_user_list = [str(row[0]) for row in mbrs_user_list]
        logger.info("mbrs user list size : " + str(len(mbrs_user_list)))

        idx = 0
        user_id_set = set()
        result_list = []
        first = True
        logger.info('start for')
        for row in obj_rows:
            idx = idx + 1
            if idx == len(obj_rows):
                break

            user_id = row.split(',')[0].replace(",", "").replace("\"", "")
            branch_id = row.split(',')[1].replace(",", "").replace("\"", "")
            mcc = row.split(',')[2].replace(",", "").replace("\"", "")
            csc = row.split(',')[3].replace("\"", "").replace("\r", "")

            if user_id in mbrs_user_list and user_id not in user_id_set:
                result_list.append((user_id, branch_id, mcc, csc))

            if first:
                first = False
            else:
                if user_id not in user_id_set:
                    user_id_set.add(user_id)

        logger.info('end for')
        file_name = 'mbrs_user_list_{0}_{1}_{2}.csv'.format(start_date.year, start_date.month, start_date.day)

        logger.info('open file for s3 upload')
        with open(file_name, 'w', encoding='utf-8', newline='\n') as f:
            wr = csv.writer(f)
            for result in result_list:
                wr.writerow(result)
        f.close()

        logger.info('close file and start upload file')
        s3_client.upload_file(file_name, bucket_name, 'backup/mbrs_user/' + file_name)
        logger.info('end upload')

    except Exception as e:
        logger.error(str(e))
