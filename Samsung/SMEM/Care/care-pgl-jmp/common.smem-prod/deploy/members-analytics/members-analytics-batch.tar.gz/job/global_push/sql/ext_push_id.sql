SELECT id FROM global_push
WHERE
crt_dt < '{date}'
ORDER BY id DESC
LIMIT 1