#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
from common.base.base_batch_job import BaseBatchJob
from common.base.es_query import ElasticSearchQuery
from common.base.reader import ElasticSearchReader
from common.logger import Logger, func_logger
from utils import args_util, s3_util
from datetime import datetime, timedelta
from config.loader import load_config
import gzip
import json


class UsageLogBatchJob(BaseBatchJob):

    def __init__(self, _start_dt, _end_dt):
        BaseBatchJob.__init__(self, _start_dt, _end_dt)

        self.reader = ElasticSearchReader(es_query=ScreenViewESQuery())

    @func_logger
    def do_read(self):
        pass

    @func_logger
    def do_process(self):
        _start_dt = datetime.strptime(self.date.get('start_dt'), '%Y-%m-%d')
        _end_dt = datetime.strptime(self.date.get('end_dt'), '%Y-%m-%d')

        while _start_dt < _end_dt:
            _to = _start_dt + timedelta(hours=1)

            ret_rows = self.reader.read(_start_dt, _to)

            file_name = 'v2_usagelog_{0}.log.gz'.format(_start_dt.strftime('%Y_%m_%d_%H_%M'))

            with gzip.open(file_name, 'wt', encoding='utf-8') as f:
                for item in ret_rows:
                    f.write(item)

            aws_config = load_config().get('aws')
            s3_client = s3_util.get_client()

            bucket_name = aws_config.get('s3').get('bucket')

            s3_obj_path = "{0}/{1}/{2}/{3}/{4}".format(
                "backup/v2_usagelog", "year=" + str(_start_dt.year), "month=" + str(_start_dt.month),
                                      "day=" + str(_start_dt.day), file_name)

            s3_client.upload_file(file_name, bucket_name, s3_obj_path)
            os.remove(file_name)

            _start_dt = _to

        """
        athena_client = athena_util.get_client()
        db = aws_config.get('athena').get('db')
        table = aws_config.get('athena').get('table')
        log_path = aws_config.get('athena').get('log')
        athena_sql = 'MSCK REPAIR TABLE ' + table

        context = {'Database': db}
        athena_client.start_query_execution(
            QueryString=athena_sql,
            QueryExecutionContext=context,
            ResultConfiguration={
                'OutputLocation': 's3://' + bucket_name + log_path
            }
        )
        """

    @func_logger
    def do_write(self):
        pass


class ScreenViewESQuery(ElasticSearchQuery):
    @staticmethod
    def convert_list(_scroll_result):
        result_list = list()
        for _data in _scroll_result['hits']['hits']:
            serial_no = _data['_source'].get('deviceSerial', None)
            type_ = _data['_source'].get('type', None)
            page_id = _data['_source'].get('pageId', None)
            event_target_id = _data['_source'].get('eventTargetId', None)
            event_action = _data['_source'].get('eventAction', None)
            timestamp = _data['_source'].get('timestamp', None)
            createdatetime = _data['_source'].get('createTime', None)
            extra_info = _data['_source'].get('extraInfo', None)

            transaction_id = _data['_source'].get('transactionId', None)
            branch_id = _data['_source'].get('branchId', None)
            model = _data['_source'].get('model', None)
            app_id = _data['_source'].get('appId', None)
            app_version = _data['_source'].get('appVersion', None)
            os_version = _data['_source'].get('osVersion', None)

            lang = _data['_source'].get('lang', None)
            csc = _data['_source'].get('csc', None)
            user_id = _data['_source'].get('guid', None)
            mcc = _data['_source'].get('osVersion', None)
            mnc = _data['_source'].get('mnc', None)
            country_code = _data['_source'].get('countryCode', None)
            device_fp = _data['_source'].get('deviceFp', None)

            row = {
                "serial_no": serial_no,
                "type": type_,
                "page_id": page_id,
                "event_target_id": event_target_id,
                "event_action": event_action,
                "timestamp": timestamp,
                "createdatetime": createdatetime,
                "extra_info": extra_info,
                "transaction_id": transaction_id,
                "branch_id": branch_id,
                "model": model,
                "app_id": app_id,
                "app_version": app_version,
                "os_version": os_version,
                "lang": lang,
                "csc": csc,
                "user_id": user_id,
                "mcc": mcc,
                "mnc": mnc,
                "country_code": country_code,
                "device_fp": device_fp
            }

            result_list.append(json.dumps(row) + '\n')

        return result_list

    @staticmethod
    def query(_start_dt, _end_dt, _param):
        return {
            "query": {
                "bool": {
                    "must": [
                        {
                            "range": {
                                "createTime": {
                                    "gte": _start_dt,
                                    "lt": _end_dt
                                }
                            }
                        }
                    ]
                }
            },
            "_source": ['deviceSerial', 'type', 'pageId', 'eventTargetId', 'eventAction', 'timestamp', 'createTime',
                        'extraInfo', 'transactionId', 'branchId', 'model', 'appId', 'appVersion', 'osVersion',
                        'lang', 'csc', 'guid', 'mcc', 'mnc', 'countryCode', 'deviceFp']
        }


if __name__ == '__main__':
    logger = Logger(__file__)
    logger.start_batch()

    try:
        start_dt, end_dt = args_util.parse_sys_argv('date', 2)
        UsageLogBatchJob(start_dt, end_dt).execute()

        logger.end_batch()

    except Exception as e:
        logger.error(str(e))
