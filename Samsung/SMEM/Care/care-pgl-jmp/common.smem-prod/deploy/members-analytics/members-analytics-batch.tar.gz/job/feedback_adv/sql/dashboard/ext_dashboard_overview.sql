SELECT date, branch_id, main_type, prd_cat, SUM(cnt) AS cnt
FROM v3_feedback
WHERE
date >= '{start_dt}'
AND
date <= '{end_dt}'
GROUP BY date, branch_id, main_type, prd_cat
ORDER BY date, branch_id, main_type, prd_cat