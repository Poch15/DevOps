#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import yaml
import os


def load_config():
    try:
        current_dir = os.path.dirname(os.path.realpath(__file__))
        config_path = os.path.join(current_dir, 'config.yaml')
        config = yaml.load(open(config_path, 'r'))
        if config is None:
            raise __ConfigError("ConfigError - Can not load config!")

        return config

    except FileNotFoundError:
        raise __ConfigError("ConfigError - Can not find config.yaml file!")
    except yaml.YAMLError as e:
        raise __ConfigError("ConfigError - {0}".format(e))


class __ConfigError(Exception):
    pass
