SELECT '{start_dt}', mu.last_branch, mu_dvc.dvc_model, COUNT(*)
FROM mbrs_user PARTITION({part_name}) mu
INNER JOIN mbrs_user_dvc PARTITION({part_name}) mu_dvc
	ON mu.mbrs_id = mu_dvc.mbrs_id
WHERE mu_dvc.crt_dt>='{start_dt}'
  AND mu_dvc.crt_dt<'{end_dt}'
  AND mu.eula_agree=1
  AND mu.last_branch=3
GROUP BY mu.last_branch, mu_dvc.dvc_model
ORDER BY mu.last_branch, mu_dvc.dvc_model;