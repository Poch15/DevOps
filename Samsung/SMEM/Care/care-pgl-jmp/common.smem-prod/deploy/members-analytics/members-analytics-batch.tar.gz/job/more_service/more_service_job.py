#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from common.base.base_batch_job import BaseBatchJob
from common.base.es_query import ElasticSearchQuery
from common.base.reader import  ElasticSearchReader
from common.base.writer import PostgresqlWriter
from common.logger import func_logger, Logger
from utils import args_util, file_util
import pandas as pd
from datetime import datetime


class MoreServiceJob(BaseBatchJob):
    ins_pv_sql = file_util.load_sql_in_cur_dir('sql', 'ins_more_service.sql')
    ins_event_sql = file_util.load_sql_in_cur_dir('sql', 'ins_more_service_event.sql')

    def __init__(self, _start_dt, _end_dt):
        BaseBatchJob.__init__(self, _start_dt, _end_dt)

        self.start_dt = _start_dt

        self.reader = ElasticSearchReader(es_query=MoreServiceESQuery())
        self.writer = PostgresqlWriter()

        self.row_list = list()
        self.summary_pv_list = list()
        self.summary_service_list = list()

    @func_logger
    def do_read(self):
        self.row_list = self.reader.read(self.date.get('start_dt'), self.date.get('end_dt'))

    @func_logger
    def do_process(self):
        df = pd.DataFrame(data=self.row_list, columns=['dt', 'branch_id', 'model', 'type', 'service_id', 'status'])

        # page view
        pv_df = df[df['type'] == 'pageView']
        pv_summary_df = pv_df.groupby(['branch_id', 'model'])['type'].count()
        for index, value in pv_summary_df.items():
            self.summary_pv_list.append((self.start_dt, int(index[0]), index[1], int(value)))

        # event
        event_df = df[df['type'] == 'event']
        summary_df = event_df.groupby(['branch_id', 'model', 'service_id', 'status'])['type'].count()

        for idx, item in summary_df.items():
            self.summary_service_list.append(
                (self.start_dt, int(idx[0]), idx[1], idx[2], idx[3], int(item)))

    @func_logger
    def do_write(self):
        self.writer.write(self.summary_pv_list, MoreServiceJob.ins_pv_sql)
        self.writer.write(self.summary_service_list, MoreServiceJob.ins_event_sql)


class MoreServiceESQuery(ElasticSearchQuery):
    @staticmethod
    def convert_list(_scroll_result):
        result_list = list()
        for _data in _scroll_result['hits']['hits']:
            branch_id = _data['_source'].get('branchId', None)
            model = _data['_source'].get('model', None)
            petype = _data['_source'].get('type', None)
            event_target_id = _data['_source'].get('eventTargetId', None)
            extra_info = _data['_source'].get('extraInfo', None)
            timestamp = _data['_source'].get('timestamp', None)

            timestamp = datetime.strptime(timestamp, "%Y-%m-%dT%H:%M:%S.%fZ").date()
            service_id = extra_info.get('serviceId', None)
            app_status = extra_info.get('appStatus', None)

            if (petype == 'pageView') or \
                    (petype == 'event' and event_target_id == 'EBS502' and service_id is not None and app_status is not None):
                result_list.append((timestamp, int(branch_id), model, petype, service_id, app_status))

        return result_list

    @staticmethod
    def query(_start_dt, _end_dt, _param):
        return {
            "query": {
                "bool": {
                    "must": [
                        {
                            "match_phrase": {
                                "pageId.keyword": {
                                    "query": "SBS46"
                                }
                            }
                        },
                        {
                            "range": {
                                "createTime": {
                                    "gte": _start_dt,
                                    "lt": _end_dt
                                }
                            }
                        }
                    ]
                }
            },
            "_source": ['timestamp', 'branchId', 'model', 'type', 'extraInfo', 'eventTargetId']
        }


if __name__ == '__main__':
    logger = Logger(__file__)
    logger.start_batch()

    try:
        start_dt, end_dt = args_util.parse_sys_argv('date', 2)

        MoreServiceJob(start_dt, end_dt).execute()

        logger.end_batch()

    except Exception as e:
        logger.error(str(e))
