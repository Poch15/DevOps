#!/usr/bin/python3
# -*- coding: utf-8 -*-

from common.base.base_batch_job import BaseBatchJob
from common.base.es_query import ElasticSearchQuery
from common.base.reader import ElasticSearchReader
from common.base.writer import PostgresqlWriter
from common.logger import func_logger, Logger
from utils import args_util, file_util, date_util
from datetime import datetime
from pandas import DataFrame


class ScreenViewBatchJob(BaseBatchJob):
    def __init__(self, _start_dt, _end_dt):
        BaseBatchJob.__init__(self, _start_dt, _end_dt)
        self.start_dt = datetime.strptime(_start_dt, '%Y-%m-%d')

        self.reader = ElasticSearchReader(es_query=ScreenViewESQuery())
        self.writer = PostgresqlWriter()

        self.ret_rows = []
        self.daily_list = []
        self.weekly_list = []
        self.monthly_list = []

        self.summary_daily_list = []
        self.summary_weekly_list = []
        self.summary_monthly_list = []

    @func_logger
    def do_read(self):
        self.ret_rows = self.reader.read(self.date.get('start_dt'), self.date.get('end_dt'))

    @func_logger
    def do_process(self):
        # daily
        daily_df = DataFrame(self.ret_rows, columns=['date', 'branch_id', 'model', 'screen_id', 'cnt'])
        summary_daily_df = daily_df.groupby(['date', 'branch_id', 'model', 'screen_id'])['cnt'].sum()
        for index, count in zip(summary_daily_df.index, summary_daily_df.values):
            date, branch_id, model, screen_id = index
            self.summary_daily_list.append((date, branch_id, model, screen_id, int(count)))

        # weekly, monthly
        for row in self.summary_daily_list:
            date, branch_id, model, screen_id, cnt = row
            dt = datetime.combine(date, datetime.min.time())
            self.weekly_list.append((date_util.get_last_sunday(dt), branch_id, model, screen_id, cnt))
            self.monthly_list.append((date_util.get_first_day_month(dt), branch_id, model, screen_id, cnt))

        weekly_df = DataFrame(data=self.weekly_list,
                              columns=['date', 'branch_id', 'model', 'screen_id', 'cnt'])
        summary_weekly_df = weekly_df.groupby(['date', 'branch_id', 'model', 'screen_id']).sum()
        for index, count in zip(summary_weekly_df.index, summary_weekly_df.values):
            date, branch_id, model, screen_id = index
            self.summary_weekly_list.append((date, branch_id, model, screen_id, int(count[0])))

        monthly_df = DataFrame(data=self.monthly_list,
                               columns=['date', 'branch_id', 'model', 'screen_id', 'cnt'])
        summary_monthly_df = monthly_df.groupby(['date', 'branch_id', 'model', 'screen_id']).sum()
        for index, count in zip(summary_monthly_df.index, summary_monthly_df.values):
            date, branch_id, model, screen_id = index
            self.summary_monthly_list.append((date, branch_id, model, screen_id, int(count[0])))

    @func_logger
    def do_write(self):
        ins_daily_sql = file_util.load_file(__file__, 'sql/ins_daily_screenview.sql')
        self.writer.write(self.summary_daily_list, ins_daily_sql)

        ins_weekly_sql = file_util.load_file(__file__, 'sql/ins_weekly_screenview.sql')
        upt_weekly_sql = file_util.load_file(__file__, 'sql/upt_weekly_screenview.sql')
        self.writer.write(self.summary_weekly_list, ins_weekly_sql, upt_weekly_sql)

        ins_monthly_sql = file_util.load_file(__file__, 'sql/ins_monthly_screenview.sql')
        upt_monthly_sql = file_util.load_file(__file__, 'sql/upt_monthly_screenview.sql')
        self.writer.write(self.summary_monthly_list, ins_monthly_sql, upt_monthly_sql)


class ScreenViewESQuery(ElasticSearchQuery):
    @staticmethod
    def convert_list(_scroll_result):
        result_list = list()
        for _data in _scroll_result['hits']['hits']:
            branch_id = _data['_source'].get('branchId', None)
            model = _data['_source'].get('model', None)
            page_id = _data['_source'].get('pageId', None)
            timestamp = _data['_source'].get('timestamp', None)

            timestamp = datetime.strptime(timestamp, "%Y-%m-%dT%H:%M:%S.%fZ").date()

            result_list.append((timestamp, int(branch_id), model, page_id, 1))

        return result_list

    @staticmethod
    def query(_start_dt, _end_dt, _param):
        return {
            "query": {
                "bool": {
                    "must": [
                        {
                            "match_phrase": {
                                "type.keyword": {
                                    "query": "pageView"
                                }
                            }
                        },
                        {
                            "range": {
                                "createTime": {
                                    "gte": _start_dt,
                                    "lt": _end_dt
                                }
                            }
                        }
                    ]
                }
            },
            "_source": ['timestamp', 'branchId', 'model', 'pageId']
        }


if __name__ == '__main__':
    logger = Logger(__file__)
    logger.start_batch()

    try:
        start_dt, end_dt = args_util.parse_sys_argv('date', 2)
        ScreenViewBatchJob(start_dt, end_dt).execute()

        logger.end_batch()

    except Exception as e:
        logger.error(str(e))
