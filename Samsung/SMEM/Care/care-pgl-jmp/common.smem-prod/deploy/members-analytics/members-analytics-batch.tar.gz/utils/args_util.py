#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from datetime import datetime
import sys


def parse_sys_argv(_format, count):
    args_list = sys.argv

    # remove 1st args because 1st args of system args is file path & name
    _args_list = [args for index, args in enumerate(args_list) if index > 0]

    __check_count(_args_list, count)
    __check_format_list(_args_list, _format)

    if len(_args_list) == 1:
        _args_list = _args_list[0]

    return _args_list


def __check_count(args_list, count):
    if len(args_list) != count:
        raise __SystemArgsError(
            "SystemArgsError - System arguments must be {0} (but {1} given)"
            .format(str(count), str(len(args_list)))
        )


def __check_format_list(args_list, args_format):
    try:
        if args_format is list or args_format is tuple:
            if len(args_list) != len(args_format):
                raise __SystemArgsError(
                    "SystemArgsError - length of args_format is not equal length of args_list"
                )

            for arg, _format in zip(args_list, args_format):
                __check_format(arg, _format)

        else:
            for arg in args_list:
                __check_format(arg, args_format)

    except ValueError as e:
        raise __SystemArgsError("SystemArgsError -" + str(e))


def __check_format(arg, _format):
    if _format is 'date':
        datetime.strptime(arg, '%Y-%m-%d')
    elif _format is 'datetime':
        datetime.strptime(arg, '%Y-%m-%dT%H:%M:%S')


class __SystemArgsError(Exception):
    pass
