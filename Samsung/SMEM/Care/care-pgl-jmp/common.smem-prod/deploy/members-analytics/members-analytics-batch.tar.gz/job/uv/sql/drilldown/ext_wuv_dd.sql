SELECT '{cur_date}' as date, branch_id, cnt
FROM v3_wuv
WHERE
date = '{ext_date}'