#!/bin/bash

BASE_PYTHON_PATH='/home/common/members-analytics/members-analytics-batch'
source ${BASE_PYTHON_PATH}/.venv/bin/activate
export PYTHONPATH=${BASE_PYTHON_PATH}/backup_usagelog

export from="$(date --date="1 days ago" +%Y-%m-%d)"
export to="$(date +%Y-%m-%d)"
python3 /home/common/members-analytics/members-analytics-batch/backup_usagelog/job/backup_usagelog/backup_usagelog.py $from $to
