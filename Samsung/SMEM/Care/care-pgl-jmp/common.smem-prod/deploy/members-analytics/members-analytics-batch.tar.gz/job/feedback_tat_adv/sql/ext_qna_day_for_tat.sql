SELECT
  DATE_FORMAT(feedback.crt_dt,"%Y-%m-%d %H:%i:%s") AS qna_datetime,
  DATE_FORMAT(fb_ans.crt_dt,"%Y-%m-%d %H:%i:%s") AS qna_ans_datetime,
  feedback.branch_id, feedback.model_name, feedback.prd_cat
FROM feedback,
(
	SELECT fb_id, COUNT(fb_id) AS ans_cnt, MIN(crt_dt) AS crt_dt
	FROM fb_ans
	WHERE crt_dt >= '{start_dt}' AND crt_dt < '{end_dt}'
	GROUP BY fb_id
) AS fb_ans
WHERE
  feedback.fb_id = fb_ans.fb_id
  AND
  feedback.main_type = 3
  AND
  feedback.ans_cnt = fb_ans.ans_cnt