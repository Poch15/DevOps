SELECT  date(timestamp + INTERVAL '{timezone} hour') as datetime, branch_id, model, page_id, count(*)
FROM uldata2
WHERE createdatetime >= (date '{start_dt}' - INTERVAL '{timezone} hour')
AND createdatetime < (date '{end_dt}'- INTERVAL '{timezone} hour')
AND type = 'pageView'
GROUP BY datetime, branch_id, model, page_id;