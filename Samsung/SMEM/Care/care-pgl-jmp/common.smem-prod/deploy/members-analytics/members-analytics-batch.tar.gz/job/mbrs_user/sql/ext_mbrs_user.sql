SELECT guid
FROM mbrs_user
WHERE crt_dt >= '{start_dt}' AND crt_dt < '{end_dt}'