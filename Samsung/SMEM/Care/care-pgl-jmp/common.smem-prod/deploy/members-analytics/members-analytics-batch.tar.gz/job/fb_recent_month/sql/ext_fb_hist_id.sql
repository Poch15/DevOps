SELECT hist_id
FROM fb_hist
WHERE
crt_dt < '{date}'
ORDER BY hist_id DESC
LIMIT 1