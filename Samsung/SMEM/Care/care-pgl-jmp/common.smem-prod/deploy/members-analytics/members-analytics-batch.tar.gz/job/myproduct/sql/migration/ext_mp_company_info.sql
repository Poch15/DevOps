SELECT mp.gcic_company_cd, '', svc.branch_id
FROM
mp_cnty_info mp, svc_cnty svc
where mp.cnty_cd = svc.cnty_cd
group by mp.gcic_company_cd, svc.branch_id