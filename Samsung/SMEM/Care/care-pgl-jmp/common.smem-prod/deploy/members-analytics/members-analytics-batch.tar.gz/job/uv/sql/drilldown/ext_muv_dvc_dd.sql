SELECT '{cur_date}' as date, branch_id, model, cnt
FROM v3_muv_dvc
WHERE
date = '{ext_date}'