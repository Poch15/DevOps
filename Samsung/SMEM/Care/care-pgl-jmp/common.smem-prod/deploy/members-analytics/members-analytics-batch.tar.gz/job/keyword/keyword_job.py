#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from common.base.base_batch_job import BaseBatchJob
from common.base.reader import PostgresqlReader
from common.base.writer import PostgresqlWriter
from common.logger import func_logger, Logger
from job.keyword.keyword_adv_job import KeywordAdvBatchJob
from utils import args_util, file_util
from job.keyword.keyword_dashboard_adv_job import KeywordDashboardAdvBatchJob
from job.keyword.search_job import SearchBatchJob


read_sql = file_util.load_sql_in_cur_dir('sql', 'ext_keyword.sql')
write_sql = file_util.load_sql_in_cur_dir('sql', 'ins_keyword.sql')


class KeywordBatchJob(BaseBatchJob):

    def __init__(self, _start_dt, _end_dt):
        BaseBatchJob.__init__(self, _start_dt, _end_dt)

        self.reader = PostgresqlReader(read_sql)
        self.writer = PostgresqlWriter(write_sql)

        self.summary_list = []

    @func_logger
    def do_read(self):
        self.summary_list = self.reader.read(param=self.date)

    @func_logger
    def do_process(self):
        pass

    @func_logger
    def do_write(self):
        self.writer.write(self.summary_list)


if __name__ == '__main__':
    logger = Logger(__file__)
    logger.start_batch()

    try:
        start_dt, end_dt = args_util.parse_sys_argv('date', 2)

        KeywordAdvBatchJob(start_dt, end_dt).execute()

        SearchBatchJob(start_dt, end_dt).execute()

        # KeywordDashboardAdvBatchJob(start_dt, end_dt, 'day').execute()
        # KeywordDashboardAdvBatchJob(start_dt, end_dt, 'week').execute()

        logger.end_batch()

    except Exception as e:
        logger.error(str(e))
