#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import boto3
from botocore.config import Config
from config.loader import load_config


def get_client():
    profile = load_config().get('profile')
    config_dict = load_config().get('aws')
    verify = None
    config = None

    if profile is 'local':
        verify = config_dict.get('verify')
        config = Config(proxies={
            'http': config_dict.get('proxy'),
            'https': config_dict.get('proxy')
        })

    _client = boto3.client(service_name='athena',
                           aws_access_key_id=config_dict.get('athena_access_key'),
                           aws_secret_access_key=config_dict.get('athena_secret_key'),
                           verify=verify, config=config, region_name='ap-northeast-2')
    return _client
