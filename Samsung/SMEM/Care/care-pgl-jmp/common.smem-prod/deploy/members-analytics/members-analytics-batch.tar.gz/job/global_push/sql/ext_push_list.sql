SELECT crt_dt, mdf_dt, message, status
FROM global_push
WHERE
id > '{start_push_id}'
AND
id <= '{end_push_id}'