#!/usr/bin/python3
# -*- coding: utf-8 -*-

from common.base.base_batch_job import BaseBatchJob
from common.base.reader import MysqlReader
from common.base.writer import PostgresqlWriter
from common.logger import func_logger, Logger
from utils import args_util, file_util
from job.new_user.user_partition import UserPartition

from pandas import DataFrame

read_sql_global = file_util.load_sql_in_cur_dir('sql', 'new_user_without_eula/ext_new_user_device.sql')

read_sql_china = file_util.load_sql_in_cur_dir('sql', 'new_user_with_eula/ext_new_user_device1.sql')
read_sql2_china = file_util.load_sql_in_cur_dir('sql', 'new_user_with_eula/ext_new_user_device2.sql')


write_sql = file_util.load_sql_in_cur_dir('sql', 'ins_new_user_device.sql')


class NewUserDeviceBatchJob(BaseBatchJob):

    def __init__(self, _start_dt, _end_dt):
        BaseBatchJob.__init__(self, _start_dt, _end_dt)

        self.reader = MysqlReader()
        self.writer = PostgresqlWriter(write_sql)

        self.summary_list = []

    @func_logger
    def do_read(self):
        params = self.date.copy()

        # global
        for i in range(UserPartition.START, UserPartition.END):
            params.update({'part_name': UserPartition.get_partition_name(i)})
            result = self.reader.read(sql=read_sql_global, param=params)
            self.summary_list.extend(result)

        # china
        for i in range(UserPartition.START, UserPartition.END):
            params.update({'part_name': UserPartition.get_partition_name(i)})
            result = self.reader.read(sql=read_sql_china, param=params)
            self.summary_list.extend(result)

        for i in range(UserPartition.START, UserPartition.END):
            params.update({'part_name': UserPartition.get_partition_name(i)})
            result = self.reader.read(sql=read_sql2_china, param=params)
            self.summary_list.extend(result)

    @func_logger
    def do_process(self):
        summary_df = DataFrame(
            data=self.summary_list,
            columns=['dt', 'branch_id', 'model', 'cnt']
        )

        result = summary_df.groupby(['dt', 'branch_id', 'model']).sum()

        total_summary_list = []
        for index, cnt in zip(result.index, result.values):
            total_summary_list.append(
                (str(index[0]), int(index[1]), str(index[2]), int(cnt)))

        self.summary_list = total_summary_list

    @func_logger
    def do_write(self):
        self.writer.write(self.summary_list)


if __name__ == '__main__':
    logger = Logger(__file__)
    logger.start_batch()

    try:
        start_dt, end_dt = args_util.parse_sys_argv('date', 2)
        NewUserDeviceBatchJob(start_dt, end_dt).execute()
        logger.end_batch()

    except Exception as e:
        logger.error(str(e))
