#!/usr/bin/python
# -*- coding: utf-8 -*-

from datetime import datetime, timedelta
from job.myproduct.myproduct_register_job import MyProductRegisterJob


if __name__ == '__main__':

    # start_datetime <= batch < end_datetime
    start_datetime = datetime(2019, 11, 1, 0, 0, 0, 0, None)
    end_datetime = datetime(2019, 11, 3, 0, 0, 0, 0, None)

    print(str(start_datetime) + "  /  " + str(end_datetime))

    cur_datetime = start_datetime
    while cur_datetime < end_datetime:

        str_cur_datetime = cur_datetime.strftime('%Y-%m-%dT%H:%M:%S')
        str_end_datetime = (cur_datetime + timedelta(days=1)).strftime('%Y-%m-%dT%H:%M:%S')

        MyProductRegisterJob(str_cur_datetime, str_end_datetime).execute()

        print(str(cur_datetime) + '  complete')

        cur_datetime = cur_datetime + timedelta(days=1)
