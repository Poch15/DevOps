SELECT fb_id
FROM fb_hist
WHERE
hist_id > '{start_hist_id}'
AND
hist_id <= '{end_hist_id}'
AND
(
  hist_type = 3
  OR
  hist_type = 6
  OR
  (
    hist_type = 4
    AND
    fb_status IN ('CLOSED', 'DISCARDED')
  )
)
GROUP BY fb_id