SELECT DATE_TRUNC('day', TIMESTAMP)::DATE AS DATE, branch_id, page_id AS screen_id, event_target_id AS event_id, COUNT(*) AS cnt
FROM uldata2
WHERE
createdatetime >= '{start_dt}'
AND
createdatetime < '{end_dt}'
AND
TYPE = 'event'
AND
event_target_id IS NOT NULL
GROUP BY DATE, branch_id, screen_id, event_id