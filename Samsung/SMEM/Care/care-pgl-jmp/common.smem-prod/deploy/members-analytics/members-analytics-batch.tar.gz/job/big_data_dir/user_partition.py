#!/usr/bin/env python3
# -*- coding: utf-8 -*-


class UserPartition:

    PREFIX = 'p'
    START = 0
    END = 36

    @staticmethod
    def get_partition_name(i):
        return '{0}{1}'.format(UserPartition.PREFIX, str(i))
