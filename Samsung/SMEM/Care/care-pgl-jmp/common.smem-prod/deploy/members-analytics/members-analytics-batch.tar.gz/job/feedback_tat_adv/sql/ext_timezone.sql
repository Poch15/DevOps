SELECT branch_id, tz
FROM svc_cnty
WHERE
  def_cnty = 1
ORDER BY branch_id