#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from distutils.util import strtobool

from common.base.base_batch_job import BaseBatchJob
from common.base.es_query import ElasticSearchQuery
from utils import file_util
from pandas import DataFrame
from common.base.reader import ElasticSearchReader
from common.base.writer import PostgresqlWriter
from datetime import datetime

read_sql = file_util.load_sql_in_cur_dir('sql', 'ext_diagnosis_inter.sql')
write_sql = file_util.load_sql_in_cur_dir('sql', 'ins_diagnosis_battery.sql')
write_detail_sql = file_util.load_sql_in_cur_dir('sql', 'ins_diagnosis_inter.sql')
upsert_sql = file_util.load_sql_in_cur_dir('sql', 'upt_diagnosis_battery.sql')


class DiagnosisInterBatchJob(BaseBatchJob):
    __UNKNOWN = '0'
    __BATTERY_RESULT = {'Bad': 0, 'Weak': 1, 'Normal': 2, 'Good': 3}

    __CATEGORY = {
        'IRIS': 1, 'SIM': 2, 'CHARGER': 3, 'TOUCH': 4, 'BATTERY': 5, 'WI_FI': 6,
        'BLUETOOTH': 7, 'VIBRATOR': 8, 'CAMERA': 9, 'FINGERPRINT': 10, 'WIRELESS_CHARGING': 11, 'HEADPHONE': 12,
        'HEART_RATE': 13, 'SPEAKER': 14, 'BUTTON': 15, 'MIC': 16, 'SPEN': 17
    }

    def __init__(self, _start_dt, _end_dt):
        BaseBatchJob.__init__(self, _start_dt, _end_dt)

        self.reader = ElasticSearchReader(es_query=DiagnosisInterESQuery())
        self.writer = PostgresqlWriter()

        self.detail_list = list()
        self.battery_list = list()

        self.detail_summary = None
        self.battery_summary = None

    def do_read(self):
        ret_rows = self.reader.read(self.date.get('start_dt'), self.date.get('end_dt'))

        for row in ret_rows:
            dt, branch_id, model, extra_info = row

            # detail result - v3_diagnosis_inter
            for cat in self.__CATEGORY:
                detail = extra_info.get(cat, self.__UNKNOWN)
                if detail != self.__UNKNOWN and cat != 'BATTERY':
                    detail_result = detail.get('diagnosisResult', self.__UNKNOWN)
                    if detail_result != self.__UNKNOWN:
                        diagnosis_result = self.__get_diagnosis_result(detail_result)
                        self.detail_list.append((dt, branch_id, model, self.__CATEGORY[cat], diagnosis_result, 1))

                # battery result - v3_diagnosis_battery
                elif detail != self.__UNKNOWN and cat == 'BATTERY':
                    battery_result = detail.get('life', self.__UNKNOWN)
                    if battery_result != self.__UNKNOWN:
                        self.battery_list.append((dt, branch_id, model, 0, self.__BATTERY_RESULT[battery_result], 1))

    def do_process(self):
        df = DataFrame(data=self.detail_list, columns=['dt', 'branch_id', 'model', 'cat', 'result', 'cnt'])
        self.detail_summary = df['cnt'].groupby([df['dt'], df['branch_id'], df['model'], df['cat'], df['result']]).sum()

        df = DataFrame(data=self.battery_list, columns=['dt', 'branch_id', 'model', 'is_auto', 'result', 'cnt'])
        self.battery_summary = df['cnt'].groupby(
            [df['dt'], df['branch_id'], df['model'], df['is_auto'], df['result']]).sum()

    def do_write(self):
        self.__insert_diagnosis()
        self.__insert_battery_diagnosis()

    def __insert_battery_diagnosis(self):
        battery = []
        for idx, count in zip(self.battery_summary.index, self.battery_summary.values):
            dt, branch_id, model, is_auto, result = idx
            battery.append((dt, branch_id, model, is_auto, result, int(count)))
        self.writer.write(battery, write_sql, upsert_sql)

    def __insert_diagnosis(self):
        detail = []
        for idx, count in zip(self.detail_summary.index, self.detail_summary.values):
            dt, branch_id, model, cat, result = idx
            detail.append((dt, branch_id, model, cat, result, int(count)))
        self.writer.write(detail, write_detail_sql)

    def __get_diagnosis_result(self, detail_result):
        if detail_result != self.__UNKNOWN:
            if detail_result == 'skip':
                return 2
            else:
                return 1 if strtobool(detail_result) else 0


class DiagnosisInterESQuery(ElasticSearchQuery):
    @staticmethod
    def convert_list(_scroll_result):
        result_list = list()
        for _data in _scroll_result['hits']['hits']:
            branch_id = _data['_source'].get('branchId', None)
            model = _data['_source'].get('model', None)
            extra_info = _data['_source'].get('extraInfo', None)
            timestamp = _data['_source'].get('timestamp', None)

            timestamp = datetime.strptime(timestamp, "%Y-%m-%dT%H:%M:%S.%fZ").date()

            if extra_info is not None:
                result_list.append((timestamp, int(branch_id), model, extra_info))

        return result_list

    @staticmethod
    def query(_start_dt, _end_dt, _param):
        return {
            "query": {
                "bool": {
                    "must": [
                        {
                            "match_phrase": {
                                "pageId.keyword": {
                                    "query": "SPC7"
                                }
                            }
                        },
                        {
                            "match_phrase": {
                                "eventTargetId.keyword": {
                                    "query": "EPC101"
                                }
                            }
                        },
                        {
                            "match_phrase": {
                                "type.keyword": {
                                    "query": "event"
                                }
                            }
                        },
                        {
                            "range": {
                                "createTime": {
                                    "gte": _start_dt,
                                    "lt": _end_dt
                                }
                            }
                        }
                    ]
                }
            },
            "_source": ['timestamp', 'branchId', 'model', 'extraInfo']
        }
