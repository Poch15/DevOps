#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from common.base.base_batch_job import BaseBatchJob
from common.base.reader import PostgresqlReader
from common.base.writer import PostgresqlWriter
from common.logger import func_logger
from utils import file_util

read_sql = file_util.load_sql_in_cur_dir('sql/search', 'ext_search.sql')
write_sql = file_util.load_sql_in_cur_dir('sql/search', 'ins_search.sql')


class SearchBatchJob(BaseBatchJob):

    def __init__(self, _start_dt, _end_dt):
        BaseBatchJob.__init__(self, _start_dt, _end_dt)

        self.reader = PostgresqlReader(read_sql)
        self.writer = PostgresqlWriter(write_sql)

        self.summary_list = []

    @func_logger
    def do_read(self):
        self.summary_list = self.reader.read(param=self.date)

    @func_logger
    def do_process(self):
        pass

    @func_logger
    def do_write(self):
        self.writer.write(self.summary_list)
