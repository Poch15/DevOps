SELECT device_fp, page_id, branch_id, timestamp
FROM uldata2
  WHERE
    createdatetime >= '{start_dt}'::timestamp - INTERVAL '1' HOUR
  AND
    createdatetime < '{end_dt}'::timestamp + INTERVAL '1' HOUR
  AND
    type = 'pageView'
  AND
    branch_id = {branch_id}
  AND
    device_fp is not null