SELECT date_trunc('day', crt_dt) as dt, branch_id, dvc_model, keyword, lang_cd, count(*) as cnt
FROM v3_search
WHERE
  crt_dt >= '{start_dt}'
AND
	crt_dt < '{end_dt}'
AND
   types != 'contentsTag'
GROUP BY dt, branch_id, dvc_model, keyword, lang_cd;