#!/bin/bash

BASE_PYTHON_PATH='/home/common/members-analytics/members-analytics-batch'
source ${BASE_PYTHON_PATH}/.venv/bin/activate
export PYTHONPATH=${BASE_PYTHON_PATH}/global_push

export cur_datetime="$(date +%Y-%m-%dT%H:%M:%S)"
python3 /home/common/members-analytics/members-analytics-batch/global_push/job/global_push/global_push_job.py $cur_datetime