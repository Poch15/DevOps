#!/usr/bin/python3
# -*- coding: utf-8 -*-

from datetime import datetime, timedelta
from common.base.base_batch_job import BaseBatchJob
from common.logger import func_logger, Logger
from utils import file_util
from common.base.writer import PostgresqlWriter
import job.tmp_user_cnty.helper as helper


class TempGuid(BaseBatchJob):
    def __init__(self, _start_dt, _end_dt):
        BaseBatchJob.__init__(self, _start_dt, _end_dt)
        self.start_dt = _start_dt
        self.end_dt = _end_dt
        self.last_access_list = []

        self.writer = PostgresqlWriter()

    @func_logger
    def do_read(self):
        self.last_access_list = helper.get_raw_data(self.start_dt, self.end_dt)

    @func_logger
    def do_process(self):
        pass

    @func_logger
    def do_write(self):
        ins_user_temp_sql = file_util.load_file(__file__, 'sql/ins_user_temp.sql')
        upt_user_temp_sql = file_util.load_file(__file__, 'sql/upt_user_temp.sql')

        self.writer.write(self.last_access_list, ins_user_temp_sql, upt_user_temp_sql)


if __name__ == '__main__':
    logger = Logger(__file__)
    logger.start_batch()

    try:
        # start_datetime <= batch < end_datetime
        start_datetime = datetime(2019, 11, 8, 0, 0, 0, 0, None)
        end_datetime = datetime(2019, 12, 20, 0, 0, 0, 0, None)

        print(str(start_datetime) + "  /  " + str(end_datetime))

        cur_datetime = start_datetime
        while cur_datetime < end_datetime:
            str_cur_datetime = cur_datetime.strftime('%Y-%m-%dT%H:%M:%S')
            str_end_datetime = (cur_datetime + timedelta(days=1)).strftime('%Y-%m-%dT%H:%M:%S')

            TempGuid(str_cur_datetime, str_end_datetime).execute()

            print(str(cur_datetime) + '  complete')

            cur_datetime = cur_datetime + timedelta(days=1)

        logger.end_batch()

    except Exception as e:
        logger.error(str(e))
