SELECT timestamp, branch_id, model, type, extra_info->'serviceId' as service_id, extra_info->'appStatus' as status
FROM uldata2
WHERE createdatetime >= '{start_dt}' and createdatetime < '{end_dt}'
AND (
  (page_id = 'SBS46' AND type='pageView') OR
  (page_id = 'SBS46' AND event_target_id = 'EBS502' AND type='event' AND extra_info is not null)
)