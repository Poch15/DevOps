from common.base.base_batch_job import BaseBatchJob
from common.base.reader import PostgresqlReader
from common.base.writer import PostgresqlWriter
from common.logger import func_logger, Logger
from utils import args_util, file_util
from external import branch_inf
from datetime import datetime, timedelta
import pandas as pd
import numpy as np


class KeywordDashboardAdvBatchJob(BaseBatchJob):
    HQ_BRANCH_NAME = 'All'
    SOURCE_DICT = {
        "members": 0,
        "finder": 1
    }

    def __init__(self, _start_dt, _end_dt, period):
        BaseBatchJob.__init__(self, _start_dt, _end_dt)

        self.period = period
        self.end_date = datetime.strptime(_end_dt, '%Y-%m-%d')
        self.start_date = self.__get_start_date(period)

        env = 'postgresql_read'
        self.reader = PostgresqlReader(env=env)
        self.writer = PostgresqlWriter()

        self.branch_dict = dict()

        self.m_top10_id2word = dict()
        self.m_top10_word2id = dict()

        self.f_top10_id2word = dict()
        self.f_top10_word2id = dict()

        self.summary_rank = dict()
        self.summary_data = dict()

        self.logger = Logger(__file__)
        self.logger.start_batch()

    def __del__(self):
        BaseBatchJob.__del__(self)
        self.logger.end_batch()

    @func_logger
    def do_read(self):
        self.branch_dict = branch_inf.get_all_branch_id_to_name_dict()

    @func_logger
    def do_process(self):

        # HQ (ALL)
        self.__do_process(tuple(self.branch_dict.keys()), KeywordDashboardAdvBatchJob.HQ_BRANCH_NAME)

        # Region
        region_list = branch_inf.get_all_region_list()

        for region in region_list:
            region_list = branch_inf.get_branch_list_by_region(region)
            region_list.append(0)
            branch_ids = tuple(region_list)
            self.__do_process(branch_ids, region)

        # Local
        for branch_id, branch_name in self.branch_dict.items():
            branch_ids = (branch_id, 0)
            self.__do_process(branch_ids, branch_name)

    @func_logger
    def do_write(self):
        # Delete
        self.__delete_dashboard_keywords()

        for branch_name, keyword_rank_list in self.summary_rank.items():
            self.__insert_keyword_rank_list(keyword_rank_list)

        for branch_name, keyword_data_list in self.summary_data.items():
            self.__insert_keyword_data_list(keyword_data_list)

    @func_logger
    def __do_process(self, branch_ids, branch_name):
        m_top100 = self.__extract_top100(branch_ids, branch_name, KeywordDashboardAdvBatchJob.SOURCE_DICT["members"])
        f_top100 = self.__extract_top100(branch_ids, branch_name, KeywordDashboardAdvBatchJob.SOURCE_DICT["finder"])

        self.summary_rank[branch_name] = m_top100 + f_top100

        m_data_list = self.__extract_keyword_data_list(
            branch_ids, branch_name, m_top100[0:10], KeywordDashboardAdvBatchJob.SOURCE_DICT["members"])

        f_data_list = self.__extract_keyword_data_list(
            branch_ids, branch_name, f_top100[0:10], KeywordDashboardAdvBatchJob.SOURCE_DICT["finder"])

        self.summary_data[branch_name] = m_data_list + f_data_list

    @func_logger
    def __extract_top100(self, branch_ids, branch_name, source):
        top100 = []

        sql = file_util.load_file(__file__, 'sql/dashboard_adv/ext_dashboard_keyword_rank.sql')
        params = {
            'start_date': self.start_date,
            'end_date': self.end_date,
            'branch_ids': branch_ids,
            'source': source
        }

        return_rows = self.reader.read(sql, params)

        df = pd.DataFrame(return_rows, columns=['keyword', 'keyword_idx', 'cnt'])
        df.index = np.arange(1, len(df) + 1)

        for index, row in df.iterrows():
            keyword, keyword_idx, cnt = row
            top100.append((branch_name, source, keyword, int(cnt), int(index), self.period))

            if index <= 10:
                if source == KeywordDashboardAdvBatchJob.SOURCE_DICT["members"]:
                    self.m_top10_id2word[keyword_idx] = keyword
                    self.m_top10_word2id[keyword] = keyword_idx
                else:
                    self.f_top10_id2word[keyword_idx] = keyword
                    self.f_top10_word2id[keyword] = keyword_idx

        return top100

    @func_logger
    def __extract_keyword_data_list(self, branch_ids, branch_name, top_10, source):
        keyword_list = []
        data_list = []
        for row in top_10:
            branch_name, source, keyword, cnt, rank, period = row
            if source == 0:
                k = self.m_top10_word2id.get(keyword)
            else:
                k = self.f_top10_word2id.get(keyword)
            keyword_list.append(k)

        if len(keyword_list) > 1:
            keyword_idx_list = tuple(keyword_list)

            sql = file_util.load_file(__file__, 'sql/dashboard_adv/ext_dashboard_keyword_%s.sql' % self.period)
            params = {
                'start_date': self.__get_start_date(self.period),
                'end_date': self.end_date,
                'branch_ids': branch_ids,
                'branch_name': branch_name,
                'keyword_idx_list': keyword_idx_list,
                'source': source,
                'period': self.period
            }

            data_list = self.reader.read(sql, params)

        return data_list

    def __insert_keyword_rank_list(self, keyword_rank_list):
        sql = file_util.load_file(__file__, 'sql/dashboard_adv/ins_dashboard_keyword_rank.sql')
        data_list = []
        for row in keyword_rank_list:
            branch_name, source, keyword, cnt, rank, period = row
            data_list.append((branch_name, source, keyword, int(cnt), int(rank), period))

        self.writer.write(data_list, sql)

    def __insert_keyword_data_list(self, keyword_data_list):
        data_list = []
        sql = file_util.load_file(__file__, 'sql/dashboard_adv/ins_dashboard_keyword.sql')
        for row in keyword_data_list:
            date, source, branch_name, keyword_idx, cnt, period = row
            if source == 0:
                keyword = self.m_top10_id2word.get(keyword_idx)
            else:
                keyword = self.f_top10_id2word.get(keyword_idx)

            data_list.append((date, source, branch_name, keyword, int(cnt), period))

        self.writer.write(data_list, sql)

    def __delete_dashboard_keywords(self):
        sql = file_util.load_file(__file__, 'sql/dashboard_adv/del_dashboard_keyword.sql')
        params = {'period': self.period}

        self.writer.query(sql=sql, param=params)

    def __get_start_date(self, period):
        if period == "day":
            start_date = self.end_date - timedelta(days=10)
        elif period == "week":
            diff = ((self.end_date.weekday() + 1) % 7) + 49
            start_date = self.end_date - timedelta(days=diff)

        return start_date
