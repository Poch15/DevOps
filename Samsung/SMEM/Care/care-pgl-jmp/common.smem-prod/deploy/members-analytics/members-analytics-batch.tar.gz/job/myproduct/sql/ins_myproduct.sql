INSERT INTO v3_myproduct_summary
  (datetime, branch_id, model, req_type, category, status, cnt)
VALUES