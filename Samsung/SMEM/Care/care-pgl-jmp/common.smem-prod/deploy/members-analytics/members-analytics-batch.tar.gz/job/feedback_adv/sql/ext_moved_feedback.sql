SELECT
 DATE_FORMAT(crt_dt,'%Y-%m-%d') AS DATE,
  feedback.branch_id AS branch_id,
  feedback.model_name AS model_name,
  CASE WHEN fb_hist_latest_moved.main_type = 1 THEN 3
       WHEN fb_hist_latest_moved.main_type = 3 THEN 1
       ELSE fb_hist_latest_moved.main_type
  END AS original_main_type,
  CASE WHEN feedback.main_type = 1 THEN 3
       WHEN feedback.main_type = 3 THEN 1
       ELSE feedback.main_type
  END AS moved_main_type,
  CASE WHEN fb_hist_latest_moved.cat_id IS NULL THEN feedback.cat_id
       ELSE fb_hist_latest_moved.cat_id
  END AS original_cat_id,
  feedback.cat_id AS moved_cat_id,
  feedback.app_id AS app_id,
  feedback.beta_prj_id AS beta_prj_id,
  feedback.prd_cat AS prd_cat,
  COUNT(*) AS cnt
FROM
(
    SELECT A.fb_id, fb_hist.main_type, fb_hist.sub_type
    FROM fb_hist
    INNER JOIN
      (
        SELECT fb_id, MAX(hist_id) AS hist_id
	      FROM fb_hist
	      WHERE
	        crt_dt >= '{start_dt}'
	      AND
	        crt_dt < '{end_dt}'
	      AND
	        hist_type = 3
	      GROUP BY fb_id
      ) AS A
    ON A.hist_id = fb_hist.hist_id
) AS fb_hist_new_moved
INNER JOIN
(
    SELECT A.fb_id, fb_hist.main_type, fb_hist.sub_type, fb_hist.cat_id
    FROM fb_hist
    INNER JOIN
      (
        SELECT fb_id, MAX(hist_id) AS hist_id
	      FROM fb_hist
        WHERE
          crt_dt < '{start_dt}'
        AND
          (hist_type = 0 OR hist_type = 3)
        GROUP BY fb_id
      ) AS A
    ON A.hist_id = fb_hist.hist_id
) AS fb_hist_latest_moved
ON fb_hist_new_moved.fb_id = fb_hist_latest_moved.fb_id
INNER JOIN feedback
ON fb_hist_latest_moved.fb_id = feedback.fb_id
GROUP BY DATE, branch_id, model_name, original_cat_id, moved_cat_id, original_main_type, moved_main_type, beta_prj_id, app_id, prd_cat