SELECT date_trunc('day', timestamp)::date as date, branch_id, model, extra_info ->> 'filter' as category, count(*) as cnt
FROM uldata2
WHERE
createdatetime >= '{start_dt}'
AND
createdatetime < '{end_dt}'
AND
page_id = 'SNT1'
AND
event_target_id IN ('ENT3', 'ENT14')
AND
extra_info IS NOT NULL
AND
extra_info ->> 'filter' != ''
GROUP BY date, branch_id, model, category