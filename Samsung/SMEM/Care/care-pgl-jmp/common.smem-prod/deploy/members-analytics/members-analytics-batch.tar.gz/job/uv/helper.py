#!/usr/bin/python3
# -*- coding: utf-8 -*-

import time
from datetime import timedelta

from utils import elasticsearch_util


def get_raw_data(_start_dt, _end_dt, _type):
    if _type is 'UV':
        index = elasticsearch_util.API_SUCCESS_INDEX
        id_field_name = 'membersId'

        request_body_global = __get_api_access_log_query_body_global(_start_dt, _end_dt)
        request_body_china = __get_api_access_log_query_body_china(_start_dt, _end_dt)

        ud_list = __get_raw_data_list(index, request_body_global, id_field_name, _start_dt)
        ud_list_china = __get_raw_data_list(index, request_body_china, id_field_name, _start_dt)

        ud_list.extend(ud_list_china)

    elif _type is 'UD':
        index = elasticsearch_util.USABILITY_INDEX
        request_body = __get_usability_log_query_body(_start_dt, _end_dt)
        id_field_name = 'deviceUID'

        ud_list = __get_raw_data_list(index, request_body, id_field_name, _start_dt)
    else:
        return []

    return ud_list


def __get_raw_data_list(index, request_body, id_field_name, _start_dt):
    elasticsearch_util.disable_unused_log()
    es_connection = elasticsearch_util.get_connection()

    scroll_info = elasticsearch_util.set_search_scroll(es_connection, index, request_body)
    ud_list = __get_raw_data_scroll(es_connection, scroll_info, id_field_name)

    # fill current datetime in hourly uv
    ud_list = [row + (_start_dt,) for row in ud_list]

    return ud_list


def __get_raw_data_scroll(_es_connection, scroll_info, id_field_name):
    sid = scroll_info['_scroll_id']
    scroll_size = scroll_info['hits']['total']['value']
    ret_set = set()

    # get all scroll
    while scroll_size > 0:
        scroll_result = elasticsearch_util.get_search_scroll_result(_es_connection, sid)

        # Update the scroll ID
        sid = scroll_result['_scroll_id']
        # Get the number of results that we returned in the last scroll
        scroll_size = len(scroll_result['hits']['hits'])
        if scroll_size < 0:
            continue

        ret_set = ret_set.union(__convert_set(scroll_result, id_field_name))

    return list(ret_set)


def __convert_set(scroll_result, id_field_name):
    ud_set = set()
    for _data in scroll_result['hits']['hits']:
        identifier = _data['_source'].get(id_field_name, None)
        guid = _data['_source'].get('guid', None)
        branch_id = _data['_source'].get('branchId', None)
        model = _data['_source'].get('model', None)
        serial = _data['_source'].get('serial', None)
        country = _data['_source'].get('country', None)

        if not identifier or not branch_id or not model or not serial:
            continue

        ud_set.add((identifier, guid, int(branch_id), model, serial, country))

    return ud_set


def __get_usability_log_query_body(start_datetime, end_datetime):
    return {
        "query": {
            "filtered": {
                "query": {
                    "match_all": {}
                },
                "filter": {
                    "bool": {
                        "must": [
                            {
                                "range": {
                                    "client_createTime": {
                                        "gte": __datetime_to_unixtimestamp(start_datetime),
                                        "lt": __datetime_to_unixtimestamp(end_datetime)
                                    }
                                }
                            },
                        ]
                    }
                }
            }
        },
        "fields": ['deviceUID', 'branchId', 'model'],
    }


def __get_api_access_log_query_body_global(start_datetime, end_datetime):
    return {
        "query": {
            "bool": {
                "must": [
                    {"exists": {"field": "model"}},
                    {"exists": {"field": "branchId"}},
                    {"exists": {"field": "country"}},
                    {"exists": {"field": "membersId"}},
                    {"exists": {"field": "serial"}}
                ],
                "must_not": [
                    {"term": {"model": ""}},
                    {"term": {"branchId": ""}},
                    {"term": {"country": ""}},
                    {"term": {"membersId.keyword": ""}},
                    {"term": {"serial.keyword": ""}},
                    {"match_phrase": {"branchId": "3"}}
                ],
                "filter": [
                    {
                        "range": {
                            "@timestamp": {
                                "gte": start_datetime,
                                "lt": end_datetime
                            }
                        }
                    }
                ]
            }
        },
        "_source": ['membersId', 'guid', 'branchId', 'model', 'serial', 'country']
    }


def __get_api_access_log_query_body_china(start_datetime, end_datetime):
    return {
        "query": {
            "bool": {
                "must": [
                    {"exists": {"field": "model"}},
                    {"exists": {"field": "branchId"}},
                    {"exists": {"field": "country"}},
                    {"exists": {"field": "membersId"}},
                    {"exists": {"field": "serial"}},
                    {"match": {"eulaAgreement": "true"}},
                    {"match_phrase": {"branchId": "3"}}
                ],
                "must_not": [
                    {"term": {"model": ""}},
                    {"term": {"branchId": ""}},
                    {"term": {"country": ""}},
                    {"term": {"membersId.keyword": ""}},
                    {"term": {"serial.keyword": ""}}
                ],
                "filter": [
                    {
                        "range": {
                            "@timestamp": {
                                "gte": start_datetime,
                                "lt": end_datetime
                            }
                        }
                    }
                ]
            }
        },
        "_source": ['membersId', 'guid', 'branchId', 'model', 'serial', 'country']
    }


def __datetime_to_unixtimestamp(_datetime):
    utc_offset = (-1) * (time.timezone / 3600)
    _datetime = _datetime + timedelta(hours=utc_offset)
    return (time.mktime(_datetime.timetuple()) * 1000) + int(_datetime.time().microsecond)
