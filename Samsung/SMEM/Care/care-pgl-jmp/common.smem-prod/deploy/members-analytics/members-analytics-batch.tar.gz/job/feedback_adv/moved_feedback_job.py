#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from common.base.base_batch_job import BaseBatchJob
from common.base.writer import PostgresqlWriter
from utils import file_util
from common.logger import func_logger, Logger
from common.base.reader import MysqlReader
from pandas import DataFrame


read_sql = file_util.load_sql_in_cur_dir('sql', 'ext_moved_feedback.sql')
write_sql = file_util.load_sql_in_cur_dir('sql', 'ins_feedback.sql')


class MovedFeedbackBatchJob(BaseBatchJob):
    def __init__(self, _start_dt, _end_dt):
        BaseBatchJob.__init__(self, _start_dt, _end_dt)
        self.reader = MysqlReader(read_sql)
        self.writer = PostgresqlWriter()
        self.moved_fb_list = []
        self.src_fb_list = []
        self.dst_fb_list = []
        self.summary_src_fb_list = []
        self.summary_dst_fb_list = []

        self.logger = Logger(__file__)
        self.logger.start_batch()

    def __del__(self):
        BaseBatchJob.__del__(self)
        self.logger.end_batch()

    @func_logger
    def do_read(self):
        self.moved_fb_list = self.reader.read(param=self.date)

    @func_logger
    def do_process(self):
        for row in self.moved_fb_list:
            date, branch_id, model, src_main_type, dst_main_type, \
            src_cat_id, dst_cat_id, app_id, beta_prj_id, prd_cat, cnt = row

            self.src_fb_list.append((date, branch_id, model, src_main_type, src_cat_id,
                                     app_id, beta_prj_id, prd_cat, cnt))
            self.dst_fb_list.append((date, branch_id, model, dst_main_type, dst_cat_id,
                                     app_id, beta_prj_id, prd_cat, cnt))

        df_columns = ['date', 'branch_id', 'model', 'main_type', 'cat_id', 'app_id', 'beta_prj_id', 'prd_cat']
        df_cnt_columns = df_columns + ['cnt']
        src_fb_df = DataFrame(data=self.src_fb_list, columns=df_cnt_columns)
        summary_src_fb_df = src_fb_df.groupby(df_columns).sum()
        for index, count in zip(summary_src_fb_df.index, summary_src_fb_df.values):
            date, branch_id, model, main_type, cat_id, app_id, beta_prj_id, prd_cat = index
            self.summary_src_fb_list.append((date, branch_id, model, main_type, cat_id, app_id,
                                             beta_prj_id, prd_cat, int(count[0])))

        dst_fb_df = DataFrame(data=self.dst_fb_list, columns=df_cnt_columns)
        summary_dst_fb_df = dst_fb_df.groupby(df_columns).sum()
        for index, count in zip(summary_dst_fb_df.index, summary_dst_fb_df.values):
            date, branch_id, model, main_type, cat_id, app_id, beta_prj_id, prd_cat = index
            self.summary_dst_fb_list.append((date, branch_id, model, main_type, cat_id, app_id,
                                             beta_prj_id, prd_cat, int(count[0])))

    @func_logger
    def do_write(self):
        upt_src_fb_sql = file_util.load_file(__file__, 'sql/upt_src_feedback.sql')
        upt_dst_fb_sql = file_util.load_file(__file__, 'sql/upt_dst_feedback.sql')

        self.writer.write(self.summary_src_fb_list, write_sql, upt_src_fb_sql)
        self.writer.write(self.summary_dst_fb_list, write_sql, upt_dst_fb_sql)
