SELECT ROW_TO_JSON(A)::TEXT FROM
(SELECT id, deviceuid AS serial_no,
type, page_id, event_target_id, event_action,
timestamp, createdatetime, extra_info, transaction_id,
branch_id, model, app_id, app_version, os_version,
lang, csc, user_id, mcc, device_fp
FROM uldata2
WHERE createdatetime >= '{from}'
AND createdatetime < '{to}'
) AS A;