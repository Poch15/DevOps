import abc


class ElasticSearchQuery(metaclass=abc.ABCMeta):

    def __init__(self):
        pass

    @abc.abstractmethod
    def convert_list(self):
        pass

    @abc.abstractmethod
    def query(self, *args, **kwargs):
        pass
