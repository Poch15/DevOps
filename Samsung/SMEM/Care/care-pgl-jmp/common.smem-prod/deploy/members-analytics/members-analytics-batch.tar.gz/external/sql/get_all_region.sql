SELECT DISTINCT(region)
FROM branch
ORDER BY region