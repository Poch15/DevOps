#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from common.base.base_batch_job import BaseBatchJob
from common.logger import func_logger
from utils import file_util
from common.base.reader import PostgresqlReader
from common.base.writer import PostgresqlWriter

read_sql = file_util.load_sql_in_cur_dir('sql', 'ext_myproduct.sql')
write_sql = file_util.load_sql_in_cur_dir('sql', 'ins_myproduct.sql')


class MyProductSummaryJob(BaseBatchJob):

    def __init__(self, _start_dt, _end_dt):
        BaseBatchJob.__init__(self, _start_dt, _end_dt)
        self.reader = PostgresqlReader(read_sql)
        self.writer = PostgresqlWriter(write_sql)

        self.mp_list = list()
        self.summary = None

    @func_logger
    def do_read(self):
        ret_rows = self.reader.read(param=self.date)

        for row in ret_rows:
            dt, branch_id, model, req_type, category, status, cnt = row
            self.mp_list.append((dt, branch_id, model, req_type, category, status, cnt))

    @func_logger
    def do_process(self):
        None

    @func_logger
    def do_write(self):
        self.writer.write(self.mp_list)
