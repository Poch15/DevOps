#!/usr/bin/python3
# -*- coding: utf-8 -*-


from common.base.base_batch_job import BaseBatchJob
from common.logger import func_logger, Logger
from utils import file_util
from common.base.reader import PostgresqlReader
from common.base.writer import PostgresqlWriter


class ArticleLikeBatchJob(BaseBatchJob):
    def __init__(self, _start_dt, _end_dt):
        BaseBatchJob.__init__(self, _start_dt, _end_dt)
        self.reader = PostgresqlReader()
        self.writer = PostgresqlWriter()
        self.like_list = list()

        self.logger = Logger(__file__)
        self.logger.start_batch()

    def __del__(self):
        BaseBatchJob.__del__(self)
        self.logger.end_batch()

    @func_logger
    def do_read(self):
        ext_sql = file_util.load_file(__file__, 'sql/article/ext_article_like.sql')
        self.like_list = self.reader.read(ext_sql, self.date)

    @func_logger
    def do_process(self):
        pass

    @func_logger
    def do_write(self):
        ins_add_sql = file_util.load_file(__file__, 'sql/article/ins_article_like.sql')
        self.writer.write(self.like_list, ins_add_sql)
