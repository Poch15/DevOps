import boto3
from botocore.credentials import InstanceMetadataProvider
from botocore.utils import InstanceMetadataFetcher
from config.loader import load_config
import json
import os
import logging


class Credential:
    def __init__(self):
        profile = load_config().get('profile')
        current_dir = os.path.dirname(os.path.realpath(__file__))
        credential_path = os.path.join(current_dir, '.credential.json')

        logging.getLogger('boto3').setLevel(logging.CRITICAL)
        logging.getLogger('botocore').setLevel(logging.CRITICAL)
        logging.getLogger('s3transfer').setLevel(logging.CRITICAL)
        logging.getLogger('urllib3').setLevel(logging.CRITICAL)

        if profile == 'local':
            with open(credential_path) as f:
                self.secrets = json.loads(f.read())
        else:
            secret_name = '/secret/dev/analytics'
            if profile == 'prd':
                secret_name = '/secret/prd/analytics'

            provider = InstanceMetadataProvider(iam_role_fetcher=InstanceMetadataFetcher(timeout=1000, num_attempts=2))
            credentials = provider.load().get_frozen_credentials()
            aws_access_key_id = credentials.access_key
            aws_secret_access_key = credentials.secret_key
            aws_session_token = credentials.token

            secret_client = boto3.client(service_name='secretsmanager',
                                         aws_access_key_id=aws_access_key_id,
                                         aws_secret_access_key=aws_secret_access_key,
                                         aws_session_token=aws_session_token,
                                         verify=None, config=None, region_name='ap-northeast-2')

            response = secret_client.get_secret_value(SecretId=secret_name)
            self.secrets = json.loads(response['SecretString'])

    def get_benefit_api_key(self):
        return self.secrets['benefit-api-key']

    def get_postgresql_user(self):
        return self.secrets['postgresql.user']

    def get_postgresql_password(self):
        return self.secrets['postgresql.password']

    def get_mysql_user(self):
        return self.secrets['mysql.user']

    def get_mysql_password(self):
        return self.secrets['mysql.password']

    def get_aws_s3_access_key(self):
        return self.secrets['aws.s3.access-key']

    def get_aws_s3_secret_key(self):
        return self.secrets['aws.s3.secret-key']
