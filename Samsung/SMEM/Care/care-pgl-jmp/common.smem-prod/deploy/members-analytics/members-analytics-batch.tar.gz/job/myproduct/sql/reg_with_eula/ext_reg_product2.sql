SELECT '{start_dt}', model_name, category, company_cd, COUNT(*)
FROM
(
  SELECT mp.guid, mp.prd_id, mp.model_name, mp.category
  FROM mbrs_user_eula_history PARTITION({part_name}) as eula_hist
  JOIN mp_product PARTITION({part_name}) as mp
  ON mp.guid = eula_hist.guid
  WHERE
    eula_hist.crt_dt >='{start_dt}' AND eula_hist.crt_dt < '{end_dt}'
  AND
    eula_hist.is_first = 1
  AND
    mp.crt_dt < '{start_dt}'
) as A
JOIN
(
  SELECT guid, prd_id, company_cd FROM mp_gcic_product PARTITION({part_name}) gcic
  WHERE gcic.company_cd ='C630'
) as B
ON A.guid = B.guid AND A.prd_id = B.prd_id
GROUP BY model_name, category, company_cd