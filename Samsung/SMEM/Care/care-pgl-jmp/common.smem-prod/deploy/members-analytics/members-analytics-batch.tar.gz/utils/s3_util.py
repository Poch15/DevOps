#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import boto3
from botocore.config import Config
from botocore.credentials import InstanceMetadataProvider, InstanceMetadataFetcher
from datetime import datetime
import logging
from utils import branch_util
from config.loader import load_config
from config.credential import Credential


def get_client():
    profile = load_config().get('profile')
    config_dict = load_config().get('aws')
    credential = Credential()
    verify = None
    config = None

    if profile == 'local':
        verify = config_dict.get('verify')
        config = Config(proxies={
            'http': config_dict.get('proxy'),
            'https': config_dict.get('proxy')
        })

        aws_access_key_id = credential.get_aws_s3_access_key()
        aws_secret_access_key = credential.get_aws_s3_secret_key()
        aws_session_token = None
    else:
        provider = InstanceMetadataProvider(iam_role_fetcher=InstanceMetadataFetcher(timeout=1000, num_attempts=2))
        credentials = provider.load().get_frozen_credentials()
        aws_access_key_id = credentials.access_key
        aws_secret_access_key = credentials.secret_key
        aws_session_token = credentials.token

    _client = boto3.client(service_name='s3',
                           aws_access_key_id=aws_access_key_id,
                           aws_secret_access_key=aws_secret_access_key,
                           aws_session_token=aws_session_token,
                           verify=verify, config=config, region_name='ap-northeast-2')
    return _client


def upload_file(_client, _bucket_name, local_file_path, s3_obj_path):
    with open(local_file_path, 'rb') as data:
        _client.upload_fileobj(data, _bucket_name, s3_obj_path)


def put_object(_client, _bucket_name, _bytes_object, _s3_obj_path):
    _client.put_object(
        Body=_bytes_object,
        Bucket=_bucket_name,
        Key=_s3_obj_path
    )


def create_summary_s3_obj_path(branch_id, batch_type, _str_date, ext='csv'):
    country_code = branch_util.get_country_code(branch_id)
    _date = datetime.strptime(_str_date, '%Y-%m-%d')

    file_name = "{0}_summary_{1}.{2}".format(
        batch_type, _date.strftime('%Y_%m_%d_%H'), ext
    )

    if country_code != branch_util.ALL_BRANCH:
        file_name = "{0}_{1}".format(country_code, file_name)

    s3_obj_path = "{0}/summary/{1}/{2}/{3}".format(
        country_code, batch_type, _date.strftime('%Y/%m/%d'), file_name
    )

    return s3_obj_path


def disable_unused_log():
    logging.getLogger('boto3').propagate = False
    logging.getLogger('botocore').propagate = False
    logging.getLogger('s3transfer').propagate = False
    logging.getLogger("urllib3.connectionpool").disabled = True
    logging.getLogger('urllib3.util.retry').disabled = True
