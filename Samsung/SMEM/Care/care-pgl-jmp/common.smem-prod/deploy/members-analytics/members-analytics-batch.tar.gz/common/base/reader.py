#!/usr/bin/python3
# -*- coding: utf-8 -*-

import abc
from common.db_manager import MysqlManager, PostgresqlManager
from utils import elasticsearch_util


class BaseReader(metaclass=abc.ABCMeta):

    def __init__(self):
        pass

    @abc.abstractmethod
    def read(self, *args, **kwargs):
        pass

    @abc.abstractmethod
    def close(self):
        pass


class MysqlReader(BaseReader):
    def __init__(self, sql=None):
        super().__init__()
        self.mysql_db = MysqlManager()
        self.sql = sql

    def read(self, sql=None, param=None):
        if sql is None:
            sql = self.sql

        return self.mysql_db.query_with_results(sql, param)

    def close(self):
        self.mysql_db.close()


class PostgresqlReader(BaseReader):
    def __init__(self, sql=None, env=None):
        super().__init__()
        self.postgres_db = PostgresqlManager(env)
        self.sql = sql

    def read(self, sql=None, param=None):
        if sql is None:
            sql = self.sql

        return self.postgres_db.query_with_results(sql, param)

    def get_cursor(self):
        return self.postgres_db.get_cursor()

    def close(self):
        self.postgres_db.close()


class ElasticSearchReader(BaseReader):
    def __init__(self, es_query=None):
        super().__init__()
        self.es_connection = elasticsearch_util.get_connection()
        self.convert_list = es_query.convert_list
        self.query = es_query.query

    def read(self, start_dt=None, end_dt=None, param=None):
        elasticsearch_util.disable_unused_log()
        index = elasticsearch_util.KAFKA_USAGELOG_INDEX

        query = self.query(start_dt, end_dt, param)

        scroll_info = elasticsearch_util.set_search_scroll(self.es_connection, index, query)

        sid = scroll_info['_scroll_id']
        scroll_size = scroll_info['hits']['total']['value']

        summary_list = self.convert_list(scroll_info)

        # get all scroll
        while scroll_size > 0:
            scroll_result = elasticsearch_util.get_search_scroll_result(self.es_connection, sid)

            # Update the scroll ID
            sid = scroll_result['_scroll_id']
            # Get the number of results that we returned in the last scroll
            scroll_size = len(scroll_result['hits']['hits'])
            if scroll_size > 0:
                return_list = self.convert_list(scroll_result)
                summary_list.extend(return_list)

        return summary_list

    def close(self):
        pass
