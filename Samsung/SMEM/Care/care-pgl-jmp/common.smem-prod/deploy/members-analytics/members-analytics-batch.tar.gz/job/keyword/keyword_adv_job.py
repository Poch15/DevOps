#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from common.base.base_batch_job import BaseBatchJob
from common.base.reader import PostgresqlReader
from common.base.writer import PostgresqlWriter
from common.logger import func_logger
from utils import file_util

import pandas as pd

read_sql = file_util.load_sql_in_cur_dir('sql', 'v3_ext_keyword.sql')
write_sql = file_util.load_sql_in_cur_dir('sql', 'v3_ins_keyword.sql')

ins_keyword_dict_sql = file_util.load_sql_in_cur_dir('sql', 'keyword_dict_ins.sql')
upt_keyword_dict_sql = file_util.load_sql_in_cur_dir('sql', 'keyword_dict_upt.sql')
ext_keyword_dict_sql = file_util.load_sql_in_cur_dir('sql', 'keyword_dict_ext.sql')


class KeywordAdvBatchJob(BaseBatchJob):

    def __init__(self, _start_dt, _end_dt):
        BaseBatchJob.__init__(self, _start_dt, _end_dt)

        self.reader = PostgresqlReader()
        self.writer = PostgresqlWriter()

        self.summary_list = list()

        self.keyword_dict = dict()
        self.keyword_list = list()
        self.df = None

    @func_logger
    def do_read(self):
        rows = self.reader.read(sql=read_sql, param=self.date)
        self.df = pd.DataFrame(rows, columns=['date', 'branch_id', 'dvc_model', 'keyword', 'source', 'cnt'])

        self.keyword_list = self.df['keyword'].unique().tolist()

    @func_logger
    def do_process(self):
        self.__insert_keyword_dict()

        rows = self.__get_updated_keyword_dict()
        for idx, keyword in rows:
            self.keyword_dict[keyword] = idx

        self.df['keyword_id'] = self.df['keyword'].map(self.keyword_dict)
        self.df = self.df.drop('keyword', axis=1)

    @func_logger
    def __insert_keyword_dict(self):
        summary_insert_list = [(keyword,) for keyword in self.keyword_list]

        self.writer.write(summary_insert_list, ins_keyword_dict_sql, upt_keyword_dict_sql)

    @func_logger
    def __get_updated_keyword_dict(self):
        cursor = self.reader.get_cursor()
        param_text = ','.join(cursor.mogrify('%s', (row,)).decode('utf-8') for row in self.keyword_list)
        cursor.execute(ext_keyword_dict_sql + '(' + param_text + ')')

        return cursor.fetchall()

    @func_logger
    def do_write(self):
        for idx, row in self.df.iterrows():
            date, branch_id, model, source, cnt, keyword_id = row
            self.summary_list.append((date, branch_id, model, source, int(cnt), keyword_id))

        self.writer.write(self.summary_list, write_sql)
