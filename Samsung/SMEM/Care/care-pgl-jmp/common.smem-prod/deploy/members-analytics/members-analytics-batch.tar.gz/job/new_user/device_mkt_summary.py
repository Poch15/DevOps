#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from common.base.base_batch_job import BaseBatchJob
from common.base.reader import PostgresqlReader
from common.base.reader import MysqlReader
from common.base.writer import PostgresqlWriter
from common.logger import func_logger, Logger
from utils import file_util

from pandas import DataFrame


class UserDeviceMkt(BaseBatchJob):
    HQ_BRANCH_NAME = 'All'

    def __init__(self, _start_dt, _end_dt):
        BaseBatchJob.__init__(self, _start_dt, _end_dt)

        self.ext_mkt_sql = file_util.load_file(__file__, 'sql/ext_mkt.sql')
        self.ext_mkt_user_dvc_sql1 = file_util.load_file(__file__, 'sql/ext_mkt_user_dvc1.sql')
        self.ext_mkt_user_dvc_sql2 = file_util.load_file(__file__, 'sql/ext_mkt_user_dvc2.sql')

        self.ins_mkt_sql = file_util.load_sql_in_cur_dir('sql/ins_mkt.sql')

        self.end_date = _end_dt
        self.start_date = _start_dt

        self.reader = MysqlReader()
        self.preader = PostgresqlReader()
        self.writer = PostgresqlWriter()

        self.summary_list = []
        self.dvc_2_mkt = {}
        self.summary_df = None

    @func_logger
    def do_read(self):
        rows = self.reader.read(self.ext_mkt_sql)
        for dvc_model, name in rows:
            self.dvc_2_mkt[dvc_model] = name

        temp_list = self.preader.read(self.ext_mkt_user_dvc_sql1)
        self.summary_list.extend(temp_list)

        temp_list2 = self.preader.read(self.ext_mkt_user_dvc_sql2)
        self.summary_list.extend(temp_list2)

    @func_logger
    def do_process(self):
        summary_df = DataFrame(data=self.summary_list, columns=['model', 'cnt'])
        result_df = summary_df.groupby(['model']).sum()

        result_df['mkt'] = result_df.index.to_series().map(self.dvc_2_mkt)
        result_df['mkt'].fillna("ETC", inplace=True)
        # result_df["mkt"].fillna(result_df.index.to_series(), inplace=True)

        self.summary_df = result_df.groupby(['mkt'])['cnt'].sum()
        None

    @func_logger
    def do_write(self):
        total_list = []
        for idx, count in zip(self.summary_df.index, self.summary_df.values):
            total_list.append((idx, int(count)))

        self.writer.write(total_list, self.ins_mkt_sql)


if __name__ == '__main__':
    logger = Logger(__file__)
    logger.start_batch()

    try:
        UserDeviceMkt('2019-01-01', '2019-01-02').execute()

    except Exception as e:
        logger.error(str(e))
