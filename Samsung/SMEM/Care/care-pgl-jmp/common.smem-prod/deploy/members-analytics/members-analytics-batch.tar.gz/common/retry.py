#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import time
import logging


def retry(tries=3, delay=15, backoff=2):
    """
    Retry calling the decorated function

    :param tries: Number of times to try (not retry) before giving up.
    :param delay: Initial delay between retries in seconds.
    :param backoff: Back off multiplier (e.g. value of 2 will double the delay
            each retry).
    """
    tries = int(tries)
    if tries <= 0:
        raise ValueError("tries must be integer greater than 0")
    if delay <= 0:
        raise ValueError("delay must be greater than 0")
    if backoff <= 0:
        raise ValueError("backoff must be greater than 0")

    def decorator_retry(func):

        def _wrapper(*args, **kwargs):

            delay_time = delay
            for retry_cnt in range(0, tries):

                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    msg = 'Retrying in {} seconds... {}'.format(delay_time, e)
                    logging.warning(msg)

                    time.sleep(delay_time)
                    delay_time *= backoff

            return func(*args, **kwargs)

        return _wrapper

    return decorator_retry
