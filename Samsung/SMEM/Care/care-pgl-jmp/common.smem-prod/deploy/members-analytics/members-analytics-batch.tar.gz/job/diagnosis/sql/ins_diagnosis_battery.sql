INSERT INTO v3_diagnosis_battery
  (datetime, branch_id, model, is_auto, result, cnt)
VALUES