#!/usr/bin/python
# -*- coding: utf-8 -*-

import json
from external import branch_inf
from common.logger import Logger, load_config
import http.client
from config.credential import Credential


class ResponseException(Exception):
    def __init__(self, status):
        self.status = status


class BenefitInf:
    COUPON = "COUPON"
    OFFER = "OFFER"

    EU = "EU"
    CIS = "CIS"
    LA = "LA"
    NA = "NA"
    AP = "AP"

    def __init__(self):
        self.logger = Logger(__file__)
        benefit_config = load_config().get('loyalty')
        credential = Credential()

        loyalty_domain_eu = benefit_config.get('LOYALTY_DOMAIN_EU')
        loyalty_domain_us = benefit_config.get('LOYALTY_DOMAIN_US')
        loyalty_domain_ap = benefit_config.get('LOYALTY_DOMAIN_AP')
        loyalty_offer_url = benefit_config.get('LOYALTY_OFFER_URL')
        loyalty_coupon_url = benefit_config.get('LOYALTY_COUPON_URL')

        self.proxy = False
        proxy = benefit_config.get('PROXY_HOST', None)
        if proxy is not None:
            self.proxy = True
            self.proxy_host = benefit_config.get('PROXY_HOST')
            self.proxy_port = benefit_config.get('PROXY_PORT')

        self.domain = {
            BenefitInf.EU: loyalty_domain_eu,
            BenefitInf.CIS: loyalty_domain_eu,
            BenefitInf.LA: loyalty_domain_us,
            BenefitInf.NA: loyalty_domain_us,
            BenefitInf.AP: loyalty_domain_ap
        }

        self.headers = {
            "auth": credential.get_benefit_api_key(),
            "cache-control": "no-cache",
            "content-type": "application/json"
        }
        self.offer_url = loyalty_offer_url
        self.cpn_url = loyalty_coupon_url

    @staticmethod
    def is_eu_region(region):
        return BenefitInf.EU == region or BenefitInf.CIS == region

    @staticmethod
    def is_us_region(region):
        return BenefitInf.NA == region or BenefitInf.LA == region

    def get_active_dict(self, obj, object_ids):
        eu_objects = list()
        us_objects = list()
        ap_objects = list()
        region_dict = branch_inf.get_all_region_dict()

        for row in object_ids:
            obj_id, branch_id = row
            region = region_dict.get(branch_id, None)
            if BenefitInf.is_eu_region(region):
                eu_objects.append(obj_id)
            elif BenefitInf.is_us_region(region):
                us_objects.append(obj_id)
            else:
                ap_objects.append(obj_id)

        ret_dict = dict()
        if len(eu_objects) > 0:
            ret_dict.update(self.__get_active_dict(
                obj, self.domain[BenefitInf.EU], eu_objects))

        if len(us_objects) > 0:
            ret_dict.update(self.__get_active_dict(
                obj, self.domain[BenefitInf.LA], us_objects))

        if len(ap_objects) > 0:
            ret_dict.update(self.__get_active_dict(
                obj, self.domain[BenefitInf.AP], ap_objects))

        return ret_dict

    def __get_active_dict(self, obj, host, objects):
        if BenefitInf.OFFER == obj:
            return self.__get_offer_dict(host, objects)
        elif BenefitInf.COUPON == obj:
            return self.__get_coupon_dict(host, objects)

    def __get_offer_dict(self, host, body):
        title_dict = dict()
        try:
            if self.proxy is False:
                conn = http.client.HTTPSConnection(host)
            else:
                conn = http.client.HTTPSConnection(self.proxy_host, self.proxy_port)
                conn.set_tunnel(host)

            conn.request("POST", self.offer_url, json.dumps(body), self.headers)
            response = conn.getresponse()
            if not 200 <= response.status < 300:
                raise ResponseException(response.status)
            data = json.loads(response.read().decode('utf-8'))

            offers = data['detail']['offerTitleList']
            for offer in offers:
                title_dict[offer['offerId']] = offer['countryCode']

        except ResponseException as e:
            self.logger.error(e)
        except Exception as e:
            self.logger.error(e)

        return title_dict

    def __get_coupon_dict(self, host, body):
        title_dict = {}
        try:
            if self.proxy is False:
                conn = http.client.HTTPSConnection(host)
            else:
                conn = http.client.HTTPSConnection(self.proxy_host, self.proxy_port)
                conn.set_tunnel(host)

            conn.request("POST", self.cpn_url, json.dumps(body), self.headers)
            response = conn.getresponse()
            if not 200 <= response.status < 300:
                raise ResponseException(response.status)
            data = json.loads(response.read().decode('utf-8'))

            coupons = data['detail']['couponTitleList']
            for coupon in coupons:
                title_dict[coupon['couponId']] = coupon['countryCode']

        except ResponseException as e:
            self.logger.error(e)
        except Exception as e:
            self.logger.error(e)

        return title_dict
