#!/usr/bin/python3
# -*- coding: utf-8 -*-

from common.base.base_batch_job import BaseBatchJob
from common.logger import func_logger, Logger
from job.journey.journey_job import JourneyJob
from utils import file_util, args_util
from common.base.reader import MysqlReader


class JourneyJobExecutor(BaseBatchJob):

    def __init__(self, _start_dt, _end_dt):
        BaseBatchJob.__init__(self, _start_dt, _end_dt)
        self.branch_id_list = list()
        self.reader = MysqlReader()

    @func_logger
    def do_read(self):
        branch_id_list_sql = file_util.load_file(__file__, 'sql/get_branch_id_list.sql')
        self.branch_id_list = self.reader.read(branch_id_list_sql, self.date)

    @func_logger
    def do_process(self):
        for branch_id in self.branch_id_list:
            JourneyJob(start_dt, end_dt, branch_id[0]).execute()

    @func_logger
    def do_write(self):
        None


if __name__ == '__main__':
    logger = Logger(__file__)
    logger.start_batch()

    try:
        start_dt, end_dt = args_util.parse_sys_argv('date', 2)

        JourneyJobExecutor(start_dt, end_dt).execute()

        logger.end_batch()

    except Exception as e:
        logger.error(str(e))
