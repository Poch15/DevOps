#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import json
from datetime import datetime
from pandas import DataFrame

from common.base.base_batch_job import BaseBatchJob
from common.base.es_query import ElasticSearchQuery
from common.logger import func_logger, Logger
from utils import args_util, file_util
from common.base.reader import MysqlReader, ElasticSearchReader
from common.base.writer import PostgresqlWriter
from job.contents.article_like_job import ArticleLikeBatchJob
from job.contents.article_bookmark_job import ArticleBookmarkBatchJob
from job.contents.article_category_job import ArticleCategoryBatchJob

read_cat_sql = file_util.load_sql_in_cur_dir('sql', 'ext_category.sql')
read_v2_cat_sql = file_util.load_sql_in_cur_dir('sql', 'ext_v2_category.sql')
ext_v2_category_parent = file_util.load_sql_in_cur_dir('sql', 'ext_v2_category_parent.sql')

write_total_sql = file_util.load_sql_in_cur_dir('sql', 'ins_contents_total_count.sql')
upsert_total_sql = file_util.load_sql_in_cur_dir('sql', 'upt_contents_total_count.sql')

write_search_total_sql = file_util.load_sql_in_cur_dir('sql', 'ins_search_contents_total.sql')

write_weblink_sql = file_util.load_sql_in_cur_dir('sql', 'ins_contents_weblink.sql')


class ContentsBatchJob(BaseBatchJob):
    # KEY : page_id
    # VALUE : [contents_type, contents_type_id, list, insert_query, writable]
    __CONTENTS_DICT = {
        "SBS23": ["notice", 1, list(), file_util.load_sql_in_cur_dir('sql', 'ins_notice.sql'), 1],
        "SNT2": ['newsntips', 2, list(), file_util.load_sql_in_cur_dir('sql', 'ins_newsntips.sql'), 1],
        "SFQ3": ['faq', 3, list(), file_util.load_sql_in_cur_dir('sql', 'ins_faq.sql'), 1],
        "SCM11": ['community', 4, list(), file_util.load_sql_in_cur_dir('sql', 'ins_community.sql'), 1],
        "SBN21": ['benefit', 5, list(), file_util.load_sql_in_cur_dir('sql', 'ins_benefit.sql'), 1],
        "SBN2": ['coupon', 6, list(), file_util.load_sql_in_cur_dir('sql', 'ins_coupon.sql'), 1],
        "SMP5": ['profile', 7, list(), file_util.load_sql_in_cur_dir('sql', 'ins_coupon.sql'), 0],
    }

    UNKNOWN_ID = '0'
    GALAXY_GIFT_ID = '-1'

    def __init__(self, _start_dt, _end_dt):
        BaseBatchJob.__init__(self, _start_dt, _end_dt)

        self.reader = ElasticSearchReader(es_query=ContentsESQuery())
        self.mysql_reader = MysqlReader()
        self.writer = PostgresqlWriter()

        self.contents_list = list()
        self.faq_list = list()
        self.faq_id_list = []
        self.df = None
        self.search_df = None

    def __del__(self):
        BaseBatchJob.__del__(self)
        if self.mysql_reader is not None:
            self.mysql_reader.close()

    @func_logger
    def do_read(self):
        ret_rows = self.reader.read(self.date.get('start_dt'), self.date.get('end_dt'))

        for row in ret_rows:
            page_id, dt, branch_id, model, extra_info = row
            content_id, referer, referer_src = self.__get_ref_content_id(page_id, extra_info)
            page_id = ContentsBatchJob.__convert_default_page_id(page_id)
            page_id, content_id = ContentsBatchJob.__convert_galaxy_gift(page_id, content_id, branch_id)

            if content_id is not None:
                self.contents_list.append((dt, branch_id, model, content_id, page_id, referer, referer_src, 1))

    @func_logger
    def do_process(self):
        self.df = DataFrame(
            data=self.contents_list,
            columns=['dt', 'branch_id', 'model', 'content_id', 'page_id', 'referer', 'referer_src', 'cnt'])

        self.search_df = self.df[self.df['referer'] == 'SBS11']

        self.df = self.df[self.df['page_id'] != 'SMP5']

    @func_logger
    def do_write(self):
        self.__insert_contents()
        self.__insert_contents_total()
        self.__insert_search_contents_total()
        self.__insert_weblink_data()

    def __get_ref_content_id(self, _page_id, _extra_info):
        if type(_extra_info) is str:
            extra_dict = json.loads(_extra_info)
        else:
            extra_dict = _extra_info

        if extra_dict is None:
            referer = self.UNKNOWN_ID
            referer_src = self.UNKNOWN_ID
            content_id = None if _page_id == 'RW037' else self.UNKNOWN_ID
        else:
            if _page_id == 'SFQ3' or _page_id == 'SBS23' or _page_id == 'SBN2' or _page_id == 'SBN21' or _page_id == 'SMP5':
                referer = extra_dict.get('referer', self.UNKNOWN_ID)
                content_id = extra_dict.get('ID', self.UNKNOWN_ID)
                if _page_id == 'SFQ3' and content_id != self.UNKNOWN_ID:
                    self.faq_id_list.append(content_id)
                if _page_id == 'SBN2':
                    content_id = extra_dict.get('couponID', self.UNKNOWN_ID)
                elif _page_id == 'SBN21':
                    content_id = extra_dict.get('benefitID', self.UNKNOWN_ID)

            elif _page_id == 'RW037':
                content_id = None
                referer = extra_dict.get('referer', self.UNKNOWN_ID)
                page_type = extra_dict.get('type', self.UNKNOWN_ID)
                if page_type == 'benefit':
                    content_id = extra_dict.get('couponID', None)

            else:  # SNT2, SCM11
                referer = extra_dict.get('Referer', self.UNKNOWN_ID)
                if referer == self.UNKNOWN_ID:
                    referer = extra_dict.get('referer', self.UNKNOWN_ID)

                if _page_id == 'SNT2':
                    content_id = extra_dict.get('id', self.UNKNOWN_ID)
                else:
                    content_id = extra_dict.get('ID', self.UNKNOWN_ID)

            referer_src = extra_dict.get('referer_src', self.UNKNOWN_ID)

        return content_id, referer, referer_src

    @func_logger
    def __insert_contents(self):
        category_dict = self.__get_category_list(read_cat_sql)
        v2_category_dict = self.__get_category_list(read_v2_cat_sql)
        v2_category_parent_dict = self.__get_v2_category_parent(v2_category_dict.values())

        summary = self.df.groupby(['dt', 'branch_id', 'model', 'content_id', 'page_id', 'referer'])['cnt'].sum()

        for idx, count in zip(summary.index, summary.values):
            dt, branch_id, model, content_id, page_id, referer = idx
            referer = self.__get_empty_value(referer)
            content_id = self.__get_empty_value(content_id)

            if ContentsBatchJob.__CONTENTS_DICT[page_id][0] == 'faq':
                if int(content_id) < 100000:
                    parent_cat_id = category_dict.get(int(content_id), 0)
                    cat_id = 0
                else:
                    cat_id = v2_category_dict.get(int(content_id), 0)
                    parent_cat_id = v2_category_parent_dict.get(cat_id, 0)

                faq_list = ContentsBatchJob.__CONTENTS_DICT[page_id][2]
                faq_list.append(
                    (dt, branch_id, model, str(content_id), referer, int(parent_cat_id), int(cat_id), int(count)))
            else:
                temp_list = ContentsBatchJob.__CONTENTS_DICT[page_id][2]
                temp_list.append((dt, branch_id, model, str(content_id), referer, int(count)))

        for key in ContentsBatchJob.__CONTENTS_DICT:
            if ContentsBatchJob.__CONTENTS_DICT[key][4] == 1:
                self.writer.write(ContentsBatchJob.__CONTENTS_DICT[key][2], ContentsBatchJob.__CONTENTS_DICT[key][3])

    @func_logger
    def __insert_contents_total(self):
        total_list = []

        summary = self.df.groupby(['branch_id', 'model', 'content_id', 'page_id'])['cnt'].sum()

        for idx, count in zip(summary.index, summary.values):
            branch_id, model, content_id, page_id = idx
            content_id = self.__get_empty_value(content_id)
            content_type = ContentsBatchJob.__CONTENTS_DICT[page_id][1]

            if content_type == 1 or content_type == 2 or content_type == 3:
                total_list.append((branch_id, model, str(content_id), content_type, int(count)))

        self.writer.write(total_list, write_total_sql, upsert_total_sql)

    @func_logger
    def __insert_weblink_data(self):
        total_list = list()

        df = self.df[self.df['referer_src'] != '0']

        summary = df.groupby(['dt', 'branch_id', 'model', 'content_id', 'page_id', 'referer_src'])['cnt'].sum()

        for idx, count in zip(summary.index, summary.values):
            dt, branch_id, model, content_id, page_id, referer_src = idx

            content_type = ContentsBatchJob.__CONTENTS_DICT[page_id][1]
            referer_src = self.__get_empty_value(referer_src)

            if self.UNKNOWN_ID != referer_src:
                total_list.append((dt, branch_id, model, content_id, content_type, referer_src, int(count)))

        self.writer.write(total_list, write_weblink_sql)

    @func_logger
    def __insert_search_contents_total(self):
        search_total_list = list()

        sdf = self.search_df[['dt', 'branch_id', 'model', 'page_id', 'cnt']]
        summary = sdf.groupby(['dt', 'branch_id', 'model', 'page_id'])['cnt'].sum()

        for idx, count in zip(summary.index, summary.values):
            dt, branch_id, model, page_id = idx
            content_type = ContentsBatchJob.__CONTENTS_DICT[page_id][1]
            search_total_list.append((dt, branch_id, model, content_type, int(count)))

        self.writer.write(search_total_list, write_search_total_sql)

    @func_logger
    def __get_category_list(self, sql):
        ret_dict = dict()
        if len(self.faq_id_list) != 0:
            self.faq_id_list = [int(faq) for faq in self.faq_id_list]
            params = self.date.copy()
            params.update({"faqIds": tuple(self.faq_id_list)})

            ret_rows = self.mysql_reader.read(sql, params)
            ret_dict = dict((x, y) for x, y in ret_rows)

        return ret_dict

    @func_logger
    def __get_v2_category_parent(self, v2_category_list):
        ret_dict = dict()
        if len(v2_category_list) != 0:
            cat_id_list = [int(cat) for cat in v2_category_list]
            params = self.date.copy()
            params.update({"catIds": tuple(cat_id_list)})

            ret_rows = self.mysql_reader.read(ext_v2_category_parent, params)
            for x, y in ret_rows:
                if y is None:
                    ret_dict[x] = x
                else:
                    ret_dict[x] = y

        return ret_dict

    def __get_empty_value(self, value):
        ret_value = self.UNKNOWN_ID if value == '' else value
        return ret_value

    @staticmethod
    def __convert_default_page_id(_page_id):
        default_page_id_dict = {
            'RW037': 'SBN2'
        }
        page_id = default_page_id_dict.get(_page_id, _page_id)

        return page_id

    @staticmethod
    def __convert_galaxy_gift(_page_id, _content_id, _branch_id):

        ret_page_id = _page_id
        ret_content_id = _content_id

        # Galaxy Gift for Thailand
        if _page_id == 'SEP3':
            ret_page_id = 'SBN21'
            ret_content_id = ContentsBatchJob.GALAXY_GIFT_ID
        if _page_id == 'SBN21' and _content_id == ContentsBatchJob.UNKNOWN_ID and _branch_id == 73:
            ret_content_id = ContentsBatchJob.GALAXY_GIFT_ID

        return ret_page_id, ret_content_id


class ContentsESQuery(ElasticSearchQuery):
    @staticmethod
    def convert_list(_scroll_result):
        result_list = list()
        for _data in _scroll_result['hits']['hits']:
            branch_id = _data['_source'].get('branchId', None)
            model = _data['_source'].get('model', None)
            page_id = _data['_source'].get('pageId', None)
            extra_info = _data['_source'].get('extraInfo', None)
            timestamp = _data['_source'].get('timestamp', None)

            timestamp = datetime.strptime(timestamp, "%Y-%m-%dT%H:%M:%S.%fZ").date()

            result_list.append((page_id, timestamp, int(branch_id), model, extra_info))

        return result_list

    @staticmethod
    def query(_start_dt, _end_dt, _param):
        return {
            "query": {
                "bool": {
                    "must": [
                        {
                            "bool": {
                                "should": [
                                    {
                                        "match_phrase": {
                                            "pageId.keyword": "SFQ3"
                                        }
                                    },
                                    {
                                        "match_phrase": {
                                            "pageId.keyword": "SNT2"
                                        }
                                    },
                                    {
                                        "match_phrase": {
                                            "pageId.keyword": "SCM11"
                                        }
                                    },
                                    {
                                        "match_phrase": {
                                            "pageId.keyword": "SBN2"
                                        }
                                    },
                                    {
                                        "match_phrase": {
                                            "pageId.keyword": "SBN21"
                                        }
                                    },
                                    {
                                        "match_phrase": {
                                            "pageId.keyword": "SEP3"
                                        }
                                    },
                                    {
                                        "match_phrase": {
                                            "pageId.keyword": "SBS23"
                                        }
                                    },
                                    {
                                        "match_phrase": {
                                            "pageId.keyword": "SMP5"
                                        }
                                    },
                                    {
                                        "match_phrase": {
                                            "pageId.keyword": "RW037"
                                        }
                                    }
                                ],
                                "minimum_should_match": 1
                            }
                        },
                        {
                            "match_phrase": {
                                "type.keyword": {
                                    "query": "pageView"
                                }
                            }
                        },
                        {
                            "range": {
                                "createTime": {
                                    "gte": _start_dt,
                                    "lt": _end_dt
                                }
                            }
                        }
                    ]
                }
            },
            "_source": ['timestamp', 'branchId', 'model', 'pageId', 'extraInfo']
        }


if __name__ == '__main__':
    logger = Logger(__file__)
    logger.start_batch()

    try:
        start_dt, end_dt = args_util.parse_sys_argv('date', 2)
        ContentsBatchJob(start_dt, end_dt).execute()
        ArticleLikeBatchJob(start_dt, end_dt).execute()
        ArticleBookmarkBatchJob(start_dt, end_dt).execute()
        ArticleCategoryBatchJob(start_dt, end_dt).execute()

        logger.end_batch()

    except Exception as e:
        logger.error(str(e))
