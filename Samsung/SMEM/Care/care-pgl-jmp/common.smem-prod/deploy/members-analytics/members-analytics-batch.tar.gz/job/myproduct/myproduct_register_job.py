#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from common.base.base_batch_job import BaseBatchJob
from common.logger import func_logger, Logger
from utils import file_util
from common.base.reader import MysqlReader
from common.base.writer import PostgresqlWriter
from pandas import DataFrame
from utils import args_util

read_sql_global = file_util.load_sql_in_cur_dir('sql', 'reg_without_eula/ext_reg_product.sql')

read_sql1_china = file_util.load_sql_in_cur_dir('sql', 'reg_with_eula/ext_reg_product1.sql')
read_sql2_china = file_util.load_sql_in_cur_dir('sql', 'reg_with_eula/ext_reg_product2.sql')

write_sql = file_util.load_sql_in_cur_dir('sql', 'ins_reg_product.sql')


class MyProductPartition:

    PREFIX = 'p'
    START = 0
    END = 36

    @staticmethod
    def get_partition_name(i):
        return '{0}{1}'.format(MyProductPartition.PREFIX, str(i))


class MyProductRegisterJob(BaseBatchJob):

    def __init__(self, _start_dt, _end_dt):
        BaseBatchJob.__init__(self, _start_dt, _end_dt)
        self.reader = MysqlReader()
        self.writer = PostgresqlWriter(write_sql)

        self.mp_list = list()
        self.summary_list = list()

    @func_logger
    def do_read(self):
        params = self.date.copy()

        # global
        for i in range(MyProductPartition.START, MyProductPartition.END):
            params.update({'part_name': MyProductPartition.get_partition_name(i)})

            result = self.reader.read(read_sql_global, params)
            self.mp_list.extend(result)

        # china
        for i in range(MyProductPartition.START, MyProductPartition.END):
            params.update({'part_name': MyProductPartition.get_partition_name(i)})

            result = self.reader.read(read_sql1_china, params)
            self.mp_list.extend(result)

        for i in range(MyProductPartition.START, MyProductPartition.END):
            params.update({'part_name': MyProductPartition.get_partition_name(i)})

            result = self.reader.read(read_sql2_china, params)
            self.mp_list.extend(result)

    @func_logger
    def do_process(self):
        summary_df = DataFrame(data=self.mp_list, columns=['dt', 'model_name', 'category', 'company_cd', 'cnt'])

        result = summary_df.groupby(['dt', 'model_name', 'category', 'company_cd'])['cnt'].sum()

        total_summary_list = []
        for index, cnt in zip(result.index, result.values):
            total_summary_list.append((str(index[0]), str(index[1]), str(index[2]), str(index[3]), int(cnt)))

        self.summary_list = total_summary_list

    @func_logger
    def do_write(self):
        self.writer.write(self.summary_list)


if __name__ == '__main__':
    logger = Logger(__file__)
    logger.start_batch()

    try:
        start_dt, end_dt = args_util.parse_sys_argv('date', 2)
        MyProductRegisterJob(start_dt, end_dt).execute()

        logger.end_batch()

    except Exception as e:
        logger.error(str(e))
