#!/usr/bin/env python3
# -*- coding: utf-8 -*-

ALL_BRANCH = 'ALL'


def is_china(branch_id):
    if branch_id == 3:
        return True
    else:
        return False


def get_country_code(branch_id):
    if is_china(branch_id):
        return 'CN'
    else:
        return ALL_BRANCH
