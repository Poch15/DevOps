ON CONFLICT (fb_id) DO UPDATE SET
crt_dt = EXCLUDED.crt_dt,
mdf_dt = EXCLUDED.mdf_dt,
branch_id = EXCLUDED.branch_id,
main_type = EXCLUDED.main_type,
sub_type = EXCLUDED.sub_type,
beta_prj_id = EXCLUDED.beta_prj_id,
fb_status = EXCLUDED.fb_status,
deleted = EXCLUDED.deleted,
app_id = EXCLUDED.app_id,
cat_id = EXCLUDED.cat_id