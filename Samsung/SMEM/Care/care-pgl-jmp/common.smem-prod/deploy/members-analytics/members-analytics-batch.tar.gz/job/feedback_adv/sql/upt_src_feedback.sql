ON CONFLICT ON CONSTRAINT v3_feedback_unique
DO UPDATE SET cnt = v3_feedback.cnt - EXCLUDED.cnt;