SELECT date_trunc('hour', timestamp) as dt, branch_id, model, req_type, category, status, count(*) as cnt
FROM v3_myproduct
WHERE
  crt_dt >='{start_dt}' AND crt_dt < '{end_dt}'
  AND status NOT IN ('E0010', 'E9999')
GROUP BY dt, branch_id, model, req_type, category, status
ORDER BY dt