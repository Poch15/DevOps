#!/bin/bash

BASE_PYTHON_PATH='/home/common/members-analytics/members-analytics-batch'
source ${BASE_PYTHON_PATH}/.venv/bin/activate
export PYTHONPATH=${BASE_PYTHON_PATH}/benefit

export from="$(date --date="1 days ago" +%Y-%m-%d)"
export to="$(date +%Y-%m-%d)"
python3 /home/common/members-analytics/members-analytics-batch/benefit/job/benefit/benefit_job.py $from $to