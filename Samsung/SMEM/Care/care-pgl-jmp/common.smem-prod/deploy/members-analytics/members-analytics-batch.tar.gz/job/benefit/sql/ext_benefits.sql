SELECT timestamp, page_id, event_target_id, branch_id, model, extra_info->'benefitID'
FROM uldata2
WHERE
  createdatetime >='{start_dt}' AND createdatetime < '{end_dt}'
  AND page_id = 'SBN21'
  AND event_target_id IN ('EBN52', 'EBN53', 'EBN54', 'EBN55', 'EBN57', 'EBN58')
  AND type = 'event'
  AND extra_info IS NOT NULL