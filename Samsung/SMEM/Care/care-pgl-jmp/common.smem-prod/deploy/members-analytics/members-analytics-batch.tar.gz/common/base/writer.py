#!/usr/bin/python3
# -*- coding: utf-8 -*-

import abc
from common.db_manager import PostgresqlManager
from utils import s3_util
from config.loader import load_config


class BaseWriter(metaclass=abc.ABCMeta):
    def __init__(self):
        pass

    @abc.abstractmethod
    def write(self, *args, **kwargs):
        pass

    @abc.abstractmethod
    def close(self):
        pass


class PostgresqlWriter(BaseWriter):
    def __init__(self, sql=None):
        super().__init__()
        self.postgres_db = PostgresqlManager()
        self.sql = sql

    def close(self):
        self.postgres_db.close()

    def write(self, _list, sql=None, update_sql=''):
        if sql is None:
            sql = self.sql

        self.postgres_db.insert_bulk(sql, _list, update_sql)

    def query(self, sql, param=None):
        self.postgres_db.query_with_commit(sql, param)


class S3Writer(BaseWriter):
    def __init__(self, s3_obj_path=None):
        super().__init__()
        s3_util.disable_unused_log()
        # TODO region change
        aws_config = load_config().get('aws')

        self.bucket_name = aws_config.get('s3').get('bucket')
        self.root_dir = aws_config.get('s3').get('root_dir')

        self.s3_client = s3_util.get_client()
        self.s3_obj_path = s3_obj_path

    def close(self):
        pass

    def write(self, _list, _s3_obj_path=None):
        if _s3_obj_path is None:
            _s3_obj_path = self.s3_obj_path
        _s3_obj_path = '{0}/{1}'.format(self.root_dir, _s3_obj_path)

        # convert list to csv list string
        str_list = str()
        for row in _list:
            str_list = str_list + ",".join(str(field) for field in row) + "\n"

        s3_util.put_object(self.s3_client, self.bucket_name, str_list.encode(), _s3_obj_path)
