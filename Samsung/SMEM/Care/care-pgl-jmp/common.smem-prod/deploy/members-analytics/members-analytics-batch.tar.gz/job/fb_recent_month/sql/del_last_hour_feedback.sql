DELETE FROM tbl_v2_fb_recent_month
WHERE
crt_dt < '{last_hour_dt}'