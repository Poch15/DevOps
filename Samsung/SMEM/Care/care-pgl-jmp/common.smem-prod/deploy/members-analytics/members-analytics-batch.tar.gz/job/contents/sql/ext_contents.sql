SELECT page_id, timestamp, branch_id, model, extra_info
FROM uldata2
WHERE
  createdatetime >='{start_dt}' AND createdatetime < '{end_dt}'
  AND (page_id IN ('SFQ3', 'SNT2', 'SCM11', 'SBN2', 'SBN21', 'SBS23', 'SMP5', 'RW037'))
  AND type = 'pageView'