#!/usr/bin/python3
# -*- coding: utf-8 -*-

from common.base.base_batch_job import BaseBatchJob
from common.base.reader import MysqlReader
from common.logger import func_logger, Logger
from io import StringIO
from config.loader import load_config
from job.big_data_dir.user_partition import UserPartition
from utils import args_util, file_util, s3_util

import pandas as pd

read_sql = file_util.load_sql_in_cur_dir('sql', 'ext_new_user.sql')


class BigDataDirBatchJob(BaseBatchJob):

    def __init__(self, _start_dt, _end_dt):
        BaseBatchJob.__init__(self, _start_dt, _end_dt)

        self.reader = MysqlReader(read_sql)
        self.summary_list = []
        self.df = None

    @func_logger
    def do_read(self):
        params = self.date.copy()

        for i in range(UserPartition.START, UserPartition.END):
            params.update({'part_name': UserPartition.get_partition_name(i)})

            result = self.reader.read(param=params)
            self.summary_list.extend(result)

    @func_logger
    def do_process(self):
        pass

    @func_logger
    def do_write(self):
        df = pd.DataFrame(self.summary_list, columns=['guid', 'last_branch', 'dvc_model', 'crt_dt', 'mkt_name', 'imei'])

        file_name = "new_members_2020_01_01_2020_05_24.csv"

        csv_buffer = StringIO()
        df.to_csv(csv_buffer, sep=",", index=False)

        aws_config = load_config().get('aws')
        s3_client = s3_util.get_client()

        bucket_name = aws_config.get('s3').get('bucket')

        s3_obj_path = "{0}/{1}".format("uv/new_members_dir", file_name)

        s3_util.put_object(s3_client, bucket_name, csv_buffer.getvalue(), s3_obj_path)


if __name__ == '__main__':
    logger = Logger(__file__)
    logger.start_batch()

    try:
        start_dt, end_dt = args_util.parse_sys_argv('date', 2)
        BigDataDirBatchJob(start_dt, end_dt).execute()
        logger.end_batch()

    except Exception as e:
        logger.error(str(e))
