#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from common.base.base_batch_job import BaseBatchJob
from common.logger import func_logger, Logger
from job.myproduct.myproduct_summary_job import MyProductSummaryJob
from job.myproduct.myproduct_register_job import MyProductRegisterJob
from utils import args_util


class MyProductBatchJob(BaseBatchJob):
    def __init__(self, _start_dt, _end_dt):
        BaseBatchJob.__init__(self, _start_dt, _end_dt)

    @func_logger
    def do_read(self):
        pass

    @func_logger
    def do_process(self):
        pass

    @func_logger
    def do_write(self):
        pass


if __name__ == '__main__':
    logger = Logger(__file__)
    logger.start_batch()

    try:
        start_dt, end_dt = args_util.parse_sys_argv('date', 2)
        MyProductSummaryJob(start_dt, end_dt).execute()
        MyProductRegisterJob(start_dt, end_dt).execute()

        logger.end_batch()

    except Exception as e:
        logger.error(str(e))
