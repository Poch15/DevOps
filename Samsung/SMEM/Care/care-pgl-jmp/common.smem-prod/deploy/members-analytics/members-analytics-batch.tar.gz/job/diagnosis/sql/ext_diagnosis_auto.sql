select timestamp, branch_id, model, extra_info
from uldata2
where createdatetime >= '{start_dt}' and createdatetime < '{end_dt}'
  and page_id = 'SPC6' and event_target_id = 'EPC71' and extra_info is not null;