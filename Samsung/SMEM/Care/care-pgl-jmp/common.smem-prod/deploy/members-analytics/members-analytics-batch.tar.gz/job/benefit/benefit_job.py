#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from common.base.base_batch_job import BaseBatchJob
from common.base.es_query import ElasticSearchQuery
from common.logger import func_logger, Logger
from external.benefit_inf import BenefitInf
from external import branch_inf
from pandas import DataFrame
from utils import args_util, file_util
from common.base.reader import ElasticSearchReader
from common.base.writer import PostgresqlWriter
from datetime import datetime

read_sql = file_util.load_sql_in_cur_dir('sql', 'ext_benefits.sql')
write_sql = file_util.load_sql_in_cur_dir('sql', 'ins_benefits.sql')


class BenefitBatchJob(BaseBatchJob):
    __PLAY = 1
    __VIEW_DETAIL = 2
    __CALL = 3
    __DOWNLOAD_COUPON = 4
    __VIEW_COUPON = 5
    __APPLY_FOR_EVENT = 6

    __TYPES = {
        'EBN52': __PLAY, 'EBN53': __VIEW_DETAIL, 'EBN54': __CALL, 'EBN55': __DOWNLOAD_COUPON,
        'EBN57': __VIEW_COUPON, 'EBN58': __APPLY_FOR_EVENT}

    def __init__(self, _start_dt, _end_dt):
        BaseBatchJob.__init__(self, _start_dt, _end_dt)

        self.reader = ElasticSearchReader(es_query=BenefitESQuery())
        self.writer = PostgresqlWriter(write_sql)

        self.benefit_list = list()
        self.benefit_summary = None
        self.summary_list = list()

        self.benefit_helper = None
        self.country_dict = branch_inf.get_all_branch_country()
        # SEUK country code of benefit is 'GB'
        self.country_dict['GB'] = 13

    @func_logger
    def do_read(self):
        self.benefit_helper = BenefitJobHelper(start_dt, end_dt)

        ret_rows = self.reader.read(self.date.get('start_dt'), self.date.get('end_dt'))

        benefit_legacy_ids = set()

        tmp_benefit_legacy_list = list()
        tmp_benefit_new_list = list()

        for row in ret_rows:
            dt, branch_id, model, benefit_id, page_id, event_target_id = row
            bnf_type = BenefitBatchJob.__TYPES[event_target_id]

            if benefit_id.startswith('_'):
                benefit_legacy_ids.add((benefit_id, branch_id))
                tmp_benefit_legacy_list.append((dt, branch_id, model, benefit_id, bnf_type, 1))
            else:
                tmp_benefit_new_list.append((dt, branch_id, model, benefit_id, bnf_type, 1))

        atv_benefit_dict = self.benefit_helper.get_active_benefits(benefit_legacy_ids)

        self.benefit_list = self.__get_active_benefit_list(
            tmp_benefit_legacy_list,
            atv_benefit_dict)

        self.benefit_list.extend(tmp_benefit_new_list)

    def __get_active_benefit_list(self, tmp_benefit_list, atv_benefit_dict):
        _benefit_list = list()
        for row in tmp_benefit_list:
            dt, branch, model, benefit_id, bnf_type, cnt = row
            country_code = atv_benefit_dict.get(benefit_id, None)
            if country_code is not None:
                if self.__is_match_country(branch, country_code):
                    _benefit_list.append(row)

        return _benefit_list

    def __is_match_country(self, branch_id, cnty_cd):
        ret_branch_id = self.country_dict.get(cnty_cd.upper(), None)
        return ret_branch_id is not None and ret_branch_id == branch_id

    @func_logger
    def do_process(self):
        df = DataFrame(data=self.benefit_list,
                       columns=['dt', 'branch_id', 'model', 'content_id', 'type', 'cnt'])

        self.benefit_summary = df['cnt'].groupby(
            [df['dt'], df['branch_id'], df['model'], df['content_id'], df['type']]).sum()

        for idx, cnt in zip(self.benefit_summary.index, self.benefit_summary.values):
            self.summary_list.append((idx[0], int(idx[1]), idx[2], idx[3], int(idx[4]), int(cnt)))

    @func_logger
    def do_write(self):
        self.writer.write(self.summary_list)


class BenefitJobHelper:
    def __init__(self, _start_dt, _end_dt):
        self.start_dt = _start_dt
        self.end_dt = _end_dt
        self.benefit_list = list()
        self.benefit_inf = BenefitInf()

    def get_active_benefits(self, benefits):
        return self.benefit_inf.get_active_dict(BenefitInf.OFFER, benefits)


class BenefitESQuery(ElasticSearchQuery):
    @staticmethod
    def convert_list(_scroll_result):
        result_list = list()
        for _data in _scroll_result['hits']['hits']:
            branch_id = _data['_source'].get('branchId', None)
            model = _data['_source'].get('model', None)
            page_id = _data['_source'].get('pageId', None)
            event_target_id = _data['_source'].get('eventTargetId', None)
            extra_info = _data['_source'].get('extraInfo', None)
            timestamp = _data['_source'].get('timestamp', None)

            timestamp = datetime.strptime(timestamp, "%Y-%m-%dT%H:%M:%S.%fZ").date()
            benefit_id = extra_info.get('benefitID', None)

            if benefit_id is not None:
                result_list.append((timestamp, int(branch_id), model, benefit_id, page_id, event_target_id))

        return result_list

    @staticmethod
    def query(_start_dt, _end_dt, _param):
        return {
            "query": {
                "bool": {
                    "must": [
                        {
                            "match_phrase": {
                                "pageId.keyword": {
                                    "query": "SBN21"
                                }
                            }
                        },
                        {
                            "match_phrase": {
                                "type.keyword": {
                                    "query": "event"
                                }
                            }
                        },
                        {
                            "bool": {
                                "should": [
                                    {
                                        "match_phrase": {
                                            "eventTargetId.keyword": "EBN52"
                                        }
                                    },
                                    {
                                        "match_phrase": {
                                            "eventTargetId.keyword": "EBN53"
                                        }
                                    },
                                    {
                                        "match_phrase": {
                                            "eventTargetId.keyword": "EBN54"
                                        }
                                    },
                                    {
                                        "match_phrase": {
                                            "eventTargetId.keyword": "EBN55"
                                        }
                                    },
                                    {
                                        "match_phrase": {
                                            "eventTargetId.keyword": "EBN57"
                                        }
                                    },
                                    {
                                        "match_phrase": {
                                            "eventTargetId.keyword": "EBN58"
                                        }
                                    }
                                ],
                                "minimum_should_match": 1
                            }
                        },
                        {
                            "exists": {
                                "field": "extraInfo.benefitID"
                            }
                        },
                        {
                            "range": {
                                "createTime": {
                                    "gte": _start_dt,
                                    "lt": _end_dt
                                }
                            }
                        }
                    ]
                }
            },
            "_source": ['timestamp', 'branchId', 'model', 'extraInfo', 'pageId', 'eventTargetId']
        }


if __name__ == '__main__':
    logger = Logger(__file__)
    logger.start_batch()

    try:
        start_dt, end_dt = args_util.parse_sys_argv('date', 2)
        BenefitBatchJob(start_dt, end_dt).execute()

        logger.end_batch()

    except Exception as e:
        logger.error(str(e))
