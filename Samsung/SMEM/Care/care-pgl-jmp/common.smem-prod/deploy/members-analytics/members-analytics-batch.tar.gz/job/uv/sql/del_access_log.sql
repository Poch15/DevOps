DELETE FROM v3_last_access
WHERE
    datetime >= '{start_datetime}'
AND
    datetime < '{end_datetime}'