#!/usr/bin/python3
# -*- coding: utf-8 -*-

import time
from datetime import timedelta

from utils import elasticsearch_util


def get_page_uv_data(_start_dt, _end_dt, page_list_str):
    elasticsearch_util.disable_unused_log()
    es_connection = elasticsearch_util.get_connection()

    index = elasticsearch_util.KAFKA_USAGELOG_INDEX
    page_list_json_string = __get_page_list_json_string(page_list_str)

    request_body = __get_page_uv_query_body(_start_dt, _end_dt, page_list_json_string)

    res = elasticsearch_util.get_search_result(es_connection, index, request_body)

    return_list = list()
    result_list = res["aggregations"]["3"]["buckets"]
    for result in result_list:
        branch_id = result["key"]
        cnt = result["1"]["value"]

        return_list.append((branch_id, cnt))

    return return_list


def get_page_event_uv_data(_start_dt, _end_dt, page_id, event_target_id, branch_list):
    elasticsearch_util.disable_unused_log()
    es_connection = elasticsearch_util.get_connection()

    index = elasticsearch_util.KAFKA_USAGELOG_INDEX
    branch_list_json_string = __get_branch_list_json_string(branch_list)

    request_body = __get_page_event_uv_query_body(_start_dt, _end_dt, page_id, event_target_id, branch_list_json_string)

    res = elasticsearch_util.get_search_result(es_connection, index, request_body)

    return_list = list()
    result_list = res["aggregations"]["3"]["buckets"]
    for result in result_list:
        branch_id = result["key"]
        cnt = result["1"]["value"]

        return_list.append((branch_id, cnt))

    return return_list


def __get_page_list_json_string(page_list_str):
    page_list = page_list_str.split(",")

    p_list = list()
    for page in page_list:
        p_list.append({"match_phrase": {"pageId.keyword": page}})

    return p_list


def __get_branch_list_json_string(branch_list):
    p_list = list()
    for branch in branch_list:
        p_list.append({"match_phrase": {"branchId": branch}})

    return p_list


def __get_page_uv_query_body(start_datetime, end_datetime, page_list_json_string):
    return {
        "aggs": {
            "3": {
                "terms": {
                    "field": "branchId",
                    "size": 1000
                },
                "aggs": {
                    "1": {
                        "cardinality": {
                            "field": "guid.keyword",
                            "precision_threshold": 40000
                        }
                    }
                }
            }
        },
        "query": {
            "bool": {
                "must": [
                    {
                        "bool": {
                            "minimum_should_match": 1,
                            "should": page_list_json_string
                        }
                    },
                    {
                        "range": {
                            "timestamp": {
                                "gte": start_datetime,
                                "lt": end_datetime
                            }
                        }
                    }
                ]
            }
        }
    }


def __get_page_event_uv_query_body(start_datetime, end_datetime, page_id, event_target_id, branch_list):
    return {
        "aggs": {
            "3": {
                "terms": {
                    "field": "branchId",
                    "size": 1000
                },
                "aggs": {
                    "1": {
                        "cardinality": {
                            "field": "guid.keyword",
                            "precision_threshold": 40000
                        }
                    }
                }
            }
        },
        "query": {
            "bool": {
                "must": [
                    {
                        "match_phrase": {
                            "pageId.keyword": {
                                "query": page_id
                            }
                        }
                    },
                    {
                        "match_phrase": {
                            "eventTargetId.keyword": {
                                "query": event_target_id
                            }
                        }
                    },
                    {
                        "bool": {
                            "minimum_should_match": 1,
                            "should": branch_list
                        }
                    },
                    {
                        "range": {
                            "timestamp": {
                                "gte": start_datetime,
                                "lt": end_datetime
                            }
                        }
                    }
                ]
            }
        }
    }


def __datetime_to_unixtimestamp(_datetime):
    utc_offset = (-1) * (time.timezone / 3600)
    _datetime = _datetime + timedelta(hours=utc_offset)
    return (time.mktime(_datetime.timetuple()) * 1000) + int(_datetime.time().microsecond)
