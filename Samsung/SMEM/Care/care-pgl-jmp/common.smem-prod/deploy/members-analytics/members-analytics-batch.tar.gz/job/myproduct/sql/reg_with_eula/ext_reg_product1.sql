SELECT '{start_dt}', model_name, category, company_cd, COUNT(*)
FROM
(
  SELECT mp.guid, mp.prd_id, mp.model_name, mp.category
  FROM mbrs_user PARTITION({part_name}) as mu
  JOIN mp_product PARTITION({part_name}) as mp
  ON mu.guid = mp.guid
  WHERE
    mp.crt_dt >='{start_dt}' AND mp.crt_dt < '{end_dt}'
  AND
    mu.eula_agree = 1
) AS A
JOIN
(
   SELECT guid, prd_id, company_cd FROM mp_gcic_product PARTITION({part_name}) as gcic
   WHERE gcic.company_cd ='C630'
) AS B
ON A.guid = B.guid AND A.prd_id = B.prd_id
GROUP BY model_name, category, company_cd