SELECT main_type, branch_id, prd_cat, SUM(cnt) AS cnt
FROM v3_feedback
GROUP BY main_type, branch_id, prd_cat