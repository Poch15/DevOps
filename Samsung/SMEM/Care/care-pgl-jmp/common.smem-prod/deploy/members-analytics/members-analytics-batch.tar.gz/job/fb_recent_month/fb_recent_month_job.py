#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from common.base.base_batch_job import BaseBatchJob
from common.logger import func_logger, Logger
from common.base.reader import MysqlReader
from common.base.writer import PostgresqlWriter
from utils import args_util, file_util
from datetime import datetime, timedelta


FB_STATUS = ["OPENED", "REVIEWED", "PROCESSING",
             "RESOLVED", "DISCARDED", "CLOSED"]
read_sql = file_util.load_sql_in_cur_dir('sql', 'ext_created_feedback.sql')
write_sql = file_util.load_sql_in_cur_dir('sql', 'ins_feedback.sql')


class FeedbackRecentMonthBatchJob(BaseBatchJob):

    def __init__(self, _start_dt, _end_dt):
        BaseBatchJob.__init__(self, _start_dt, _end_dt)

        self.reader = MysqlReader(read_sql)
        self.writer = PostgresqlWriter(write_sql)

        self.created_feedback_list = []
        self.updated_feedback_list = []
        self.created_fb_ids = ()
        self.updated_fb_ids = ()
        self.start_hist_id = None
        self.end_hist_id = None

    @func_logger
    def do_read(self):
        self.__read_fb_hist_id()
        self.__read_created_feedback()
        self.__read_updated_feedback()

    @func_logger
    def do_process(self):
        pass

    @func_logger
    def do_write(self):
        self.__write_created_feedback()
        self.__update_recent_hour_feedback()
        self.__delete_last_hour_feedback()
        pass

    @func_logger
    def __read_fb_hist_id(self):
        sql = file_util.load_sql_in_cur_dir('sql', 'ext_fb_hist_id.sql')
        params = {"date": self.date.get('start_dt')}
        self.start_hist_id = self.reader.read(sql, params)[0][0]

        params = {"date": self.date.get('end_dt')}
        self.end_hist_id = self.reader.read(sql, params)[0][0]

    @func_logger
    def __read_created_feedback(self):
        created_fb_id_sql = file_util.load_sql_in_cur_dir('sql', 'ext_created_fb_id.sql')
        params = {"start_hist_id": self.start_hist_id,
                  "end_hist_id": self.end_hist_id}
        created_fb_id_list = self.reader.read(created_fb_id_sql, params)

        self.created_fb_ids = get_fb_ids(created_fb_id_list)
        created_feedback_sql = file_util.load_sql_in_cur_dir('sql', 'ext_created_feedback.sql')

        params = {"fb_ids": self.created_fb_ids}
        self.created_feedback_list = self.reader.read(created_feedback_sql, params)

    @func_logger
    def __read_updated_feedback(self):
        updated_fb_id_sql = file_util.load_sql_in_cur_dir('sql', 'ext_updated_fb_id.sql')
        params = {"start_hist_id": self.start_hist_id, "end_hist_id": self.end_hist_id}
        updated_fb_id_list = self.reader.read(updated_fb_id_sql, params)

        self.updated_fb_ids = get_fb_ids(updated_fb_id_list)
        updated_feedback_sql = file_util.load_sql_in_cur_dir('sql', 'ext_updated_feedback.sql')
        recent_month_start_date = self.date.get('start_dt') - timedelta(days=30)

        params = {"fb_ids": self.updated_fb_ids,
                  "recent_month_start_date": recent_month_start_date}
        self.updated_feedback_list = self.reader.read(updated_feedback_sql, params)

    @func_logger
    def __write_created_feedback(self):
        self.__insert_feedback(self.created_feedback_list)

    @func_logger
    def __update_recent_hour_feedback(self):
        # delete
        del_fb_recent_month_sql = file_util.load_sql_in_cur_dir('sql', 'del_updated_feedback.sql')
        params = {"fb_ids": self.updated_fb_ids}
        self.writer.query(del_fb_recent_month_sql, params)

        # insert
        self.__insert_feedback(self.updated_feedback_list)

    @func_logger
    def __delete_last_hour_feedback(self):
        last_hour_dt = self.date.get('end_dt') - timedelta(days=30)
        del_last_hour_fb_sql = file_util.load_sql_in_cur_dir('sql', 'del_last_hour_feedback.sql')
        params = {"last_hour_dt": last_hour_dt}
        self.writer.query(del_last_hour_fb_sql, params)

    @func_logger
    def __insert_feedback(self, fb_list):
        ins_fb_sql = file_util.load_sql_in_cur_dir('sql', 'ins_feedback.sql')
        upt_fb_sql = file_util.load_sql_in_cur_dir('sql', 'upt_feedback.sql')

        ins_fb_list = list()
        for row in fb_list:
            fb_id, crt_dt, mdf_dt, branch_id, main_type, sub_type, \
            beta_prj_id, fb_status, deleted, app_id, cat_id = row
            fb_status = FB_STATUS.index(fb_status)
            deleted = is_deleted(deleted)

            ins_fb_list.append((fb_id, crt_dt, mdf_dt, branch_id, main_type, sub_type,
                                beta_prj_id, fb_status, deleted, app_id, cat_id))

        self.writer.write(ins_fb_list, ins_fb_sql, upt_fb_sql)


def get_fb_ids(_fb_id_list):
    fb_id_list = list()
    for row in _fb_id_list:
        fb_id = row[0]
        fb_id_list.append(str(fb_id))

    if len(fb_id_list) < 1:
        fb_ids = ('0', '0')
    elif len(fb_id_list) == 1:
        fb_ids = tuple(fb_id_list) + ('0',)
    else:
        fb_ids = tuple(fb_id_list)

    return fb_ids


def is_deleted(deleted='\x00'):
    return True if deleted == '\x01' else False


if __name__ == '__main__':
    logger = Logger(__file__)
    logger.start_batch()

    try:
        str_cur_datetime = args_util.parse_sys_argv('datetime', 1)
        _cur_datetime = datetime.strptime(str_cur_datetime, '%Y-%m-%dT%H:%M:%S')
        end_dt = _cur_datetime.replace(minute=0, second=0, microsecond=0, tzinfo=None)
        start_dt = end_dt - timedelta(hours=1)
        FeedbackRecentMonthBatchJob(start_dt, end_dt).execute()
        logger.end_batch()

    except Exception as e:
        logger.error(str(e))
