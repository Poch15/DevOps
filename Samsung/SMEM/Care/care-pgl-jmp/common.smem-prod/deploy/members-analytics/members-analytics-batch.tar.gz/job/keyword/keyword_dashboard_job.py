from common.base.base_batch_job import BaseBatchJob
from common.base.reader import PostgresqlReader
from common.base.writer import PostgresqlWriter
from common.logger import func_logger, Logger
from utils import file_util
from external import branch_inf
from datetime import datetime, timedelta


class KeywordDashboardBatchJob(BaseBatchJob):
    HQ_BRANCH_NAME = 'All'

    def __init__(self, _start_dt, _end_dt):
        BaseBatchJob.__init__(self, _start_dt, _end_dt)
        self.end_date = datetime.strptime(_end_dt, '%Y-%m-%d')
        self.start_date = self.end_date - timedelta(days=10)

        self.reader = PostgresqlReader()
        self.writer = PostgresqlWriter()

        self.all_branch_id_to_name_dict = dict()
        self.branch_name_to_keyword_rank_dict = dict()
        self.branch_name_to_data_list_dict = dict()

        self.logger = Logger(__file__)
        self.logger.start_batch()

    def __del__(self):
        BaseBatchJob.__del__(self)
        self.logger.end_batch()

    @func_logger
    def do_read(self):
        self.all_branch_id_to_name_dict = branch_inf.get_all_branch_id_to_name_dict()

        # HQ(All)
        hq_branch_name = KeywordDashboardBatchJob.HQ_BRANCH_NAME
        branch_ids = tuple(self.all_branch_id_to_name_dict.keys())
        keyword_rank_list = self.__extract_keyword_rank_list(branch_ids, hq_branch_name)
        self.branch_name_to_keyword_rank_dict[hq_branch_name] = keyword_rank_list
        self.branch_name_to_data_list_dict[hq_branch_name] = \
            self.__extract_keyword_data_list(branch_ids, hq_branch_name, keyword_rank_list)

        # Region
        region_list = branch_inf.get_all_region_list()
        for region in region_list:
            region_branch_list = branch_inf.get_branch_list_by_region(region)
            region_branch_list.append(0)
            branch_ids = tuple(region_branch_list)
            keyword_rank_list = self.__extract_keyword_rank_list(branch_ids, region)
            self.branch_name_to_keyword_rank_dict[region] = keyword_rank_list
            self.branch_name_to_data_list_dict[region] = \
                self.__extract_keyword_data_list(branch_ids, region, keyword_rank_list)

        # Local
        for branch_id, branch_name in self.all_branch_id_to_name_dict.items():
            branch_ids = (branch_id, 0)
            keyword_rank_list = self.__extract_keyword_rank_list(branch_ids, branch_name)
            self.branch_name_to_keyword_rank_dict[branch_name] = keyword_rank_list
            self.branch_name_to_data_list_dict[branch_name] = \
                self.__extract_keyword_data_list(branch_ids, branch_name, keyword_rank_list)

    @func_logger
    def do_process(self):
        pass

    @func_logger
    def do_write(self):
        # Delete
        self.__delete_dashboard_keywords()

        for branch_name, keyword_rank_list in self.branch_name_to_keyword_rank_dict.items():
            self.__insert_keyword_rank_list(keyword_rank_list)

        for branch_name, keyword_data_list in self.branch_name_to_data_list_dict.items():
            self.__insert_keyword_data_list(keyword_data_list)

    def __extract_keyword_rank_list(self, branch_ids, branch_name):
        keyword_rank_list = []
        sql = file_util.load_file(__file__, 'sql/dashboard/ext_dashboard_keyword_rank.sql')
        params = {'start_date': self.start_date, 'end_date': self.end_date, 'branch_ids': branch_ids}
        return_rows = self.reader.read(sql, params)
        for idx, row in enumerate(return_rows, start=1):
            keyword = row[0]
            keyword_rank_list.append((branch_name, keyword, idx))

        return keyword_rank_list

    def __extract_keyword_data_list(self, branch_ids, branch_name, keyword_rank_list):
        keyword_list = []
        for row in keyword_rank_list:
            branch_name, keyword, idx = row
            keyword_list.append(keyword)
        keywords = tuple(keyword_list)

        sql = file_util.load_file(__file__, 'sql/dashboard/ext_dashboard_keyword.sql')
        params = {'start_date': self.start_date, 'end_date': self.end_date, 'branch_ids': branch_ids,
                  'branch_name': branch_name, 'keywords': keywords}
        data_list = self.reader.read(sql, params)
        return data_list

    def __insert_keyword_rank_list(self, keyword_rank_list):
        sql = file_util.load_file(__file__, 'sql/dashboard/ins_dashboard_keyword_rank.sql')
        self.writer.write(keyword_rank_list, sql)

    def __insert_keyword_data_list(self, keyword_data_list):
        sql = file_util.load_file(__file__, 'sql/dashboard/ins_dashboard_keyword.sql')
        self.writer.write(keyword_data_list, sql)

    def __delete_dashboard_keywords(self):
        sql = file_util.load_file(__file__, 'sql/dashboard/del_dashboard_keyword.sql')
        self.writer.query(sql)
