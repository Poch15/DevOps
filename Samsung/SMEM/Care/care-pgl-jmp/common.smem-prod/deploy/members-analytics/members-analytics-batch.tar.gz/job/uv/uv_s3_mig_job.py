#!/usr/bin/python3
# -*- coding: utf-8 -*-

from datetime import datetime, timedelta
from common.base.base_batch_job import BaseBatchJob
from common.logger import func_logger, Logger
from utils import args_util, cryptosecurity
import job.uv.helper2 as helper2
from utils import s3_util
from config.loader import load_config
import pandas as pd
from io import StringIO


class UvS3MigJob(BaseBatchJob):
    def __init__(self, _start_dt, _end_dt):
        BaseBatchJob.__init__(self, _start_dt, _end_dt)
        self.start_dt = _start_dt
        self.end_dt = _end_dt
        self.daily_uv_list = []

    @func_logger
    def do_read(self):
        last_access_list = helper2.get_raw_data(self.start_dt, self.end_dt, 'UV')
        for last_access in last_access_list:
            members_id, guid, branch_id, model, serial, country, dt = last_access
            encrypt_serial = cryptosecurity.encrypt_aes128(serial).decode().rstrip('\n')
            self.daily_uv_list.append((members_id, guid, branch_id, model, encrypt_serial, country, dt))

    @func_logger
    def do_process(self):
        pass

    @func_logger
    def do_write(self):
        # write daily unique data to s3
        start_date = datetime.strptime(self.start_dt, "%Y-%m-%dT%H:%M:%S")
        file_name = 'uniqueuser_{0}_{1}_{2}.txt'.format(
            start_date.strftime("%Y"), start_date.strftime("%m"), start_date.strftime("%d"))

        df = pd.DataFrame(self.daily_uv_list,
                          columns=['members_id', 'guid', 'branch_id', 'model', 'serial', 'country', 'dt'])
        df.drop('dt', axis=1, inplace=True)

        csv_buffer = StringIO()
        df.to_csv(csv_buffer, sep=",", index=False)

        aws_config = load_config().get('aws')
        s3_client = s3_util.get_client()

        bucket_name = aws_config.get('s3').get('bucket')

        s3_obj_path = "{0}/{1}/{2}/{3}".format(
            "uv/unique_user",
            "year=" + str(start_date.year),
            "month=" + str(start_date.month),
            file_name)

        s3_util.put_object(s3_client, bucket_name, csv_buffer.getvalue(), s3_obj_path)


if __name__ == '__main__':
    logger = Logger(__file__)
    logger.start_batch()

    try:
        start_dt, end_dt = args_util.parse_sys_argv('date', 2)

        start_datetime = datetime.strptime(start_dt, "%Y-%m-%d")
        end_datetime = datetime.strptime(end_dt, "%Y-%m-%d")

        print(str(start_datetime) + "  /  " + str(end_datetime))

        cur_datetime = start_datetime
        while cur_datetime < end_datetime:
            str_cur_datetime = cur_datetime.strftime('%Y-%m-%dT%H:%M:%S')
            str_end_datetime = (cur_datetime + timedelta(days=1)).strftime('%Y-%m-%dT%H:%M:%S')

            UvS3MigJob(str_cur_datetime, str_end_datetime).execute()
            print(str(cur_datetime) + '  complete')

            cur_datetime = cur_datetime + timedelta(days=1)

        logger.end_batch()

    except Exception as e:
        logger.error(str(e))
