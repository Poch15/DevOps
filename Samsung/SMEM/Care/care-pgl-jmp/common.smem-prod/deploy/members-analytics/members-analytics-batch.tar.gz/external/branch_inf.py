#!/usr/bin/python
# -*- coding: utf-8 -*-

from common.base.reader import MysqlReader
from utils import file_util


def get_all_region_dict():
    query = "SELECT branch_id, region FROM branch ORDER BY branch_id"
    reader = MysqlReader(query)
    ret = reader.read()

    region_dict = dict()
    for row in ret:
        branch_id, region = row
        region_dict[branch_id] = region

    reader.close()
    return region_dict


def get_all_branch_country():
    query = "SELECT cnty_cd, branch_id FROM svc_cnty"
    reader = MysqlReader(query)
    ret = reader.read()

    region_dict = dict()
    for row in ret:
        branch_id, cnty_cd = row
        region_dict[branch_id] = cnty_cd

    reader.close()
    return region_dict


def get_all_branch_id_to_name_dict():
    sql = file_util.load_file(__file__, 'sql/get_all_branch.sql')
    reader = MysqlReader(sql)
    ret = reader.read()

    branch_dict = dict()
    for row in ret:
        branch_id, branch_name = row
        branch_dict[branch_id] = branch_name

    reader.close()
    return branch_dict


def get_all_region_list():
    sql = file_util.load_file(__file__, 'sql/get_all_region.sql')
    reader = MysqlReader(sql)
    ret = reader.read()

    region_list = list()
    for row in ret:
        region_list.append(row[0])

    reader.close()
    return region_list


def get_branch_list_by_region(region):
    sql = file_util.load_file(__file__, 'sql/get_branch_by_region.sql')
    param = {'region': region}
    reader = MysqlReader()
    ret = reader.read(sql, param)

    branch_list = list()
    for row in ret:
        branch_list.append(row[0])

    reader.close()
    return branch_list
