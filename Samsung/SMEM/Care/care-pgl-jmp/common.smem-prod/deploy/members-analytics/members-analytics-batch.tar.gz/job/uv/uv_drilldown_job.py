#!/usr/bin/python3
# -*- coding: utf-8 -*-

from common.base.base_batch_job import BaseBatchJob
from common.logger import func_logger, Logger
from common.base.reader import PostgresqlReader
from common.base.writer import PostgresqlWriter
from utils import file_util, date_util


class UvDrillDownJob(BaseBatchJob):
    def __init__(self, _start_dt, _end_dt):
        BaseBatchJob.__init__(self, _start_dt, _end_dt)
        self.start_dt = _start_dt
        self.start_week_date = None
        self.start_month_date = None

        self.reader = PostgresqlReader()
        self.writer = PostgresqlWriter()

        self.wuv_list = []
        self.wuv_dvc_list = []
        self.muv_list = []
        self.muv_dvc_list = []

        self.logger = Logger(__file__)
        self.logger.start_batch()

    def __del__(self):
        BaseBatchJob.__del__(self)
        self.logger.end_batch()

    @func_logger
    def do_read(self):
        self.start_week_date = date_util.get_last_sunday(self.start_dt)
        self.start_month_date = date_util.get_first_day_month(self.start_dt)

        params = {'cur_date': self.start_dt, 'ext_date': self.start_week_date}
        # wuv
        wuv_sql = file_util.load_file(__file__, 'sql/drilldown/ext_wuv_dd.sql')
        self.wuv_list = self.reader.read(wuv_sql, params)

        # wuv dvc
        wuv_dvc_sql = file_util.load_file(__file__, 'sql/drilldown/ext_wuv_dvc_dd.sql')
        self.wuv_dvc_list = self.reader.read(wuv_dvc_sql, params)

        params['ext_date'] = self.start_month_date
        # muv
        muv_sql = file_util.load_file(__file__, 'sql/drilldown/ext_muv_dd.sql')
        self.muv_list = self.reader.read(muv_sql, params)

        # muv dvc
        muv_dvc_sql = file_util.load_file(__file__, 'sql/drilldown/ext_muv_dvc_dd.sql')
        self.muv_dvc_list = self.reader.read(muv_dvc_sql, params)

    @func_logger
    def do_process(self):
        pass

    @func_logger
    def do_write(self):
        # wuv
        wuv_sql = file_util.load_file(__file__, 'sql/drilldown/ins_wuv_dd.sql')
        self.writer.write(self.wuv_list, wuv_sql)

        # wuv dvc
        wuv_dvc_sql = file_util.load_file(__file__, 'sql/drilldown/ins_wuv_dvc_dd.sql')
        self.writer.write(self.wuv_dvc_list, wuv_dvc_sql)

        # muv
        muv_sql = file_util.load_file(__file__, 'sql/drilldown/ins_muv_dd.sql')
        self.writer.write(self.muv_list, muv_sql)

        # muv dvc
        muv_dvc_sql = file_util.load_file(__file__, 'sql/drilldown/ins_muv_dvc_dd.sql')
        self.writer.write(self.muv_dvc_list, muv_dvc_sql)
