SELECT branch_id
FROM branch
WHERE
region = '{region}'
ORDER BY branch_id