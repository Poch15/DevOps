SELECT '{start_dt}', mu.last_branch, COUNT(*)
FROM mbrs_user PARTITION({part_name}) mu
WHERE mu.crt_dt >= '{start_dt}'
	AND mu.crt_dt < '{end_dt}'
	AND mu.last_branch != 3
GROUP BY mu.last_branch
ORDER BY mu.last_branch;