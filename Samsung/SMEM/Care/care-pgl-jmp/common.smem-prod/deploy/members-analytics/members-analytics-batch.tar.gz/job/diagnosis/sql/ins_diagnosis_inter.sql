INSERT INTO v3_diagnosis_inter
  (datetime, branch_id, model, cat_id, result, cnt)
VALUES