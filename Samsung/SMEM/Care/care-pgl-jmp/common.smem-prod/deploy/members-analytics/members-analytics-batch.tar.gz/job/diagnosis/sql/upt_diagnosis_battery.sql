ON CONFLICT ON CONSTRAINT v3_diagnosis_battery_unique
DO UPDATE SET cnt = v3_diagnosis_battery.cnt + EXCLUDED.cnt