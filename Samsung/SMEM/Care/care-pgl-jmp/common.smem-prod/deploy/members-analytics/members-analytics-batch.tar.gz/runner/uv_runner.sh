#!/bin/bash

BASE_PYTHON_PATH='/home/common/members-analytics/members-analytics-batch'
source ${BASE_PYTHON_PATH}/.venv/bin/activate
export PYTHONPATH=${BASE_PYTHON_PATH}/uv

export cur_date="$(date +%Y-%m-%d)"
python3 /home/common/members-analytics/members-analytics-batch/uv/job/uv/uv_job.py $cur_date