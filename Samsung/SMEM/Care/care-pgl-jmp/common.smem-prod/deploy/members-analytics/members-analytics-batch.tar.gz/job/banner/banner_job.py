#!/usr/bin/python3
# -*- coding: utf-8 -*-
from pandas import DataFrame

from common.base.base_batch_job import BaseBatchJob
from common.base.es_query import ElasticSearchQuery
from common.base.reader import ElasticSearchReader
from common.base.writer import PostgresqlWriter
from common.logger import func_logger, Logger
from utils import args_util, file_util
from datetime import datetime

read_sql = file_util.load_sql_in_cur_dir('sql', 'ext_banner.sql')
write_sql = file_util.load_sql_in_cur_dir('sql', 'ins_banner.sql')


class BannerBatchJob(BaseBatchJob):
    def __init__(self, _start_dt, _end_dt):
        BaseBatchJob.__init__(self, _start_dt, _end_dt)

        self.reader = ElasticSearchReader(es_query=BannerESQuery())
        self.writer = PostgresqlWriter()

        self.ret_rows = list()
        self.summary_list = list()

        self.banner_dict = dict()
        self.banner_list = list()

    @func_logger
    def do_read(self):
        self.ret_rows = self.reader.read(self.date.get('start_dt'), self.date.get('end_dt'))

    @func_logger
    def do_process(self):
        df = DataFrame(self.ret_rows, columns=['date', 'branch_id', 'model', 'banner_id', 'event_target_id', 'cnt'])
        summary_df = df.groupby(['date', 'branch_id', 'model', 'banner_id', 'event_target_id'])['cnt'].sum()
        for index, count in zip(summary_df.index, summary_df.values):
            date, branch_id, model, banner_id, event_target_id = index
            self.summary_list.append((date, branch_id, model, banner_id, event_target_id, int(count)))

        event_id_to_type = {'EEP333': 'Impression', 'EEP3': 'Click'}

        for row in self.summary_list:
            date, branch_id, model, banner_id, event_target_id, cnt = row
            key = (date, branch_id, model, banner_id)
            event_type = event_id_to_type.get(event_target_id, None)
            if event_type is None:
                continue
            if self.banner_dict.get(key, None) is None:
                self.banner_dict[key] = {'Impression': 0, 'Click': 0}
            self.banner_dict[key][event_type] = cnt

        for key, value in self.banner_dict.items():
            date, branch_id, model, banner_id = key
            imp_cnt = value.get('Impression', 0)
            click_cnt = value.get('Click', 0)
            self.banner_list.append((date, branch_id, model, banner_id, imp_cnt, click_cnt))

    @func_logger
    def do_write(self):
        self.writer.write(self.banner_list, write_sql)


class BannerESQuery(ElasticSearchQuery):
    @staticmethod
    def convert_list(_scroll_result):
        result_list = list()
        for _data in _scroll_result['hits']['hits']:
            branch_id = _data['_source'].get('branchId', None)
            model = _data['_source'].get('model', None)
            event_target_id = _data['_source'].get('eventTargetId', None)
            extra_info = _data['_source'].get('extraInfo', None)
            timestamp = _data['_source'].get('timestamp', None)

            timestamp = datetime.strptime(timestamp, "%Y-%m-%dT%H:%M:%S.%fZ").date()
            banner_id = extra_info.get('BannerID', None)

            if banner_id is not None:
                result_list.append((timestamp, int(branch_id), model, banner_id, event_target_id, 1))

        return result_list

    @staticmethod
    def query(_start_dt, _end_dt, _param):
        return {
            "size" : 5000,
            "query": {
                "bool": {
                    "must": [
                        {
                            "match_phrase": {
                                "type.keyword": {
                                    "query": "event"
                                }
                            }
                        },
                        {
                            "match_phrase": {
                                "pageId.keyword": {
                                    "query": "SEP1"
                                }
                            }
                        },
                        {
                            "bool": {
                                "should": [
                                    {
                                        "match_phrase": {
                                            "eventTargetId.keyword": "EEP3"
                                        }
                                    },
                                    {
                                        "match_phrase": {
                                            "eventTargetId.keyword": "EEP333"
                                        }
                                    }
                                ],
                                "minimum_should_match": 1
                            }
                        },
                        {
                            "exists": {
                                "field": "extraInfo.BannerID"
                            }
                        },
                        {
                            "range": {
                                "createTime": {
                                    "gte": _start_dt,
                                    "lt": _end_dt
                                }
                            }
                        }
                    ]
                }
            },
            "_source": ['timestamp', 'branchId', 'model', 'extraInfo', 'eventTargetId']
        }


if __name__ == '__main__':
    logger = Logger(__file__)
    logger.start_batch()

    try:
        start_dt, end_dt = args_util.parse_sys_argv('date', 2)
        BannerBatchJob(start_dt, end_dt).execute()

        logger.end_batch()

    except Exception as e:
        logger.error(str(e))
