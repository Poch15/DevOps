SELECT mu.guid, mu.last_branch, mudvc.dvc_model, mu.crt_dt, mkt_name.name,
AES_DECRYPT(FROM_BASE64(imei), 'E456D5BDAVCDEF4F', 'E456D5BDAVCDEF4F') AS imei

FROM mbrs_user PARTITION({part_name}) mu
JOIN mbrs_user_dvc PARTITION({part_name}) mudvc
ON mu.guid = mudvc.guid

JOIN device ON
mudvc.dvc_model = device.dvc_model
JOIN mkt_name ON
device.mkt_id = mkt_name.mkt_id

WHERE mu.crt_dt>='2020-01-01' AND mu.crt_dt<'2020-05-25'
AND mudvc.crt_dt>='2020-01-01' AND mudvc.crt_dt<'2020-05-25'
AND mu.eula_agree=1
AND mu.last_branch IN (2,6,9,11,13)

LIMIT 10