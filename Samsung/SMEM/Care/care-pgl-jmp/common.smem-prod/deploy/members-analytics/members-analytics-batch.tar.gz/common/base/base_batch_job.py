#!/usr/bin/python3
# -*- coding: utf-8 -*-

import abc
from config.loader import load_config


class BaseBatchJob(metaclass=abc.ABCMeta):

    def __init__(self, _start_dt, _end_dt):
        self.date = {"start_dt": _start_dt, "end_dt": _end_dt}
        self.config = load_config()

        self.reader = None
        self.writer = None

    def __del__(self):
        if self.reader is not None:
            self.reader.close()

        if self.writer is not None:
            self.writer.close()

    def execute(self):
        self.do_read()
        self.do_process()
        self.do_write()

    @abc.abstractmethod
    def do_read(self):
        pass

    @abc.abstractmethod
    def do_process(self):
        pass

    @abc.abstractmethod
    def do_write(self):
        pass

    def get_branch_id(self):
        return int(self.config.get('branch'))
