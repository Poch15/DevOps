SELECT date_trunc('day', timestamp)::date as date, branch_id, model, page_id, count(*) as cnt
FROM uldata2
WHERE
createdatetime >= '{start_dt}'
AND
createdatetime < '{end_dt}'
AND
type = 'pageView'
GROUP BY date, branch_id, model, page_id