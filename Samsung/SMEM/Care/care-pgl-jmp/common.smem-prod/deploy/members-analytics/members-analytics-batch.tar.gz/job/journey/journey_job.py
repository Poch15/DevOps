#!/usr/bin/python3
# -*- coding: utf-8 -*-

from datetime import datetime, timedelta
from common.base.base_batch_job import BaseBatchJob
from common.base.es_query import ElasticSearchQuery
from common.base.reader import ElasticSearchReader
from common.base.writer import PostgresqlWriter
from common.logger import func_logger, Logger
from utils import file_util, args_util
import pandas as pd
import queue


class JourneyJob(BaseBatchJob):
    __MAX_STEP_NUM = 11

    def __init__(self, _start_dt, _end_dt, _branch_id):
        BaseBatchJob.__init__(self, _start_dt, _end_dt)

        self.reader = ElasticSearchReader(es_query=JourneyESQuery())
        self.writer = PostgresqlWriter()

        self.start_dt = _start_dt
        self.end_dt = _end_dt
        self.branch_id = _branch_id

        self.usage_logs = list()
        self.summary_dict = dict()

        self.summary_list = list()
        self.summary_df = None
        self.summary_columns = ['start_dt', 'branch', 'from', 'to', 'step', 'cnt']

    @func_logger
    def do_read(self):
        es_param = {'branch_id': self.branch_id}

        self.usage_logs = self.reader.read(self.start_dt, self.end_dt, es_param)

    @func_logger
    def do_process(self):
        logs = pd.DataFrame(self.usage_logs, columns=['device', 'page', 'branch', 'timestamp'])

        logs.set_index(keys=['device', 'branch'], inplace=True)
        logs = logs.sort_index()

        unique_devices = logs.index.drop_duplicates()

        for idx in unique_devices:
            df = logs.loc[(idx[0], idx[1])]
            df = df.sort_values(by=['timestamp'], axis=0)

            prev_ts = df.iloc[0]['timestamp']
            prev_page = None
            session_queue = queue.Queue()

            for _, row in df.iterrows():
                ts = row['timestamp']
                page = row['page']

                if ts > prev_ts + timedelta(minutes=30):
                    if session_queue.qsize() > 0:
                        self.__flush_queue(session_queue, idx[1])

                if page != prev_page:
                    session_queue.put((row['page'], row['timestamp']))

                prev_ts = ts
                prev_page = page

            if session_queue.qsize() > 0:
                self.__flush_queue(session_queue, idx[1])

            # logs.drop(df.index.tolist(), inplace=True)

    def __flush_queue(self, session_queue, branch):
        step_num = 0
        from_page_id = None

        session_queue.put(('FIN_SESSION', pd.Timestamp(self.start_dt)))

        while session_queue.qsize() > 0:
            item = session_queue.get()
            to_page_id = item[0]
            ts = item[1]

            if from_page_id is None:
                if self.__is_not_today_session(ts):
                    while session_queue.qsize():
                        session_queue.get()
                    break
            else:
                key = "{0}:{1}:{2}".format(branch, from_page_id, to_page_id)
                if step_num in self.summary_dict:
                    step_dict = self.summary_dict[step_num]
                    step_dict[key] = step_dict.get(key, 0) + 1
                else:
                    self.summary_dict[step_num] = {key: 1}

            from_page_id = to_page_id
            step_num += 1

    def __is_not_today_session(self, _ts):
        _start_dt = datetime.strptime(self.start_dt, "%Y-%m-%d")
        _ts = _ts.to_pydatetime()
        _ts = _ts.replace(tzinfo=None)

        return _ts < _start_dt or _ts > _start_dt + timedelta(days=1)

    @func_logger
    def do_write(self):
        self.__write_journey()
        self.__write_journey_summary()

    def __write_journey(self):
        ins_journey_sql = file_util.load_file(__file__, 'sql/ins_journey.sql')
        summary_list = list()

        for step_num in self.summary_dict.keys():
            step_dict = self.summary_dict[step_num]
            for key in step_dict.keys():
                key_arr = key.split(':')
                cnt = step_dict.get(key, 0)

                summary_list.append((self.start_dt, key_arr[0], key_arr[1], key_arr[2], step_num, cnt))

        self.summary_df = pd.DataFrame(data=summary_list, columns=self.summary_columns)

        filtered_summary_df = self.__filter_percentage(0.90, 30)
        filtered_summary_df = filtered_summary_df[filtered_summary_df['step'] < JourneyJob.__MAX_STEP_NUM]

        final_list = filtered_summary_df[self.summary_columns].values.tolist()

        # self.summary_df = self.summary_df[self.summary_df['cnt'] != 1]
        # final_list = self.summary_df.values.tolist()

        self.writer.write(final_list, sql=ins_journey_sql)

    def __write_journey_summary(self):
        ins_journey_summary_sql = file_util.load_file(__file__, 'sql/ins_journey_summary.sql')
        journey_summary_list = list()

        for branch in self.summary_df['branch'].unique():
            branch_df = self.summary_df[self.summary_df['branch'] == branch]
            for step in branch_df['step'].unique():
                step_df = branch_df[branch_df['step'] == step]
                fin_sum = step_df[step_df['to'] == 'FIN_SESSION']['cnt'].sum()
                out_sum = step_df[step_df['to'] != 'FIN_SESSION']['cnt'].sum()

                if step < JourneyJob.__MAX_STEP_NUM:
                    journey_summary_list.append((self.start_dt, int(branch), int(step), int(fin_sum), int(out_sum)))

            total_fin_sum = branch_df[branch_df['to'] == 'FIN_SESSION']['cnt'].sum()
            total_out_sum = branch_df[branch_df['to'] != 'FIN_SESSION']['cnt'].sum()
            journey_summary_list.append((self.start_dt, int(branch), 0, int(total_fin_sum), int(total_out_sum)))

        self.writer.write(journey_summary_list, sql=ins_journey_summary_sql)

    def __filter_percentage(self, percentage, head_num):
        filtered_summary_df = pd.DataFrame(columns=self.summary_columns)

        branch_step_set = self.summary_df[['branch', 'step']].drop_duplicates()

        for _, row in branch_step_set.iterrows():
            branch = row['branch']
            step = row['step']

            df = self.summary_df[(self.summary_df['branch'] == branch) & (self.summary_df['step'] == step)]
            df = df.sort_values(by=['cnt'], ascending=False)

            df['perc'] = df['cnt'] / df['cnt'].sum()
            df['cumsum_perc'] = df['perc'].cumsum()

            if df.iloc[0]['cumsum_perc'] >= percentage:
                last_row = df.iloc[0]
            else:
                last_row = df[df['cumsum_perc'] < percentage].iloc[-1]

            df2 = df[df['cnt'] >= last_row['cnt']]

            # if len(df2) > head_num:
            #     head_num_row = df2.iloc[head_num]
            #     df2 = df2[df2['cnt'] >= head_num_row['cnt']]

            filtered_summary_df = filtered_summary_df.append(df2)

        return filtered_summary_df


class JourneyESQuery(ElasticSearchQuery):
    @staticmethod
    def convert_list(_scroll_result):
        result_list = list()
        for _data in _scroll_result['hits']['hits']:
            branch_id = _data['_source'].get('branchId', None)
            page_id = _data['_source'].get('pageId', None)
            device_fp = _data['_source'].get('deviceFp', None)
            timestamp = _data['_source'].get('timestamp', None)

            timestamp = datetime.strptime(timestamp, "%Y-%m-%dT%H:%M:%S.%fZ")

            if device_fp is not None:
                result_list.append((device_fp, page_id, int(branch_id), timestamp))

        return result_list

    @staticmethod
    def query(_start_dt, _end_dt, _param):
        _branch_id = _param.get('branch_id')

        return {
            "query": {
                "bool": {
                    "must": [
                        {
                            "match_phrase": {
                                "type.keyword": {
                                    "query": "pageView"
                                }
                            }
                        },
                        {
                            "match_phrase": {
                                "branchId": {
                                    "query": _branch_id
                                }
                            }
                        },
                        {
                            "exists": {
                                "field": "deviceFp.keyword"
                            }
                        },
                        {
                            "range": {
                                "createTime": {
                                    "gte": _start_dt,
                                    "lt": _end_dt
                                }
                            }
                        }
                    ]
                }
            },
            "_source": ['timestamp', 'deviceFp', 'pageId', 'branchId']
        }
