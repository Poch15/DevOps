#!/bin/bash

BASE_PYTHON_PATH='/home/common/members-analytics/members-analytics-batch'
source ${BASE_PYTHON_PATH}/.venv/bin/activate
export PYTHONPATH=${BASE_PYTHON_PATH}/screen_event

export from="$(date --date="1 days ago" +%Y-%m-%d)"
export to="$(date +%Y-%m-%d)"
python3 /home/common/members-analytics/members-analytics-batch/screen_event/job/screen_event/screen_event_job.py $from $to