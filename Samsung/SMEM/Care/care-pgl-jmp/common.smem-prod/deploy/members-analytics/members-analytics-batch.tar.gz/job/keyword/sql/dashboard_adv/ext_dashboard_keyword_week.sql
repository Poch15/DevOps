SELECT
date_trunc('week', date + '1 day'::interval)::date - '1 day'::interval as week1,
{source} as source,
'{branch_name}' as branch_name,
keyword_idx,
sum(cnt) as cnt,
'{period}' as period
FROM v3_keyword
  WHERE
    date >= '{start_date}'
  AND
    date < '{end_date}'
  AND
    source = {source}
  AND
    branch_id IN {branch_ids}
  AND
    keyword_idx IN {keyword_idx_list}
GROUP BY week1, keyword_idx
ORDER BY week1