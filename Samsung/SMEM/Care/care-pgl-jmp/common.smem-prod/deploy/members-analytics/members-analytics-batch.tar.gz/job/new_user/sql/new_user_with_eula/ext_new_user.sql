SELECT '{start_dt}', mu.last_branch, COUNT(*)
FROM mbrs_user PARTITION({part_name}) mu
INNER JOIN mbrs_user_eula_history PARTITION({part_name}) eula_hist
	ON mu.guid = eula_hist.guid
WHERE eula_hist.eula_date >= '{start_dt}'
	AND eula_hist.eula_date < '{end_dt}'
	AND eula_hist.is_first = 1
	AND mu.last_branch = 3
GROUP BY mu.last_branch
ORDER BY mu.last_branch;