SELECT dvc.dvc_model, mkt.name
FROM device dvc
INNER JOIN mkt_name mkt
ON dvc.mkt_id = mkt.mkt_id