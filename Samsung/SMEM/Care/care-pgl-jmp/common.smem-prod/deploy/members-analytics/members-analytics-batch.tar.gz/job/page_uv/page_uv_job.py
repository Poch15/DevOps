#!/usr/bin/python3
# -*- coding: utf-8 -*-

from datetime import datetime, timedelta
from common.base.base_batch_job import BaseBatchJob
from common.logger import func_logger, Logger
from utils import args_util, file_util, date_util
from common.base.reader import PostgresqlReader
from common.base.writer import PostgresqlWriter
import job.page_uv.helper as helper


class PageUvJob(BaseBatchJob):
    __INHOUSE_COMMUNITY_BRANCH_LIST = [11, 92]

    def __init__(self, _start_dt, _end_dt):
        BaseBatchJob.__init__(self, _start_dt, _end_dt)
        self.start_dt = _start_dt
        self.end_dt = _end_dt

        self.pv_info_list = list()

        self.daily_summary_list = list()
        self.weekly_summary_list = list()
        self.monthly_summary_list = list()

        self.reader = PostgresqlReader()
        self.writer = PostgresqlWriter()

    @func_logger
    def do_read(self):
        unique_pv_info_sql = file_util.load_file(__file__, 'sql/unique_pv_info.sql')
        self.pv_info_list = self.reader.read(unique_pv_info_sql, self.date)

    @func_logger
    def do_process(self):

        # daily
        summary_list = self.__do_process(self.start_dt, self.end_dt)
        self.writer.write(summary_list, file_util.load_file(__file__, 'sql/ins_unique_pv_daily.sql'))

        # weekly (delete and insert)
        # for migration : only saturday
        # if self.end_dt.weekday() == 5:
        start_date = date_util.get_last_sunday(self.start_dt)
        summary_list = self.__do_process(start_date, self.end_dt)

        self.writer.query(file_util.load_file(__file__, 'sql/del_unique_pv_weekly.sql'), {'date': start_date})
        self.writer.write(summary_list, file_util.load_file(__file__, 'sql/ins_unique_pv_weekly.sql'))

        # monthly (delete and insert)
        # for migration : only last day
        # if (self.end_dt + timedelta(days=1)).day == 1:
        start_date = date_util.get_first_day_month(self.start_dt)
        summary_list = self.__do_process(start_date, self.end_dt)

        self.writer.query(file_util.load_file(__file__, 'sql/del_unique_pv_monthly.sql'), {'date': start_date})
        self.writer.write(summary_list, file_util.load_file(__file__, 'sql/ins_unique_pv_monthly.sql'))

    def __do_process(self, _start_dt, _end_dt):
        return_list = list()

        for pv_info in self.pv_info_list:
            page_grp_id, page_group_name, page_list = pv_info
            branch_count_list = helper.get_page_uv_data(_start_dt, _end_dt, page_list)

            for branch_id, cnt in branch_count_list:
                return_list.append((page_grp_id, _start_dt, branch_id, cnt))

        # in-house community
        inhouse_community_branch_count_list = helper.get_page_event_uv_data(_start_dt, _end_dt, 'SEP1', 'EEP21',
                                                                            PageUvJob.__INHOUSE_COMMUNITY_BRANCH_LIST)

        for branch_id, cnt in inhouse_community_branch_count_list:
            return_list.append((300, _start_dt, branch_id, cnt))

        return return_list

    @func_logger
    def do_write(self):
        pass


if __name__ == '__main__':
    logger = Logger(__file__)
    logger.start_batch()

    try:
        str_cur_date = args_util.parse_sys_argv('date', 1)
        _cur_datetime = datetime.strptime(str_cur_date, '%Y-%m-%d')
        end_dt = _cur_datetime.replace(hour=0, minute=0, second=0, microsecond=0, tzinfo=None)
        start_dt = end_dt - timedelta(days=1)

        PageUvJob(start_dt, end_dt).execute()

        # for migration
        # migration_start_dt = datetime.strptime('2021-03-14', '%Y-%m-%d')
        # migration_end_dt = datetime.strptime('2021-03-15', '%Y-%m-%d')
        # while migration_start_dt < migration_end_dt:
        #     PageUvJob(migration_start_dt, migration_start_dt + timedelta(days=1)).execute()
        #     migration_start_dt = migration_start_dt + timedelta(days=1)

        logger.end_batch()

    except Exception as e:
        logger.error(str(e))
