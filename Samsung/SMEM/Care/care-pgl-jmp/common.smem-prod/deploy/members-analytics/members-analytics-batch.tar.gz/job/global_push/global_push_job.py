#!/usr/bin/env python3
# -*- coding: utf-8 -*-


from common.base.base_batch_job import BaseBatchJob
from common.logger import func_logger, Logger
from common.base.reader import MysqlReader
from common.base.writer import PostgresqlWriter
from utils import args_util, file_util
from datetime import datetime, timedelta
import json


class GlobalPushBatchJob(BaseBatchJob):
    def __init__(self, _start_dt, _end_dt):
        BaseBatchJob.__init__(self, _start_dt, _end_dt)

        self.reader = MysqlReader()
        self.writer = PostgresqlWriter()

        self.start_push_id = None
        self.end_push_id = None
        self.push_row_list = []
        self.push_status_dict = {}
        self.tat_tot_cnt = 0
        self.event_members_sec = 0
        self.members_push_sec = 0

    @func_logger
    def do_read(self):
        self.__read_push_id()
        self.__read_push_row_list()

    @func_logger
    def do_process(self):
        for push_row in self.push_row_list:
            crt_dt, mdf_dt, message, status = push_row
            if status == 6:
                try:
                    msg_dict = json.loads(message)
                except Exception as e:
                    continue
                timestamp = msg_dict.get('timestamp', 0)
                self.__calc_push_tat(crt_dt, mdf_dt, timestamp)

            self.__calc_push_status_dict(status)

    @func_logger
    def do_write(self):
        dt = self.date.get('start_dt').strftime("%Y-%m-%d %H:00:00")
        ins_tat_list = [(dt, self.tat_tot_cnt, self.event_members_sec, self.members_push_sec)]

        tat_sql = file_util.load_sql_in_cur_dir('sql', 'ins_push_tat.sql')
        self.writer.write(ins_tat_list, tat_sql)

        ins_push_status_list = []
        for status, cnt in self.push_status_dict.items():
            ins_push_status_list.append((dt, status, cnt))

        status_sql = file_util.load_sql_in_cur_dir('sql', 'ins_push_status.sql')
        self.writer.write(ins_push_status_list, status_sql)

    def __read_push_id(self):
        sql = file_util.load_sql_in_cur_dir('sql', 'ext_push_id.sql')
        params = {"date": self.date.get('start_dt')}
        self.start_push_id = self.reader.read(sql, params)[0][0]

        params = {"date": self.date.get('end_dt')}
        self.end_push_id = self.reader.read(sql, params)[0][0]

    def __read_push_row_list(self):
        sql = file_util.load_sql_in_cur_dir('sql', 'ext_push_list.sql')
        params = {"start_push_id": self.start_push_id, "end_push_id": self.end_push_id}
        self.push_row_list = self.reader.read(sql, params)

    def __calc_push_tat(self, crt_dt, mdf_dt, timestamp):
        if timestamp != 0:
            event_time = datetime.utcfromtimestamp(timestamp / 1000)
            self.event_members_sec += (crt_dt - event_time).seconds
            self.members_push_sec += (mdf_dt - crt_dt).seconds
            self.tat_tot_cnt += 1

    def __calc_push_status_dict(self, status):
        status_cnt = self.push_status_dict.get(status, 0)
        if status_cnt == 0:
            self.push_status_dict[status] = 1
        else:
            self.push_status_dict[status] = status_cnt + 1


if __name__ == '__main__':
    logger = Logger(__file__)
    logger.start_batch()

    try:
        str_cur_datetime = args_util.parse_sys_argv('datetime', 1)
        _cur_datetime = datetime.strptime(str_cur_datetime, '%Y-%m-%dT%H:%M:%S')
        end_dt = _cur_datetime.replace(minute=0, second=0, microsecond=0, tzinfo=None)
        start_dt = end_dt - timedelta(hours=1)
        GlobalPushBatchJob(start_dt, end_dt).execute()
        logger.end_batch()
    except Exception as e:
        logger.error(str(e))