SELECT date, branch_id, model, source, sum(cnt)
FROM v3_keyword
WHERE
 date >= '{start_dt}'
AND
 date < '{end_dt}'
GROUP BY date, branch_id, model, source
ORDER BY date, branch_id, source
