SELECT b.csc, c.cnty_cd
FROM carrier c INNER JOIN buyer_code b
ON c.carrier_id = b.carrier_id