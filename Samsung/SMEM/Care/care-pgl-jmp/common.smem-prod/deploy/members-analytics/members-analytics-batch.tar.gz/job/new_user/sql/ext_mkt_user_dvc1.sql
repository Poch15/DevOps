SELECT model, sum(cnt) FROM v3_new_user_device_2019
group by model