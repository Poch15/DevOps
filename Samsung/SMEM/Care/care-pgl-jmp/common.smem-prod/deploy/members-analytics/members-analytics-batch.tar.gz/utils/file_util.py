#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import sys
import csv
import gzip


def load_sql_in_cur_dir(*paths):
    sql_path = join_path_to_cur_dir(*paths)
    return read_file(sql_path)


def get_current_dir(cur_file):
    return os.path.dirname(os.path.realpath(cur_file))


def read_file(path):
    with open(path) as f:
        return f.read()


def load_file(cur_file, filename):
    with open(os.path.join(get_current_dir(cur_file), filename)) as f:
        return f.read()


def write_to_csv(_file_name, _list, _separator=','):
    create_parent_dir(_file_name)

    with open(_file_name, 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f, delimiter=',')
        for item in _list:
            writer.writerow(item)


def write_to_file(_file_name, _list):
    create_parent_dir(_file_name)

    with open(_file_name, 'w', encoding='utf-8') as f:
        for item in _list:
            f.write(item)


def write_to_gz(_file_name, _list):
    create_parent_dir(_file_name)

    with gzip.open(_file_name, 'wt', encoding='utf-8') as f:
        for item in _list:
            f.write(item)


def create_parent_dir(_file_name):
    _dir = os.path.dirname(_file_name)
    if not os.path.exists(_dir):
        os.makedirs(_dir)


def join_path_to_cur_dir(*paths):
    joined_path = os.path.dirname(sys.argv[0])
    for path in paths:
        joined_path = os.path.join(joined_path, path)

    return joined_path
