SELECT
    DATE_FORMAT(crt_dt,'%Y-%m-%d') AS date, branch_id, model_name,
    CASE WHEN main_type=1 THEN 3
         WHEN main_type=3 THEN 1
	       ELSE main_type
	  END AS mtype,
    cat_id, app_id, beta_prj_id, prd_cat, COUNT(*) AS cnt
  FROM feedback
WHERE crt_dt >= '{start_dt}' AND crt_dt < '{end_dt}'
GROUP BY date, branch_id, model_name, mtype, cat_id, app_id, beta_prj_id, prd_cat