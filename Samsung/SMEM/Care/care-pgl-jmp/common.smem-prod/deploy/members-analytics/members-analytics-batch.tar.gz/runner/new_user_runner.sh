#!/bin/bash

BASE_PYTHON_PATH='/home/common/members-analytics/members-analytics-batch'
source ${BASE_PYTHON_PATH}/.venv/bin/activate
export PYTHONPATH=${BASE_PYTHON_PATH}/new_user

export start_dt="$(date --date="1 days ago" +%Y-%m-%d)"
export end_dt="$(date +%Y-%m-%d)"
python3 ${BASE_PYTHON_PATH}/new_user/job/new_user/new_user.py $start_dt $end_dt