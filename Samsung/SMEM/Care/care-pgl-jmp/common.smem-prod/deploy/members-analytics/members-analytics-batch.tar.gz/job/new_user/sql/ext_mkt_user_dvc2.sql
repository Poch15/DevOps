SELECT model, sum(cnt) FROM v3_new_user_device
WHERE datetime>='2019-08-01' and datetime<'2020-01-01'
group by model