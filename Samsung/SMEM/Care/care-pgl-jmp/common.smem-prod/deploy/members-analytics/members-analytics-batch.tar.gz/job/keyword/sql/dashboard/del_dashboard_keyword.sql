DELETE FROM v3_dash_keyword;
DELETE FROM v3_dash_keyword_rank;