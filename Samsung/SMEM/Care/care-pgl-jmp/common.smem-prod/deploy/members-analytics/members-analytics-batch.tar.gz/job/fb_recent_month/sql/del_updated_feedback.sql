DELETE FROM tbl_v2_fb_recent_month
WHERE
fb_id IN {fb_ids}