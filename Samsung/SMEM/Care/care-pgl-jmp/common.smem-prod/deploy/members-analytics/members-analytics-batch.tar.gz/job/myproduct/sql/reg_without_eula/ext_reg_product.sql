SELECT start_dt, model_name, category, B.cd, cnt
FROM
(
  SELECT '{start_dt}' as start_dt, model_name, category, IFNULL(company_cd, 'C1X0') as cd, COUNT(*) as cnt
  FROM
  (
    SELECT mp.guid, mp.prd_id, mp.model_name, mp.category
    FROM mp_product PARTITION({part_name}) as mp
    WHERE
      mp.crt_dt >='{start_dt}' AND mp.crt_dt < '{end_dt}'
  ) AS A
  LEFT JOIN
  mp_gcic_product PARTITION({part_name}) as gcic
  ON A.guid = gcic.guid AND A.prd_id = gcic.prd_id
  GROUP BY model_name, category, company_cd
) AS B
WHERE B.cd != 'C630'