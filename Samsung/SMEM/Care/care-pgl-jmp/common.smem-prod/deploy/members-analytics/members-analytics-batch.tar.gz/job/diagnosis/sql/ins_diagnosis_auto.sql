INSERT INTO v3_diagnosis_auto
  (datetime, branch_id, model, result, cnt)
VALUES