#!/usr/bin/env python3
# -*- coding: utf-8 -*-


from datetime import datetime, timedelta
from job.global_push.global_push_job import GlobalPushBatchJob


if __name__ == '__main__':
    start_dt = datetime(2020, 4, 1, 0)
    end_dt = datetime(2020, 4, 2, 0)

    cur_dt = start_dt
    while cur_dt != end_dt:
        _start_dt = cur_dt
        _end_dt = cur_dt + timedelta(hours=1)
        print(_start_dt)
        print(_end_dt)
        GlobalPushBatchJob(_start_dt, _end_dt).execute()
        cur_dt = cur_dt + timedelta(hours=1)
