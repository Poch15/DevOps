#!/usr/bin/python3
# -*- coding: utf-8 -*-

from datetime import timedelta


class UvDateUtil:

    def __init__(self, cur_datetime):
        self.cur_datetime = cur_datetime

    def get_cur_datetime(self):
        return self.cur_datetime

    def get_uv_month_start_datetime(self, _format='date'):
        start_datetime = self.cur_datetime.replace(day=1)
        if self.cur_datetime.hour < 12 and _format == 'datetime':
            if self.cur_datetime.day == 1:
                start_datetime = (start_datetime - timedelta(days=1)).replace(day=1)
        else:
            start_datetime = start_datetime - timedelta(days=1)

        return start_datetime

    def get_uv_week_start_datetime(self):
        delta = self.cur_datetime.isoweekday()
        if self.cur_datetime.isoweekday() == 7:
            if self.cur_datetime.hour > 11:
                delta = 1
        else:
            delta = self.cur_datetime.isoweekday() + int(self.cur_datetime.hour / 12)

        start_datetime = self.cur_datetime - timedelta(days=delta)
        return start_datetime

    def get_uv_day_start_datetime(self):
        start_datetime = self.cur_datetime - timedelta(days=1)
        return start_datetime

    def get_uv_hour_start_datetime(self):
        start_datetime = self.cur_datetime - timedelta(hours=1)
        return start_datetime

    def get_uv_data_loading_start_datetime(self):
        month_start_datetime = self.get_uv_month_start_datetime()
        week_start_datetime = self.get_uv_week_start_datetime()

        data_loading_start_datetime = month_start_datetime
        if week_start_datetime < month_start_datetime:
            data_loading_start_datetime = week_start_datetime

        return data_loading_start_datetime

    def get_timezone(self):
        return self.cur_datetime.hour - ((self.cur_datetime.hour % 12) * 2)

    def is_delete_datetime(self, _format='date'):
        first_day = self.cur_datetime.replace(day=1)
        first_sunday = first_day + timedelta(days=7 - first_day.isoweekday())
        first_monday = first_sunday + timedelta(days=1)
        if _format == 'datetime':
            is_delete = True if self.cur_datetime == first_sunday and self.cur_datetime.hour == 12 else False
        else:
            is_delete = True if self.cur_datetime == first_monday else False
        return is_delete

    def get_uv_delete_start_end_datetime(self, _format='date'):
        end_datetime = self.get_uv_month_start_datetime(_format)
        start_datetime = end_datetime.replace(day=1) - timedelta(days=1)
        return start_datetime, end_datetime
