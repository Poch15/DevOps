SELECT
	      CASE WHEN monthval < 10 THEN yearval || '/0' || monthval
			       ELSE yearval || '/' || monthval
			       END as yearmonth,
        sumval AS sum
FROM
  (
    SELECT extract(year from dateval) as yearval, extract(month from dateval) as monthval, sum(cnt) as sumval
    FROM
      (
	      SELECT date_with_timezone as dateval, sum(A.cnt) as cnt
	      FROM
	        (
		        SELECT (datetime + INTERVAL '{interval_hour}' HOUR)::DATE as date_with_timezone,
		          model,cnt
		        FROM {tbl_name}
		        WHERE
              datetime >= '{start_date}'::timestamp - INTERVAL '{interval_hour}' HOUR
            AND
              datetime < '{end_date}'::timestamp - INTERVAL '{interval_hour}' HOUR + INTERVAL '1' DAY
            AND
              branch_id IN {branch_ids}
            AND
              model {model}
	        ) as A
	      GROUP BY date_with_timezone
	      ORDER BY date_with_timezone
      ) as B
    GROUP BY extract(year from dateval), extract(month from dateval)
    ORDER BY extract(year from dateval), extract(month from dateval)
  ) as C