SELECT company_cd
FROM v3_mp_company_info
WHERE
  branch_id IN {branch_ids}