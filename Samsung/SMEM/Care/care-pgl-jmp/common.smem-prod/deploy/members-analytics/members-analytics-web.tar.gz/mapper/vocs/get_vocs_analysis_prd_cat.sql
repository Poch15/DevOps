SELECT prd_cat, SUM(cnt) AS COUNT, ROUND(SUM(cnt) / SUM(SUM(cnt)) OVER() * 100.0, 2) AS percent
FROM v3_feedback
  WHERE
    date >= '{start_date}'
  AND
    date <= '{end_date}'
  AND
    branch_id IN {branch_ids}
  AND
    model {model}
  AND
    main_type  = {voc_types}
  AND
    prd_cat IN {prd_cat}
GROUP BY prd_cat
ORDER BY SUM(cnt) DESC