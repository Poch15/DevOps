SELECT cat_id, ver, SUM(cnt) as count, ROUND(SUM(cnt) / SUM(SUM(cnt)) OVER() * 100.0, 2) AS percent
FROM
(
SELECT cat_id, SUM(cnt) as cnt, 'v1' as ver FROM v3_faq
WHERE
  datetime >= '{start_date}'::timestamp
  AND
  datetime < '{end_date}'::timestamp + INTERVAL '1' DAY
	AND
  branch_id IN {branch_ids}
	AND
		CASE
    WHEN '{content_id}' = '0' THEN
      model {model}
    ELSE
      model {model} AND content_id = '{content_id}'
    END
  AND
    cast(content_id as integer) <= 100000
GROUP BY cat_id
UNION ALL
SELECT cat_id, SUM(cnt) as cnt, 'v2' as ver FROM v3_faq
WHERE
  datetime >= '{start_date}'::timestamp
  AND
  datetime < '{end_date}'::timestamp + INTERVAL '1' DAY
	AND
  branch_id IN {branch_ids}
	AND
		CASE
    WHEN '{content_id}' = '0' THEN
      model {model}
    ELSE
      model {model} AND content_id = '{content_id}'
    END
  AND
    cast(content_id as integer) > 100000
GROUP BY cat_id
) AS A
GROUP BY cat_id, ver
ORDER BY count DESC