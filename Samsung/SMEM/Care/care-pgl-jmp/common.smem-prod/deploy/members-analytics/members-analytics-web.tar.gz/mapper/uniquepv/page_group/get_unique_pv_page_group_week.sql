SELECT page_grp_id, yearval ||' '|| weekval ||'W' as yearweek, cnt
FROM
  (
    SELECT page_grp_id, extract(isoyear from dateval) as yearval, extract(week from dateval) as weekval, cnt
    FROM
    (
          (
            SELECT page_grp_id, date + interval '1' day as dateval, sum(cnt) as cnt
            FROM v3_unique_pv_weekly
            WHERE
              date >= '{start_date}'::date
            AND
              date < '{end_date}'::date + INTERVAL '1' DAY
            AND
              branch_id IN {branch_ids}
            AND
              page_grp_id IN {page_grp_id}
            GROUP BY page_grp_id, dateval
            ORDER BY page_grp_id, dateval
          )
    ) AS A
  ) AS B
