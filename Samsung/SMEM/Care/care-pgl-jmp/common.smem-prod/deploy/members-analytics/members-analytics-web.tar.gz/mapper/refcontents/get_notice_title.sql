SELECT noti_id, title, noti_start_dt, noti_end_dt
FROM notice
WHERE
noti_id IN {ids}