from common.dbutils import DBUtils
from common.branch_utils import BranchUtils
from common.chart_utils import ChartUtils
from common.excel_utils import ExcelUtils
from common.params_utils import ParamsUtils
from Device.controls import DeviceController
from NewUser.utils import NewUserUtils
from common.utils import Utils


class MyProductController:
    TYPE_PRODUCT_REGISTRATION = '0'
    TYPE_BOOK_APPOINTMENT = '1'
    TYPE_SUPPORT_REQUEST = '2'

    __STATUS = {
        'E0000': 'Requested',
        'E0003': 'Canceled by user',
        'E0003A': 'Canceled by system (No show)',
        'ST025': 'Engineer assigned',
        'E9999': 'Create failed', 'E0010': 'Already booked'
    }

    __NOT_IN_STATUS = ['E0010', 'E9999']

    __QUERY = {
        TYPE_PRODUCT_REGISTRATION: 'registration/get_registered_myproduct_',
        TYPE_BOOK_APPOINTMENT: 'get_myproduct_',
        TYPE_SUPPORT_REQUEST: 'get_myproduct_'
    }

    @staticmethod
    def get_count_chart_data(start_date, end_date, period, model, branch_ids, request_type):
        chart_name = ("New Products", "Total Products")

        return_rows = MyProductController.get_count_data(start_date, end_date, period, model, branch_ids, request_type)

        if request_type == MyProductController.TYPE_PRODUCT_REGISTRATION:
            status_chart_rows = MyProductController.convert_mp_chart_rows(return_rows, 'main')
            status_chart_data = MyProductController.wrap_status_chart_data(status_chart_rows, 'product')
        else:
            status_chart_rows = MyProductController.convert_type_chart_rows(return_rows, request_type, 'main')
            status_chart_data = MyProductController.wrap_status_chart_data(status_chart_rows, 'status')
            chart_name = ("New Requests", "Total Requests")

        total_cnt = MyProductController.get_count_data_total(start_date, branch_ids, request_type, model)

        ret_rows = MyProductController.get_total_count_data(start_date, end_date, period, model, branch_ids,
                                                            request_type)

        cumulative_rows = MyProductController.convert_chart_rows(ret_rows, total_cnt, chart_name[1])
        chart_data = ChartUtils.wrap_dual_stack_chart_data(chart_name[0], chart_name[1], status_chart_data, cumulative_rows)

        return chart_data

    @staticmethod
    def get_count_data(start_date, end_date, period, model, branch_ids, request_type):
        params = {
            'start_date': start_date,
            'end_date': end_date,
            'branch_ids': branch_ids,
            'model': model,
            'request_type': int(request_type)
        }

        sql = DBUtils.load_query('myproduct', MyProductController.__QUERY.get(request_type) + '%s.sql' % period)

        if request_type == MyProductController.TYPE_PRODUCT_REGISTRATION:
            params = MyProductController.update_params(branch_ids, params)

        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)
        return return_rows

    @staticmethod
    def get_total_count_data(start_date, end_date, period, model, branch_ids, request_type):
        params = {
            'start_date': start_date,
            'end_date': end_date,
            'branch_ids': branch_ids,
            'model': model,
            'request_type': int(request_type)
        }

        sql = DBUtils.load_query('myproduct', MyProductController.__QUERY.get(request_type) + 'cnt_%s.sql' % period)
        if request_type == MyProductController.TYPE_PRODUCT_REGISTRATION:
            params = MyProductController.update_params(branch_ids, params)

        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)
        return return_rows

    @staticmethod
    def get_cnty_data(start_date, end_date, period, branch_ids, model, request_type):
        params = {
            'start_date': start_date,
            'end_date': end_date,
            'branch_ids': branch_ids,
            'model': model,
            'request_type': request_type
        }

        sql = DBUtils.load_query('myproduct',
                                 MyProductController.__QUERY.get(request_type) + 'cnty_chart_%s.sql' % period)

        if request_type == MyProductController.TYPE_PRODUCT_REGISTRATION:
            params = MyProductController.update_params(branch_ids, params)

        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)
        return return_rows

    @staticmethod
    def get_cnty_chart_data(start_date, end_date, period, branch_ids, model, request_type):
        return_rows = MyProductController.get_cnty_data(start_date, end_date, period, branch_ids, model, request_type)
        sql = DBUtils.load_query('myproduct', MyProductController.__QUERY.get(request_type) + 'total.sql')
        chart_name = ("New Products", "Total Products")

        if request_type != MyProductController.TYPE_PRODUCT_REGISTRATION:
            cnty_chart_rows = ChartUtils.convert_country_chart_rows(return_rows)
            cnty_chart_data = ChartUtils.wrap_country_chart_data(cnty_chart_rows)
            chart_data = cnty_chart_data
        else:
            cnty_chart_rows = MyProductController.convert_mp_chart_rows(return_rows, 'cnty')
            cnty_chart_data = MyProductController.wrap_status_chart_data(cnty_chart_rows, 'product')

            params = {
                'start_date': start_date,
                'end_date': end_date,
                'branch_ids': branch_ids,
                'request_type': request_type,
                'model': model
            }

            if request_type == MyProductController.TYPE_PRODUCT_REGISTRATION:
                params = MyProductController.update_params(branch_ids, params)

            return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)
            total_cnt = return_rows[0][0]
            if total_cnt is None:
                total_cnt = 0

            sql = DBUtils.load_query('myproduct', MyProductController.__QUERY.get(request_type) + 'cnt_%s.sql' % period)
            ret_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)

            total_rows = MyProductController.convert_chart_rows(ret_rows, total_cnt, chart_name[1])
            chart_data = ChartUtils.wrap_dual_stack_chart_data(chart_name[0], chart_name[1], cnty_chart_data, total_rows)

        return chart_data

    @staticmethod
    def get_tab_count_data(start_date, end_date, branch_ids, model, tab_type, request_type, cur_p, page_size):
        params = {
            'start_date': start_date,
            'end_date': end_date,
            'branch_ids': branch_ids,
            'model': model,
            'request_type': request_type,
            'cur_p': cur_p
        }

        sql = DBUtils.load_query('myproduct', MyProductController.__QUERY.get(
            request_type) + 'analysis_%s_total_count.sql' % tab_type)

        if request_type == MyProductController.TYPE_PRODUCT_REGISTRATION:
            params = MyProductController.update_params(branch_ids, params)
            if tab_type == 'branch':
                company_name_dict = BranchUtils.get_company_name_dict()
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)
        total_count = return_rows[0][0]

        paging_params = ParamsUtils.get_paging_params(cur_p, total_count, page_size)
        params.update(paging_params)

        sql = DBUtils.load_query('myproduct',
                                 MyProductController.__QUERY.get(request_type) + 'analysis_%s.sql' % tab_type)
        if request_type == MyProductController.TYPE_PRODUCT_REGISTRATION:
            params = MyProductController.update_params(branch_ids, params)
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)

        category = []
        device_to_mkt_name_dict = DeviceController.get_device_to_mkt_name_dict()
        if tab_type == 'category':
            cat_dict = MyProductController.get_category()

        for row in return_rows:
            cat_item = row[0]
            if tab_type == 'category':
                cat_item = cat_dict.get(cat_item, "")
            elif tab_type == 'branch' and request_type == MyProductController.TYPE_PRODUCT_REGISTRATION:
                cat_item = company_name_dict.get(cat_item, "")
            category.append(cat_item)

        return dict(category=category, data=return_rows, count=len(return_rows),
                    tot_p=paging_params['total_page'], cur_p=int(cur_p))

    @staticmethod
    def get_count_data_total(start_date, branch_ids, request_type, model):
        sql = DBUtils.load_query('myproduct', MyProductController.__QUERY.get(request_type) + 'total.sql')

        params = {'start_date': start_date, 'branch_ids': branch_ids, 'request_type': request_type, 'model': model}
        if request_type == MyProductController.TYPE_PRODUCT_REGISTRATION:
            params = MyProductController.update_params(branch_ids, params)
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)
        tot_cnt = return_rows[0][0]
        if tot_cnt is None:
            tot_cnt = 0
        return tot_cnt

    @staticmethod
    def get_cnty_chart_data_total(start_date, branch_ids, request_type, model):
        sql = DBUtils.load_query('myproduct', 'get_myproduct_cnty_chart_total.sql')
        params = {'start_date': start_date, 'branch_ids': branch_ids, 'request_type': request_type, 'model': model}
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)

        prev_tot_dict = {}
        for row in return_rows:
            branch_id, cnt = row
            prev_tot_dict[branch_id] = cnt
        return prev_tot_dict

    @staticmethod
    def get_category():
        prd_cat_id_to_name_dict = {}
        prd_cat_dict = Utils.get_product_category_dict()
        for key in prd_cat_dict.keys():
            prd_cat_id_to_name_dict[key] = prd_cat_dict.get(key, {}).get('name', '')

        return prd_cat_id_to_name_dict

    @staticmethod
    def get_count_excel_data(start_date, end_date, period, branch_ids, model, request_type):
        return_rows = MyProductController.get_count_data(start_date, end_date, period, model, branch_ids, request_type)
        total_cnt = MyProductController.get_count_data_total(start_date, branch_ids, request_type, model)

        if int(request_type) == 0:
            file_name = 'my_product'
        elif int(request_type) == 1:
            file_name = 'book_appointment'
        else:
            file_name = 'support_request'
        file_name = ExcelUtils.get_file_name(file_name)

        excel_rows = MyProductController.convert_excel_rows(return_rows, total_cnt, request_type, 'main')
        excel_data = ExcelUtils.list_to_excel(file_name, excel_rows)
        return excel_data

    @staticmethod
    def get_country_excel_data(start_date, end_date, period, branch_ids, model, request_type):
        return_rows = MyProductController.get_cnty_data(start_date, end_date, period, branch_ids, model, request_type)
        if int(request_type) == 0:
            file_name = 'my_product_company_code'
        elif int(request_type) == 1:
            file_name = 'book_appointment_cnty'
        else:
            file_name = 'support_request_cnty'
        file_name = ExcelUtils.get_file_name(file_name)

        if int(request_type) != 0:
            total_cnt = MyProductController.get_cnty_chart_data_total(start_date, branch_ids, request_type, model)
            cnty_excel_rows = NewUserUtils.convert_cnty_excel_rows(return_rows, total_cnt, branch_ids, period)
            cnty_excel_data = NewUserUtils.cnty_list_to_excel(file_name, cnty_excel_rows)
        else:
            total_cnt = MyProductController.get_count_data_total(start_date, branch_ids, request_type, model)
            cnty_excel_rows = MyProductController.convert_excel_rows(return_rows, total_cnt, request_type, 'cnty')
            cnty_excel_data = ExcelUtils.list_to_excel(file_name, cnty_excel_rows)

        return cnty_excel_data

    @staticmethod
    def convert_chart_rows(rows, prev_tot_cnt, name):
        category = []
        row_list = []
        for row in rows:
            category.append(row[0])
            count = prev_tot_cnt + int(row[1])
            row_list.append(count)
            prev_tot_cnt = count
        convert = ChartUtils.row_to_column(row_list)

        data = {"name": name, "data": convert}
        return dict(category=category, data=data)

    @staticmethod
    def convert_excel_rows(rows, prev_tot_cnt, request_type, chart_type):
        if request_type != '0':
            excel_rows = [["Date", "Status", "Count(New)", "Count(Cumulative)"]]
            for row in rows:
                if row[1] != '' and row[1] not in MyProductController.__NOT_IN_STATUS:
                    if row[1] != 'E0003':
                        status_name = MyProductController.__STATUS[row[1]]
                    else:
                        if int(request_type) == 1:
                            status_name = MyProductController.__STATUS[row[1]]
                        else:
                            status_name = 'Consultation Completed'
                    count = prev_tot_cnt + int(row[2])
                    excel_rows.append([row[0], status_name, int(row[2]), count])
                    prev_tot_cnt = count
        else:
            if chart_type == 'main':
                excel_rows = [["Date", "Category", "Count(New)", "Count(Cumulative)"]]
                cat_dict = MyProductController.get_category()
                for row in rows:
                    if row[1] != -1:
                        cat_name = cat_dict[row[1]]
                        count = prev_tot_cnt + int(row[2])
                        excel_rows.append([row[0], cat_name, int(row[2]), count])
                        prev_tot_cnt = count
            else:
                company_dict = BranchUtils.get_company_name_dict()
                excel_rows = [["Date", "Company code", "Company name", "Count(New)", "Count(Cumulative)"]]
                for row in rows:
                    if row[1] != '':
                        count = prev_tot_cnt + int(row[2])
                        excel_rows.append([row[0], row[1], company_dict[row[1]], int(row[2]), count])
                        prev_tot_cnt = count
        return excel_rows

    @staticmethod
    def wrap_status_chart_data(chart_rows, chart_type):
        status_list = chart_rows['status_list']
        date_list = chart_rows['date_list']
        statistics_dic = chart_rows['statistics_dic']

        chart_data = []
        if chart_type == 'status':
            for status in status_list:
                if status != '' and status not in MyProductController.__NOT_IN_STATUS:
                    tmp_data = []
                    for _date in date_list:
                        value = statistics_dic.get((status, _date), 0)
                        tmp_data.append(value)
                    chart_data.append({"name": status, "data": tmp_data})
        elif chart_type == 'product':
            for status in status_list:
                tmp_data = []
                for _date in date_list:
                    value = statistics_dic.get((status, _date), 0)
                    tmp_data.append(value)
                chart_data.append({"name": status, "data": tmp_data})

        return dict(category=date_list, data=chart_data)

    @staticmethod
    def convert_type_chart_rows(rows, request_type, chart_type):
        dic = {}
        date_list = []
        statistics_dic = {}
        if chart_type == 'main':
            for return_row in rows:
                date, status, count = return_row
                if status == '':
                    date_list.append(date)
                elif status not in MyProductController.__NOT_IN_STATUS:
                    if status != 'E0003':
                        status_name = MyProductController.__STATUS[status]
                    else:
                        if int(request_type) == 1:
                            status_name = MyProductController.__STATUS[status]
                        else:
                            status_name = 'Consultation Completed'
                    dic[status_name] = dic.get(status_name, 0) + int(count)
                    statistics_dic[(status_name, date)] = int(count)
        elif chart_type == 'cnty':
            branch_dic = BranchUtils.get_all_branch_dict()
            for return_row in rows:
                branch_id, date, count = return_row
                if branch_id == 0:
                    date_list.append(date)
                else:
                    dic[(branch_dic[branch_id])] = dic.get(branch_dic[branch_id], 0) + int(count)
                    statistics_dic[(branch_dic[branch_id], date)] = int(count)
        status_list = sorted(dic, key=dic.get, reverse=True)

        return dict(status_list=status_list, date_list=date_list, statistics_dic=statistics_dic)

    @staticmethod
    def convert_mp_chart_rows(rows, chart_type):
        dic = {}
        date_list = []
        statistics_dic = {}
        if chart_type == 'main':
            cat_dict = MyProductController.get_category()
            for return_row in rows:
                date, cat, cnt = return_row
                if cat == -1:
                    date_list.append(date)
                else:
                    dic[cat_dict[cat]] = dic.get(cat_dict[cat], 0) + int(cnt)
                    statistics_dic[(cat_dict[cat], date)] = int(cnt)
        elif chart_type == 'cnty':
            company_dict = BranchUtils.get_company_name_dict()
            for return_row in rows:
                date, company_cd, cnt = return_row
                if company_cd == '':
                    date_list.append(date)
                else:
                    company_name = company_dict[company_cd]

                    dic[company_name] = dic.get(company_name, 0) + int(cnt)
                    statistics_dic[(company_name, date)] = statistics_dic.get((company_name, date), 0) + int(cnt)

        status_list = sorted(dic, key=dic.get, reverse=True)
        return dict(status_list=status_list, date_list=date_list, statistics_dic=statistics_dic)

    @staticmethod
    def update_params(branch_ids, params):
        company_codes = BranchUtils.get_company_code_list(branch_ids)
        params.update({'company_codes': company_codes})

        return params
