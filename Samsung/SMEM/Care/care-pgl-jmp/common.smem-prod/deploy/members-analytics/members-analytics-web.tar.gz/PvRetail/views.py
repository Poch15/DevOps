from django.shortcuts import render_to_response
from django.template.context import RequestContext
from common.utils import custom_login_required
from PvRetail.controls import PvRetailController
from django.views.decorators.http import require_http_methods


@custom_login_required
@require_http_methods(["GET"])
def view_pv_retail(request):

    pv_data_list = PvRetailController.get_pv_retail_data('pageView')
    banner_data_list = PvRetailController.get_pv_retail_data('banner')
    ctx = {
        'pv_data_list': pv_data_list,
        'banner_data_list': banner_data_list
    }

    return render_to_response('tmp_pv_retail.html', ctx, context_instance=RequestContext(request))


@custom_login_required
@require_http_methods(["GET"])
def export_excel(request):
    try:
        return PvRetailController.get_pv_retail_excel_data(
            type=request.GET.get("type")
        )
    except Exception:
        print("error")
