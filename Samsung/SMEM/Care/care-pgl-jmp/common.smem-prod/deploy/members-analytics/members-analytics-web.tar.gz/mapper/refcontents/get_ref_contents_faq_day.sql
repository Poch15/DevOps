(
SELECT datetime::date as date, referer, cat_id, sum(cnt) AS cnt
FROM v3_faq
WHERE
  datetime >= '{start_date}'::timestamp
  AND
  datetime < '{end_date}'::timestamp + INTERVAL '1' DAY
  AND
  branch_id IN {branch_ids}
  AND
    CASE
    WHEN '{content_id}' = '0' THEN
      model {model}
    ELSE
      model {model} AND content_id = '{content_id}'
    END
  AND
    CASE
    WHEN '{category}' = 'new' THEN
      cast(content_id as integer) > 100000
    WHEN '{category}' = 'old' THEN
      cast(content_id as integer) <= 100000
    ELSE
      cast(content_id as integer) > 0
    END
GROUP BY date, referer, cat_id
ORDER BY date, referer, cat_id
)
  UNION ALL
  (
    SELECT
      date,
      '' as referer,
      0 as cat_id,
      0 AS sum
    FROM
      (
        SELECT C.date
        FROM
          (
            SELECT '{start_date}' :: DATE + (100 * aa.a + 10 * bb.a + cc.a) AS date
            FROM (
                   SELECT 0 AS a
                   UNION ALL SELECT 1
                   UNION ALL SELECT 2
                   UNION ALL SELECT 3
                   UNION ALL SELECT 4
                   UNION ALL SELECT 5
                   UNION ALL SELECT 6
                   UNION ALL SELECT 7
                   UNION ALL SELECT 8
                   UNION ALL SELECT 9
                 ) AS aa CROSS JOIN
              (
                SELECT 0 AS a
                UNION ALL SELECT 1
                UNION ALL SELECT 2
                UNION ALL SELECT 3
                UNION ALL SELECT 4
                UNION ALL SELECT 5
                UNION ALL SELECT 6
                UNION ALL SELECT 7
                UNION ALL SELECT 8
                UNION ALL SELECT 9
              ) AS bb
              CROSS JOIN
              (
                SELECT 0 AS a
                UNION ALL SELECT 1
                UNION ALL SELECT 2
                UNION ALL SELECT 3
                UNION ALL SELECT 4
                UNION ALL SELECT 5
                UNION ALL SELECT 6
                UNION ALL SELECT 7
                UNION ALL SELECT 8
                UNION ALL SELECT 9
              ) AS cc
          ) AS C
        WHERE C.DATE < '{end_date}' :: DATE + INTERVAL '1' DAY
      ) AS D
  )
