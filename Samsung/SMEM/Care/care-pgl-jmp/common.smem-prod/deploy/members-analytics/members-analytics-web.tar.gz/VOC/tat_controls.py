from common.dbutils import DBUtils
from common.excel_utils import ExcelUtils
from common.branch_utils import BranchUtils
from Branch.controls import BranchController
from common.utils import Utils


class TaTController:

    @staticmethod
    def get_qna_tat_count(branch_ids, model, start_date, end_date, period, cs_type):
        sql = DBUtils.load_query('vocs', 'get_vocs_tat_%s.sql' % period)
        params = {'start_date': start_date, 'end_date': end_date,
                  'branch_ids': branch_ids, 'model': model,
                  'prd_cat': Utils.get_product_categories(cs_type)}
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)

        tot_avg_sql = DBUtils.load_query('vocs', 'get_vocs_tat_total_avg.sql')
        return_tot_avg = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL,
                                               tot_avg_sql, params)

        return return_rows, return_tot_avg

    @staticmethod
    def get_qna_tat_chart_count(branch_ids, model, start_date, end_date, period, cs_type):
        return_rows, return_tot_avg = TaTController.\
            get_qna_tat_count(branch_ids, model, start_date, end_date, period, cs_type)

        date_list = []
        period_avg_list = []
        tot_avg_list = []
        tot_cnt_list = []
        for return_row in return_rows:
            date_list.append(return_row[0])
            period_avg_list.append(float(return_row[1]))
            tot_cnt_list.append(int(return_row[2]))
            tot_avg_list.append(float(return_tot_avg[0][0]))

        data = [
            {"name": TaTController.get_display_period(period) + ' Average TAT', "data": period_avg_list},
            {"name": 'The number of QnA completed', "data": tot_cnt_list},
            {"name": 'Period Average TAT', "data": tot_avg_list}
        ]

        display_timezone = ''
        if BranchUtils.is_local_branch(branch_ids) is True:
            local_timezone = BranchController.get_local_time_zone(branch_ids[0])
            sign = ''
            if int(local_timezone) >= 0:
                sign = '+'
            display_timezone = ' (GMT' + sign + str(local_timezone) + ') '

        return dict(category=date_list, data=data,
                    display_timezone=display_timezone)

    @staticmethod
    def get_qna_tat_excel_count(branch_ids, model, start_date, end_date, period, cs_type):
        return_rows, return_tot_avg = TaTController.\
            get_qna_tat_count(branch_ids, model, start_date, end_date, period, cs_type)

        file_name = ExcelUtils.get_file_name("QNA_Average_TAT")

        excel_rows = [["Date", "Average TAT", "Count"]]
        excel_rows[0].extend(
            ["", "", "Period Average TAT", return_tot_avg[0][0]])
        for return_row in return_rows:
            excel_rows.append(
                [return_row[0], return_row[1], return_row[2]])

        excel_data = ExcelUtils.list_to_excel(file_name, excel_rows)
        return excel_data

    @staticmethod
    def get_display_period(period):
        display_period = ''
        if period == 'day':
            display_period = 'Daily'
        elif period == 'week':
            display_period = 'Weekly'
        elif period == 'month':
            display_period = 'Monthly'
        return display_period
