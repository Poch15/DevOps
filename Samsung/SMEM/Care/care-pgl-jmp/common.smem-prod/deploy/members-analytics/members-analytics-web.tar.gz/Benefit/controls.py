from common.dbutils import DBUtils
from common.chart_utils import ChartUtils
from common.params_utils import ParamsUtils
from common.branch_utils import BranchUtils
from Benefit.utils import BenefitTitle, BenefitUtils
from common.excel_utils import ExcelUtils
from sys import maxsize
from Device.controls import DeviceController
from common.date_utils import DateUtils


class BenefitController:
    @staticmethod
    def __get_count_data(start_date, end_date, period, branch_ids, model, timezone, benefit_id, branch_id):

        BenefitController.__get_branch_ids(branch_id, branch_ids)

        sql = DBUtils.load_query('benefit', 'get_benefit_%s.sql' % period)
        params = {
            'start_date': start_date,
            'end_date': end_date,
            'branch_ids': branch_ids,
            'model': model,
            'timezone': timezone,
            'interval_hour': timezone,
            'benefit_id': benefit_id,
            'tbl_name': BenefitUtils.get_tbl_info('benefit', period)
        }

        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)

        date_set = set()
        data_dict = {}
        from_list_counts = []
        from_home_counts = []
        for row in return_rows:
            date, count, home = row
            date_set.add(date)
            data_dict[(date, home)] = int(count)

        date_list = list(date_set)
        date_list.sort(key=DateUtils.get_date_sort_key(period))

        for date in date_list:
            from_list = data_dict.get((date, 0), 0)
            from_list_counts.append(from_list)

        for date in date_list:
            from_home = data_dict.get((date, 1), 0)
            from_home_counts.append(from_home)

        return dict(date_list=date_list, from_list_counts=from_list_counts, from_home_counts=from_home_counts)

    @staticmethod
    def get_analysis_title_data(start_dt, end_dt, period, branch_ids, model, tz, benefit_id, branch_id, cur_p, pg_size):

        BenefitController.__get_branch_ids(branch_id, branch_ids)

        # get total count
        sql = DBUtils.load_query('benefit/analysis', 'get_analysis_title_total_count.sql')
        params = {
            'start_date': start_dt,
            'end_date': end_dt,
            'branch_ids': branch_ids,
            'model': model,
            'timezone': tz,
            'benefit_id': benefit_id,
            'tbl_name': BenefitUtils.get_tbl_info('benefit', period)
        }
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)
        total_page, total_count = return_rows[0]

        # get title count
        paging_params = ParamsUtils.get_paging_params(cur_p, total_page, pg_size)
        params.update(paging_params)
        sql = DBUtils.load_query('benefit/analysis', 'get_analysis_title.sql')
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)

        title_list = BenefitController.get_title_list(return_rows)
        branch_list = BenefitController.get_branch_list(return_rows)

        return dict(category=title_list, data=return_rows, tot_p=paging_params['total_page'],
                    total_count=total_count, cur_p=int(cur_p), branch_list=branch_list)

    @staticmethod
    def get_analysis_device_data(start_dt, end_dt, period, branch_ids, model, tz, benefit_id, branch_id, cur_p,
                                 pg_size):

        BenefitController.__get_branch_ids(branch_id, branch_ids)

        # get total count
        sql = DBUtils.load_query('benefit/analysis', 'get_analysis_device_total_count.sql')
        params = {
            'start_date': start_dt,
            'end_date': end_dt,
            'branch_ids': branch_ids,
            'model': model,
            'timezone': tz,
            'benefit_id': benefit_id,
            'tbl_name': BenefitUtils.get_tbl_info('benefit', period)
        }
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)
        total_count = return_rows[0][0]

        # get tab count
        paging_params = ParamsUtils.get_paging_params(cur_p, total_count, pg_size)
        params.update(paging_params)
        sql = DBUtils.load_query('benefit/analysis', 'get_analysis_device.sql')
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)

        device_list = []
        device_to_mkt_name_dict = DeviceController.get_device_to_mkt_name_dict()
        for row in return_rows:
            device, cnt, percent = row
            mkt_name = device_to_mkt_name_dict.get(device, "")
            device = device + DeviceController.get_tab_mkt_name(mkt_name)
            device_list.append(device)

        return dict(category=device_list, data=return_rows, tot_p=paging_params['total_page'], cur_p=int(cur_p))

    @staticmethod
    def get_chart_count_data(start_date, end_date, period, branch_ids, model, timezone, benefit_id, branch_id):
        return_dict = BenefitController.__get_count_data(
            start_date, end_date, period, branch_ids, model, timezone, benefit_id, branch_id)

        date_list = return_dict['date_list']
        from_home_counts = return_dict['from_home_counts']
        from_list_counts = return_dict['from_list_counts']

        data = [
            {"name": "Benefit List", "data": from_list_counts},
            {"name": "Home", "data": from_home_counts}
        ]

        return dict(category=date_list, data=data)

    @staticmethod
    def get_title_list(return_rows):
        benefit_ids = list()
        for row in return_rows:
            benefit_id, count, percent, branch_id = row
            if benefit_id != '':
                benefit_ids.append((benefit_id, branch_id))

        benefit_title = BenefitTitle()
        title_dict = benefit_title.get_title_dict(BenefitTitle.OFFER, benefit_ids)
        cnty_dict = BranchUtils.get_country_names()

        title_list = list()
        for row in return_rows:
            benefit_id, count, percent, branch_id = row
            title_tuple = title_dict.get(benefit_id, None)
            if title_tuple is None or title_tuple[0] is None:
                title = 'Unknown' + " [ID:" + benefit_id + "]"
            else:
                title = title_tuple[0]
                country_code = title_tuple[1]
                upper_cnty_cd = str(country_code).upper()
                title += ' (' + cnty_dict.get(upper_cnty_cd, upper_cnty_cd) + ')'
            title_list.append(title)

        return title_list

    @staticmethod
    def get_branch_list(return_rows):
        branch_dict = BranchUtils.get_all_branch_dict()
        branch_list = []
        for row in return_rows:
            branch_id = row[3]
            branch_list.append(branch_dict.get(branch_id, 'Unknown'))
        return branch_list

    @staticmethod
    def get_count_excel_data(start_date, end_date, period, branch_ids, model, timezone, benefit_id, branch_id):
        return_dict = BenefitController.__get_count_data(
            start_date, end_date, period, branch_ids, model, timezone, benefit_id, branch_id)

        date_list = return_dict['date_list']
        from_home_counts = return_dict['from_home_counts']
        from_list_counts = return_dict['from_list_counts']

        excel_rows = [["Date", "Home", "Benefit List"]]
        for date, home, list in zip(date_list, from_home_counts, from_list_counts):
            excel_rows.append([date, home, list])

        excel_name = ExcelUtils.get_file_name("Benefit")
        title_rows = BenefitController.get_title_excel_data(
            start_date, end_date, period, branch_ids, model, timezone, benefit_id, branch_id)

        device_rows = BenefitController.get_device_excel_data(
            start_date, end_date, period, branch_ids, model, timezone, benefit_id, branch_id)

        excel_data = ExcelUtils.multi_list_to_contents_excel(
            excel_name, benefit_id, start_date, end_date, excel_rows, title_rows, device_rows)

        return excel_data

    @staticmethod
    def get_title_excel_data(start_date, end_date, period, branch_ids, model, timezone, benefit_id, branch_id):
        excel_data_dict = BenefitController.get_analysis_title_data(
            start_date, end_date, period, branch_ids, model, timezone, benefit_id, branch_id, 0, maxsize)

        title_list = excel_data_dict['category']
        data_list = excel_data_dict['data']
        branch_list = excel_data_dict['branch_list']

        excel_header = ['ID', 'Title', 'Count']
        excel_rows = [excel_header]
        for data, title, branch in zip(data_list, title_list, branch_list):
            benefit_id, count, percent, branch_id = data
            rows = [benefit_id, title, count]
            excel_rows.append(rows)

        return excel_rows

    @staticmethod
    def get_device_excel_data(start_date, end_date, period, branch_ids, model, timezone, benefit_id, branch_id):
        excel_data_dict = BenefitController.get_analysis_device_data(
            start_date, end_date, period, branch_ids, model, timezone, benefit_id, branch_id, 0, maxsize)

        data_list = excel_data_dict['data']
        excel_header = ['Device', 'Count']
        excel_rows = [excel_header]

        device_to_mkt_name_dict = DeviceController.get_device_to_mkt_name_dict()
        for data in data_list:
            model, count, percent = data
            mkt_name = device_to_mkt_name_dict.get(model, "")
            model = model + DeviceController.get_tab_mkt_name(mkt_name)
            rows = [model, count]
            excel_rows.append(rows)

        return excel_rows

    @staticmethod
    def __get_branch_ids(branch_id, branch_ids):
        return branch_ids if branch_id == '-1' else [branch_id]
