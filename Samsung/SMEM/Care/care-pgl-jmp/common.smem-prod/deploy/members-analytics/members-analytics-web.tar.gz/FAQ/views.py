from django.shortcuts import render_to_response
from django.template.context import RequestContext
from django.views.decorators.http import require_http_methods
from django.http import JsonResponse
from common.utils import custom_login_required
from SessionManager.controls import SessionManagerController
from FAQ.controls import FAQController
from common.params_utils import ParamsUtils


@custom_login_required
@require_http_methods(["GET"])
def view_faq(request):
    template = 'faq/faq_detail.html'
    return render_to_response(template, context_instance=RequestContext(request))


@custom_login_required
@require_http_methods(["GET"])
def get_count_chart_data(request):
    try:
        return JsonResponse(FAQController.get_count_chart_data(
            model=request.GET.get("query_model"),
            start_date=request.GET.get("start_date"),
            end_date=request.GET.get("end_date"),
            period=request.GET.get("period"),
            interval_hour=SessionManagerController.get_selected_time_zone(request),
            branch_ids=SessionManagerController.get_selected_branch_ids(request)))
    except Exception as e:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})


@custom_login_required
@require_http_methods(["GET"])
def get_analysis_tab_data(request):
    try:
        return JsonResponse(FAQController.get_analysis_tab_data(
            start_date=request.GET.get("start_date"),
            end_date=request.GET.get("end_date"),
            branch_ids=SessionManagerController.get_selected_branch_ids(request),
            model=request.GET.get("query_model"),
            interval_hour=SessionManagerController.get_selected_time_zone(request),
            tab_type=ParamsUtils.get_param(request, "tab_type"),
            cur_p=ParamsUtils.get_param(request, "cur_p"),
            page_size=int(ParamsUtils.get_param(request, "page_size"))
            )
        )
    except Exception as e:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})


@custom_login_required
@require_http_methods(["GET"])
def get_analysis_category_data(request):
    try:
        return JsonResponse(FAQController.get_analysis_category_data(
            start_date=request.GET.get("start_date"),
            end_date=request.GET.get("end_date"),
            branch_ids=SessionManagerController.get_selected_branch_ids(request),
            model=request.GET.get("query_model"),
            interval_hour=SessionManagerController.get_selected_time_zone(request)
            )
        )
    except Exception as e:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})


@custom_login_required
@require_http_methods(["GET"])
def export_excel(request):
    try:
        excel_count_data = FAQController.get_count_excel_data(
            start_date=ParamsUtils.get_param(request, "start_date"),
            end_date=ParamsUtils.get_param(request, "end_date"),
            period=ParamsUtils.get_param(request, "period"),
            branch_ids=SessionManagerController.get_selected_branch_ids(request),
            model=ParamsUtils.get_param(request, "query_model"),
            interval_hour=SessionManagerController.get_selected_time_zone(request),
        )
        return excel_count_data
    except Exception as e:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})