SELECT cat_id, cat_name
FROM category
WHERE
  lang_id = 3
AND
  cat_id IN ( SELECT cat_id FROM cat_node WHERE cat_type = 0 )
ORDER BY cat_id;