import os
from django.conf import settings
from django.db import connections, connection
from common.dbutils import DBUtils


class BranchUtils:

    @staticmethod
    def get_all_branch_dict():
        cursor = connections["mysql"].cursor()
        sql = open(os.path.join(settings.MAPPER_DIR, os.path.join('branch', 'get_all_branch.sql')), 'r').read()
        cursor.execute(sql)

        branch_dict = {}
        for idx in range(cursor.rowcount):
            row = cursor.fetchone()
            branch_dict[row[0]] = row[1]

        return branch_dict

    @staticmethod
    def get_all_region_dict():
        cursor = connections["mysql"].cursor()
        sql = open(os.path.join(
            settings.MAPPER_DIR, os.path.join('branch', 'get_all_region_by_branch.sql')), 'r').read()
        cursor.execute(sql)

        region_dict = dict()
        for idx in range(cursor.rowcount):
            row = cursor.fetchone()
            region_dict[row[0]] = row[1]

        return region_dict

    @staticmethod
    def get_region_branch_dict(region):
        cursor = connections["mysql"].cursor()
        sql_param = {"region": region}
        sql = open(os.path.join(settings.MAPPER_DIR, os.path.join('branch', 'get_region_branch.sql')), 'r').read()
        sql = sql.format(**sql_param)
        cursor.execute(sql)
        return_row = cursor.fetchall()
        branch_list = return_row

        branch_dict = {}
        for branch_id, branch_name in branch_list:
            if branch_id != 1 and branch_id != 20:
                branch_dict[branch_id] = branch_name

        return branch_dict

    @staticmethod
    def get_timezone_list(request):
        branch_id = request.session.get('branch_id')
        return_data = {}
        sql = open(os.path.join(settings.MAPPER_DIR, os.path.join('branch', 'get_timezone.sql')), 'r').read()
        if branch_id == 'region':
            params = {"branch_id": 0,
                      "branch_ids": list(BranchUtils.get_region_branch_dict(request.session.get('branch_name')).keys())}
        else:
            params = {"branch_id": int(branch_id), "branch_ids": list(branch_id)}
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_MYSQL, sql, params)

        if branch_id == '1' or branch_id == 'region':
            for cnty_name, tz, branch_id in return_rows:
                if branch_id == 20:
                    continue

                if tz > -1:
                    name = cnty_name + '(GMT+' + str(tz) + ')'
                else:
                    name = cnty_name + '(GMT' + str(tz) + ')'
                return_data[name] = str(tz)
        else:
            cnty_name, tz, branch_id = return_rows[0]
            if tz > -1:
                name = cnty_name + '(GMT+' + str(tz) + ')'
            else:
                name = cnty_name + '(GMT' + str(tz) + ')'
            return_data[name] = str(tz)

        return return_data

    @staticmethod
    def get_default_timezone(branch_id):
        return '0'

    @staticmethod
    def remove_samsungplus_and_mysamsung_branch(branch_ids):
        """
        S+ : USA(4)
        MySamsung : Indonesia(8), Singapore(14), Australia(16), New Zealand(71), Malaysia(72),
                    Thailand(73), Philippines(74), Vietnam(92), Myanmar(93), Cambodia(94)
        """
        remove_branch_ids = ('4', '8', '14', '16', '71', '72', '73', '74', '92', '93', '94')
        new_branch_list = []
        for branch in branch_ids:
            if branch not in remove_branch_ids:
                new_branch_list.append(branch)
        new_branch_list.append('0')
        return new_branch_list

    @staticmethod
    def get_country_names():
        cursor = connection.cursor()
        cursor.execute("SELECT cnty_cd_2, cnty_name from cnty_cd")

        cnty_dict = dict()
        for idx in range(cursor.rowcount):
            row = cursor.fetchone()
            cnty_dict[row[0]] = row[1]

        return cnty_dict

    @staticmethod
    def is_local_branch(branch_ids):
        if '0' in branch_ids:
            branch_ids.remove('0')
        return True if len(branch_ids) == 1 else False

    @staticmethod
    def get_company_name_dict():
        cursor = connection.cursor()
        cursor.execute("SELECT company_cd, company_name FROM v3_mp_company_info")

        company_dict = dict()
        for idx in range(cursor.rowcount):
            row = cursor.fetchone()
            company_dict[row[0]] = row[1]

        return company_dict

    @staticmethod
    def get_company_code_list(branch_ids):
        sql = open(os.path.join(settings.MAPPER_DIR, os.path.join('branch', 'get_company_code.sql')), 'r').read()
        params = {"branch_ids": branch_ids}
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)

        company_code_list = []
        for row in return_rows:
            if row[0] not in company_code_list:
                company_code_list.append(row[0])

        company_code_list = str(company_code_list).replace("[", "(").replace("]", ")")
        return company_code_list
