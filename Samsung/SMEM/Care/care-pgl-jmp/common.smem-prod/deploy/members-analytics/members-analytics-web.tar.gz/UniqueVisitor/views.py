from django.http import JsonResponse
from django.shortcuts import render_to_response
from django.template.context import RequestContext
from django.views.decorators.http import require_http_methods
from UniqueVisitor.controls import UniqueVisitorController
from common.utils import custom_login_required, access_log
from common.params_utils import ParamsUtils
from SessionManager.controls import SessionManagerController
from common.exception_handler import ExceptionHandler
from UniqueVisitor.drilldown_controls import UniqueVisitorDrillDownController


@ExceptionHandler(return_type=ExceptionHandler.RETURN_HTTP)
@custom_login_required
@require_http_methods(["GET"])
@access_log
def view_uv(request):
    data_type = ParamsUtils.get_param(request, "data_type")
    if data_type is not None and data_type == 'v3_uv_before':
        template = 'user/v3_uniquevisitor_before.html'
    elif data_type is not None and 'v3' in data_type:
        template = 'user/v3_uniquevisitor.html'
    else:
        template = 'user/uniquevisitor.html'
    return render_to_response(template, context_instance=RequestContext(request))


@custom_login_required
@require_http_methods(["GET"])
def get_chart_data(request):
    try:
        chart_data = UniqueVisitorController.get_chart_count_data(
            start_date=ParamsUtils.get_param(request, "start_date"),
            end_date=ParamsUtils.get_param(request, "end_date"),
            period=ParamsUtils.get_param(request, "period"),
            branch_ids=SessionManagerController.get_selected_branch_ids(request),
            model=ParamsUtils.get_param(request, "query_model"),
            timezone=SessionManagerController.get_selected_time_zone(request),
            data_type=ParamsUtils.get_param(request, "data_type"),
            branch_name=SessionManagerController.get_selected_branch_name(request)
        )
        return JsonResponse(chart_data)

    except Exception as e:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})


@custom_login_required
@require_http_methods(["GET"])
def get_excel_count_data(request):
    try:
        excel_count_data = UniqueVisitorController.get_excel_count_data(
            start_date=ParamsUtils.get_param(request, "start_date"),
            end_date=ParamsUtils.get_param(request, "end_date"),
            period=ParamsUtils.get_param(request, "period"),
            branch_ids=SessionManagerController.get_selected_branch_ids(request),
            model=ParamsUtils.get_param(request, "query_model"),
            timezone=SessionManagerController.get_selected_time_zone(request),
            data_type=ParamsUtils.get_param(request, "data_type")
        )
        return excel_count_data

    except Exception as e:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})


@custom_login_required
@require_http_methods(["GET"])
def get_country_chart_data(request):
    try:
        cnty_chart_data = UniqueVisitorController.get_country_chart_data(
            start_date=ParamsUtils.get_param(request, "start_date"),
            end_date=ParamsUtils.get_param(request, "end_date"),
            period=ParamsUtils.get_param(request, "period"),
            branch_ids=SessionManagerController.get_selected_branch_ids(request),
            model=ParamsUtils.get_param(request, "query_model"),
            interval_hour=SessionManagerController.get_selected_time_zone(request),
            data_type=ParamsUtils.get_param(request, "data_type")
        )
        return JsonResponse(cnty_chart_data)

    except Exception as e:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})


@custom_login_required
@require_http_methods(["GET"])
def get_country_excel_data(request):
    try:
        return UniqueVisitorController.get_country_excel_date(
            model=ParamsUtils.get_param(request, "query_model"),
            start_date=ParamsUtils.get_param(request, "start_date"),
            end_date=ParamsUtils.get_param(request, "end_date"),
            period=ParamsUtils.get_param(request, "period"),
            interval_hour=SessionManagerController.get_selected_time_zone(request),
            branch_ids=SessionManagerController.get_selected_branch_ids(request),
            data_type=ParamsUtils.get_param(request, "data_type")
        )

    except Exception as e:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})


@custom_login_required
@require_http_methods(["GET"])
def get_tab_count_data(request):
    try:
        tab_count_data = UniqueVisitorController.get_tab_count_data(
            cur_date=ParamsUtils.get_param(request, "cur_date"),
            period=ParamsUtils.get_param(request, "period"),
            branch_ids=SessionManagerController.get_selected_branch_ids(request),
            model=ParamsUtils.get_param(request, "query_model"),
            interval_hour=SessionManagerController.get_selected_time_zone(request),
            cur_p=ParamsUtils.get_param(request, "cur_p"),
            tab_type=ParamsUtils.get_param(request, "tab_type"),
            view_type=ParamsUtils.get_param(request, "view_type"),
            page_size=int(ParamsUtils.get_param(request, "page_size")),
            data_type=ParamsUtils.get_param(request, "data_type")
        )
        return JsonResponse(tab_count_data)

    except Exception as e:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})


@custom_login_required
@require_http_methods(["GET"])
def get_tab_excel_data(request):
    try:
        excel_count_data = UniqueVisitorController.get_tab_excel_data(
            cur_date=ParamsUtils.get_param(request, "cur_date"),
            period=ParamsUtils.get_param(request, "period"),
            branch_ids=SessionManagerController.get_selected_branch_ids(request),
            model=ParamsUtils.get_param(request, "query_model"),
            tab_type=ParamsUtils.get_param(request, "tab_type"),
            data_type=ParamsUtils.get_param(request, "data_type")
        )
        return excel_count_data

    except Exception as e:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})


@custom_login_required
@require_http_methods(["GET"])
def get_drilldown_chart_data(request):
    try:
        chart_data = UniqueVisitorDrillDownController.get_drilldown_chart_data(
            start_date=ParamsUtils.get_param(request, "start_date"),
            end_date=ParamsUtils.get_param(request, "end_date"),
            period=ParamsUtils.get_param(request, "period"),
            branch_ids=SessionManagerController.get_selected_branch_ids(request),
            model=ParamsUtils.get_param(request, "query_model"),
            data_type=ParamsUtils.get_param(request, "data_type")
        )
        return JsonResponse(chart_data)

    except Exception as e:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})


@custom_login_required
@require_http_methods(["GET"])
def get_drilldown_excel_count_data(request):
    try:
        excel_count_data = UniqueVisitorDrillDownController.get_drilldown_excel_count_data(
            start_date=ParamsUtils.get_param(request, "start_date"),
            end_date=ParamsUtils.get_param(request, "end_date"),
            period=ParamsUtils.get_param(request, "period"),
            branch_ids=SessionManagerController.get_selected_branch_ids(request),
            model=ParamsUtils.get_param(request, "query_model"),
            data_type=ParamsUtils.get_param(request, "data_type")
        )
        return excel_count_data

    except Exception as e:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})
