SELECT
	CASE WHEN monthval < 10 THEN yearval || '/0' || monthval
			ELSE yearval || '/' || monthval
			END AS yearmonth,
	category_id, cnt
FROM
(
	SELECT EXTRACT(year FROM date) as yearval, EXTRACT(month FROM date) as monthval,
			category_id, SUM(cnt) as cnt
	FROM
	(
		SELECT (datetime + INTERVAL '{interval_hour}' HOUR)::date as date, category_id, cnt
		FROM tbl_v2_faq
		WHERE
		  datetime >= '{start_date}'::timestamp - INTERVAL '{interval_hour}' HOUR
	    AND
	    datetime < '{end_date}'::timestamp - INTERVAL '{interval_hour}' HOUR + INTERVAL '1' DAY
			AND
			branch_id IN {branch_ids}
			AND
			model like '{model}%'
	) AS A
	GROUP BY EXTRACT(year FROM date), EXTRACT(month FROM date), category_id
	ORDER BY EXTRACT(year FROM date), EXTRACT(month FROM date), category_id
) AS B