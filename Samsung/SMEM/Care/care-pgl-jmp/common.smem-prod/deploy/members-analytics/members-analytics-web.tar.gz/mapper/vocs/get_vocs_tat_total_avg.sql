SELECT ROUND(SUM(tot_sec) / SUM(cnt) / 3600, 2) as total_avg
FROM v3_feedback_tat
WHERE
  datetime >= '{start_date}'
AND
  datetime < '{end_date}'::timestamp + INTERVAL '1' DAY
AND
  branch_id IN {branch_ids}
AND
  prd_cat IN {prd_cat}
AND
  model {model}