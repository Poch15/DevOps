SELECT m.name, d.dvc_model
FROM mkt_name m, device d
WHERE
m.mkt_id = d.mkt_id
AND
d.dvc_type != 'ThirdParty'