from Device.controls import DeviceController


class ParamsUtils:

    @staticmethod
    def get_param(request, name):
        if name == "query_model":
            param = DeviceController.get_device_list(request.GET.get(name))
        else:
            param = request.GET.get(name)
        return param

    @staticmethod
    def get_paging_params(cur_p, total_count, limit=10):
        offset = int(cur_p) * limit
        total_page = int(total_count / limit)
        if total_count % limit != 0:
            total_page += 1

        paging_params = {'limit': limit, 'offset': offset, 'total_page': total_page}
        return paging_params

    @staticmethod
    def convert_list_to_tuple_params(params):
        return str(params).replace("[", "(").replace("]", ")")