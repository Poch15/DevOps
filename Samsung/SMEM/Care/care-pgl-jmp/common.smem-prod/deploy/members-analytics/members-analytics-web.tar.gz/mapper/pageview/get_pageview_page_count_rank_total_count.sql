SELECT count(*), sum(cnt) as total_cnt
FROM
(
	SELECT screen_id, sum(cnt) as cnt
  FROM {tbl_name}
  WHERE
      date >= '{start_date}'
  AND
      date <= '{end_date}'
  AND
      branch_id IN {branch_ids}
    AND
    model {model}
	GROUP BY screen_id
) AS A LEFT JOIN tbl_v2_screen_pv_info B
ON A.screen_id = B.screen_id