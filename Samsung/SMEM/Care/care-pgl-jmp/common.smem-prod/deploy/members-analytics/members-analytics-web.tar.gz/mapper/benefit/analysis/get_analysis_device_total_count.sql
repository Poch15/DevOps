SELECT COUNT(*)
FROM
(
  SELECT model
  FROM {tbl_name}
    WHERE
      date >= '{start_date}'
    AND
      date <= '{end_date}'
    AND
      timezone = {timezone}
    AND
      branch_id IN {branch_ids}
    AND
      CASE
        WHEN '{benefit_id}' = '0' THEN
          model {model} AND benefit_id != ''
        ELSE
          model {model} AND benefit_id = '{benefit_id}'
      END
  GROUP BY model
) AS A