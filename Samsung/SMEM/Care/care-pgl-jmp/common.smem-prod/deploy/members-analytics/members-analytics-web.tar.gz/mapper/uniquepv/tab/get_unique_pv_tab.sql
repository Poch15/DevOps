SELECT page_grp_id, sum(cnt) as count, ROUND(SUM(cnt) / SUM(SUM(cnt)) OVER() * 100.0, 2) AS percent
FROM {tbl_name}
WHERE
      date = '{date} '::timestamp
    AND
      branch_id IN {branch_ids}
    AND
      page_grp_id IN (SELECT id FROM v3_unique_pv_info WHERE is_use = true)
GROUP BY page_grp_id
ORDER BY count DESC
LIMIT {limit} OFFSET {offset}