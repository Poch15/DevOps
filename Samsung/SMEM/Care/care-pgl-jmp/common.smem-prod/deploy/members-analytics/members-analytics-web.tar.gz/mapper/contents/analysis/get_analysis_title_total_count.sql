SELECT COUNT(*), SUM(count) as total_count
FROM
(
  SELECT contents_id, contents_type, SUM(cnt) as count, branch_id
  FROM tbl_v2_contents
  WHERE
    datetime >= '{start_date}'::timestamp - INTERVAL '{interval_hour}' HOUR
    AND
    datetime < '{end_date}'::timestamp - INTERVAL '{interval_hour}' HOUR + INTERVAL '1' DAY
    AND
    contents_type = {contents_type}
    AND
    branch_id IN {branch_ids}
    AND
    model {model}
  GROUP BY contents_id, branch_id, contents_type
) AS A