from common.dbutils import DBUtils
from common.chart_utils import ChartUtils
from common.excel_utils import ExcelUtils
from common.params_utils import ParamsUtils
from common.branch_utils import BranchUtils
from Device.controls import DeviceController


class PageViewController:

    @staticmethod
    def get_count_data(start_date, end_date, period, branch_ids, model, page_id):
        sql = DBUtils.load_query('pageview', 'get_pageview_%s.sql' % period)
        params = {'start_date': start_date, 'end_date': end_date, 'branch_ids': branch_ids,
                  'model': model, 'page_id': page_id}
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)
        return return_rows

    @staticmethod
    def get_count_chart_data(start_date, end_date, period, branch_ids, model, page_id):
        return_rows = PageViewController.get_count_data(start_date, end_date, period, branch_ids, model, page_id)

        chart_rows = ChartUtils.convert_chart_rows(return_rows)
        chart_data = ChartUtils.wrap_chart_data('Page View', chart_rows)
        return chart_data

    @staticmethod
    def get_count_excel_data(start_date, end_date, period, branch_ids, model, page_id):
        return_rows = PageViewController.get_count_data(start_date, end_date, period, branch_ids, model, page_id)

        excel_name = ExcelUtils.get_file_name('pageview')
        excel_rows = ExcelUtils.convert_excel_rows(return_rows)
        excel_data = ExcelUtils.list_to_excel(excel_name, excel_rows)
        return excel_data

    @staticmethod
    def get_country_count_data(start_date, end_date, period, branch_ids, model, page_id):
        sql = DBUtils.load_query('pageview', 'get_pageview_cnty_%s.sql' % period)
        params = {'start_date': start_date, 'end_date': end_date, 'branch_ids': branch_ids,
                  'model': model, 'page_id': page_id}
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)
        return return_rows

    @staticmethod
    def get_country_count_chart_data(start_date, end_date, period, branch_ids, model, page_id):
        return_rows = PageViewController.get_country_count_data(start_date, end_date, period, branch_ids, model, page_id)
        chart_rows = ChartUtils.convert_country_chart_rows_except_zero(return_rows, period)
        chart_data = ChartUtils.wrap_country_chart_data(chart_rows)
        return chart_data

    @staticmethod
    def get_country_excel_data(start_date, end_date, period, branch_ids, model, page_id):
        return_rows = PageViewController.get_country_count_data(start_date, end_date, period, branch_ids, model, page_id)

        excel_name = ExcelUtils.get_file_name('pageview_cnty')
        excel_rows = ExcelUtils.convert_cnty_excel_rows_except_zero(return_rows, branch_ids, period)
        excel_data = ExcelUtils.list_to_excel(excel_name, excel_rows)
        return excel_data

    @staticmethod
    def get_tab_count_data(start_date, end_date, branch_ids, model, page_id, cur_p, page_size, tab_type, period):
        # get total count
        sql = DBUtils.load_query('pageview', 'get_pageview_tab_total.sql')
        params = {'start_date': start_date, 'end_date': end_date, 'branch_ids': branch_ids, 'model': model,
                  'page_id': page_id, 'cur_p': cur_p, 'tab_type': tab_type,
                  'tbl_name': PageViewController.get_table_name_by_period(period)}
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)
        total_count = return_rows[0][0]

        # get tab count
        paging_params = ParamsUtils.get_paging_params(cur_p, total_count, page_size)
        params.update(paging_params)
        params["model"] = model
        sql = DBUtils.load_query('pageview', 'get_pageview_tab.sql')
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)

        category = []
        device_to_mkt_name_dict = DeviceController.get_device_to_mkt_name_dict()
        for row in return_rows:
            cat_item, cnt, percent = row
            if tab_type == 'model':
                mkt_name = device_to_mkt_name_dict.get(cat_item, "")
                cat_item = cat_item + DeviceController.get_tab_mkt_name(mkt_name)
            category.append(cat_item)

        return dict(category=category, data=return_rows, tot_p=paging_params['total_page'],
                    cur_p=int(cur_p), limit=paging_params['limit'])

    @staticmethod
    def get_pagerank_count_data(start_date, end_date, branch_ids, model, page_id, cur_p, page_size, period):
        # get total count
        sql = DBUtils.load_query('pageview', 'get_pageview_page_count_rank_total_count.sql')
        params = {'start_date': start_date, 'end_date': end_date, 'branch_ids': branch_ids,
                  'model': model, 'page_id': page_id, 'cur_p': cur_p,
                  'tbl_name': PageViewController.get_table_name_by_period(period)}
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)
        total_page, total_count = return_rows[0]

        # get page count rank
        paging_params = ParamsUtils.get_paging_params(cur_p, total_page, page_size)
        params.update(paging_params)
        sql = DBUtils.load_query('pageview', 'get_pageview_page_count_rank_day.sql')
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)

        category = []
        page_name_list = []
        for row in return_rows:
            page_id, cnt, percent, page_name, app_type, ux_version = row
            category.append(page_id)
            page_name_list.append(page_name)

        return dict(category=category, page_name=page_name_list, data=return_rows, limit=paging_params['limit'],
                    total_count=total_count, tot_p=paging_params['total_page'], cur_p=int(cur_p))

    @staticmethod
    def get_tab_excel_data(start_date, end_date, branch_ids, model, page_id, tab_type, period):
        params = {'start_date': start_date, 'end_date': end_date, 'branch_ids': branch_ids,
                  'model': model, 'page_id': page_id,
                  'tab_type': tab_type, 'limit': 'ALL', 'offset': 0,
                  'tbl_name': PageViewController.get_table_name_by_period(period)}

        if tab_type == 'page_id':
            sql = DBUtils.load_query('pageview', 'get_pageview_page_count_rank_day.sql')
            return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)

            # remove unused column
            for idx, row in enumerate(return_rows):
                page_id, cnt, percent, page_name, app_type, ux_version = row
                return_rows[idx] = [page_name, cnt, percent, ux_version]

        else:
            sql = DBUtils.load_query('pageview', 'get_pageview_tab.sql')
            return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)

        excel_name = ExcelUtils.get_file_name('pageview_' + tab_type)
        excel_rows = ExcelUtils.convert_tab_excel_rows('tab_'+tab_type, return_rows)
        excel_data = ExcelUtils.list_to_excel(excel_name, excel_rows)

        return excel_data

    @staticmethod
    def get_pv_mapping_info():
        sql = DBUtils.load_query('pageview', 'get_pageview_mapping_info.sql')
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, {})
        pv_info_dict = {}
        event_info_list = []
        for row in return_rows:
            screen_id, screen_name, event_target_id, event_name, ux_version = row
            pv_info_dict[screen_id] = {"screen_id": screen_id, "screen_name": screen_name, "ux_version": ux_version}
            if event_target_id:
                event_info_list.append({"event_target_id": event_target_id, "event_name": event_name,
                                        "ux_version": ux_version})
        return dict(pv_info_list=list(pv_info_dict.values()), event_info_list=event_info_list)

    @staticmethod
    def get_table_name_by_period(period):
        tbl_dic = {
            'day': 'v3_screenview_daily',
            'week': 'v3_screenview_weekly',
            'month': 'v3_screenview_monthly'
        }

        tbl_name = tbl_dic[period]
        return tbl_name
