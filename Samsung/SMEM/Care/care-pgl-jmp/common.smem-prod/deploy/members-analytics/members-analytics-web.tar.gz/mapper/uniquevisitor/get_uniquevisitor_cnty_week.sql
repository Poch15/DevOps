SELECT branch_id,
        EXTRACT(isoyear FROM (date + INTERVAL '1' DAY)) || '-'
      || EXTRACT(week FROM (date + INTERVAL '1' DAY)) ||'W' AS yearweek,
      SUM(cnt)
FROM {tbl_name}
WHERE
    date >= '{start_date}'
  AND
    date <= '{end_date}'
  AND
    timezone = {timezone}
  AND
    branch_id IN {branch_ids}
GROUP BY branch_id, date
ORDER BY branch_id, date