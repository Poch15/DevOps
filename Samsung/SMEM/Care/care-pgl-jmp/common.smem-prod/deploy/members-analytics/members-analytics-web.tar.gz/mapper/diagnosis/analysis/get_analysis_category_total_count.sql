SELECT COUNT(*)
FROM
(
  SELECT cat_id
  FROM {tbl_name}
  WHERE
    datetime >= '{start_date}'::timestamp
    AND
    datetime < '{end_date}'::timestamp + INTERVAL '1' DAY
    AND
    branch_id IN {branch_ids}
    AND
    model {model}
  GROUP BY cat_id
) AS A