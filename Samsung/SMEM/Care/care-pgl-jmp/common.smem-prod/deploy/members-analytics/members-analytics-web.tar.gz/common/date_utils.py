from datetime import datetime, timedelta
from common.utils import Utils


class DateUtils:
    @staticmethod
    def create_date_list(start_date, end_date, period):
        start_date = datetime.strptime(start_date, '%Y-%m-%d')
        end_date = datetime.strptime(end_date, '%Y-%m-%d')
        date_list = []

        if period == 'day':
            delta = timedelta(days=1)
            while start_date <= end_date:
                date_list.append(start_date.date())
                start_date += delta

        elif period == 'week':
            # set start date to Sunday
            start_date = start_date - timedelta(
                days=(start_date.isoweekday()) % 7
            )
            start_date += timedelta(days=1)

            delta = timedelta(days=7)
            while start_date <= end_date + timedelta(days=1):
                year = str(start_date.isocalendar()[0])
                week = str(start_date.isocalendar()[1])

                date_list.append(year + ' ' + week + 'W')
                start_date += delta

            # date_list = list(set(date_list))
            # date_list.sort()
            date_list = [data.replace(' 0', ' ') for data in date_list]

        elif period == 'month':
            start_date = datetime(start_date.year, start_date.month, 1)
            end_date = datetime(end_date.year, end_date.month, 1)
            while start_date <= end_date:
                date_list.append(start_date.strftime('%Y/%m'))
                if start_date.month == 12:
                    start_date = datetime(start_date.year + 1, 1, 1)
                else:
                    start_date = datetime(start_date.year, start_date.month + 1, 1)

            date_list = list(set(date_list))
            date_list.sort()

        elif period == 'hour':
            end_date += timedelta(days=1)
            delta = timedelta(hours=1)
            while start_date < end_date:
                date_list.append(start_date.strftime('%Y-%m-%d %H:%M'))
                start_date += delta

        return date_list

    @staticmethod
    def get_timedelta_days_ago(date, timedelta_days):
        date = datetime.strptime(date, '%Y-%m-%d')
        date = date - timedelta(days=timedelta_days)
        return date

    @staticmethod
    def get_date_sort_key(period):
        return None if period == 'day' else Utils.alphanum_key

    @staticmethod
    def is_default_date_range(_start_date, _end_date, timedelta_days, period):
        end_date = datetime.now()

        if period == 'week':
            diff = ((end_date.weekday() + 1) % 7) + timedelta_days
            start_date = end_date - timedelta(days=diff)
        else:
            start_date = end_date - timedelta(days=timedelta_days)

        start_date = start_date.strftime('%Y-%m-%d')

        end_date = end_date - timedelta(days=1)
        end_date = end_date.strftime('%Y-%m-%d')

        return True if _start_date == start_date and _end_date == end_date else False
