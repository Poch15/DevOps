from django.http import JsonResponse
from django.shortcuts import render_to_response
from django.template.context import RequestContext
from django.views.decorators.http import require_http_methods
from Retention.controls import RetentionController
from common.utils import custom_login_required, access_log
from common.params_utils import ParamsUtils
from SessionManager.controls import SessionManagerController
from common.exception_handler import ExceptionHandler


@ExceptionHandler(return_type=ExceptionHandler.RETURN_HTTP)
@custom_login_required
@require_http_methods(["GET"])
@access_log
def view(request):
    template = 'retention/retention.html'
    return render_to_response(template, context_instance=RequestContext(request))


@custom_login_required
@require_http_methods(["GET"])
def get_retention(request):
    try:
        chart_data = RetentionController.get_retention(
            start_date=ParamsUtils.get_param(request, "start_date"),
            end_date=ParamsUtils.get_param(request, "end_date"),
            period=ParamsUtils.get_param(request, "period"),
            branch_ids=SessionManagerController.get_selected_branch_ids(request),
            branch_name=SessionManagerController.get_selected_branch_name(request)
        )
        return JsonResponse(chart_data)
    except Exception as e:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})


@custom_login_required
@require_http_methods(["GET"])
def get_excel_data(request):
    try:
        excel_data = RetentionController.get_retention_excel_data(
            start_date=ParamsUtils.get_param(request, "start_date"),
            end_date=ParamsUtils.get_param(request, "end_date"),
            period=ParamsUtils.get_param(request, "period"),
            branch_ids=SessionManagerController.get_selected_branch_ids(request)
        )
        return excel_data
    except Exception as e:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})
