SELECT
    CASE WHEN month < 10 THEN year || '/0' || month
         ELSE year || '/' || month
         END as yearmonth, imp_cnt, click_cnt
FROM
(
    SELECT EXTRACT(YEAR FROM DATE) AS YEAR, EXTRACT(MONTH FROM DATE) AS MONTH, SUM(imp_cnt) AS imp_cnt, SUM(click_cnt) AS click_cnt
    FROM v3_banner
    WHERE
    DATE >= '{start_date}'
    AND
    DATE <= '{end_date}'
    AND
    branch_id IN {branch_ids}
    AND
        CASE
        WHEN '{banner_id}' = '0' THEN
          model {model}
        ELSE
          model {model} AND banner_id = '{banner_id}'
        END
    GROUP BY YEAR, month
) AS A
ORDER BY yearmonth