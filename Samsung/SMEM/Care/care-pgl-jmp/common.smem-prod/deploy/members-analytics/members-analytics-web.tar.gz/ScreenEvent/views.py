from django.shortcuts import render_to_response
from django.template.context import RequestContext
from django.views.decorators.http import require_http_methods
from django.http import JsonResponse
from common.utils import custom_login_required, access_log
from ScreenEvent.controls import ScreenEventController
from common.exception_handler import ExceptionHandler
from common.params_utils import ParamsUtils
from SessionManager.controls import SessionManagerController


@ExceptionHandler(return_type=ExceptionHandler.RETURN_JSON)
@custom_login_required
@require_http_methods(["GET"])
@access_log
def view_screenevent(request):
    template = 'screenevent/event_overview.html'
    return render_to_response(template, context_instance=RequestContext(request))


@ExceptionHandler(return_type=ExceptionHandler.RETURN_JSON)
@custom_login_required
@require_http_methods(["GET"])
def get_chart_data(request):
    chart_data = ScreenEventController.get_count_chart_data(
        start_date=ParamsUtils.get_param(request, "start_date"),
        end_date=ParamsUtils.get_param(request, "end_date"),
        period=ParamsUtils.get_param(request, "period"),
        branch_ids=SessionManagerController.get_selected_branch_ids(request),
        model=ParamsUtils.get_param(request, "query_model"),
        interval_hour=SessionManagerController.get_selected_time_zone(request),
        page_id=ParamsUtils.get_param(request, "page_id"),
        event_id=ParamsUtils.get_param(request, "event_id")
    )
    return JsonResponse(chart_data)


@ExceptionHandler(return_type=ExceptionHandler.RETURN_HTTP)
@custom_login_required
@require_http_methods(["GET"])
def get_excel_data(request):
    excel_data = ScreenEventController.get_count_excel_data(
        start_date=ParamsUtils.get_param(request, "start_date"),
        end_date=ParamsUtils.get_param(request, "end_date"),
        period=ParamsUtils.get_param(request, "period"),
        branch_ids=SessionManagerController.get_selected_branch_ids(request),
        model=ParamsUtils.get_param(request, "query_model"),
        interval_hour=SessionManagerController.get_selected_time_zone(request),
        page_id=ParamsUtils.get_param(request, "page_id"),
        event_id=ParamsUtils.get_param(request, "event_id")
    )
    return excel_data


@ExceptionHandler(return_type=ExceptionHandler.RETURN_JSON)
@custom_login_required
@require_http_methods(["GET"])
def get_cnty_chart_data(request):
    cnty_chart_data = ScreenEventController.get_country_count_chart_data(
        start_date=ParamsUtils.get_param(request, "start_date"),
        end_date=ParamsUtils.get_param(request, "end_date"),
        period=ParamsUtils.get_param(request, "period"),
        branch_ids=SessionManagerController.get_selected_branch_ids(request),
        model=ParamsUtils.get_param(request, "query_model"),
        interval_hour=SessionManagerController.get_selected_time_zone(request),
        page_id=ParamsUtils.get_param(request, "page_id"),
        event_id=ParamsUtils.get_param(request, "event_id")
    )
    return JsonResponse(cnty_chart_data)


@ExceptionHandler(return_type=ExceptionHandler.RETURN_HTTP)
@custom_login_required
@require_http_methods(["GET"])
def get_cnty_excel_data(request):
    cnty_excel_data = ScreenEventController.get_country_excel_data(
        start_date=ParamsUtils.get_param(request, "start_date"),
        end_date=ParamsUtils.get_param(request, "end_date"),
        period=ParamsUtils.get_param(request, "period"),
        branch_ids=SessionManagerController.get_selected_branch_ids(request),
        model=ParamsUtils.get_param(request, "query_model"),
        interval_hour=SessionManagerController.get_selected_time_zone(request),
        page_id=ParamsUtils.get_param(request, "page_id"),
        event_id=ParamsUtils.get_param(request, "event_id")
    )
    return cnty_excel_data


@ExceptionHandler(return_type=ExceptionHandler.RETURN_JSON)
@custom_login_required
@require_http_methods(["GET"])
def get_tab_count_data(request):
    tab_type = ParamsUtils.get_param(request, "tab_type")

    if tab_type == 'event':
        tab_count_data = ScreenEventController.get_event_rank_count_data(
            start_date=ParamsUtils.get_param(request, "start_date"),
            end_date=ParamsUtils.get_param(request, "end_date"),
            branch_ids=SessionManagerController.get_selected_branch_ids(request),
            model=ParamsUtils.get_param(request, "query_model"),
            page_id=ParamsUtils.get_param(request, "page_id"),
            cur_p=int(ParamsUtils.get_param(request, "cur_p")),
            page_size=int(ParamsUtils.get_param(request, "page_size"))
        )
    else:
        tab_count_data = ScreenEventController.get_tab_count_data(
            start_date=ParamsUtils.get_param(request, "start_date"),
            end_date=ParamsUtils.get_param(request, "end_date"),
            branch_ids=SessionManagerController.get_selected_branch_ids(request),
            model=ParamsUtils.get_param(request, "query_model"),
            page_id=ParamsUtils.get_param(request, "page_id"),
            event_id=ParamsUtils.get_param(request, "event_id"),
            cur_p=int(ParamsUtils.get_param(request, "cur_p")),
            page_size=int(ParamsUtils.get_param(request, "page_size")),
            tab_type=tab_type,
        )
    return JsonResponse(tab_count_data)


@ExceptionHandler(return_type=ExceptionHandler.RETURN_HTTP)
@custom_login_required
@require_http_methods(["GET"])
def get_tab_excel_data(request):
    tab_excel_data = ScreenEventController.get_tab_excel_data(
            start_date=ParamsUtils.get_param(request, "start_date"),
            end_date=ParamsUtils.get_param(request, "end_date"),
            branch_ids=SessionManagerController.get_selected_branch_ids(request),
            model=ParamsUtils.get_param(request, "query_model"),
            interval_hour=SessionManagerController.get_selected_time_zone(request),
            page_id=ParamsUtils.get_param(request, "page_id"),
            event_id=ParamsUtils.get_param(request, "event_id"),
            tab_type=ParamsUtils.get_param(request, "tab_type"),
            period=ParamsUtils.get_param(request, "period")
    )

    return tab_excel_data
