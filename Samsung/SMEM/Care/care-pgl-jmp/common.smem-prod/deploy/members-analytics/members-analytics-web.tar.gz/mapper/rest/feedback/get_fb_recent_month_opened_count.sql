SELECT count(*)
FROM tbl_v2_fb_recent_month
WHERE
crt_dt >= '{start_date}'
AND
crt_dt < '{end_date}'
AND
main_type = {main_type}
AND
sub_type IN {sub_type}
AND
  CASE
  WHEN {branch_id} = 1 THEN
    branch_id > 1
  ELSE
    branch_id = {branch_id}
  END
AND
beta_prj_id = {beta_prj_id}
AND
deleted = false
AND
fb_status < 4