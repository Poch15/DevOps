SELECT noti_id, title
FROM notice
WHERE
noti_id IN {ids}