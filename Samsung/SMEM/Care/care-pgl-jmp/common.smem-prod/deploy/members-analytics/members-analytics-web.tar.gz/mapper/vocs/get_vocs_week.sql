SELECT yearval ||' '|| weekval ||'W' as yearweek, sumval as sum
FROM
  (
    SELECT extract(isoyear from dateval) as yearval, extract(week from dateval) as weekval, sum(cnt) as sumval
    FROM
      (
        SELECT E.date + interval '1' day as dateval, COALESCE(B.cnt,0) as cnt
        FROM
          (
            SELECT date, sum(cnt) as cnt
            FROM
              (
                SELECT date, cnt, model, branch_id
                FROM v3_feedback
                WHERE
                  date >= '{start_date}'
                AND
                  date <= '{end_date}'
                AND
                  branch_id IN {branch_ids}
                AND
                  model {model}
                AND
                  main_type  = {voc_types}
                AND
                  prd_cat IN {prd_cat}
                AND
                  beta_prj_id = 0
              ) AS A
            GROUP BY date
            ORDER BY date
          ) AS B RIGHT JOIN
          (
            SELECT *
            FROM
              (
                SELECT C.date
                FROM
                  (
                    SELECT '{start_date}'::date + (100 * aa.a + 10 * bb.a + cc.a) as date
                    FROM (
                            select 0 as a
                            union all select 1
                            union all select 2
                            union all select 3
                            union all select 4
                            union all select 5
                            union all select 6
                            union all select 7
                            union all select 8
                            union all select 9
                          ) as aa cross join
                          (
                            select 0 as a
                            union all select 1
                            union all select 2
                            union all select 3
                            union all select 4
                            union all select 5
                            union all select 6
                            union all select 7
                            union all select 8
                            union all select 9
                          ) as bb cross join
                          (
                            select 0 as a
                            union all select 1
                            union all select 2
                            union all select 3
                            union all select 4
                            union all select 5
                            union all select 6
                            union all select 7
                            union all select 8
                            union all select 9
                          ) as cc
                  ) AS C
                WHERE C.DATE < '{end_date}'::date + interval '1' day
              ) AS D
          ) AS E ON E.date=B.date
      ) AS F
    GROUP BY extract(isoyear from dateval), extract(week from dateval)
    ORDER BY extract(isoyear from dateval), extract(week from dateval)
  ) as G