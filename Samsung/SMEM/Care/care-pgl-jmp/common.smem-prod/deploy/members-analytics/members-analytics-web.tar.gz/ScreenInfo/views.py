from django.views.decorators.http import require_http_methods
from django.http import JsonResponse
from ScreenInfo.controls import ScreenInfoController
from django.views.decorators.cache import cache_page


@cache_page(60 * 15)
@require_http_methods(["GET"])
def get_all_screen_info(request):
    all_screen_info = ScreenInfoController.get_all_screen_info()
    return JsonResponse(all_screen_info, safe=False)