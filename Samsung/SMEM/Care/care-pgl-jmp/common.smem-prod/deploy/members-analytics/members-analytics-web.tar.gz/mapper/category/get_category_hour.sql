SELECT CASE
          WHEN EXTRACT(hour FROM timestamp_with_timezone) < 10
            THEN timestamp_with_timezone::date || ' 0' || EXTRACT(hour FROM timestamp_with_timezone) || ':00'
				    ELSE timestamp_with_timezone::date || ' ' || EXTRACT(hour FROM timestamp_with_timezone) || ':00'
				  END AS date,
	SUM(battery_cnt)  battery_cnt,
	SUM(application_cnt) application_cnt,
	SUM(system_cnt) system_cnt,
	SUM(pc_cnt) pc_cnt,
	SUM(camera_cnt) camera_cnt,
	SUM(call_cnt) call_cnt,
	SUM(accessory_cnt) accessory_cnt,
	SUM(sensor_cnt) sensor_cnt,
	SUM(network_cnt) network_cnt
FROM
	(
			SELECT distinct (to_timestamp(date||' '||hour,'YYYY-MM-DD HH24') + INTERVAL '{interval_hour'} HOUR) as timestamp_with_timezone,
					model, cnty, lang,
					battery_cnt, application_cnt, system_cnt, pc_cnt,
					camera_cnt, call_cnt, accessory_cnt, sensor_cnt, network_cnt
			FROM tbl_category_day
			WHERE
        (to_timestamp(date||' '|| hour,'YYYY-MM-DD HH24') + INTERVAL '{interval_hour}' HOUR)
         BETWEEN '{start_date}'::date AND '{end_date}'::date + interval '23 hours'
      	AND
         branch_id IN {branch_ids}
        AND
         model like '{model}%'
	) AS A
GROUP BY date
ORDER BY date