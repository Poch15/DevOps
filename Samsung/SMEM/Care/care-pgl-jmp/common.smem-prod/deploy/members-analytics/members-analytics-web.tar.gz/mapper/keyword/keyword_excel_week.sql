SELECT date1, keyword, rank, cnt
FROM
  v3_keyword_dict as dict
JOIN
(
  SELECT date1, keyword_idx, rank, cnt
  FROM
    (
      SELECT date1, keyword_idx, rank() OVER (PARTITION BY date1 ORDER BY cnt DESC ) as rank, cnt
      FROM
        (
          SELECT concat(EXTRACT(isoyear FROM dateval), ' ', EXTRACT(week FROM dateval), 'W') as date1, keyword_idx, sum(cnt) as cnt
          FROM
            (
              SELECT (date + INTERVAL '1' DAY) :: DATE as dateval, keyword_idx, sum(cnt)  as cnt
              FROM v3_keyword
              WHERE
                date >= '{start_date}'
              AND
                date < '{end_date}' :: timestamp + INTERVAL '1' DAY
              AND
                source = {source}
              AND
                branch_id IN {branch_ids}
              AND
                model {model}
              GROUP BY dateval, keyword_idx
              ORDER BY dateval
            ) AS A
          GROUP BY date1, keyword_idx
          ORDER BY date1
        ) as B
    ) as C
  WHERE rank <= 100
) as rank_summary
ON rank_summary.keyword_idx = dict.id
ORDER BY date1, rank