from common.utils import Utils
from common.dbutils import DBUtils
from datetime import datetime
import httpagentparser
from common.excel_utils import ExcelUtils
from common.chart_utils import ChartUtils
from common.branch_utils import BranchUtils
from Device.controls import DeviceController
from common.date_utils import DateUtils


class VOCOverviewController:

    MAIN_TYPES = (1, 2, 3)
    MAIN_TYPE_NAME_LIST = ['Q&A - IM', 'Q&A - CE', 'ErrorReport', 'Suggestion']

    @staticmethod
    def get_overview_count_data(branch_ids, model, start_date, end_date, period):
        sql = DBUtils.load_query('vocs', 'get_vocs_overview_chart_%s.sql' % period)
        params = {'start_date': start_date, 'end_date': end_date, 'branch_ids': branch_ids, 'model': model,
                  'main_types': VOCOverviewController.MAIN_TYPES}
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)
        date_list, row_list = VOCOverviewController.convert_overview_count_to_chart_data(start_date, end_date,
                                                                                         period, return_rows)
        return date_list, row_list

    @staticmethod
    def get_overview_chart_type(main_type, _cs_type=None):
        main_types = ['none', 'qna', 'error', 'suggestion']
        cs_type = ""
        if _cs_type is not None:
            cs_type = "_" + _cs_type.lower()
        chart_type = main_types[main_type] + cs_type
        return chart_type

    @staticmethod
    def get_overview_chart_data(branch_ids, model, start_date, end_date, period):
        date_list, row_list = VOCOverviewController.get_overview_count_data(branch_ids, model, start_date, end_date,
                                                                            period)
        name = VOCOverviewController.MAIN_TYPE_NAME_LIST
        convert = Utils.row_to_column(row_list)
        data = []
        for idx, _ in enumerate(name):
            data.append({"name": name[idx], "data": convert[idx]})
        return dict(category=date_list, data=data, count=len(row_list), period=period, model=model,
                    branch_ids=branch_ids, start_date=start_date, end_date=end_date)

    @staticmethod
    def get_overview_excel_data(request, branch_ids, model, start_date, end_date, period):
        file_name = 'voc_overview_%s.xlsx' % datetime.now().date()
        date_list, row_list = VOCOverviewController.get_overview_count_data(branch_ids, model, start_date, end_date,
                                                                            period)
        excel_rows = []
        title_row = ['Date']
        title_row.extend(VOCOverviewController.MAIN_TYPE_NAME_LIST)
        excel_rows.append(title_row)
        for date, row in zip(date_list, row_list):
            qna_im, qna_ce, error_report, suggestion = row
            excel_rows.append([date, qna_im, qna_ce, error_report, suggestion])

        return Utils.list_to_excel('result', excel_rows, file_name,
                                   httpagentparser.detect(request.META['HTTP_USER_AGENT']))

    @staticmethod
    def get_cnty_count_data(branch_ids, model, start_date, end_date, period):
        sql = DBUtils.load_query('vocs', 'get_vocs_overview_cnty_chart_%s.sql' % period)
        params = {'start_date': start_date, 'end_date': end_date, 'branch_ids': branch_ids, 'model': model,
                  'main_types': VOCOverviewController.MAIN_TYPES}
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)

        branch_list = []
        date_list = []
        statistics_dic = {}
        for return_row in return_rows:
            branch_id, date, count = return_row
            if branch_id == 0:
                date_list.append(date)
            branch_list.append(branch_id)
            statistics_dic[(branch_id, date)] = int(count)
        branch_list = list(set(branch_list))
        branch_list.sort()

        return dict(branch_list=branch_list, date_list=date_list, statistics_dic=statistics_dic)

    @staticmethod
    def get_overview_cnty_chart_data(branch_ids, model, start_date, end_date, period):
        return_dict = VOCOverviewController.get_cnty_count_data(branch_ids, model, start_date, end_date, period)

        branch_list = return_dict['branch_list']
        date_list = return_dict['date_list']
        statistics_dic = return_dict['statistics_dic']

        branch_dic = BranchUtils.get_all_branch_dict()

        chart_data = []
        for branch in branch_list:
            if branch != 0:
                tmp_data = []
                for date in date_list:
                    value = statistics_dic.get((branch, date), 0)
                    tmp_data.append(value)
                chart_data.append({"name": branch_dic[branch], "data": tmp_data})

        return dict(category=date_list, data=chart_data, count=len(date_list), period=period,
                    model=model, branch_ids=branch_ids, start_date=start_date, end_date=end_date)

    @staticmethod
    def get_overview_cnty_excel_data(request, branch_ids, model, start_date, end_date, period):
        file_name = 'voc_country_%s.xlsx' % datetime.now().date()
        return_dict = VOCOverviewController.get_cnty_count_data(branch_ids, model, start_date, end_date, period)

        branch_list = list(map(int, branch_ids))
        date_list = return_dict['date_list']
        statistics_dic = return_dict['statistics_dic']

        branch_dic = BranchUtils.get_all_branch_dict()

        cnty = ["Date"]
        for branch in branch_list:
            if branch != 0:
                cnty.append(branch_dic[branch])
        excel_rows = [cnty]

        for date in date_list:
            row = [date]
            for branch in branch_list:
                if branch != 0:
                    value = statistics_dic.get((branch, date), 0)
                    row.append(value)
            excel_rows.append(row)

        return Utils.list_to_excel('result', excel_rows, file_name,
                                   httpagentparser.detect(request.META['HTTP_USER_AGENT']))

    @staticmethod
    def get_overview_cnty_percentage_chart_data(branch_ids, model, start_date, end_date):
        branch_dic = BranchUtils.get_all_branch_dict()

        sql = DBUtils.load_query('vocs', 'get_vocs_overview_cnty_percentage.sql')
        params = {'start_date': start_date, 'end_date': end_date, 'branch_ids': branch_ids, 'model': model,
                  'main_types': VOCOverviewController.MAIN_TYPES}
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)

        data = []
        total_count = 0
        for return_row in return_rows:
            total_count += return_row[1]
            data.append({"name": branch_dic[return_row[0]], "y": return_row[2],
                         "real_count": return_row[1]})

        return dict(data=[{"name": "Percentage of count by country", "colorByPoint": True, "data": data}],
                    count=total_count)

    @staticmethod
    def get_overview_app_count_data(start_date, end_date, period, branch_ids, model):
        sql = DBUtils.load_query('vocs', 'get_vocs_overview_app_%s.sql' % period)
        params = {'start_date': start_date, 'end_date': end_date, 'branch_ids': branch_ids,
                  'model': model, 'main_types': VOCOverviewController.MAIN_TYPES}
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)
        return return_rows

    @staticmethod
    def get_overview_app_chart_data(start_date, end_date, period, branch_ids, model):
        return_rows = VOCOverviewController.get_overview_app_count_data(start_date, end_date, period,
                                                                        branch_ids, model)
        chart_data = ChartUtils.convert_app_id_chart_rows(return_rows, period)
        return chart_data

    @staticmethod
    def get_overview_app_excel_data(start_date, end_date, period, branch_ids, model):
        return_rows = VOCOverviewController.get_overview_app_count_data(start_date, end_date, period,
                                                                        branch_ids, model)
        excel_name = ExcelUtils.get_voc_file_name('vocs')
        excel_rows = ExcelUtils.convert_appid_excel_rows(return_rows, period)
        excel_data = ExcelUtils.list_to_excel(excel_name, excel_rows)

        return excel_data

    @staticmethod
    def get_overview_app_percentage_chart_data(start_date, end_date, branch_ids, model):
        sql = DBUtils.load_query('vocs', 'get_vocs_overview_app_percentage.sql')
        params = {'start_date': start_date, 'end_date': end_date, 'branch_ids': branch_ids,
                  'model': model, 'main_types': VOCOverviewController.MAIN_TYPES}
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)

        chart_data = ChartUtils.convert_app_id_percentage_chart_data(return_rows)
        return chart_data

    @staticmethod
    def get_overview_data_by_device(branch_ids, model, start_date, end_date):
        sql = DBUtils.load_query('vocs', 'get_vocs_overview_top_device.sql')
        params = {'start_date': start_date, 'end_date': end_date, 'branch_ids': branch_ids,
                  'model': model, 'main_types': VOCOverviewController.MAIN_TYPES}
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)

        category = []
        device_to_mkt_name_dict = DeviceController.get_device_to_mkt_name_dict()
        for row in return_rows:
            cat_item = row[0]
            mkt_name = device_to_mkt_name_dict.get(cat_item, "")
            cat_item = cat_item + DeviceController.get_tab_mkt_name(mkt_name)
            category.append(cat_item)

        return dict(category=category, data=return_rows, count=len(return_rows),
                    start_date=start_date, end_date=end_date)

    @staticmethod
    def get_overview_data_by_category(branch_ids, model, start_date, end_date, voc_type):
        sql = DBUtils.load_query('vocs', 'get_vocs_analysis_category.sql')
        params = {'start_date': start_date, 'end_date': end_date, 'branch_ids': branch_ids, 'model': model,
                  'voc_types': voc_type, 'prd_cat': Utils.get_product_categories()}
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)

        category = []
        cat_dict = Utils.get_category_dict(voc_type)
        for return_row in return_rows:
            category.append(cat_dict.get(return_row[0], 'Unknown'))

        return dict(category=category, data=return_rows, count=len(return_rows), start_date=start_date,
                    end_date=end_date, voc_type=voc_type)

    @staticmethod
    def get_overview_dashboard_chart_data(branch_ids, start_date, end_date):
        sql = DBUtils.load_query('vocs', 'get_vocs_overview_dashboard_chart_week.sql')
        params = {'start_date': start_date, 'end_date': end_date, 'branch_ids': branch_ids,
                  'main_types': VOCOverviewController.MAIN_TYPES}
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)
        date_list, row_list = VOCOverviewController.convert_overview_count_to_chart_data(start_date, end_date,
                                                                                         'week', return_rows)
        name = VOCOverviewController.MAIN_TYPE_NAME_LIST
        convert = Utils.row_to_column(row_list)
        data = []
        for idx, _ in enumerate(name):
            data.append({"name": name[idx], "data": convert[idx]})
        return dict(category=date_list, data=data)

    @staticmethod
    def convert_overview_count_to_chart_data(start_date, end_date, period, return_rows):
        prd_cat_dict = Utils.get_product_category_dict()
        stat_dict = dict()
        for row in return_rows:
            date, main_type, prd_cat, cnt = row
            cs_type = None
            if main_type == 1:
                cs_type = prd_cat_dict.get(prd_cat, {}).get('cs_type', None)
            chart_type = VOCOverviewController.get_overview_chart_type(main_type, cs_type)
            prev_cnt = stat_dict.get(date, {}).get(chart_type, 0)
            if date in stat_dict:
                stat_dict[date][chart_type] = prev_cnt + cnt
            else:
                stat_dict[date] = {chart_type: prev_cnt + cnt}

        row_list = []
        date_list = DateUtils.create_date_list(start_date, end_date, period)
        for date in date_list:
            chart_type_dict = stat_dict.get(date, {})
            qna_im = chart_type_dict.get('qna_im', 0)
            qna_ce = chart_type_dict.get('qna_ce', 0)
            error = chart_type_dict.get('error', 0)
            suggestion = chart_type_dict.get('suggestion', 0)
            row_list.append([int(qna_im), int(qna_ce), int(error), int(suggestion)])

        return date_list, row_list
