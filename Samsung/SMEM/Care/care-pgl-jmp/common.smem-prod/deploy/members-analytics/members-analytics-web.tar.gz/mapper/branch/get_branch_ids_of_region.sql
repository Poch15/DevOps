SELECT branch_id
FROM branch
WHERE region =
  (
   SELECT region
   FROM branch
   WHERE branch_id = {branch_id}
  )