from common.utils import Utils
from common.dbutils import DBUtils
from datetime import datetime, timedelta
from common.branch_utils import BranchUtils


class PvRetailController:
    @staticmethod
    def get_pv_retail_data(type):
        last_sunday = Utils.get_week_start_date()
        start_date = last_sunday - timedelta(weeks=10)

        params = {"type": type, "start_date": start_date}
        sql = DBUtils.load_query('pvretail', 'get_pvretail_week.sql')
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)

        branch_dic = BranchUtils.get_all_branch_dict()
        pv_data_list = []
        for return_row in return_rows:
            yearweek, type, page, event_target, branch_id, count = return_row
            if type == 'pageView':
                menu = page
            elif type == 'banner':
                menu = event_target
            else:
                menu = page

            pv_data_list.append({"date": yearweek, "menu": menu, "branch": branch_dic[branch_id], "count": count})

        return pv_data_list

    @staticmethod
    def get_pv_retail_excel_data(type):
        return_dict = PvRetailController.get_pv_retail_data(type)
        cell = [["Date", "Menu", "Country", "Count"]]

        for row in return_dict:
            cell.append([row['date'], row['menu'], row['branch'], row['count']])

        file_name = 'pv_retail_%s_count_%s.xlsx' % (type, datetime.now().date())
        return Utils.list_to_excel('result', cell, file_name, None)