SELECT cat_id, cat_name
FROM category
WHERE
  lang_id = 3
ORDER BY cat_id;