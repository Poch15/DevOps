SELECT branch_id, branch_name
FROM branch
WHERE
region = '{region}'
ORDER BY branch_id