SELECT yearval ||' '|| weekval ||'W' as yearweek, source, cnt
FROM
(
    SELECT extract(isoyear from date + INTERVAL '1' DAY) as yearval, extract(week from date + INTERVAL '1' DAY) as weekval, source, sum(cnt) as cnt
    FROM v3_contents_weblink
    WHERE
        date >= '{start_date}'::timestamp
      AND
        date < '{end_date}'::timestamp + INTERVAL '1' DAY
      AND
        contents_type = {contents_type}
      AND
        branch_id IN {branch_ids}
      AND
        CASE
        WHEN '{contents_id}' = '0' THEN
          model {model}
        ELSE
          model {model} AND contents_id = '{contents_id}'
        END
    GROUP BY yearval, weekval, source
	  ORDER BY yearval, weekval, source
) AS A