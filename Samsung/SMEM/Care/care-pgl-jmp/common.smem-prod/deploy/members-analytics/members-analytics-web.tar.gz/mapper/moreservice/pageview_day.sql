(
  SELECT 'Total screen views', date, sum(cnt)
  FROM v3_more_svc
  WHERE
      date >= '{start_date}'
  AND
      date <= '{end_date}'
  AND
      branch_id IN {branch_ids}
  AND
      model {model}
  GROUP BY date
  ORDER BY date
)
UNION ALL
(
  SELECT 'Total clicks', date, sum(cnt)
  FROM v3_more_svc_event
  WHERE
      date >= '{start_date}'
  AND
      date <= '{end_date}'
  AND
      branch_id IN {branch_ids}
  AND
      model {model}
  GROUP BY date
  ORDER BY date
)