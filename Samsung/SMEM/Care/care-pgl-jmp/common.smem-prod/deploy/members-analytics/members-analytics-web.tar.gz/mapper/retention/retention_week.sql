SELECT base_date, ret_date, sum(ret_num)
FROM v3_retention_weekly
WHERE
  base_date >= '{start_date}' and base_date <= '{end_date}'
AND
  ret_date <= '{end_date}'
AND
  branch_id IN {branch_ids}
GROUP BY base_date, ret_date
ORDER BY base_date, ret_date