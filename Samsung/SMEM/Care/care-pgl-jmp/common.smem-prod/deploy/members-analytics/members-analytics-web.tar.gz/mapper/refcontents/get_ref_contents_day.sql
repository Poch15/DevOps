(
SELECT datetime::date as date, {type}, sum(cnt) AS cnt
FROM {tbl_name}
WHERE
  datetime >= '{start_date}'::timestamp
  AND
  datetime < '{end_date}'::timestamp + INTERVAL '1' DAY
  AND
  branch_id IN {branch_ids}
  AND
    CASE
    WHEN '{content_id}' = '0' THEN
      model {model}
    ELSE
      model {model} AND content_id = '{content_id}'
    END
GROUP BY date, {type}
ORDER BY date, {type}
)
  UNION ALL
  (
    SELECT
      date,
      '{default_val}' as {type},
      0 AS sum
    FROM
      (
        SELECT C.date
        FROM
          (
            SELECT '{start_date}' :: DATE + (100 * aa.a + 10 * bb.a + cc.a) AS date
            FROM (
                   SELECT 0 AS a
                   UNION ALL SELECT 1
                   UNION ALL SELECT 2
                   UNION ALL SELECT 3
                   UNION ALL SELECT 4
                   UNION ALL SELECT 5
                   UNION ALL SELECT 6
                   UNION ALL SELECT 7
                   UNION ALL SELECT 8
                   UNION ALL SELECT 9
                 ) AS aa CROSS JOIN
              (
                SELECT 0 AS a
                UNION ALL SELECT 1
                UNION ALL SELECT 2
                UNION ALL SELECT 3
                UNION ALL SELECT 4
                UNION ALL SELECT 5
                UNION ALL SELECT 6
                UNION ALL SELECT 7
                UNION ALL SELECT 8
                UNION ALL SELECT 9
              ) AS bb
              CROSS JOIN
              (
                SELECT 0 AS a
                UNION ALL SELECT 1
                UNION ALL SELECT 2
                UNION ALL SELECT 3
                UNION ALL SELECT 4
                UNION ALL SELECT 5
                UNION ALL SELECT 6
                UNION ALL SELECT 7
                UNION ALL SELECT 8
                UNION ALL SELECT 9
              ) AS cc
          ) AS C
        WHERE C.DATE < '{end_date}' :: DATE + INTERVAL '1' DAY
      ) AS D
  )
