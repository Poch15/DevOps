SELECT date, sum(cnt)
FROM v3_screenview_daily
WHERE
    date >= '{start_date}'
AND
    date <= '{end_date}'
AND
    branch_id IN {branch_ids}
AND
    CASE
        WHEN '{page_id}' = ''
             THEN  model {model}
        ELSE
             model {model} AND screen_id = '{page_id}'
    END
GROUP BY date
ORDER BY date