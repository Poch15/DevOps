SELECT cat_id, cat_cd
FROM cat_node
WHERE
cat_type = 6
ORDER BY cat_id