from common.dbutils import DBUtils
from common.params_utils import ParamsUtils
from common.branch_utils import BranchUtils
from Benefit.utils import BenefitTitle, BenefitUtils
from common.excel_utils import ExcelUtils
from sys import maxsize
from common.date_utils import DateUtils
from Device.controls import DeviceController


class BenefitDetailController:
    UAE_BRANCH = 5
    EVENT_TYPE = {
        0: [1, 2, 3, 4, 5],
        1: 1,  # Play
        2: 2,  # View Detail
        3: 3,  # Call
        4: 4,  # Download coupon
        5: 5   # View coupon
    }

    @staticmethod
    def __get_count_data(start_dt, end_dt, period, branch_ids, model, tz, benefit_id, coupon_id, event_type, branch_id):
        branch_ids = BenefitDetailController.__get_branch_ids(branch_id, branch_ids)
        event_types = BenefitDetailController.__get_event_types(event_type)

        sql = DBUtils.load_query('benefit/detail', 'get_benefit_detail_%s.sql' % period)
        params = {
            'start_date': start_dt,
            'end_date': end_dt,
            'branch_ids': branch_ids,
            'model': model,
            'timezone': tz,
            'interval_hour': tz,
            'benefit_id': benefit_id,
            'coupon_id': coupon_id,
            'event_types': event_types,
            'event_type': event_type,
            'tbl_name': BenefitUtils.get_tbl_info('detail', period)
        }

        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)

        return return_rows

    @staticmethod
    def get_analysis_title_data(start_date, end_date, period, branch_ids, model, timezone, benefit_id, coupon_id,
                                event_type, branch_id, cur_p, page_size):

        branch_ids = BenefitDetailController.__get_branch_ids(branch_id, branch_ids)
        event_types = BenefitDetailController.__get_event_types(event_type)

        # get total count
        sql = DBUtils.load_query('benefit/detail/analysis', 'get_analysis_title_total_count.sql')
        params = {
            'start_date': start_date,
            'end_date': end_date,
            'branch_ids': branch_ids,
            'model': model,
            'timezone': timezone,
            'benefit_id': benefit_id,
            'coupon_id': coupon_id,
            'event_types': event_types,
            'event_type': event_type,
            'tbl_name': BenefitUtils.get_tbl_info('detail', period)
        }
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)
        total_page, total_count = return_rows[0]

        # get title count
        paging_params = ParamsUtils.get_paging_params(cur_p, total_page, page_size)
        params.update(paging_params)
        sql = DBUtils.load_query('benefit/detail/analysis', 'get_analysis_title.sql')
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)

        title_list = BenefitDetailController.get_title_list(return_rows)
        branch_list = BenefitDetailController.get_branch_list(return_rows)

        return dict(category=title_list, data=return_rows, tot_p=paging_params['total_page'],
                    total_count=total_count, cur_p=int(cur_p), branch_list=branch_list)

    @staticmethod
    def get_analysis_device_data(start_date, end_date, period, branch_ids, model, timezone, benefit_id, coupon_id,
                                 event_type, branch_id, cur_p, page_size):

        branch_ids = BenefitDetailController.__get_branch_ids(branch_id, branch_ids)
        event_types = BenefitDetailController.EVENT_TYPE[0] if event_type == "0" else [int(event_type)]

        # get total count
        sql = DBUtils.load_query('benefit/detail/analysis', 'get_analysis_device_total_count.sql')
        params = {
            'start_date': start_date,
            'end_date': end_date,
            'branch_ids': branch_ids,
            'model': model,
            'timezone': timezone,
            'benefit_id': benefit_id,
            'coupon_id': coupon_id,
            'event_types': event_types,
            'event_type': event_type,
            'tbl_name': BenefitUtils.get_tbl_info('detail', period)
        }
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)
        total_count = return_rows[0][0]

        # get tab count
        paging_params = ParamsUtils.get_paging_params(cur_p, total_count, page_size)
        params.update(paging_params)
        sql = DBUtils.load_query('benefit/detail/analysis', 'get_analysis_device.sql')
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)

        device_list = []
        device_to_mkt_name_dict = DeviceController.get_device_to_mkt_name_dict()
        for row in return_rows:
            model, cnt, percent = row
            mkt_name = device_to_mkt_name_dict.get(model, "")
            model = model + DeviceController.get_tab_mkt_name(mkt_name)
            device_list.append(model)

        return dict(category=device_list, data=return_rows, tot_p=paging_params['total_page'], cur_p=int(cur_p))

    @staticmethod
    def get_chart_count_data(start_dt, end_dt, period, branch_ids, model, tz, benefit_id, coupon_id, event_type,
                             branch_id):
        return_rows = BenefitDetailController.__get_count_data(
            start_dt, end_dt, period, branch_ids, model, tz, benefit_id, coupon_id, event_type, branch_id)

        statistics_dic = dict()
        event_type_dic = dict()
        date_set = set()
        for row in return_rows:
            date, event_type, count = row
            date_set.add(date)
            event_type_dic[event_type] = event_type_dic.get(event_type, 0) + int(count)
            statistics_dic[(date, event_type)] = int(count)
        event_type_list = sorted(event_type_dic, key=event_type_dic.get, reverse=True)

        date_list = list(date_set)
        date_list.sort(key=DateUtils.get_date_sort_key(period))

        event_type_dict = BenefitUtils.get_event_type_dict()
        chart_data = []
        for event_type in event_type_list:
            tmp_data = []
            for date in date_list:
                value = statistics_dic.get((date, event_type), 0)
                tmp_data.append(value)
            chart_data.append({"name": event_type_dict[event_type], "data": tmp_data})

        return dict(category=date_list, data=chart_data)

    @staticmethod
    def get_title_list(return_rows):
        benefit_ids = list()
        coupon_ids = list()
        for row in return_rows:
            benefit_id, coupon_id, event_type, branch_id, count, percent = row
            if event_type == BenefitDetailController.EVENT_TYPE[5]:
                coupon_ids.append((coupon_id, branch_id))
            else:
                benefit_ids.append((benefit_id, branch_id))

        benefit_title = BenefitTitle()
        offer_title_dict = benefit_title.get_title_dict(BenefitTitle.OFFER, benefit_ids)
        coupon_title_dict = benefit_title.get_title_dict(BenefitTitle.COUPON, coupon_ids)
        cnty_dict = BranchUtils.get_country_names()

        title_list = list()
        for row in return_rows:
            benefit_id, coupon_id, event_type, branch_id, count, percent = row
            if event_type == BenefitDetailController.EVENT_TYPE[5]:
                coupon_tuple = coupon_title_dict.get(coupon_id, None)
                cc = coupon_tuple[1] if coupon_tuple is not None else None
            else:
                offer_tuple = offer_title_dict.get(benefit_id, None)
                cc = offer_tuple[1] if offer_tuple is not None else None
            upper_cnty_cd = str(cc).upper()
            country_name = ' (' + cnty_dict.get(upper_cnty_cd, upper_cnty_cd) + ')'

            if event_type == BenefitDetailController.EVENT_TYPE[5]:
                ctuple = coupon_title_dict.get(coupon_id, None)
                title = ctuple[0] if ctuple is not None else "Unknown" + " [ID:" + coupon_id + "]"
                title = (title + country_name, 'coupon')
            else:
                otuple = offer_title_dict.get(benefit_id, None)
                title = otuple[0] if otuple is not None else "Unknown" + " [ID:" + benefit_id + "]"
                title = (title + country_name, 'benefit')

            title_list.append(title)

        return title_list

    @staticmethod
    def get_branch_list(return_rows):
        branch_dict = BranchUtils.get_all_branch_dict()
        branch_list = list()
        for row in return_rows:
            branch_id = row[3]
            branch_list.append(branch_dict.get(branch_id, 'Unknown'))
        return branch_list

    @staticmethod
    def get_count_excel_data(start_date, end_date, period, branch_ids, model, tz, benefit_id, coupon_id, event_type,
                             branch_id):

        return_rows = BenefitDetailController.__get_count_data(
            start_date, end_date, period, branch_ids, model, tz, benefit_id, coupon_id, event_type, branch_id)

        excel_rows = [["Date", "Count"]]
        for row in return_rows:
            date, evt_type, count = row
            excel_rows.append([date, int(count)])

        statistics_dic = dict()
        date_set = set()
        for row in return_rows:
            date, evt_type, count = row
            date_set.add(date)
            statistics_dic[(date, evt_type)] = int(count)

        date_list = list(date_set)
        date_list.sort(key=DateUtils.get_date_sort_key(period))

        event_type_list = [1, 2, 3, 4, 5]
        excel_header = ["Date", "Play", "View Detail", "Call", "Download Coupon", "View Coupon"]
        excel_rows = [excel_header]
        for date in date_list:
            row = [date]
            for evt_type in event_type_list:
                value = statistics_dic.get((date, evt_type), 0)
                row.append(value)
            excel_rows.append(row)

        excel_name = ExcelUtils.get_file_name("Benefit_Detail")

        title_rows = BenefitDetailController.get_title_excel_data(
            start_date, end_date, period, branch_ids, model, tz, benefit_id, coupon_id, event_type, branch_id)

        device_rows = BenefitDetailController.get_device_excel_data(
            start_date, end_date, period, branch_ids, model, tz, benefit_id, coupon_id, event_type, branch_id)

        excel_data = ExcelUtils.multi_list_to_contents_excel(
            excel_name, benefit_id, start_date, end_date, excel_rows, title_rows, device_rows)

        return excel_data

    @staticmethod
    def get_title_excel_data(start_dt, end_dt, period, branch_ids, model, tz, benefit_id, coupon_id, event_type,
                             branch_id):

        excel_data_dict = BenefitDetailController.get_analysis_title_data(
            start_dt, end_dt, period, branch_ids, model, tz, benefit_id, coupon_id, event_type, branch_id, 0, maxsize)

        title_list = excel_data_dict['category']
        data_list = excel_data_dict['data']
        branch_list = excel_data_dict['branch_list']

        excel_header = ['ID', 'Title', 'Type', 'Count']
        excel_rows = [excel_header]
        for data, title, branch in zip(data_list, title_list, branch_list):
            benefit_id, coupon_id, event_type, branch_id, count, percent = data
            _id = benefit_id
            _type_name = BenefitUtils.get_event_type_dict().get(event_type)
            if title[1] == 'coupon':
                _id = coupon_id
            rows = [_id, title[0], _type_name, count]
            excel_rows.append(rows)

        return excel_rows

    @staticmethod
    def get_device_excel_data(start_dt, end_dt, period, branch_ids, model, tz, benefit_id, coupon_id, event_type,
                              branch_id):

        excel_data_dict = BenefitDetailController.get_analysis_device_data(
            start_dt, end_dt, period, branch_ids, model, tz, benefit_id, coupon_id, event_type, branch_id, 0, maxsize)

        data_list = excel_data_dict['data']
        excel_header = ['Device', 'Count']
        excel_rows = [excel_header]

        device_to_mkt_name_dict = DeviceController.get_device_to_mkt_name_dict()
        for data in data_list:
            model, count, percent = data
            mkt_name = device_to_mkt_name_dict.get(model, "")
            model = model + DeviceController.get_tab_mkt_name(mkt_name)
            rows = [model, count]
            excel_rows.append(rows)

        return excel_rows

    @staticmethod
    def __get_event_types(event_type):
        return BenefitDetailController.EVENT_TYPE[0] if event_type == "0" else [int(event_type)]

    @staticmethod
    def __get_branch_ids(branch_id, branch_ids):
        return branch_ids if branch_id == '-1' else [branch_id]
