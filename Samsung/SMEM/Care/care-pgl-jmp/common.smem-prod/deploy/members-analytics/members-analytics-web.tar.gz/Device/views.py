from django.views.decorators.http import require_http_methods
from django.http import JsonResponse
from common.utils import custom_login_required
from Device.controls import DeviceController


@custom_login_required
@require_http_methods(["GET"])
def get_all_mkt_name(request):
    all_mkt_name = DeviceController.get_all_mkt_name()
    return JsonResponse(all_mkt_name)
