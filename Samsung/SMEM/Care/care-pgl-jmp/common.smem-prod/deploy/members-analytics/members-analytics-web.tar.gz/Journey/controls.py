from common.dbutils import DBUtils
import pandas as pd
import copy


class JourneyController:
    @staticmethod
    def get_journey_chart_data(start_dt, end_dt, branch_ids, model, period):
        ret_list = list()
        period = 'day'

        for page in [(1, 4), (5, 8)]:
            start_step, end_step = page
            df = JourneyController.__get_journey_data(start_dt, end_dt, branch_ids, model, period, start_step, end_step)

            if page[0] != 1:
                df['step'] = df['step'] - 4

            data_dataframe, node_dataframe = JourneyController.__get_chart_data(df, True)
            ret_dict = JourneyController.__get_chart_data_dict(data_dataframe, node_dataframe)
            ret_list.append(ret_dict)

        return ret_list

    @staticmethod
    def get_journey_detail_chart_data(start_date, end_date, branch_ids, model, period, sankey_id, step, base_level):
        sankey_ids = sankey_id.split(':')

        step = step - 1
        page = sankey_ids[1]

        from_page = base_level + 1
        to_page = base_level + 4

        df = JourneyController.__get_journey_data(start_date, end_date, branch_ids, model, period, from_page, to_page)
        data_dataframe, node_dataframe = JourneyController.__get_chart_data(df, True)

        fdf = pd.DataFrame(columns=['from', 'to', 'step', 'from_id', 'to_id', 'cnt', 'drops'])

        page_list = [page]
        _step = step

        _base_level = base_level - 1 if base_level > 0 else base_level

        for _step in range(_step, 0 + _base_level, -1):
            temp_df = data_dataframe[(data_dataframe['to'].isin(page_list)) & (data_dataframe['step'] == _step)]
            fdf = fdf.append(temp_df)

            page_list = set(temp_df['from'].tolist())

        page_list = [page]
        _step = step
        for _step in range(_step, 5 + _base_level):
            temp_df = data_dataframe[(data_dataframe['from'].isin(page_list)) & (data_dataframe['step'] == _step + 1)]
            fdf = fdf.append(temp_df)

            page_list = set(temp_df['to'].tolist())

        fdf['step'] = fdf['step'] - base_level
        node_dataframe['level'] = node_dataframe['level'] - base_level

        return JourneyController.__get_chart_data_dict(fdf, node_dataframe)

    @staticmethod
    def get_journey_summary(start_date, end_date, branch_ids, period):
        period = 'day'
        sql = DBUtils.load_query('journey', 'get_journey_summary_%s.sql' % period)

        params = {
            'start_date': start_date,
            'end_date': end_date,
            'branch_ids': branch_ids
        }

        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)

        category_list = list()
        fin_sum_list = list()
        out_sum_list = list()
        tot_sum_list = list()
        cov_list = list()

        for row in return_rows:
            step, fin_sum, out_sum = row
            if step == 0:
                branch_sum = fin_sum + out_sum
            else:
                fin_sum_list.append(fin_sum)
                out_sum_list.append(out_sum)
                tot_sum_list.append(fin_sum + out_sum)
                category_list.append('Step ' + str(step))

        cum_per = 0
        for x in tot_sum_list:
            cum_per += round(x / branch_sum * 100, 2)
            cov_list.append(float(format(cum_per, ".2f")))

        chart_data = JourneyController.__get_summary_chart_data(category_list, fin_sum_list, out_sum_list, cov_list)
        table_data = JourneyController.__get_summary_table_data(category_list, fin_sum_list, out_sum_list)

        return dict(chart_data=chart_data, table=table_data)

    @staticmethod
    def __get_summary_table_data(category_list, fin_sum_list, out_sum_list):
        total_sum_list = ['Total']
        fin_sum_perc_list = ['Drop offs']
        out_sum_perc_list = ['Outgoings']

        category_list2 = copy.deepcopy(category_list)
        category_list2.insert(0, 'Step')

        for fin_sum, out_sum in zip(fin_sum_list, out_sum_list):
            total = fin_sum + out_sum
            fin_sum_perc = round(fin_sum / total * 100, 2)
            out_sum_perc = round(out_sum / total * 100, 2)

            total_sum_list.append(total)
            fin_sum_perc_list.append(str(fin_sum) + '<br/> (' + str(fin_sum_perc) + '%)')
            out_sum_perc_list.append(str(out_sum) + '<br/> (' + str(out_sum_perc) + '%)')

        return [category_list2, total_sum_list, fin_sum_perc_list, out_sum_perc_list]

    @staticmethod
    def __get_summary_chart_data(category_list, fin_sum_list, out_sum_list, cov_list):
        categories = category_list
        series_list = [
            {
                'type': 'column',
                'name': 'Drop offs',
                'data': fin_sum_list
            },
            {
                'type': 'column',
                'name': 'Outgoings',
                'data': out_sum_list
            },
            {
                'type': 'spline',
                'name': 'Coverage',
                'data': cov_list,
                'yAxis': 1,
            }
        ]

        return dict(categories=categories, series_list=series_list)

    @staticmethod
    def __get_journey_data(start_date, end_date, branch_ids, model, period, start_step, end_step):
        sql = DBUtils.load_query('journey', 'get_journey_%s.sql' % period)

        params = {
            'start_date': start_date,
            'end_date': end_date,
            'branch_ids': branch_ids,
            'model': model,
            'start_step': start_step,
            'end_step': end_step
        }

        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)
        return pd.DataFrame(data=return_rows, columns=['from', 'to', 'step', 'cnt'])

    @staticmethod
    def __get_screen_info():
        sql = DBUtils.load_query('journey', 'get_screen_info.sql')
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, {})

        ret_dict = {row[0]: row[1] for row in return_rows}

        return ret_dict

    @staticmethod
    def __get_chart_data(df, is_top_90_percent=False):
        node_dataframe = pd.DataFrame(columns=['id', 'name', 'level'])
        data_dataframe = pd.DataFrame(columns=['from', 'to', 'step', 'from_id', 'to_id', 'cnt', 'drops'])
        prev_step_df = None

        for step in df['step'].unique():
            step_df = df[df['step'] == step]

            fin_df = step_df[step_df['to'] == 'FIN_SESSION']
            step_df = step_df[step_df['to'] != 'FIN_SESSION']

            node_df = pd.DataFrame(columns=['id', 'name', 'level'])

            if is_top_90_percent is True:
                step_df = JourneyController.__get_filtered_df(step_df)

            if prev_step_df is None:
                node_df['id'] = step_df['from'].map(lambda x: JourneyController.__get_node_id(step - 1, x))
                node_df['name'] = step_df['from']
                node_df['level'] = step_df['step'] - 1
                node_dataframe = node_dataframe.append(node_df)
            else:
                temp_df = pd.merge(step_df, prev_step_df, how='inner', left_on='from', right_on='to')
                step_df = step_df[step_df['from'].isin(temp_df['from_x'].tolist())]

            node_df['id'] = step_df['to'].map(lambda x: JourneyController.__get_node_id(step, x))
            node_df['name'] = step_df['to']
            node_df['level'] = step_df['step']

            node_dataframe = node_dataframe.append(node_df)

            data_df = pd.DataFrame(columns=['from', 'to', 'step', 'from_id', 'to_id', 'cnt', 'drops'])
            data_df['from'] = step_df['from']
            data_df['to'] = step_df['to']
            data_df['step'] = step_df['step']

            data_df['from_id'] = step_df['from'].map(lambda x: JourneyController.__get_node_id(step - 1, x))
            data_df['to_id'] = step_df['to'].map(lambda x: JourneyController.__get_node_id(step, x))
            data_df['cnt'] = step_df['cnt']

            data_df = JourneyController.__update_dataframe_with_finish_value(data_df, fin_df)
            data_dataframe = data_dataframe.append(data_df)

            prev_step_df = step_df

        node_dataframe.drop_duplicates()
        node_dataframe.replace({"name": JourneyController.__get_screen_info()}, inplace=True)

        data_dataframe["to_name"] = data_dataframe["to"].map(JourneyController.__get_screen_info()).map(str)

        return data_dataframe, node_dataframe

    @staticmethod
    def __get_chart_data_dict(data_dataframe, node_dataframe):
        ret_data_list = data_dataframe[['from_id', 'to_id', 'to_name', 'cnt', 'drops']].values.tolist()
        node_dict = node_dataframe.to_dict(orient='records')

        return dict(data=ret_data_list, nodes=node_dict)

    @staticmethod
    def __get_node_id(step, name):
        return "step-{0}:{1}".format(step, name)

    @staticmethod
    def __update_dataframe_with_finish_value(data_df, fin_df):
        for from_page in data_df['from'].unique():
            _fin_df = fin_df[fin_df['from'] == from_page]

            fin_cnt = _fin_df.iloc[0]['cnt'] if len(_fin_df) > 0 else 0
            data_df.loc[data_df['from'] == from_page, 'drops'] = fin_cnt

        return data_df

    @staticmethod
    def __get_filtered_df(step_df):
        step_df = step_df[step_df['cnt'] != 1]

        # step_df['perc'] = step_df['cnt'] / step_df['cnt'].sum()
        # step_df['cumsum_perc'] = step_df['perc'].cumsum()
        #
        # cur_percent = 0.95
        # if step_df.iloc[0]['cumsum_perc'] >= cur_percent:
        #     last_row = step_df.iloc[0]
        # else:
        #     last_row = step_df[step_df['cumsum_perc'] < cur_percent].iloc[-1]
        #
        # step_df2 = step_df[step_df['cnt'] >= last_row['cnt']]

        if len(step_df) >= 50:
            step_df = step_df.head(50)

        return step_df
