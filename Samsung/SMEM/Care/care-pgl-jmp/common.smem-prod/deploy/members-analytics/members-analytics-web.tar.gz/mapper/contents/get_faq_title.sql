SELECT faq_id, title, cat_id
FROM faq
WHERE
faq_id IN {ids}