SELECT B.type, COALESCE(A.cnt,0)
FROM
(
  SELECT main_type, SUM(cnt) as cnt
  FROM v3_dash_feedback_adv_total_count
  WHERE
    branch_id IN {branch_ids}
  GROUP BY main_type
  ORDER BY main_type
) AS A RIGHT JOIN
(
  select 1 as type
  union all select 2
  union all select 3
  ) AS B ON A.main_type = B.type