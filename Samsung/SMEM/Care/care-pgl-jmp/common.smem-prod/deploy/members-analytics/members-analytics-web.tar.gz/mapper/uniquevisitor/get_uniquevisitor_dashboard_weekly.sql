SELECT sum(cnt) as cnt
FROM v3_wuv
WHERE
  date >= '{start_date}'
  AND
  date < '{end_date}'
  AND
  timezone = {timezone}
  AND
  branch_id IN {branch_ids}