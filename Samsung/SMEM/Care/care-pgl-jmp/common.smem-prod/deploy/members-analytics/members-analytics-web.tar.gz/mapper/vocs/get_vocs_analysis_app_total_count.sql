SELECT count(*)
FROM
(
  SELECT app_id
  FROM v3_feedback
  WHERE
    date >= '{start_date}'
  AND
    date <= '{end_date}'
  AND
    branch_id IN {branch_ids}
  AND
    model {model}
  AND
    main_type  = {voc_type}
  AND
    prd_cat IN {prd_cat}
  GROUP BY app_id
) AS A