SELECT yearval || ' ' || weekval || 'W' as yearweek, keyword_idx, sumval
FROM
(
	SELECT EXTRACT(isoyear FROM dateval) as yearval, EXTRACT(week FROM dateval) as weekval, keyword_idx, sum(count) as sumval
	FROM
	(
		SELECT (date + INTERVAL '1' DAY)::DATE as dateval, keyword_idx, sum(cnt) as count
		FROM v3_keyword
		  WHERE
		      date >= '{start_date}'::date
		    AND
		      date < '{end_date}'::date + INTERVAL '1' DAY
		    AND
		      source = {source}
		    AND
		      branch_id IN {branch_ids}
        AND
          model {model}
		    AND
		      keyword_idx IN {keyword_idx_list}
		GROUP BY dateval, keyword_idx
		ORDER BY dateval
	) AS A
	GROUP BY yearval, weekval, keyword_idx
	ORDER BY yearval, weekval
) AS B