SELECT contents_id, contents_type, SUM(cnt) as count, ROUND(SUM(cnt) / SUM(SUM(cnt)) OVER() * 100.0, 2) AS percent, branch_id
FROM tbl_v2_contents
WHERE
  datetime >= '{start_date}'::timestamp - INTERVAL '{interval_hour}' HOUR
  AND
  datetime < '{end_date}'::timestamp - INTERVAL '{interval_hour}' HOUR + INTERVAL '1' DAY
	AND
	contents_type = {contents_type}
	AND
  branch_id IN {branch_ids}
	AND
	model {model}
GROUP BY contents_id, branch_id, contents_type
ORDER BY {order_type} DESC
LIMIT {limit} OFFSET {offset}