from common.dbutils import DBUtils
from common.branch_utils import BranchUtils
from common.params_utils import ParamsUtils
from common.excel_utils import ExcelUtils
from common.utils import Utils
from sys import maxsize
from common.date_utils import DateUtils
from Device.controls import DeviceController


class ContentsController:

    TYPE_NAME_LIST = ['notice', 'newsntips', 'faq']
    TYPE_NOTICE = '0'
    TYPE_NEWSNTIPS = '1'
    TYPE_FAQ = '2'
    FUNNELS_DICT = {
        TYPE_NOTICE: {0: "Notice List", 1: "Home Card"},
        TYPE_NEWSNTIPS: {0: "News&Tips List", 1: "Home Card", 2: "Contact Us"}
    }

    @staticmethod
    def get_count_data(start_date, end_date, period, branch_ids, model, interval_hour, contents_id, contents_type):
        params = {'start_date': start_date, 'end_date': end_date, 'contents_id': contents_id,
                  'branch_ids': branch_ids, 'model': model,
                  'interval_hour': interval_hour, 'contents_type': int(contents_type)}
        sql = DBUtils.load_query('contents', 'get_contents_%s.sql' % period)
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)

        from_list_counts = []
        from_home_counts = []
        from_contact_us_counts = []
        statistics_dic = {}
        date_set = set()
        for row in return_rows:
            date, home, cat_id, count = row
            date_set.add(date)
            statistics_dic[(date, home)] = int(count)

        date_list = list(date_set)
        date_list.sort(key=DateUtils.get_date_sort_key(period))

        # From List
        for date in date_list:
            from_list = statistics_dic.get((date, 0), 0)
            from_list_counts.append(from_list)

        # From Home
        for date in date_list:
            from_home = statistics_dic.get((date, 1), 0)
            from_home_counts.append(from_home)

        # From Contact Us
        for date in date_list:
            from_contact = statistics_dic.get((date, 2), 0)
            from_contact_us_counts.append(from_contact)

        return dict(date_list=date_list, from_home_counts=from_home_counts, from_list_counts=from_list_counts,
                    from_contact_us_counts=from_contact_us_counts, return_rows=return_rows)

    @staticmethod
    def get_faq_count_chart_data(date_list, return_rows):
        statistics_dic = {}
        cat_id_dic = {}
        for row in return_rows:
            date, home, cat_id, count = row
            cat_id_dic[cat_id] = cat_id_dic.get(cat_id, 0) + int(count)
            statistics_dic[(date, cat_id)] = int(count)

        category_dic = Utils.get_category_dict()
        chart_data = []
        cat_list = sorted(category_dic.keys())

        # move None category to last position
        none_index = 0
        cat_list.append(cat_list.pop(none_index))

        for cat_id in cat_list:
            tmp_data = []
            for date in date_list:
                value = statistics_dic.get((date, cat_id), 0)
                tmp_data.append(value)
            chart_data.append({"name": category_dic.get(cat_id, 'Unknown'), "data": tmp_data})

        return chart_data

    @staticmethod
    def get_count_chart_data(start_date, end_date, period, branch_ids, model, interval_hour, contents_id, contents_type):
        return_dict = ContentsController.get_count_data(start_date, end_date, period, branch_ids, model,
                                                        interval_hour, contents_id, contents_type)
        date_list = return_dict['date_list']
        return_rows = return_dict['return_rows']
        if contents_type == ContentsController.TYPE_FAQ:
            data = ContentsController.get_faq_count_chart_data(date_list, return_rows)
        else:
            from_home_counts = return_dict['from_home_counts']
            from_list_counts = return_dict['from_list_counts']
            from_contact_us_counts = return_dict['from_contact_us_counts']
            type_name = ContentsController.FUNNELS_DICT.get(contents_type, "Unknown").get(0, "Unknown")

            data = [
                {"name": type_name, "data": from_list_counts},
                {"name": "Home Card", "data": from_home_counts},
            ]

            if contents_type == ContentsController.TYPE_NEWSNTIPS:
                data.append({"name": "Contact Us", "data": from_contact_us_counts})

        return dict(category=date_list, data=data)

    @staticmethod
    def get_count_excel_data(start_date, end_date, period, branch_ids, model, interval_hour, contents_id, contents_type):
        return_dict = ContentsController.get_count_data(start_date, end_date, period, branch_ids, model,
                                                        interval_hour, contents_id, contents_type)
        date_list = return_dict['date_list']
        from_home_counts = return_dict['from_home_counts']
        from_list_counts = return_dict['from_list_counts']
        from_contact_us_counts = return_dict['from_contact_us_counts']
        return_rows = return_dict['return_rows']
        excel_rows = None

        if contents_type == ContentsController.TYPE_FAQ:
            excel_rows = ContentsController.get_faq_count_excel_data(date_list, return_rows)
            category_rows = ContentsController.get_category_excel_data(start_date, end_date, branch_ids, model, interval_hour,
                                                                       contents_id, contents_type)
        else:
            if contents_type == ContentsController.TYPE_NOTICE:
                excel_rows = [["Date", "Home Card", "Notice List"]]
                for date, home, list in zip(date_list, from_home_counts, from_list_counts):
                    excel_rows.append([date, home, list])
            elif contents_type == ContentsController.TYPE_NEWSNTIPS:
                excel_rows = [["Date", "Home Card", "News&Tips List", "Contact Us"]]
                for date, home, list, contact_us in zip(date_list, from_home_counts, from_list_counts,
                                                        from_contact_us_counts):
                    excel_rows.append([date, home, list, contact_us])
            category_rows = None

        title_rows = ContentsController.get_title_excel_data(start_date, end_date, branch_ids, model, interval_hour,
                                                             contents_id, contents_type)
        device_rows = ContentsController.get_device_excel_data(start_date, end_date, branch_ids, model, interval_hour,
                                                               contents_id, contents_type)
        excel_name = ExcelUtils.get_file_name(ContentsController.TYPE_NAME_LIST[int(contents_type)])
        excel_data = ExcelUtils.multi_list_to_contents_excel(excel_name, contents_id, start_date, end_date,
                                                             excel_rows, title_rows, device_rows, category_rows)
        return excel_data

    @staticmethod
    def get_faq_count_excel_data(date_list, return_rows):
        statistics_dic = {}
        for row in return_rows:
            date, home, cat_id, count = row
            statistics_dic[(date, cat_id)] = int(count)

        excel_rows = []
        category_dic = Utils.get_category_dict()
        excel_header = ["Date"]
        for cat_id in category_dic.keys():
            excel_header.append(category_dic.get(cat_id, 'Unknown'))
        excel_rows.append(excel_header)

        for date in date_list:
            row = [date]
            for cat_id in category_dic.keys():
                value = statistics_dic.get((date, cat_id), 0)
                row.append(value)
            excel_rows.append(row)

        return excel_rows

    @staticmethod
    def get_branch_list(return_rows):
        branch_dict = BranchUtils.get_all_branch_dict()
        branch_list = []
        for row in return_rows:
            branch_id = row[4]
            branch_list.append(branch_dict.get(branch_id, 'Unknown'))
        return branch_list

    @staticmethod
    def get_analysis_title_data(start_date, end_date, branch_ids, model, interval_hour,
                                contents_id, contents_type, cur_p, page_size, order_type='count'):
        if order_type == 'contents_id':
            order_type = 'cast(contents_id as integer)'

        # get total count
        sql = DBUtils.load_query('contents/analysis', 'get_analysis_title_total_count.sql')
        params = {'start_date': start_date, 'end_date': end_date, 'branch_ids': branch_ids,
                  'model': model, 'interval_hour': interval_hour,
                  'contents_type': int(contents_type), 'order_type': order_type}
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)
        total_page, total_count = return_rows[0]

        # get tab count
        paging_params = ParamsUtils.get_paging_params(cur_p, total_page, page_size)
        params.update(paging_params)
        sql = DBUtils.load_query('contents/analysis', 'get_analysis_title.sql')
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)

        title_list = ContentsController.get_title_list(return_rows, int(contents_type))
        branch_list = ContentsController.get_branch_list(return_rows)
        title_all_period_count = ContentsController.get_title_all_period_count(return_rows, contents_type, branch_ids,
                                                                               model)

        return dict(category=title_list, data=return_rows, tot_p=paging_params['total_page'],
                    total_count=total_count, cur_p=int(cur_p), branch_list=branch_list,
                    title_all_period_count=title_all_period_count)

    @staticmethod
    def get_analysis_title_excel_data(start_date, end_date, branch_ids, model, interval_hour, contents_type):
        params = {'start_date': start_date, 'end_date': end_date, 'branch_ids': branch_ids,
                  'model': model, 'interval_hour': interval_hour, 'contents_type': int(contents_type)}
        sql = DBUtils.load_query('contents/analysis', 'get_analysis_title_excel.sql')
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)

        title_list = ContentsController.get_title_list(return_rows, int(contents_type))
        branch_list = ContentsController.get_branch_list(return_rows)

        return dict(category=title_list, data=return_rows, branch_list=branch_list)

    @staticmethod
    def get_analysis_device_data(start_date, end_date, branch_ids, model, interval_hour,
                                 contents_id, contents_type, cur_p, page_size):
        # get total count
        sql = DBUtils.load_query('contents/analysis', 'get_analysis_device_total_count.sql')
        params = {'start_date': start_date, 'end_date': end_date, 'branch_ids': branch_ids,
                  'model': model, 'interval_hour': interval_hour,
                  'contents_id': contents_id, 'contents_type': contents_type}
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)
        total_count = return_rows[0][0]

        # get tab count
        paging_params = ParamsUtils.get_paging_params(cur_p, total_count, page_size)
        params.update(paging_params)
        params["contents_id"] = contents_id
        sql = DBUtils.load_query('contents/analysis', 'get_analysis_device.sql')
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)

        device_list = []
        device_to_mkt_name_dict = DeviceController.get_device_to_mkt_name_dict()
        for row in return_rows:
            device, cnt, percent = row
            mkt_name = device_to_mkt_name_dict.get(device, "")
            device = device + DeviceController.get_tab_mkt_name(mkt_name)
            device_list.append(device)

        return dict(category=device_list, data=return_rows, tot_p=paging_params['total_page'], cur_p=int(cur_p))

    @staticmethod
    def get_analysis_category_data(start_date, end_date, branch_ids, model, interval_hour,
                                 contents_id, contents_type, cur_p, page_size):
        params = {'start_date': start_date, 'end_date': end_date, 'branch_ids': branch_ids,
                  'model': model, 'interval_hour': interval_hour,
                  'contents_id': contents_id, 'contents_type': contents_type}
        sql = DBUtils.load_query('contents/analysis', 'get_analysis_category.sql')
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)

        category_dic = Utils.get_category_dict()
        category_list = []
        for row in return_rows:
            category_list.append(category_dic.get(row[0], 'Unknown'))

        return dict(category=category_list, data=return_rows, tot_p=1, cur_p=int(cur_p))

    @staticmethod
    def get_title_all_period_count(return_rows, contents_type, branch_ids, model):
        contents_ids = []
        contents_branch_ids = []
        for row in return_rows:
            contents_id, type = row[0:2]
            contents_ids.append(contents_id)

            branch_id = row[4]
            contents_branch_ids.append((contents_id, branch_id))

        sql = DBUtils.load_query('contents/analysis', 'get_analysis_title_all_period_count.sql')
        params = {'branch_ids': branch_ids, 'model': model,
                  'contents_ids': str(contents_ids).replace("[", "(").replace("]", ")"),
                  'contents_type': int(contents_type)}

        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)

        title_all_period_counts_dic = {}
        for row in return_rows:
            contents_id, branch_id, count = row
            title_all_period_counts_dic.update({(contents_id, branch_id): count})

        title_total_counts_list = []
        for contents_id, branch_id in contents_branch_ids:
            title_total_count = title_all_period_counts_dic.get((contents_id, branch_id), 0)
            title_total_counts_list.append(title_total_count)

        return title_total_counts_list

    @staticmethod
    def get_title_list(return_rows, contents_type):
        contents_ids = [0]
        for row in return_rows:
            id, type = row[0:2]
            contents_ids.append(int(id))

        title_list_dict = ContentsController.get_title_info(contents_ids, ContentsController.TYPE_NAME_LIST[contents_type])
        title_list = []
        for row in return_rows:
            id, type = row[0:2]
            title, category = title_list_dict.get(int(id), ('[Untitled]', 'None'))
            if not title.strip():
                title = '[Untitled]'
            title_list.append((title, category))

        return title_list

    @staticmethod
    def get_title_info(contents_ids, contents_type):
        sql = DBUtils.load_query('contents', 'get_%s_title.sql' % contents_type)
        params = {'ids': ParamsUtils.convert_list_to_tuple_params(contents_ids)}
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_MYSQL, sql, params)

        contents_title_dict = {}
        if contents_type == 'faq':
            category_dic = Utils.get_category_dict()
            for row in return_rows:
                id, title, cat_id = row
                contents_title_dict[id] = (title, category_dic.get(cat_id, 'Unknown'))
        else:
            for row in return_rows:
                id, title = row
                contents_title_dict[id] = (title, 'None')
        contents_title_dict[0] = ('Unidentified contents', 'None')
        return contents_title_dict

    @staticmethod
    def get_title_excel_data(start_date, end_date, branch_ids, model, interval_hour, contents_id, contents_type):
        excel_data_dict = ContentsController.get_analysis_title_excel_data(start_date, end_date, branch_ids, model,
                                                                           interval_hour, contents_type)
        title_list = excel_data_dict['category']
        data_list = excel_data_dict['data']
        branch_list = excel_data_dict['branch_list']

        excel_header = ['ID', 'Title', 'Count']
        if contents_type == ContentsController.TYPE_FAQ:
            excel_header.insert(1, 'Category')
        else:
            excel_header.insert(1, 'Funnel')
        if len(branch_ids) > 1:
            excel_header.insert(1, 'Branch')
        excel_rows = [excel_header]

        for data, title, branch in zip(data_list, title_list, branch_list):
            id, type, count, percent, branch_id, funnel = data
            rows = [id, title[0], count]
            if contents_type == ContentsController.TYPE_FAQ:
                rows.insert(1, title[1])
            else:
                rows.insert(1, ContentsController.FUNNELS_DICT.get(contents_type, "Unknown").get(funnel, "Unknown"))
            if len(branch_ids) > 1:
                rows.insert(1, branch)
            excel_rows.append(rows)

        return excel_rows

    @staticmethod
    def get_device_excel_data(start_date, end_date, branch_ids, model, interval_hour, contents_id, contents_type):
        excel_data_dict = ContentsController.get_analysis_device_data(start_date, end_date, branch_ids, model, interval_hour,
                                                                      contents_id, contents_type, 0, maxsize)
        data_list = excel_data_dict['data']
        excel_header = ['Device', 'Count']
        excel_rows = [excel_header]

        device_to_mkt_name_dict = DeviceController.get_device_to_mkt_name_dict()
        for data in data_list:
            model, count, percent = data
            mkt_name = device_to_mkt_name_dict.get(model, "")
            model = model + DeviceController.get_tab_mkt_name(mkt_name)
            rows = [model, count]
            excel_rows.append(rows)

        return excel_rows

    @staticmethod
    def get_category_excel_data(start_date, end_date, branch_ids, model, interval_hour,
                                 contents_id, contents_type):
        excel_data_dict = ContentsController.get_analysis_category_data(start_date, end_date, branch_ids, model,
                                                                        interval_hour, contents_id, contents_type,
                                                                        0, maxsize)
        category_list = excel_data_dict['category']
        data_list = excel_data_dict['data']
        excel_header = ['Category', 'Count']
        excel_rows = [excel_header]

        for category, data in zip(category_list, data_list):
            cat_id, count, percent = data
            rows = [category, count]
            excel_rows.append(rows)

        return excel_rows
