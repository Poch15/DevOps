select step, sum(fin_cnt) as fin_sum, sum(out_cnt) as out_sum
from v3_user_journey_summary
where
  date >= '{start_date}'::date
and
  date < '{end_date}'::date + INTERVAL '1' DAY
and
  branch_id IN {branch_ids}
and
  step <= 10
group by step
order by step