from common.dbutils import DBUtils
from common.date_utils import DateUtils
from common.excel_utils import ExcelUtils
import pandas as pd


class MoreServiceController:
    STATUS_TYPE = {
        'INSTALLED': 'Native App',
        'NOT_INSTALLED': 'Web'
    }

    @staticmethod
    def get_total_view(start_date, end_date, branch_ids, model, period):
        date_list, date_df = MoreServiceController.__get_date_list_and_dataframe(start_date, end_date, period)

        params = {'start_date': start_date, 'end_date': end_date, 'branch_ids': branch_ids, 'model': model}
        return_rows = DBUtils.execute_query(
            DBUtils.CONFIG_POSTGRESQL,
            DBUtils.load_query('moreservice', 'pageview_%s.sql' % period),
            params)

        result_list = list()

        if len(return_rows) > 0:
            df = pd.DataFrame(data=return_rows, columns=['type', 'date', 'cnt'])
            df = df.groupby(['date', 'type'])['cnt'].sum().reset_index()

            for type1 in sorted(df['type'].unique(), reverse=True):
                temp_df = df[df['type'] == type1]
                temp_df['date'] = temp_df['date'].astype(str)

                df2 = pd.merge(date_df, temp_df, how='outer', on='date').fillna(0)
                df2['cnt'] = df2['cnt'].astype(int)
                temp_list = df2['cnt'].tolist()

                result_list.append({"name": type1, "data": temp_list})

        return dict(category=date_list, data=result_list)

    @staticmethod
    def get_clicks_by_service(start_date, end_date, branch_ids, model, period):
        date_list, date_df = MoreServiceController.__get_date_list_and_dataframe(start_date, end_date, period)

        params = {'start_date': start_date, 'end_date': end_date, 'branch_ids': branch_ids, 'model': model}
        return_rows = DBUtils.execute_query(
            DBUtils.CONFIG_POSTGRESQL,
            DBUtils.load_query('moreservice', 'clicks_by_service_%s.sql' % period),
            params)

        result_list = list()
        if len(return_rows) > 0:
            service_id_to_name = MoreServiceController.__get_service_name()

            df = pd.DataFrame(data=return_rows, columns=['date', 'service', 'cnt'])
            df = df.groupby(['date', 'service'])['cnt'].sum().reset_index()

            service_list_ordered = MoreServiceController.__get_ordered_service_list_by_last_date(df, date_list[-1])

            for service in service_list_ordered:
                temp_df = df[df['service'] == service]
                temp_df['date'] = temp_df['date'].astype(str)

                df2 = pd.merge(date_df, temp_df, how='outer', on='date').fillna(0)
                df2['cnt'] = df2['cnt'].astype(int)
                temp_list = df2['cnt'].tolist()

                result_list.append({"name": service_id_to_name.get(service, service), "data": temp_list})

        return dict(category=date_list, data=result_list)

    @staticmethod
    def get_clicks_by_service_and_status(start_date, end_date, branch_ids, model, period):
        date_list, date_df = MoreServiceController.__get_date_list_and_dataframe(start_date, end_date, period)

        params = {'start_date': start_date, 'end_date': end_date, 'branch_ids': branch_ids, 'model': model}
        return_rows = DBUtils.execute_query(
            DBUtils.CONFIG_POSTGRESQL,
            DBUtils.load_query('moreservice', 'clicks_by_service_and_status_%s.sql' % period),
            params)

        result_list = list()

        if len(return_rows) > 0:
            service_id_to_name = MoreServiceController.__get_service_name()

            df = pd.DataFrame(data=return_rows, columns=['date', 'service', 'status', 'cnt'])
            df.loc[df['status'] == 'NOT_EXISTED', 'status'] = 'NOT_INSTALLED'
            df = df.groupby(['date', 'service', 'status'])['cnt'].sum().reset_index()

            service_list_ordered = MoreServiceController.__get_ordered_service_list_by_last_date(
                df.drop('status', axis=1).groupby(['date', 'service'])['cnt'].sum().reset_index(), date_list[-1])

            for service in service_list_ordered:
                temp_df = df[df['service'] == service]
                temp_df['date'] = temp_df['date'].astype(str)

                temp_df = temp_df.groupby(['date', 'status'])['cnt'].sum().reset_index()

                service_result_list = list()

                for status in sorted(MoreServiceController.STATUS_TYPE.keys()):
                    temp_df2 = temp_df[temp_df['status'] == status]
                    temp_df2['date'] = temp_df2['date'].astype(str)

                    df2 = pd.merge(date_df, temp_df2, how='outer', on='date').fillna(0)
                    df2['cnt'] = df2['cnt'].astype(int)
                    temp_list = df2['cnt'].tolist()

                    service_result_list.append({"name": MoreServiceController.STATUS_TYPE[status], "data": temp_list})

                result_list.append(
                    {"service_name": service_id_to_name.get(service, service), "data_list": service_result_list})

        return dict(category=date_list, services_data=result_list)

    @staticmethod
    def __get_ordered_service_list_by_last_date(service_df, last_date):
        service_list_df = service_df[service_df['date'] == last_date].sort_values(by='cnt', ascending=False)
        service_list_ordered = service_list_df['service'].tolist()
        service_list = service_df['service'].unique()

        for service in service_list:
            if service not in service_list_ordered:
                service_list_ordered.append(service)

        return service_list_ordered

    @staticmethod
    def __get_date_list_and_dataframe(start_date, end_date, period):
        date_list = DateUtils.create_date_list(start_date, end_date, period)
        date_df = pd.DataFrame(date_list, columns=['date'])
        date_df['date'] = date_df['date'].astype(str)

        return date_list, date_df

    @staticmethod
    def __get_service_name():
        return_rows = DBUtils.execute_query(
            DBUtils.CONFIG_MYSQL,
            DBUtils.load_query('moreservice', 'ext_service_names.sql'), {})

        service_id_to_name = dict()
        for row in return_rows:
            service_id, service_name = row
            service_id_to_name[service_id] = service_name

        return service_id_to_name

    @staticmethod
    def get_excel_data(start_dt, end_dt, branch_ids, model, period):
        final_excel_list = list()

        rows = MoreServiceController.get_total_view(start_dt, end_dt, branch_ids, model, period)
        excel_rows = list(zip(map(str, rows['category']), rows['data'][0]['data'], rows['data'][1]['data']))

        c1_rows = MoreServiceController.get_clicks_by_service(start_dt, end_dt, branch_ids, model, period)
        df = pd.DataFrame(data=c1_rows['category'], columns=['date'])
        df['date'] = df['date'].astype(str)
        excel_rows.insert(0, ('date', 'Total screen views', 'Total clicks'))

        for row in c1_rows['data']:
            df[row['name']] = row['data']

        c1_excel_rows = df.values.tolist()
        c1_excel_rows.insert(0, df.columns.values.tolist())

        c2_rows = MoreServiceController.get_clicks_by_service_and_status(start_dt, end_dt, branch_ids, model, period)
        df = pd.DataFrame(data=c2_rows['category'], columns=['date'])
        df['date'] = df['date'].astype(str)

        for service_row in c2_rows['services_data']:
            service_name = service_row['service_name']
            for status_row in service_row['data_list']:
                name = "{0} {1}".format(service_name, status_row["name"])
                df[name] = status_row['data']

        c2_excel_rows = df.values.tolist()
        c2_excel_rows.insert(0, df.columns.values.tolist())

        final_excel_list.append(excel_rows)
        final_excel_list.append(c1_excel_rows)
        final_excel_list.append(c2_excel_rows)

        response = ExcelUtils.multi_general_list_to_excel(
            ExcelUtils.get_file_name('more_service'),
            ['views', 'clicks_per_service', 'clicks_per_apptype'],
            final_excel_list
        )

        return response
