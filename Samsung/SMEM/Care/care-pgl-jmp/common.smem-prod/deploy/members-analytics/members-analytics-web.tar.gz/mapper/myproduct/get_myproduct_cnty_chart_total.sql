SELECT branch_id, sum(cnt)
FROM v3_myproduct_summary
WHERE
  datetime < '{start_date}'
AND
  branch_id IN {branch_ids}
AND
  req_type = {request_type}
AND
  status = 'E0000'
GROUP BY branch_id
ORDER BY branch_id