SELECT
  page_grp_id,
  CASE WHEN monthval < 10
    THEN yearval || '/0' || monthval
  ELSE yearval || '/' || monthval
  END AS yearmonth,
  cnt
FROM
  (
    SELECT page_grp_id, extract(YEAR FROM dateval)  AS yearval, extract(MONTH FROM dateval) AS monthval, cnt
    FROM
        (
          SELECT page_grp_id, date as dateval, sum(cnt) as cnt
          FROM v3_unique_pv_monthly
          WHERE
            date >= '{start_date}' :: date
          AND
            date < '{end_date}' :: date + INTERVAL '1' DAY
          AND
            branch_id IN {branch_ids}
           AND
            page_grp_id IN {page_grp_id}
          GROUP BY page_grp_id, dateval
          ORDER BY page_grp_id, dateval
        ) AS A
  ) AS B
