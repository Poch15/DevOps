select from_page_id, to_page_id, step, cnt
from
  (
    select *, row_number() over (partition by step order by cnt desc) as rownum
    from
      (
        select from_page_id, to_page_id, step, sum(cnt) as cnt
        from v3_user_journey
        where
          date >= '{start_date}'::date
        and
          date < '{end_date}'::date + INTERVAL '1' DAY
        and
          branch_id IN {branch_ids}
        and
          step >= '{start_step}'
        and
          step <= '{end_step}'
        group by from_page_id, to_page_id, step
      ) as a
  ) as b
where rownum <= 100
order by step;