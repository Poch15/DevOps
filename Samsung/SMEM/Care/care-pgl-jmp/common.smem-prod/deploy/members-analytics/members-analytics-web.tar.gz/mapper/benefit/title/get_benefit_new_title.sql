SELECT c.campaign_hash_id, cc.title, c.cnty_cd FROM campaign_content AS cc JOIN campaign AS c
ON cc.campaign_id = c.campaign_id
WHERE c.campaign_hash_id in {campaign_ids}