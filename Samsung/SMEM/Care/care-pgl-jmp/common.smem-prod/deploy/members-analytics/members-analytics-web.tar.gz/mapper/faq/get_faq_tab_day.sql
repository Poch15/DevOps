SELECT datetime::date AS date, {tab_type}, sum(cnt) as cnt
FROM
	(
		SELECT (datetime + INTERVAL '{interval_hour}' HOUR) as datetime, model, branch_id, cnt
		FROM tbl_v2_faq
		WHERE
	    datetime >= '{start_date}'::timestamp - INTERVAL '{interval_hour}' HOUR
	  AND
	    datetime < '{end_date}'::timestamp - INTERVAL '{interval_hour}' HOUR + INTERVAL '1' DAY
   	AND
      branch_id IN {branch_ids}
     AND
      model like '{model}%'
	) AS A
GROUP BY date, {tab_type}