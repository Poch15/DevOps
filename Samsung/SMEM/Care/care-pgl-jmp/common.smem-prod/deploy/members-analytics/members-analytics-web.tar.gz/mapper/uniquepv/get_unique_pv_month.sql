select yearmonth, sum(cnt) as cnt
  from
(
  SELECT
    CASE WHEN monthval < 10
      THEN yearval || '/0' || monthval
    ELSE yearval || '/' || monthval
    END AS yearmonth,
    cnt
  FROM
    (
      SELECT
        extract(YEAR FROM dateval)  AS yearval,
        extract(MONTH FROM dateval) AS monthval,
        sum(cnt)                    AS cnt
      FROM
        (
          (
            SELECT date as dateval, sum(cnt) as cnt
            FROM v3_unique_pv_monthly
            WHERE
              date >= '{start_date}' :: date
            AND
              date < '{end_date}' :: date + INTERVAL '1' DAY
            AND
              branch_id IN {branch_ids}
             AND
              page_grp_id = {page_grp_id}
            GROUP BY dateval
            ORDER BY dateval
          )
          UNION ALL
          (
            SELECT
              date,
              0  AS sum
            FROM
              (
                SELECT C.date
                FROM
                  (
                    SELECT '{start_date}' :: DATE + (100 * aa.a + 10 * bb.a + cc.a) AS date
                    FROM (
                           SELECT 0 AS a
                           UNION ALL SELECT 1
                           UNION ALL SELECT 2
                           UNION ALL SELECT 3
                           UNION ALL SELECT 4
                           UNION ALL SELECT 5
                           UNION ALL SELECT 6
                           UNION ALL SELECT 7
                           UNION ALL SELECT 8
                           UNION ALL SELECT 9
                         ) AS aa CROSS JOIN
                      (
                        SELECT 0 AS a
                        UNION ALL SELECT 1
                        UNION ALL SELECT 2
                        UNION ALL SELECT 3
                        UNION ALL SELECT 4
                        UNION ALL SELECT 5
                        UNION ALL SELECT 6
                        UNION ALL SELECT 7
                        UNION ALL SELECT 8
                        UNION ALL SELECT 9
                      ) AS bb
                      CROSS JOIN
                      (
                        SELECT 0 AS a
                        UNION ALL SELECT 1
                        UNION ALL SELECT 2
                        UNION ALL SELECT 3
                        UNION ALL SELECT 4
                        UNION ALL SELECT 5
                        UNION ALL SELECT 6
                        UNION ALL SELECT 7
                        UNION ALL SELECT 8
                        UNION ALL SELECT 9
                      ) AS cc
                  ) AS C
                WHERE C.DATE < '{end_date}' :: DATE + INTERVAL '1' DAY
              ) AS D
          )
        ) AS F
      GROUP BY extract(YEAR FROM dateval), extract(MONTH FROM dateval)
      ORDER BY extract(YEAR FROM dateval), extract(MONTH FROM dateval)
    ) AS G
) AS F
group by yearmonth
order by yearmonth