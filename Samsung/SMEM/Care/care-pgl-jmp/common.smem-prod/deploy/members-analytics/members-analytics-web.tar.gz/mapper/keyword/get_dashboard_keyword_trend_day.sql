SELECT date, keyword, SUM(cnt) AS count
FROM v3_dash_keyword_adv
WHERE
  date >= '{start_date}'
AND
  date < '{end_date}'::timestamp + INTERVAL '1' DAY
AND
  branch_name = '{branch_name}'
AND
  source = {source}
AND
  period = '{period}'
GROUP BY date, keyword
ORDER BY date