SELECT yearval ||' '|| weekval ||'W' as yearweek, cnt
FROM
  (
    SELECT extract(isoyear from date) as yearval, extract(week from date) as weekval, sum(cnt) as cnt
    FROM
    (
          (
            SELECT datetime::date + INTERVAL '1' DAY as date, SUM(cnt) as cnt
            FROM v3_newsntips
            WHERE
              datetime >= '{start_date}'::timestamp
            AND
              datetime < '{end_date}'::timestamp + INTERVAL '1' DAY
            AND
            CASE
            WHEN '{content_id}' = '0' THEN
                branch_id IN {branch_ids}
            ELSE
                branch_id IN {branch_ids} AND content_id = '{content_id}'
            END
            GROUP BY date
          )
          UNION ALL
          (
	          SELECT date + interval '1' day, 0 as sum
            FROM
              (
                SELECT C.date
                FROM
                  (
                    SELECT '{start_date}'::date + (100 * aa.a + 10 * bb.a + cc.a) as date
                    FROM (
                            select 0 as a
                            union all select 1
                            union all select 2
                            union all select 3
                            union all select 4
                            union all select 5
                            union all select 6
                            union all select 7
                            union all select 8
                            union all select 9
                          ) as aa cross join
                          (
                            select 0 as a
                            union all select 1
                            union all select 2
                            union all select 3
                            union all select 4
                            union all select 5
                            union all select 6
                            union all select 7
                            union all select 8
                            union all select 9
                          ) as bb cross join
                          (
                            select 0 as a
                            union all select 1
                            union all select 2
                            union all select 3
                            union all select 4
                            union all select 5
                            union all select 6
                            union all select 7
                            union all select 8
                            union all select 9
                          ) as cc
                  ) AS C
                WHERE C.DATE < '{end_date}'::date + interval '1' day
              ) AS D
          )
    ) AS E
    GROUP BY extract(isoyear from date), extract(week from date)
    ORDER BY extract(isoyear from date), extract(week from date)
  ) AS F