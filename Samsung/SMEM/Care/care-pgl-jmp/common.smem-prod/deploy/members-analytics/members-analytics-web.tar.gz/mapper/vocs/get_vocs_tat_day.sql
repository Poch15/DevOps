SELECT date, round(tot_sec/tot_cnt/3600, 2) as avg, tot_cnt
FROM
(
    SELECT date, sum(cnt) as tot_cnt, sum(tot_sec) as tot_sec
    FROM
    (
      SELECT datetime::DATE as date, cnt, tot_sec
      FROM v3_feedback_tat
      WHERE
        datetime >= '{start_date}'
      AND
        datetime < '{end_date}'::timestamp + INTERVAL '1' DAY
      AND
        branch_id IN {branch_ids}
      AND
        prd_cat IN {prd_cat}
      AND
        model {model}
    ) as a
    GROUP BY date
    ORDER BY date
) as b
ORDER BY date
