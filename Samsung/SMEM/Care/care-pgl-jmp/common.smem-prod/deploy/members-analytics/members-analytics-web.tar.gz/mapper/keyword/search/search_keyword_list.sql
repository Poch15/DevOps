SELECT keyword_idx, sum(cnt) as sum
FROM v3_keyword
WHERE
  date >= '{start_date}'::date
AND
  date < '{end_date}'::date + INTERVAL '1' DAY
AND
  source = {source}
AND
  branch_id IN {branch_ids}
AND
  model {model}
GROUP BY keyword_idx
ORDER BY sum desc
LIMIT 100