SELECT mkt_id, name
FROM mkt_name
ORDER BY mkt_id DESC