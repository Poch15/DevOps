SELECT
  CASE
  WHEN monthval < 10 THEN yearval || '/0' || monthval
  ELSE yearval || '/' || monthval
  END as yearmonth, home, cat_id, cnt
FROM
(
  SELECT EXTRACT(year FROM date) as yearval, EXTRACT(month FROM date) as monthval, home, cat_id, SUM(cnt) as cnt
  FROM
  (
    SELECT datetime as date, home, cat_id, SUM(cnt) as cnt
    FROM tbl_v2_contents
    WHERE
      datetime >= '{start_date}'::timestamp
      AND
      datetime < '{end_date}'::timestamp + INTERVAL '1' DAY
      AND
      contents_type = {contents_type}
      AND
      branch_id IN {branch_ids}
      AND
        CASE
        WHEN '{contents_id}' = '0' THEN
          model {model}
        ELSE
          model {model} AND contents_id = '{contents_id}'
        END
    GROUP BY date, home, cat_id
    ORDER BY date, home, cat_id
  ) AS A
  GROUP BY yearval, monthval, home, cat_id
  ORDER BY yearval, monthval, home, cat_id
) AS B