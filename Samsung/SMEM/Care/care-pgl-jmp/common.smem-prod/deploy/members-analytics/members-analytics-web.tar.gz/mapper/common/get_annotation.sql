SELECT date, description
FROM v3_annotation
WHERE
date >= '{start_date}'
AND
date <= '{end_date}'
AND
branch_name = '{branch_name}'