from common.utils import Utils
from common.dbutils import DBUtils
from common.chart_utils import ChartUtils
from common.excel_utils import ExcelUtils
from common.date_utils import DateUtils
import pandas as pd
from io import BytesIO
from django.http import HttpResponse


class UniquePageViewController:
    __feature_list = (201, 301, 302, 303, 304, 306, 401, 402, 403, 502, 503, 504, 505, 506, 507, 508, 509, 510)
    __tab_list = (101, 501, 601, 305)

    @staticmethod
    def get_count_data(start_date, end_date, period, branch_ids, page_grp_id):
        sql = DBUtils.load_query('uniquepv', 'get_unique_pv_%s.sql' % period)
        params = {
            'start_date': start_date,
            'end_date': end_date,
            'branch_ids': branch_ids,
            'page_grp_id': page_grp_id}

        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)
        return return_rows

    @staticmethod
    def get_count_chart_data(start_date, end_date, period, branch_ids, page_grp_id):
        return_rows = UniquePageViewController.get_count_data(start_date, end_date, period, branch_ids, page_grp_id)

        chart_rows = ChartUtils.convert_chart_rows(return_rows)
        chart_data = ChartUtils.wrap_chart_data('UV', chart_rows)

        return chart_data

    @staticmethod
    def get_count_excel_data(start_date, end_date, period, branch_ids, page_grp_id):
        return_rows = UniquePageViewController.get_count_data(start_date, end_date, period, branch_ids, page_grp_id)

        excel_name = ExcelUtils.get_file_name('members_app_uv_cntys')
        excel_rows = ExcelUtils.convert_excel_rows(return_rows)
        excel_data = ExcelUtils.list_to_excel(excel_name, excel_rows)
        return excel_data

    @staticmethod
    def __get_count_by_page_list_chart_data(start_date, end_date, period, branch_ids, page_grp_list):
        date_list, date_df = UniquePageViewController.__get_date_list_and_dataframe(start_date, end_date, period)

        sql = DBUtils.load_query('uniquepv/page_group', 'get_unique_pv_page_group_%s.sql' % period)
        params = {
            'start_date': start_date,
            'end_date': end_date,
            'branch_ids': branch_ids,
            'page_grp_id': page_grp_list
        }

        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)

        result_list = list()
        percentage_list = list()
        if len(return_rows) > 0:
            page_id_to_name = UniquePageViewController.get_page_grp_id_to_name_dict()

            df = pd.DataFrame(data=return_rows, columns=['page_grp_id', 'date', 'cnt'])
            df = df.groupby(['date', 'page_grp_id'])['cnt'].sum().reset_index()

            df_sum = df.groupby(by=['date'])['cnt'].sum().to_frame().reset_index()
            df_sum.columns = ['date', 'sum']

            df = pd.merge(df, df_sum, on='date')
            df['perc'] = round(df['cnt'] / df['sum'], 2) * 100
            df['perc'] = df['perc'].astype(int)

            page_group_list = UniquePageViewController.__get_ordered_group_id_list_by_last_date(df, date_list[-1])

            for page_group_id in page_group_list:
                temp_df = df[df['page_grp_id'] == page_group_id]
                temp_df['date'] = temp_df['date'].astype(str)

                df2 = pd.merge(date_df, temp_df, how='outer', on='date').fillna(0)
                df2['cnt'] = df2['cnt'].astype(int)
                temp_list = df2['cnt'].tolist()
                temp_perc_list = df2['perc'].tolist()

                result_list.append({"name": page_id_to_name.get(page_group_id, page_group_id), "data": temp_list})
                percentage_list.append(
                    {"name": page_id_to_name.get(page_group_id, page_group_id), "data": temp_perc_list})

        return dict(category=date_list, data=result_list, table=percentage_list)

    @staticmethod
    def get_count_by_page_group_chart_data(start_date, end_date, period, branch_ids, page_grp_id):
        child_group_list = UniquePageViewController.__get_child_group_list(page_grp_id)

        return UniquePageViewController.__get_count_by_page_list_chart_data(start_date, end_date, period, branch_ids,
                                                                            child_group_list)

    @staticmethod
    def get_count_by_summary_feature_chart_data(start_date, end_date, period, branch_ids):
        feature_list = UniquePageViewController.__feature_list

        return UniquePageViewController.__get_count_by_page_list_chart_data(start_date, end_date, period, branch_ids,
                                                                            feature_list)

    @staticmethod
    def get_count_by_summary_tab_chart_data(start_date, end_date, period, branch_ids):
        tab_list = UniquePageViewController.__tab_list

        return UniquePageViewController.__get_count_by_page_list_chart_data(start_date, end_date, period, branch_ids,
                                                                            tab_list)

    @staticmethod
    def __get_count_by_summary_excel(start_date, end_date, period, branch_ids, page_grp_list, _filename):

        sql = DBUtils.load_query('uniquepv/page_group', 'get_unique_pv_page_group_%s.sql' % period)
        params = {
            'start_date': start_date,
            'end_date': end_date,
            'branch_ids': branch_ids,
            'page_grp_id': page_grp_list
        }

        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)

        if len(return_rows) > 0:
            page_id_to_name = UniquePageViewController.get_page_grp_id_to_name_dict()

            df = pd.DataFrame(data=return_rows, columns=['page_grp_id', 'date', 'cnt'])
            df = df.groupby(['date', 'page_grp_id'])['cnt'].sum().reset_index()

            df_sum = df.groupby(by=['date'])['cnt'].sum().to_frame().reset_index()
            df_sum.columns = ['date', 'sum']

            df = pd.merge(df, df_sum, on='date')
            df['%'] = round(df['cnt'] / df['sum'], 2)

            df[_filename] = df['page_grp_id'].map(page_id_to_name)

            df = df[['date', _filename, 'cnt', '%']]

            with BytesIO() as b:
                writer = pd.ExcelWriter(b, engine='xlsxwriter')
                df.to_excel(writer, sheet_name='Sheet1', index=False)
                writer.save()
                filename = 'active_user_' + _filename
                content_type = 'application/vnd.ms-excel'
                response = HttpResponse(b.getvalue(), content_type=content_type)
                response['Content-Disposition'] = 'attachment; filename="' + filename + '.xlsx"'

        return response

    @staticmethod
    def get_count_by_summary_feature_excel(start_date, end_date, period, branch_ids):
        feature_list = UniquePageViewController.__feature_list

        return UniquePageViewController.__get_count_by_summary_excel(start_date, end_date, period, branch_ids,
                                                                     feature_list, 'feature')

    @staticmethod
    def get_count_by_summary_tab_excel(start_date, end_date, period, branch_ids):
        tab_list = UniquePageViewController.__tab_list

        return UniquePageViewController.__get_count_by_summary_excel(start_date, end_date, period, branch_ids,
                                                                     tab_list, 'tab')

    @staticmethod
    def __get_child_group_list(parent_id):
        sql = DBUtils.load_query('uniquepv/page_group', 'get_child_page_group_list.sql')
        params = {'page_grp_id': parent_id}

        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)
        str_child_list = return_rows[0]
        child_list = str_child_list[0].split(",")

        ret_list = list()
        for child in child_list:
            ret_list.append(int(child))

        return tuple(ret_list)

    @staticmethod
    def __get_date_list_and_dataframe(start_date, end_date, period):
        date_list = DateUtils.create_date_list(start_date, end_date, period)
        date_df = pd.DataFrame(date_list, columns=['date'])
        date_df['date'] = date_df['date'].astype(str)

        return date_list, date_df

    @staticmethod
    def __get_ordered_group_id_list_by_last_date(_df, last_date):
        list_df = _df[_df['date'] == last_date].sort_values(by='cnt', ascending=False)
        group_list_ordered = list_df['page_grp_id'].tolist()
        group_list = _df['page_grp_id'].unique()

        for group in group_list:
            if group not in group_list_ordered:
                group_list_ordered.append(group)

        return group_list_ordered

    @staticmethod
    def get_cnty_data(start_date, end_date, period, branch_ids, page_grp_id):
        sql = DBUtils.load_query('uniquepv/cnty', 'get_unique_pv_cnty_%s.sql' % period)

        params = {
            'start_date': start_date,
            'end_date': end_date,
            'branch_ids': branch_ids,
            'period': period,
            'page_grp_id': page_grp_id}

        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)
        return return_rows

    @staticmethod
    def get_cnty_chart_data(start_date, end_date, period, branch_ids, page_grp_id):
        return_rows = UniquePageViewController.get_cnty_data(start_date, end_date, period, branch_ids, page_grp_id)

        cnty_chart_rows = ChartUtils.convert_country_chart_rows_except_zero(return_rows, period)
        cnty_chart_data = ChartUtils.wrap_country_chart_data(cnty_chart_rows)

        return cnty_chart_data

    @staticmethod
    def get_cnty_excel_data(start_date, end_date, period, branch_ids, page_grp_id):
        return_rows = UniquePageViewController.get_cnty_data(start_date, end_date, period, branch_ids, page_grp_id)

        file_name = ExcelUtils.get_file_name('members_app_uv_cnty')

        excel_rows = ExcelUtils.convert_cnty_excel_rows_except_zero(return_rows, branch_ids, period)
        excel_data = ExcelUtils.list_to_excel(file_name, excel_rows)

        return excel_data

    @staticmethod
    def get_tab_excel_data(cur_date, period, branch_ids):
        return_dict = UniquePageViewController.get_tab_count_data(cur_date, period, branch_ids, 0, 100)

        file_name = ExcelUtils.get_file_name('members_app_uv_feature')

        categories = return_dict['category']
        rows = return_dict['data']

        excel_rows = list()
        excel_rows.append(['Feature', 'Count', '%'])
        for category, row in zip(categories, rows):
            excel_rows.append([category, row[1], row[2]])

        excel_data = ExcelUtils.list_to_excel(file_name, excel_rows)

        return excel_data

    @staticmethod
    def get_tab_count_data(cur_date, period, branch_ids, cur_p, page_size):
        params = {
            "tbl_name": UniquePageViewController.get_sql_table(period),
            "date": cur_date,
            "branch_ids": branch_ids,
            "cur_p": cur_p
        }

        # get total count
        sql = DBUtils.load_query('uniquepv/tab', 'get_unique_pv_tab_total_count.sql')
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)
        total_count = return_rows[0][0]

        # get paging data
        sql = DBUtils.load_query('uniquepv/tab', 'get_unique_pv_tab.sql')
        paging_params = Utils.get_paging_params(total_count, cur_p, page_size)
        params.update(paging_params)
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)

        category = []
        page_grp_id_list = []
        is_total_list = []
        page_id_to_name_dict = UniquePageViewController.get_page_grp_id_to_name_dict()
        page_id_to_is_total_dict = UniquePageViewController.get_page_grp_id_to_is_total_dict()

        for row in return_rows:
            page_grp_id = row[0]

            page_grp_name = page_id_to_name_dict.get(page_grp_id, "")
            page_grp_id_list.append(page_grp_id)
            is_total_list.append(page_id_to_is_total_dict.get(page_grp_id, False))
            category.append(page_grp_name)

        return dict(category=category, data=return_rows, count=len(return_rows), page_grp_id_list=page_grp_id_list,
                    page_grp_id_is_total_list=is_total_list, tot_p=paging_params.get('total_page'), cur_p=int(cur_p))

    @staticmethod
    def get_sql_table(period):
        sql_tbl_dic = {
            'day': 'v3_unique_pv_daily',
            'week': 'v3_unique_pv_weekly',
            'month': 'v3_unique_pv_monthly'
        }

        return sql_tbl_dic[period]

    @staticmethod
    def get_page_grp_id_to_name_dict():
        sql = DBUtils.load_query('uniquepv', 'get_page_grp_id_to_name.sql')

        page_dict = dict()
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, {})
        for row in return_rows:
            page_grp_id, page_grp_name = row
            page_dict[page_grp_id] = page_grp_name

        return page_dict

    @staticmethod
    def get_page_grp_id_to_is_total_dict():
        sql = DBUtils.load_query('uniquepv', 'get_page_grp_id_to_is_total.sql')

        page_dict = dict()
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, {})
        for row in return_rows:
            page_grp_id, is_total = row
            page_dict[page_grp_id] = is_total

        return page_dict
