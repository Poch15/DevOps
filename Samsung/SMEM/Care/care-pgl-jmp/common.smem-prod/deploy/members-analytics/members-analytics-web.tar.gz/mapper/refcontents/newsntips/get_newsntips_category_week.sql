SELECT EXTRACT(isoyear FROM DATE) ||' '|| EXTRACT(week FROM DATE) ||'W' AS yearweek, category, SUM(cnt) AS cnt
FROM
(
	SELECT DATE::DATE + INTERVAL '1' DAY AS DATE, category, SUM(cnt) AS cnt
	FROM v3_newsntips_category
	WHERE
    date >= '{start_date}'
    AND
    date <= '{end_date}'
    AND
    branch_id IN {branch_ids}
    AND
    model {model}
	GROUP BY date, category
) AS A
GROUP BY EXTRACT(isoyear FROM DATE), EXTRACT(week FROM DATE), category
ORDER BY EXTRACT(isoyear FROM DATE), EXTRACT(week FROM DATE), category