SELECT date, sum(cnt)
FROM v3_screen_event
WHERE
    date >= '{start_date}'
AND
    date <= '{end_date}'
AND
    CASE
        WHEN '{event_id}' != ''
             THEN branch_id IN {branch_ids} AND event_id = '{event_id}'
        WHEN '{page_id}' != ''
             THEN branch_id IN {branch_ids} AND screen_id = '{page_id}'
        ELSE
             branch_id IN {branch_ids}
    END
GROUP BY date
ORDER BY date