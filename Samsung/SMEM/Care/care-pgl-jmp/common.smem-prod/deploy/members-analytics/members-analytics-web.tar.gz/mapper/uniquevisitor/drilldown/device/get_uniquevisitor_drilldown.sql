SELECT date, SUM(cnt) as cnt
FROM {tbl_name}
  WHERE
    date >= '{start_date}'
  AND
    date <= '{end_date}'
  AND
    branch_id IN {branch_ids}
  AND
    model {model}
GROUP BY date
ORDER BY date