from django.shortcuts import render_to_response
from django.template.context import RequestContext
from django.views.decorators.http import require_http_methods
from django.http import JsonResponse
from common.utils import custom_login_required, access_log
from common.params_utils import ParamsUtils
from SessionManager.controls import SessionManagerController
from MyProduct.controls import MyProductController


@custom_login_required
@require_http_methods(["GET"])
@access_log
def view_product(request):
    template = 'myproduct/mp_product.html'

    dictionary = {
        'request_type': 0,
        'request_type_name': 'Registered Product',
        'cnty_chart_name': 'Registered Product by company name'
    }

    return render_to_response(template, dictionary=dictionary, context_instance=RequestContext(request))


@custom_login_required
@require_http_methods(["GET"])
@access_log
def view_book_appointment(request):
    template = 'myproduct/mp_sr.html'

    dictionary = {
        'request_type': 1,
        'request_type_name': 'Book Appointment',
        'cnty_chart_name': 'Book Appointment by country (only count Requested status)'
    }

    return render_to_response(template, dictionary=dictionary, context_instance=RequestContext(request))


@custom_login_required
@require_http_methods(["GET"])
@access_log
def view_support_request(request):
    template = 'myproduct/mp_sr.html'

    dictionary = {
        'request_type': 2,
        'request_type_name': 'Support Request',
        'cnty_chart_name': 'Support Request by country (only count Requested status)'
    }

    return render_to_response(template, dictionary=dictionary, context_instance=RequestContext(request))


@custom_login_required
@require_http_methods(["GET"])
def get_count_chart_data(request):
    try:
        count_data = MyProductController.get_count_chart_data(
            start_date=ParamsUtils.get_param(request, "start_date"),
            end_date=ParamsUtils.get_param(request, "end_date"),
            period=ParamsUtils.get_param(request, "period"),
            model=ParamsUtils.get_param(request, "query_model"),
            branch_ids=SessionManagerController.get_selected_branch_ids(request),
            request_type=ParamsUtils.get_param(request, "request_type")
        )
        return JsonResponse(count_data)
    except Exception as e:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})


@custom_login_required
@require_http_methods(["GET"])
def get_cnty_data(request):
    try:
        cnty_chart_data = MyProductController.get_cnty_chart_data(
            start_date=ParamsUtils.get_param(request, "start_date"),
            end_date=ParamsUtils.get_param(request, "end_date"),
            period=ParamsUtils.get_param(request, "period"),
            branch_ids=SessionManagerController.get_selected_branch_ids(request),
            model=ParamsUtils.get_param(request, "query_model"),
            request_type=ParamsUtils.get_param(request, "request_type")
        )
        return JsonResponse(cnty_chart_data)
    except Exception as e:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})


@custom_login_required
@require_http_methods(["GET"])
def get_tab_count_data(request):
    try:
        tab_count_data = MyProductController.get_tab_count_data(
            start_date=ParamsUtils.get_param(request, "start_date"),
            end_date=ParamsUtils.get_param(request, "end_date"),
            branch_ids=SessionManagerController.get_selected_branch_ids(request),
            model=ParamsUtils.get_param(request, "query_model"),
            tab_type=ParamsUtils.get_param(request, "tab_type"),
            request_type=ParamsUtils.get_param(request, "request_type"),
            cur_p=ParamsUtils.get_param(request, "cur_p"),
            page_size=int(ParamsUtils.get_param(request, "page_size"))
        )
        return JsonResponse(tab_count_data)

    except Exception as e:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})


@custom_login_required
@require_http_methods(["GET"])
def get_count_excel_data(request):
    try:
        excel_count_data = MyProductController.get_count_excel_data(
            start_date=ParamsUtils.get_param(request, "start_date"),
            end_date=ParamsUtils.get_param(request, "end_date"),
            period=ParamsUtils.get_param(request, "period"),
            model='all',
            branch_ids=SessionManagerController.get_selected_branch_ids(request),
            request_type=ParamsUtils.get_param(request, "request_type")
        )
        return excel_count_data
    except Exception as e:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})


@custom_login_required
@require_http_methods(["GET"])
def get_country_excel_data(request):
    try:
        excel_cnty_count_data = MyProductController.get_country_excel_data(
            start_date=ParamsUtils.get_param(request, "start_date"),
            end_date=ParamsUtils.get_param(request, "end_date"),
            period=ParamsUtils.get_param(request, "period"),
            model='all',
            branch_ids=SessionManagerController.get_selected_branch_ids(request),
            request_type=ParamsUtils.get_param(request, "request_type")
        )
        return excel_cnty_count_data
    except Exception as e:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})
