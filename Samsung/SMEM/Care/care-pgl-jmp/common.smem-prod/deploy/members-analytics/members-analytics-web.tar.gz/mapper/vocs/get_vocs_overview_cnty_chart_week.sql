SELECT branch_id, yearval ||' '|| weekval ||'W' as yearweek, cnt
FROM
  (
    SELECT branch_id, extract(isoyear from dateval) as yearval, extract(week from dateval) as weekval, sum(cnt) as cnt
    FROM
    (
          (
            SELECT branch_id, date + interval '1' day as dateval, sum(cnt) as cnt
            FROM
              (
                SELECT branch_id, date, sum(cnt) as cnt
                FROM v3_feedback
                WHERE
                  date >= '{start_date}'
                AND
                  date <= '{end_date}'
                AND
                  branch_id IN {branch_ids}
                AND
                  model {model}
                AND
                  main_type IN {main_types}
                GROUP BY branch_id, date
                ORDER BY branch_id, date
              ) AS A
            GROUP BY branch_id, date
            ORDER BY branch_id, date
          )
          UNION ALL
          (
	          SELECT 0 as branch_id, date + interval '1' day as date_with_timezone, 0 as sum
            FROM
              (
                SELECT C.date
                FROM
                  (
                    SELECT '{start_date}'::date + (100 * aa.a + 10 * bb.a + cc.a) as date
                    FROM (
                            select 0 as a
                            union all select 1
                            union all select 2
                            union all select 3
                            union all select 4
                            union all select 5
                            union all select 6
                            union all select 7
                            union all select 8
                            union all select 9
                          ) as aa cross join
                          (
                            select 0 as a
                            union all select 1
                            union all select 2
                            union all select 3
                            union all select 4
                            union all select 5
                            union all select 6
                            union all select 7
                            union all select 8
                            union all select 9
                          ) as bb cross join
                          (
                            select 0 as a
                            union all select 1
                            union all select 2
                            union all select 3
                            union all select 4
                            union all select 5
                            union all select 6
                            union all select 7
                            union all select 8
                            union all select 9
                          ) as cc
                  ) AS C
                WHERE C.DATE < '{end_date}'::date + interval '1' day
              ) AS D
          )
    ) AS E
    GROUP BY branch_id, yearval, weekval
    ORDER BY branch_id, yearval, weekval
  ) AS F