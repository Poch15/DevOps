from django.http import JsonResponse
from django.shortcuts import render_to_response
from django.template.context import RequestContext
from django.views.decorators.http import require_http_methods
from Journey.controls import JourneyController
from common.utils import custom_login_required, access_log
from common.params_utils import ParamsUtils
from SessionManager.controls import SessionManagerController
from common.exception_handler import ExceptionHandler


@ExceptionHandler(return_type=ExceptionHandler.RETURN_HTTP)
@custom_login_required
@require_http_methods(["GET"])
@access_log
def view(request):
    template = 'journey/journey.html'
    return render_to_response(template, context_instance=RequestContext(request))


@custom_login_required
@require_http_methods(["GET"])
def get_journey(request):
    try:
        chart_data = JourneyController.get_journey_chart_data(
            start_dt=ParamsUtils.get_param(request, "start_date"),
            end_dt=ParamsUtils.get_param(request, "end_date"),
            branch_ids=SessionManagerController.get_selected_branch_ids(request),
            model=ParamsUtils.get_param(request, "query_model"),
            period=ParamsUtils.get_param(request, "period")
        )
        return JsonResponse(chart_data, safe=False)

    except Exception as e:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})


@custom_login_required
@require_http_methods(["GET"])
def get_journey_summary(request):
    try:
        summary_data = JourneyController.get_journey_summary(
            start_date=ParamsUtils.get_param(request, "start_date"),
            end_date=ParamsUtils.get_param(request, "end_date"),
            branch_ids=SessionManagerController.get_selected_branch_ids(request),
            period=ParamsUtils.get_param(request, "period")
        )
        return JsonResponse(summary_data)

    except Exception as e:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})


@custom_login_required
@require_http_methods(["GET"])
def get_journey_detail(request):
    try:
        chart_data = JourneyController.get_journey_detail_chart_data(
            start_date=ParamsUtils.get_param(request, "start_date"),
            end_date=ParamsUtils.get_param(request, "end_date"),
            branch_ids=SessionManagerController.get_selected_branch_ids(request),
            model=ParamsUtils.get_param(request, "query_model"),
            period=ParamsUtils.get_param(request, "period"),
            sankey_id=ParamsUtils.get_param(request, "sankey_id"),
            step=int(ParamsUtils.get_param(request, "step")),
            base_level=int(ParamsUtils.get_param(request, "base_level"))
        )
        return JsonResponse(chart_data)

    except Exception as e:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})
