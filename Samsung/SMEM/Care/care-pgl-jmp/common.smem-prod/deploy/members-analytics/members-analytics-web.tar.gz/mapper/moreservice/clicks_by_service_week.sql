SELECT yearval || ' ' || weekval || 'W' as yearweek, service_id, sumval
FROM
(
	SELECT EXTRACT(isoyear FROM dateval) as yearval, EXTRACT(week FROM dateval) as weekval, service_id, sum(count) as sumval
	FROM
	(
		SELECT (date + INTERVAL '1' DAY)::DATE as dateval, service_id, sum(cnt) as count
		FROM v3_more_svc_event
		  WHERE
		      date >= '{start_date}'::date
		    AND
		      date < '{end_date}'::date + INTERVAL '1' DAY
		    AND
		      branch_id IN {branch_ids}
		    AND
		      model {model}
		GROUP BY dateval, service_id
		ORDER BY dateval
	) AS A
	GROUP BY yearval, weekval, service_id
	ORDER BY yearval, weekval
) AS B