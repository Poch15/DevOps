from datetime import datetime, timedelta


def get_range_datetime(last_hour_dt, start_delta_days, end_delta_days):
    end_dt = last_hour_dt
    start_dt = end_dt - timedelta(days=start_delta_days)
    end_dt = end_dt - timedelta(days=end_delta_days)

    start_dt = start_dt.strftime('%Y-%m-%dT%H:00')
    end_dt = end_dt.strftime('%Y-%m-%dT%H:00')

    return start_dt, end_dt


def get_last_hour_dt(last_hour_result):
    if last_hour_result[0][0] is not None:
        last_hour_dt = last_hour_result[0][0] + timedelta(hours=1)
    else:
        last_hour_dt = datetime.now()

    last_hour_dt = last_hour_dt.replace(minute=0, second=0, microsecond=0, tzinfo=None)
    return last_hour_dt
