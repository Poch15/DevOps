from django.views.decorators.http import require_http_methods
from django.http import JsonResponse
from common.params_utils import ParamsUtils
from Rest.fb_controls import FeedbackRestController
from django.views.decorators.cache import cache_page


@require_http_methods(["GET"])
def get_fb_recent_month_info(request, main_type, sub_type):
    try:
        fb_recent_month_info = FeedbackRestController.get_fb_recent_month_info(
            main_type, sub_type,
            branch_id=ParamsUtils.get_param(request, "branchId"),
            beta_prj_id=ParamsUtils.get_param(request, "betaProjectId")
            )
        return JsonResponse(fb_recent_month_info)
    except Exception as e:
        return JsonResponse({'status': 'fail', 'message': e})
