SELECT tz
FROM svc_cnty
WHERE
  branch_id = {branch_id}
  AND
  def_cnty = 1