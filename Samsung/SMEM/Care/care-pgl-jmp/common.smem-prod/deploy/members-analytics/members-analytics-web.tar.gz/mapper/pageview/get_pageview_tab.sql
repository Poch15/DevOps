SELECT {tab_type}, sum(cnt) as cnt, ROUND(SUM(cnt) / SUM(SUM(cnt)) OVER() * 100.0, 2) AS percent
FROM
(
  SELECT {tab_type}, screen_id, sum(cnt) as cnt
  FROM {tbl_name}
  WHERE
      date >= '{start_date}'
  AND
      date <= '{end_date}'
  AND
      branch_id IN {branch_ids}
  AND
      CASE
          WHEN '{page_id}' = ''
               THEN  model {model}
          ELSE
               model {model} AND screen_id = '{page_id}'
      END
    GROUP BY {tab_type}, screen_id
) AS A
GROUP BY {tab_type}
ORDER BY cnt desc
LIMIT {limit} OFFSET {offset}