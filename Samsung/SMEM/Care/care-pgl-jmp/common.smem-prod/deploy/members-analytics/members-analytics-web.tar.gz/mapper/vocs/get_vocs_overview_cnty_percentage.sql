SELECT branch_id, SUM(cnt) AS COUNT, ROUND(SUM(cnt) / SUM(SUM(cnt)) OVER() * 100.0, 2) AS percent
FROM v3_feedback
  WHERE
    date >= '{start_date}'
  AND
    date <= '{end_date}'
  AND
    branch_id IN {branch_ids}
  AND
    model {model}
  AND
    main_type IN {main_types}
GROUP BY branch_id
ORDER BY SUM(cnt) DESC