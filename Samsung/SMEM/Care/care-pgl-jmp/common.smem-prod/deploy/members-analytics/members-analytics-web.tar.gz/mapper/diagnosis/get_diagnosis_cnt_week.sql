select yearweek, sum(cnt) as cnt
from
(
  SELECT yearval ||' '|| weekval ||'W' as yearweek, cnt
FROM
  (
    SELECT extract(isoyear from dateval) as yearval, extract(week from dateval) as weekval, sum(cnt) as cnt
    FROM
    (
          (
            SELECT datetime + interval '1' day as dateval, sum(cnt) as cnt
            FROM
              (
                SELECT datetime, cnt
                FROM {tbl_name}
                WHERE
                  datetime >= '{start_date}'::timestamp
                AND
                  datetime < '{end_date}'::timestamp + INTERVAL '1' DAY
                AND
                  model {model}
                AND
                  branch_id IN {branch_ids}
              ) AS A
            GROUP BY dateval
            ORDER BY dateval
          )
          UNION ALL
          (
	          SELECT date + interval '1' day, 0 as sum
            FROM
              (
                SELECT C.date
                FROM
                  (
                    SELECT '{start_date}'::date + (100 * aa.a + 10 * bb.a + cc.a) as date
                    FROM (
                            select 0 as a
                            union all select 1
                            union all select 2
                            union all select 3
                            union all select 4
                            union all select 5
                            union all select 6
                            union all select 7
                            union all select 8
                            union all select 9
                          ) as aa cross join
                          (
                            select 0 as a
                            union all select 1
                            union all select 2
                            union all select 3
                            union all select 4
                            union all select 5
                            union all select 6
                            union all select 7
                            union all select 8
                            union all select 9
                          ) as bb cross join
                          (
                            select 0 as a
                            union all select 1
                            union all select 2
                            union all select 3
                            union all select 4
                            union all select 5
                            union all select 6
                            union all select 7
                            union all select 8
                            union all select 9
                          ) as cc
                  ) AS C
                WHERE C.DATE < '{end_date}'::date + interval '1' day
              ) AS D
          )
    ) AS E
    GROUP BY extract(isoyear from dateval), extract(week from dateval)
    ORDER BY extract(isoyear from dateval), extract(week from dateval)
  ) AS F
) AS G
group by yearweek
order by yearweek