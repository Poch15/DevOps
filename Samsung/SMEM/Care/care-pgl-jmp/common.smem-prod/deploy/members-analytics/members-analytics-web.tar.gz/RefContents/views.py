from django.shortcuts import render_to_response
from django.template.context import RequestContext
from django.views.decorators.http import require_http_methods
from django.http import JsonResponse
from common.utils import custom_login_required, access_log
from common.exception_handler import ExceptionHandler
from common.params_utils import ParamsUtils
from SessionManager.controls import SessionManagerController
from RefContents.controls import RefContentsController


@ExceptionHandler(return_type=ExceptionHandler.RETURN_JSON)
@custom_login_required
@require_http_methods(["GET"])
@access_log
def view_notice(request):
    template = 'ref_contents/ref_contents_detail.html'

    return render_to_response(template, {'content_type': 1,
                                         'content_type_name': 'Notice'},
                              context_instance=RequestContext(request))


@ExceptionHandler(return_type=ExceptionHandler.RETURN_JSON)
@custom_login_required
@require_http_methods(["GET"])
@access_log
def view_newsntips(request):
    template = 'ref_contents/ref_contents_detail.html'

    return render_to_response(template, {'content_type': 2,
                                         'content_type_name': 'News&Tips'},
                              context_instance=RequestContext(request))


@ExceptionHandler(return_type=ExceptionHandler.RETURN_JSON)
@custom_login_required
@require_http_methods(["GET"])
@access_log
def view_faq(request):
    template = 'ref_contents/ref_contents_detail.html'

    return render_to_response(template, {'content_type': 3,
                                         'content_type_name': 'FAQ'},
                              context_instance=RequestContext(request))


@ExceptionHandler(return_type=ExceptionHandler.RETURN_JSON)
@custom_login_required
@require_http_methods(["GET"])
@access_log
def view_community(request):
    template = 'ref_contents/ref_contents_detail.html'

    return render_to_response(template, {'content_type': 4,
                                         'content_type_name': 'Community'},
                              context_instance=RequestContext(request))


@ExceptionHandler(return_type=ExceptionHandler.RETURN_JSON)
@custom_login_required
@require_http_methods(["GET"])
@access_log
def view_benefit(request):
    template = 'ref_contents/ref_contents_detail.html'

    return render_to_response(template, {'content_type': 5,
                                         'content_type_name': 'Benefit'},
                              context_instance=RequestContext(request))


@ExceptionHandler(return_type=ExceptionHandler.RETURN_JSON)
@custom_login_required
@require_http_methods(["GET"])
@access_log
def view_coupon(request):
    template = 'ref_contents/ref_contents_detail.html'

    return render_to_response(template, {'content_type': 6,
                                         'content_type_name': 'Coupon'},
                              context_instance=RequestContext(request))


@ExceptionHandler(return_type=ExceptionHandler.RETURN_JSON)
@custom_login_required
@require_http_methods(["GET"])
@access_log
def view_benefit_detail(request):
    template = 'ref_contents/ref_contents_detail.html'

    return render_to_response(template, {'content_type': 7,
                                         'content_type_name': 'Benefit Detail'},
                              context_instance=RequestContext(request))


@custom_login_required
@require_http_methods(["GET"])
def get_count_chart_data(request):
    try:
        return JsonResponse(RefContentsController.get_count_chart_data(
            start_date=ParamsUtils.get_param(request, "start_date"),
            end_date=ParamsUtils.get_param(request, "end_date"),
            period=ParamsUtils.get_param(request, "period"),
            model=ParamsUtils.get_param(request, "query_model"),
            branch_ids=SessionManagerController.get_selected_branch_ids(request),
            content_id=ParamsUtils.get_param(request, "content_id"),
            content_type=ParamsUtils.get_param(request, "content_type")
        ))
    except Exception as e:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})


@custom_login_required
@require_http_methods(["GET"])
def get_faq_category_chart_data(request):
    try:
        return JsonResponse(RefContentsController.get_faq_category_chart(
            start_date=ParamsUtils.get_param(request, "start_date"),
            end_date=ParamsUtils.get_param(request, "end_date"),
            period=ParamsUtils.get_param(request, "period"),
            model=ParamsUtils.get_param(request, "query_model"),
            branch_ids=SessionManagerController.get_selected_branch_ids(request),
            content_id=ParamsUtils.get_param(request, "content_id"),
            content_type=ParamsUtils.get_param(request, "content_type")
        ))
    except Exception as e:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})


@custom_login_required
@require_http_methods(["GET"])
def get_analysis_title_data(request):
    try:
        return JsonResponse(RefContentsController.get_analysis_title_data(
            start_date=request.GET.get("start_date"),
            end_date=request.GET.get("end_date"),
            branch_ids=SessionManagerController.get_selected_branch_ids(request),
            model=ParamsUtils.get_param(request, "query_model"),
            cur_p=ParamsUtils.get_param(request, "cur_p"),
            page_size=int(ParamsUtils.get_param(request, "page_size")),
            content_type=ParamsUtils.get_param(request, "content_type"),
            order_type=ParamsUtils.get_param(request, "order_type")
            )
        )
    except Exception as e:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})


@custom_login_required
@require_http_methods(["GET"])
def get_analysis_device_data(request):
    try:
        return JsonResponse(RefContentsController.get_analysis_device_data(
            start_date=request.GET.get("start_date"),
            end_date=request.GET.get("end_date"),
            branch_ids=SessionManagerController.get_selected_branch_ids(request),
            model=ParamsUtils.get_param(request, "query_model"),
            cur_p=ParamsUtils.get_param(request, "cur_p"),
            page_size=int(ParamsUtils.get_param(request, "page_size")),
            content_id=ParamsUtils.get_param(request, "content_id"),
            content_type=ParamsUtils.get_param(request, "content_type")
            )
        )
    except Exception as e:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})


@custom_login_required
@require_http_methods(["GET"])
def get_analysis_category_data(request):
    try:
        return JsonResponse(RefContentsController.get_analysis_category_data(
            start_date=request.GET.get("start_date"),
            end_date=request.GET.get("end_date"),
            branch_ids=SessionManagerController.get_selected_branch_ids(request),
            model=ParamsUtils.get_param(request, "query_model"),
            cur_p=ParamsUtils.get_param(request, "cur_p"),
            content_id=ParamsUtils.get_param(request, "content_id"),
            content_type=ParamsUtils.get_param(request, "content_type")
            )
        )
    except Exception as e:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})


@custom_login_required
@require_http_methods(["GET"])
def export_excel(request):
    try:
        excel_count_data = RefContentsController.get_count_excel_data(
            start_date=ParamsUtils.get_param(request, "start_date"),
            end_date=ParamsUtils.get_param(request, "end_date"),
            period=ParamsUtils.get_param(request, "period"),
            branch_ids=SessionManagerController.get_selected_branch_ids(request),
            model=ParamsUtils.get_param(request, "query_model"),
            content_id=ParamsUtils.get_param(request, "content_id"),
            content_type=ParamsUtils.get_param(request, "content_type")
        )
        return excel_count_data
    except Exception as e:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})


@custom_login_required
@require_http_methods(["GET"])
def get_newsntips_ratio_chart_data(request):
    try:
        return JsonResponse(RefContentsController.get_newsntips_ratio_chart_data(
            start_date=ParamsUtils.get_param(request, "start_date"),
            end_date=ParamsUtils.get_param(request, "end_date"),
            period=ParamsUtils.get_param(request, "period"),
            branch_ids=SessionManagerController.get_selected_branch_ids(request),
            content_id=ParamsUtils.get_param(request, "content_id")
        ))
    except Exception as e:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})


@custom_login_required
@require_http_methods(["GET"])
def get_weblink_chart_data(request):
    try:
        return JsonResponse(RefContentsController.get_weblink_chart_data(
            start_date=ParamsUtils.get_param(request, "start_date"),
            end_date=ParamsUtils.get_param(request, "end_date"),
            period=ParamsUtils.get_param(request, "period"),
            model=ParamsUtils.get_param(request, "query_model"),
            branch_ids=SessionManagerController.get_selected_branch_ids(request),
            contents_id=ParamsUtils.get_param(request, "content_id"),
            contents_type=ParamsUtils.get_param(request, "content_type")
        ))
    except Exception as e:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})
