import numpy as np
from common.utils import Utils
from common.branch_utils import BranchUtils
from common.date_utils import DateUtils


class ChartUtils:

    @staticmethod
    def row_to_column(row_list):
        x = np.array(row_list)
        return x.T.tolist()

    @staticmethod
    def convert_chart_rows(rows):
        category = []
        row_list = []
        for row in rows:
            category.append(row[0])
            row_list.append(int(row[1]))
        convert = ChartUtils.row_to_column(row_list)

        return dict(category=category, data=convert)

    @staticmethod
    def wrap_chart_data(chart_name, chart_rows, annotations=None):
        category = chart_rows["category"]
        data = chart_rows["data"]

        data_list = []
        for date, cnt in zip(category, data):
            data_list.append([cnt, date])

        chart_data = [{
            "name": chart_name,
            "keys": ['y', 'id'],
            "data": data_list
        }]

        return dict(category=category, data=chart_data, annotations=annotations)

    @staticmethod
    def convert_country_chart_rows(rows):
        branch_id_dic = {}
        date_list = []
        statistics_dic = {}
        for return_row in rows:
            branch_id, date, count = return_row
            if branch_id == 0:
                date_list.append(date)
            branch_id_dic[branch_id] = branch_id_dic.get(branch_id, 0) + int(count)
            statistics_dic[(branch_id, date)] = int(count)
        branch_list = sorted(branch_id_dic, key=branch_id_dic.get, reverse=True)

        return dict(branch_list=branch_list, date_list=date_list, statistics_dic=statistics_dic)

    @staticmethod
    def convert_country_chart_rows_except_zero(rows, period):
        branch_id_dic = {}
        statistics_dic = {}
        date_set = set()
        for return_row in rows:
            branch_id, date, count = return_row
            date_set.add(date)
            branch_id_dic[branch_id] = branch_id_dic.get(branch_id, 0) + int(count)
            statistics_dic[(branch_id, date)] = int(count)
        branch_list = sorted(branch_id_dic, key=branch_id_dic.get, reverse=True)

        date_list = list(date_set)
        date_list.sort(key=DateUtils.get_date_sort_key(period))

        return dict(branch_list=branch_list, date_list=date_list, statistics_dic=statistics_dic)

    @staticmethod
    def wrap_country_chart_data(chart_rows):
        branch_list = chart_rows['branch_list']
        date_list = chart_rows['date_list']
        statistics_dic = chart_rows['statistics_dic']

        branch_dic = BranchUtils.get_all_branch_dict()

        chart_data = []
        for branch in branch_list:
            if branch != 0:
                tmp_data = []
                for _date in date_list:
                    value = statistics_dic.get((branch, _date), 0)
                    tmp_data.append(value)
                chart_data.append({"name": branch_dic[branch], "data": tmp_data})

        return dict(category=date_list, data=chart_data)

    @staticmethod
    def convert_app_id_chart_rows(rows, period):
        app_id_dic = {}
        statistics_dic = {}
        date_set = set()
        for return_row in rows:
            date, app_id, count = return_row
            date_set.add(date)
            app_id_dic[app_id] = app_id_dic.get(app_id, 0) + int(count)
            statistics_dic[(date, app_id)] = int(count)

        date_list = list(date_set)
        date_list.sort(key=DateUtils.get_date_sort_key(period))

        # sort app id list (order by total count)
        app_id_list = sorted(app_id_dic, key=app_id_dic.get, reverse=True)
        app_dic = Utils.get_all_app_info()

        chart_data = []
        for app_id in app_id_list:
            tmp_data = []
            for _date in date_list:
                value = statistics_dic.get((_date, app_id,), 0)
                tmp_data.append(value)

            chart_data.append({"name": app_dic.get(app_id, 'NOT_FOUND'), "data": tmp_data})

        return dict(category=date_list, data=chart_data)

    @staticmethod
    def convert_app_id_percentage_chart_data(rows):

        app_dic = Utils.get_all_app_info()

        data = []
        total_count = 0
        for row in rows:
            total_count += row[1]
            data.append((app_dic.get(row[0], 'NOT_FOUND'), row[1],  row[2]))

        return dict(data=data)

    @staticmethod
    def convert_app_id_tab_list(rows):

        app_dic = Utils.get_all_app_info()
        convert_rows = []
        for index, row in enumerate(rows):
            convert_rows.append((app_dic.get(row[0], 'NOT_FOUND'), row[1], row[2]))

        return convert_rows

    @staticmethod
    def convert_prev_diff_chart_rows(rows):
        category = []
        row_list = []
        prev_count = 0
        for row in rows:
            date, count = row
            category.append(date)
            row_list.append(count - prev_count)
            prev_count = count
        convert = ChartUtils.row_to_column(row_list)

        return dict(category=category, data=convert)

    @staticmethod
    def wrap_dual_stack_chart_data(left_chart_name, right_chart_name, left_chart_rows, right_chart_rows):
        category = left_chart_rows["category"]
        left_chart = {
            "name": left_chart_name,
            "data": left_chart_rows["data"]
        }

        if isinstance(right_chart_rows["data"], list):
            right_chart_data = right_chart_rows["data"]
        else:
            right_chart_data = [right_chart_rows["data"]]

        right_chart = {
            "name": right_chart_name,
            "data": right_chart_data
        }

        chart_data = [left_chart, right_chart]

        return dict(category=category, data=chart_data)
