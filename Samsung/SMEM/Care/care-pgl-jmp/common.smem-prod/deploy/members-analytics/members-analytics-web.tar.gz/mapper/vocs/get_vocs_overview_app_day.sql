SELECT date, app_id, sum(cnt) as cnt
FROM
  (
    SELECT date, app_id, cnt
    FROM v3_feedback
    WHERE
      date >= '{start_date}'
    AND
      date <= '{end_date}'
    AND
      branch_id IN {branch_ids}
    AND
      model {model}
    AND
      main_type IN {main_types}
  ) AS A
GROUP BY date, app_id
ORDER BY date, app_id