from common.utils import Utils
from common.dbutils import DBUtils
from common.chart_utils import ChartUtils
from common.excel_utils import ExcelUtils
from datetime import date
from common.branch_utils import BranchUtils
from datetime import datetime, timedelta
from Device.controls import DeviceController


class UniqueVisitorController:

    @staticmethod
    def get_dashboard_count_data(branch_ids, interval_hour):
        sql = DBUtils.load_query('uniquevisitor', 'get_uniquevisitor_dashboard_weekly.sql')
        start_date = Utils.get_week_start_date()
        end_date = date.today()
        params = {"timezone": interval_hour, "branch_ids": branch_ids,
                  "start_date": start_date, "end_date": end_date}
        return_row = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)

        return return_row

    @staticmethod
    def get_count_data(start_date, end_date, period, branch_ids, model, timezone, data_type):
        if data_type == 'uniquedevice':
            start_date, end_date = UniqueVisitorController.get_ud_start_end_date(start_date, end_date, period)

        sql_info = UniqueVisitorController.get_sql_info(data_type, period, model)
        sql = DBUtils.load_query(sql_info[0], 'get_uniquevisitor_%s.sql' % period)
        params = {'start_date': start_date, 'end_date': end_date, 'branch_ids': branch_ids,
                  'model': model, 'timezone': timezone, 'interval_hour': timezone, 'tbl_name': sql_info[1]}
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)

        return return_rows

    @staticmethod
    def get_chart_count_data(start_date, end_date, period, branch_ids, model, timezone, data_type, branch_name):
        return_rows = UniqueVisitorController.get_count_data(start_date, end_date, period,
                                                             branch_ids, model, timezone, data_type)
        chart_rows = ChartUtils.convert_chart_rows(return_rows)
        chart_name = "Active Devices" if data_type == 'uniquedevice' or data_type == 'ud' \
            or data_type == 'v3_uv_dvc' or data_type == 'v3_uniquedevice' else "Active Users"
        annotations = UniqueVisitorController.get_annotation_data(start_date, end_date, branch_name)
        chart_data = ChartUtils.wrap_chart_data(chart_name, chart_rows, annotations)
        return chart_data

    @staticmethod
    def get_excel_count_data(start_date, end_date, period, branch_ids, model, timezone, data_type):
        return_rows = UniqueVisitorController.get_count_data(start_date, end_date, period, branch_ids, model,
                                                             timezone, data_type)
        file_name = 'active_devices' if data_type == 'uniquedevice' or data_type == 'ud' \
            or data_type == 'v3_uv_dvc' or data_type == 'v3_uniquedevice' else 'active_users'
        file_name = ExcelUtils.get_file_name(file_name)
        excel_rows = ExcelUtils.convert_excel_rows(return_rows)
        excel_data = ExcelUtils.list_to_excel(file_name, excel_rows)

        return excel_data

    @staticmethod
    def get_country_count_data(model, start_date, end_date, period, interval_hour, branch_ids, data_type):
        if data_type == 'uniquedevice':
            start_date, end_date = UniqueVisitorController.get_ud_start_end_date(start_date, end_date, period)

        sql_info = UniqueVisitorController.get_sql_info(data_type, period, model)
        sql = DBUtils.load_query(sql_info[0], 'get_uniquevisitor_cnty_%s.sql' % period)
        params = {"interval_hour": interval_hour, "branch_ids": branch_ids, "model": model,
                  "start_date": start_date, "end_date": end_date, "period": period,
                  'timezone': interval_hour, 'tbl_name': sql_info[1]}
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)
        return return_rows

    @staticmethod
    def get_country_chart_data(model, start_date, end_date, period, interval_hour, branch_ids, data_type):
        return_rows = UniqueVisitorController.get_country_count_data(model, start_date, end_date,
                                                                     period, interval_hour, branch_ids, data_type)

        cnty_chart_rows = ChartUtils.convert_country_chart_rows_except_zero(return_rows, period)
        cnty_chart_data = ChartUtils.wrap_country_chart_data(cnty_chart_rows)
        return cnty_chart_data

    @staticmethod
    def get_country_excel_date(model, start_date, end_date, period, interval_hour, branch_ids, data_type):
        return_rows = UniqueVisitorController.get_country_count_data(model, start_date, end_date,
                                                                     period, interval_hour, branch_ids, data_type)

        file_name = 'active_devices_cnty' if data_type == 'uniquedevice' or data_type == 'ud' \
            or data_type == 'v3_uv_dvc' or data_type == 'v3_uniquedevice' else 'active_users_cnty'
        file_name = ExcelUtils.get_file_name(file_name)

        cnty_excel_rows = ExcelUtils.convert_user_cnty_excel_rows(return_rows, False)
        cnty_excel_data = ExcelUtils.list_to_excel(file_name, cnty_excel_rows)
        return cnty_excel_data

    @staticmethod
    def get_tab_count_data(cur_date, period, branch_ids, model, interval_hour, cur_p, tab_type, view_type,
                           page_size, data_type):
        sql_info = UniqueVisitorController.get_sql_info(data_type, period, model, tab_type)
        params = {"tbl_name": sql_info[1], "date": cur_date, "branch_ids": branch_ids, "model": model,
                  "cur_p": cur_p, "tab_type": tab_type, "view_type": view_type}
        if period == 'hour':
            params.update({'timezone': 0, 'interval_hour': interval_hour})
        else:
            params.update({'timezone': interval_hour, 'interval_hour': 0})

        if view_type == "chart":
            sql = DBUtils.load_query(sql_info[0], 'get_uniquevisitor_%s_%s.sql' % (tab_type, view_type))
            return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)

            branch_dic = BranchUtils.get_all_branch_dict()

            data = []
            total_count = 0
            for return_row in return_rows:
                branch_id, real_count, percentage = return_row
                total_count += real_count
                data.append({"name": branch_dic[branch_id], "y": percentage, "real_count": real_count})

            return dict(data=[{"name": "Percentage of count by country", "colorByPoint": True,
                               "data": data}], count=total_count)

        elif view_type == "table":
            # get total count
            sql = DBUtils.load_query(sql_info[0], 'get_uniquevisitor_%s_total_count.sql' % tab_type)
            return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)
            total_count = return_rows[0][0]

            # get paging data
            sql = DBUtils.load_query(sql_info[0], 'get_uniquevisitor_%s.sql' % tab_type)
            paging_params = Utils.get_paging_params(total_count, cur_p, page_size)
            params.update(paging_params)
            return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)

            category = []
            device_to_mkt_name_dict = DeviceController.get_device_to_mkt_name_dict()
            for row in return_rows:
                cat_item = row[0]
                if tab_type == 'device':
                    mkt_name = device_to_mkt_name_dict.get(cat_item, "")
                    cat_item = cat_item + DeviceController.get_tab_mkt_name(mkt_name)
                category.append(cat_item)

            return dict(category=category, data=return_rows, count=len(return_rows),
                        tot_p=paging_params.get('total_page'), cur_p=int(cur_p))

    @staticmethod
    def get_tab_excel_data(cur_date, period, branch_ids, model, tab_type, data_type):
        sql_info = UniqueVisitorController.get_sql_info(data_type, period, model, tab_type)
        params = {
            "tbl_name": sql_info[1],
            "date": cur_date,
            "branch_ids": branch_ids,
            "model": model,
            "tab_type": tab_type,
            "interval_hour": '0',
            'timezone': '0',
            'limit': 'ALL',
            'offset': 0
        }

        # get paging data
        sql = DBUtils.load_query(sql_info[0], 'get_uniquevisitor_%s.sql' % tab_type)
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)

        excel_name = ExcelUtils.get_file_name('active_user_' + tab_type)
        excel_rows = ExcelUtils.convert_tab_excel_rows('tab_' + tab_type, return_rows)
        excel_data = ExcelUtils.list_to_excel(excel_name, excel_rows)

        return excel_data

    @staticmethod
    def get_sql_info(data_type, period, model, tab_type=None):
        sql_dir_dic = {'uv': 'uniquevisitor', 'uv_dvc': 'uniquevisitor/device'}
        sql_tbl_dic = {
            'uv': {'hour': 'tbl_v2_huv', 'day': 'tbl_v2_duv', 'week': 'tbl_v2_wuv', 'month': 'tbl_v2_muv'},
            'uv_dvc': {'hour': 'tbl_v2_huv_dvc', 'day': 'tbl_v2_duv_dvc', 'week': 'tbl_v2_wuv_dvc',
                       'month': 'tbl_v2_muv_dvc'},
            'ud': {'hour': 'tbl_v2_hud', 'day': 'tbl_v2_dud', 'week': 'tbl_v2_wud', 'month': 'tbl_v2_mud'},

            'v3_uv_before': {'day': 'v3b4_20190801_duv', 'week': 'v3b4_20190801_wuv', 'month': 'v3b4_20190801_muv'},
            'v3_uv_before_dvc': {'day': 'v3b4_20190801_duv_dvc', 'week': 'v3b4_20190801_wuv_dvc', 'month': 'v3b4_20190801_muv_dvc'},
            'v3_uv': {'day': 'v3_duv', 'week': 'v3_wuv', 'month': 'v3_muv'},
            'v3_uv_dvc': {'day': 'v3_duv_dvc', 'week': 'v3_wuv_dvc', 'month': 'v3_muv_dvc'},
            'v3_ud': {'day': 'tbl_v2_dud', 'week': 'tbl_v2_wud', 'month': 'tbl_v2_mud'}
        }

        if data_type is not None and 'v3' in data_type:
            if 'before' in data_type:
                if model != 'all' or tab_type == 'device':
                    sql_info = (sql_dir_dic['uv_dvc'], sql_tbl_dic['v3_uv_before_dvc'][period])
                else:
                    sql_info = (sql_dir_dic['uv'], sql_tbl_dic['v3_uv_before'][period])
            else:
                if data_type == 'v3_uv_dvc':
                    sql_info = (sql_dir_dic['uv_dvc'], sql_tbl_dic['v3_uv_dvc'][period])
                elif data_type == 'v3_uniquedevice':
                    sql_info = (sql_dir_dic['uv_dvc'], sql_tbl_dic['v3_ud'][period])
                else:
                    if model != 'all' or tab_type == 'device':
                        sql_info = (sql_dir_dic['uv_dvc'], sql_tbl_dic['v3_uv_dvc'][period])
                    else:
                        sql_info = (sql_dir_dic['uv'], sql_tbl_dic['v3_uv'][period])
        else:
            if data_type == 'ud':
                sql_info = (sql_dir_dic['uv_dvc'], sql_tbl_dic['uv_dvc'][period])
            elif data_type == 'uniquedevice':
                sql_info = (sql_dir_dic['uv_dvc'], sql_tbl_dic['ud'][period])
            else:
                if model != 'all' or tab_type == 'device':
                    sql_info = (sql_dir_dic['uv_dvc'], sql_tbl_dic['uv_dvc'][period])
                else:
                    sql_info = (sql_dir_dic['uv'], sql_tbl_dic['uv'][period])

        return sql_info

    @staticmethod
    def get_ud_start_end_date(start_date, end_date, period):
        start_date = datetime.strptime(start_date, '%Y-%m-%d')
        end_date = datetime.strptime(end_date, '%Y-%m-%d')
        yesterday = (datetime.now() - timedelta(days=1)).replace(hour=0, minute=0, second=0, microsecond=0)

        if end_date == yesterday:
            if (period == 'day') or (period == 'week' and end_date.isoweekday() == 7) or \
                    (period == 'month' and end_date.day == 1):
                end_date = end_date - timedelta(days=1)
            elif period == 'hour':
                start_date = start_date - timedelta(days=1)
                end_date = end_date - timedelta(days=1)

        return start_date.strftime('%Y-%m-%d'), end_date.strftime('%Y-%m-%d')

    @staticmethod
    def get_annotation_data(start_date, end_date, branch_name):
        sql = DBUtils.load_query('common', 'get_annotation.sql')
        params = {'start_date': start_date, 'end_date': end_date, 'branch_name': branch_name}
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)

        label_list = []
        for row in return_rows:
            date, description = row
            label_list.append({'point': date, 'text': description})

        return label_list
