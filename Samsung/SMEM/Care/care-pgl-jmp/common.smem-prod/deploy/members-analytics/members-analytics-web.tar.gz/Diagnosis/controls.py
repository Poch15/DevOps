from common.dbutils import DBUtils
from common.chart_utils import ChartUtils
from common.excel_utils import ExcelUtils
from common.params_utils import ParamsUtils
from sys import maxsize
from common.branch_utils import BranchUtils
from Device.controls import DeviceController


class DiagnosisController:
    __BATTERY_RESULT = {0: 'Bad', 1: 'Weak', 2: 'Normal', 3: 'Good'}
    __TOTAL_RESULT = {0: 'Bad', 1: 'Normal', 2: 'Good'}
    __RESULT = {0: 'Fail', 1: 'Pass'}

    __INTER_CATEGORY = {
        1: 'IRIS', 2: 'SIM', 3: 'CHARGER', 4: 'TOUCH', 5: 'BATTERY', 6: 'WI_FI',
        7: 'BLUETOOTH', 8: 'VIBRATOR', 9: 'CAMERA', 10: 'FINGERPRINT', 11: 'WIRELESS_CHARGING', 12: 'HEADPHONE',
        13: 'HEART_RATE', 14: 'SPEAKER', 15: 'BUTTON', 16: 'MIC', 17: 'SPEN'
    }

    __AUTO_CATEGORY = {
        1: 'RUNNING_APPS', 2: 'PHONE_USAGE', 3: 'SETTINGS', 4: 'SENSORS', 5: 'APPS_DEFECT', 6: 'PERFORMANCE',
        7: 'ROOTING_STATUS', 8: 'REBOOT_STATUS', 9: 'BATTERY', 10: 'MEMORY_USAGE', 11: 'NETWORK', 12: 'SOFTWARE_STATUS'
    }

    __TABLE = {1: 'v3_diagnosis_auto', 2: 'v3_diagnosis_inter', 3: 'v3_diagnosis_battery'}
    __EXCEL_NAME = {1: 'Automatic_Checks', 2: 'Interactive_Checks', 3: 'Battery'}

    @staticmethod
    def get_count_chart_data(start_date, end_date, branch_ids, model, period, type):
        sql = DBUtils.load_query('diagnosis', 'get_diagnosis_%s.sql' % period)

        if int(type) == 2:
            result_type = 'cat_id'
        else:
            result_type = 'result'
        params = {'start_date': start_date, 'end_date': end_date, 'branch_ids': branch_ids, 'model': model,
                  'tbl_name': DiagnosisController.__TABLE.get(int(type), 0), 'result_type': result_type}

        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)
        result_chart_rows = DiagnosisController.convert_result_chart_rows(return_rows, int(type))
        result_chart_data = DiagnosisController.wrap_result_chart_data(result_chart_rows)

        total_cnt = DiagnosisController.get_total_count(params)
        ret_rows = DiagnosisController.get_total_count_data(period, params)

        cumulative_rows = DiagnosisController.convert_chart_rows(ret_rows, total_cnt)

        chart_name = ("Results", "Total count")
        chart_data = ChartUtils.wrap_dual_stack_chart_data(chart_name[0], chart_name[1], result_chart_data, cumulative_rows)

        return chart_data

    @staticmethod
    def get_detail_chart_data(start_date, end_date, branch_ids, model, period, type, result):
        params = {'start_date': start_date, 'end_date': end_date, 'branch_ids': branch_ids, 'model': model}
        type_params = {'result': result}
        params.update(type_params)
        if int(type) == 1:
            sql = DBUtils.load_query('diagnosis', 'get_diagnosis_auto_detail_%s.sql' % period)
        elif int(type) == 2:
            sql = DBUtils.load_query('diagnosis', 'get_diagnosis_inter_detail_%s.sql' % period)
        else:
            sql = DBUtils.load_query('diagnosis', 'get_diagnosis_battery_detail_%s.sql' % period)
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)

        if int(type) != 3:
            detail_chart_rows = ChartUtils.convert_country_chart_rows(return_rows)
        else:
            detail_chart_rows = DiagnosisController.convert_country_chart_rows(return_rows)

        if int(type) == 1:
            chart_data = DiagnosisController.wrap_country_chart_data(detail_chart_rows)
        elif int(type) == 2:
            chart_data = ChartUtils.wrap_country_chart_data(detail_chart_rows)
        else:
            chart_data = DiagnosisController.wrap_device_chart_data(detail_chart_rows)
        return chart_data

    @staticmethod
    def convert_country_chart_rows(rows):
        model_dict = {}
        date_list = []
        statistics_dic = {}
        for return_row in rows:
            model, date, count = return_row
            if model == '':
                date_list.append(date)
            model_dict[model] = model_dict.get(model, 0) + int(count)
            statistics_dic[(model, date)] = int(count)

        return dict(model_dict=model_dict, date_list=date_list, statistics_dic=statistics_dic)

    @staticmethod
    def wrap_country_chart_data(chart_rows):
        cat_list = chart_rows['branch_list']
        date_list = chart_rows['date_list']
        statistics_dic = chart_rows['statistics_dic']

        chart_data = []
        for cat in cat_list:
            if cat != 0:
                tmp_data = []
                for _date in date_list:
                    value = statistics_dic.get((cat, _date), 0)
                    tmp_data.append(value)
                chart_data.append({"name": DiagnosisController.__AUTO_CATEGORY[cat], "data": tmp_data})

        return dict(category=date_list, data=chart_data)

    @staticmethod
    def wrap_device_chart_data(chart_rows):
        model_dict = chart_rows['model_dict']
        date_list = chart_rows['date_list']
        statistics_dic = chart_rows['statistics_dic']

        mkt_dict = dict()
        chart_data = []
        device_to_mkt_name_dict = DeviceController.get_device_to_mkt_name_dict()
        for model in model_dict.keys():
            if model != '':
                tmp_data = []
                for _date in date_list:
                    value = statistics_dic.get((model, _date), 0)
                    tmp_data.append(value)
                mkt_name = device_to_mkt_name_dict.get(model, model)
                if mkt_name not in mkt_dict:
                    mkt_dict[mkt_name] = tmp_data
                else:
                    d = mkt_dict.get(mkt_name)
                    for idx, val in enumerate(d):
                        tmp_data[idx] = tmp_data[idx] + d[idx]
                    mkt_dict[mkt_name] = tmp_data
        mkt_list = sorted(mkt_dict, key=mkt_dict.get, reverse=True)

        for mkt_name in mkt_list:
            chart_data.append({"name": mkt_name, "data": mkt_dict.get(mkt_name)})

        return dict(category=date_list, data=chart_data)

    @staticmethod
    def convert_result_chart_rows(rows, type):
        result_dict = {}
        date_list = []
        statistics_dic = {}
        if type == 3:
            for val in DiagnosisController.__BATTERY_RESULT.values():
                result_dict[val] = result_dict.get(val, 0)
        for return_row in rows:
            date, result, count = return_row
            if result == -1:
                date_list.append(date)
            else:
                if type == 1:
                    result_name = DiagnosisController.__TOTAL_RESULT[result]
                elif type == 2:
                    result_name = DiagnosisController.__INTER_CATEGORY[result]
                else:
                    result_name = DiagnosisController.__BATTERY_RESULT[result]
                result_dict[result_name] = result_dict.get(result_name, 0) + int(count)
                statistics_dic[(result_name, date)] = int(count)
        if type == 3:
            result_list = ["Good", "Normal", "Weak", "Bad"]
        else:
            result_list = sorted(result_dict, key=result_dict.get, reverse=True)

        return dict(result_list=result_list, date_list=date_list, statistics_dic=statistics_dic)

    @staticmethod
    def wrap_result_chart_data(chart_rows):
        result_list = chart_rows['result_list']
        date_list = chart_rows['date_list']
        statistics_dic = chart_rows['statistics_dic']

        chart_data = []
        for result in result_list:
            if result != -1:
                tmp_data = []
                for _date in date_list:
                    value = statistics_dic.get((result, _date), 0)
                    tmp_data.append(value)
                chart_data.append({"name": result, "data": tmp_data})

        return dict(category=date_list, data=chart_data)

    @staticmethod
    def get_total_count(params):
        sql = DBUtils.load_query('diagnosis', 'get_diagnosis_total.sql')
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)
        tot_cnt = return_rows[0][0]
        if tot_cnt is None:
            tot_cnt = 0
        return tot_cnt

    @staticmethod
    def get_total_count_data(period, params):
        sql = DBUtils.load_query('diagnosis', 'get_diagnosis_cnt_%s.sql' % period)
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)
        return return_rows

    @staticmethod
    def convert_chart_rows(rows, prev_tot_cnt):
        category = []
        row_list = []
        for row in rows:
            category.append(row[0])
            count = prev_tot_cnt + int(row[1])
            row_list.append(count)
            prev_tot_cnt = count
        convert = ChartUtils.row_to_column(row_list)

        data = {"name": "Total count", "data": convert}
        return dict(category=category, data=data)

    @staticmethod
    def get_analysis_device_data(start_date, end_date, branch_ids, model, cur_p, page_size, type):
        params = {'start_date': start_date, 'end_date': end_date, 'branch_ids': branch_ids, 'model': model,
                  'tbl_name': DiagnosisController.__TABLE.get(int(type), 0)}
        sql = DBUtils.load_query('diagnosis/analysis', 'get_analysis_device_total_count.sql')
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)
        total_count = return_rows[0][0]

        paging_params = ParamsUtils.get_paging_params(cur_p, total_count, page_size)
        params.update(paging_params)
        sql = DBUtils.load_query('diagnosis/analysis', 'get_analysis_device.sql')
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)

        category = []
        device_to_mkt_name_dict = DeviceController.get_device_to_mkt_name_dict()
        for row in return_rows:
            device, cnt, percent = row
            mkt_name = device_to_mkt_name_dict.get(device, "")
            device = device + DeviceController.get_tab_mkt_name(mkt_name)
            category.append(device)

        return dict(category=category, data=return_rows, tot_p=paging_params['total_page'], cur_p=int(cur_p))

    @staticmethod
    def get_analysis_country_data(start_date, end_date, branch_ids, model, cur_p, page_size, type):
        params = {'start_date': start_date, 'end_date': end_date, 'branch_ids': branch_ids, 'model': model,
                  'tbl_name': DiagnosisController.__TABLE.get(int(type), 0)}
        sql = DBUtils.load_query('diagnosis/analysis', 'get_analysis_country_total_count.sql')
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)
        total_count = return_rows[0][0]

        paging_params = ParamsUtils.get_paging_params(cur_p, total_count, page_size)
        params.update(paging_params)
        sql = DBUtils.load_query('diagnosis/analysis', 'get_analysis_country.sql')
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)

        category = []
        for return_row in return_rows:
            category.append(return_row[0])

        return dict(category=category, data=return_rows, tot_p=paging_params['total_page'], cur_p=int(cur_p))

    @staticmethod
    def get_analysis_category_data(start_date, end_date, branch_ids, model, cur_p, page_size, type):
        params = {'start_date': start_date, 'end_date': end_date, 'branch_ids': branch_ids, 'model': model,
                  'tbl_name': DiagnosisController.__TABLE.get(int(type), 0)}
        sql = DBUtils.load_query('diagnosis/analysis', 'get_analysis_category_total_count.sql')
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)
        total_count = return_rows[0][0]

        paging_params = ParamsUtils.get_paging_params(cur_p, total_count, page_size)
        params.update(paging_params)

        sql = DBUtils.load_query('diagnosis/analysis', 'get_analysis_category.sql')
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)

        category = []
        for row in return_rows:
            category.append(DiagnosisController.__INTER_CATEGORY[row[0]])

        return dict(category=category, data=return_rows, tot_p=1, cur_p=int(cur_p))

    @staticmethod
    def get_count_excel_data(start_date, end_date, period, branch_ids, model, type):
        sql = DBUtils.load_query('diagnosis', 'get_diagnosis_%s.sql' % period)

        if int(type) == 2:
            result_type = 'cat_id'
        else:
            result_type = 'result'
        params = {'start_date': start_date, 'end_date': end_date, 'branch_ids': branch_ids, 'model': model,
                  'tbl_name': DiagnosisController.__TABLE.get(int(type), 0), 'result_type': result_type}

        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)
        result_chart_rows = DiagnosisController.convert_result_chart_rows(return_rows, int(type))
        result_chart_data = DiagnosisController.wrap_result_chart_data(result_chart_rows)

        date_list = result_chart_data['category']
        ret_list = result_chart_data['data']
        result = []
        excel_rows = []
        header = ["Date"]

        for ret in ret_list:
            data_dict = dict()
            data_dict['name'] = ret['name']
            data_dict['data'] = ret['data']
            result.append(data_dict)

        data_list = []
        for ret in result:
            header.append(ret.get('name'))
            data_list.append(ret.get('data'))
        excel_rows.append(header)

        for j in range(len(date_list)):
            row = [date_list[j]]
            for i in range(len(data_list)):
                row.append(data_list[i][j])
            excel_rows.append(row)

        device_rows = DiagnosisController.get_device_excel_data(start_date, end_date, branch_ids, model, type)
        country_rows = DiagnosisController.get_country_excel_data(start_date, end_date, branch_ids, model, type)
        category_rows = None
        if int(type) == 2:
            category_rows = DiagnosisController.get_category_excel_data(start_date, end_date, branch_ids, model, type)

        excel_name = ExcelUtils.get_file_name(DiagnosisController.__EXCEL_NAME.get(int(type), 0))
        excel_data = ExcelUtils.multi_list_to_diagnosis_excel(excel_name,
                                                              excel_rows, device_rows, country_rows,
                                                              category_rows)

        return excel_data

    @staticmethod
    def get_count_excel_data_detail(start_date, end_date, period, branch_ids, model, type):

        detail_rows = DiagnosisController.get_detail_excel_data(start_date, end_date, branch_ids, model, period, type, 0)
        detail_2_rows = None

        if int(type) == 1:
            excel_name = ExcelUtils.get_file_name("Automatic_Checks_Detail")
        elif int(type) == 2:
            excel_name = ExcelUtils.get_file_name("Interactive_Checks_Detail")
        else:
            excel_name = ExcelUtils.get_file_name("Battery_Detail")
            detail_2_rows = DiagnosisController.get_detail_excel_data(start_date, end_date, branch_ids, model, period,
                                                                      type, 1) # weak

        excel_data = ExcelUtils.multi_list_to_diagnosis_excel_detail(excel_name, detail_rows, detail_2_rows)

        return excel_data

    @staticmethod
    def get_detail_excel_data(start_date, end_date, branch_ids, model, period, type, result):
        result_chart_data = DiagnosisController.get_detail_chart_data(start_date, end_date, branch_ids,
                                                                      model, period, type, result)
        date_list = result_chart_data['category']
        ret_list = result_chart_data['data']
        result = []
        excel_rows = []
        header = ["Date"]

        for ret in ret_list:
            data_dict = dict()
            data_dict['name'] = ret['name']
            data_dict['data'] = ret['data']
            result.append(data_dict)

        data_list = []
        for ret in result:
            header.append(ret.get('name'))
            data_list.append(ret.get('data'))
        excel_rows.append(header)

        for j in range(len(date_list)):
            row = [date_list[j]]
            for i in range(len(data_list)):
                row.append(data_list[i][j])
            excel_rows.append(row)

        return excel_rows

    @staticmethod
    def get_device_excel_data(start_date, end_date, branch_ids, model, type):

        excel_data_dict = DiagnosisController.get_analysis_device_data(start_date, end_date, branch_ids, model,
                                                                       0, maxsize, type)
        data_list = excel_data_dict['data']
        excel_header = ['Device', 'Count']
        excel_rows = [excel_header]

        device_to_mkt_name_dict = DeviceController.get_device_to_mkt_name_dict()
        for data in data_list:
            model, count, percent = data
            mkt_name = device_to_mkt_name_dict.get(model, "")
            model = model + DeviceController.get_tab_mkt_name(mkt_name)
            rows = [model, count]
            excel_rows.append(rows)

        return excel_rows

    @staticmethod
    def get_country_excel_data(start_date, end_date, branch_ids, model, type):

        excel_data_dict = DiagnosisController.get_analysis_country_data(start_date, end_date, branch_ids, model,
                                                                        0, maxsize, type)
        data_list = excel_data_dict['data']
        excel_header = ['Branch', 'Count']
        excel_rows = [excel_header]

        for data in data_list:
            branch_id, count, percent = data
            branch_dic = BranchUtils.get_all_branch_dict()
            rows = [branch_dic.get(branch_id), count]
            excel_rows.append(rows)

        return excel_rows

    @staticmethod
    def get_category_excel_data(start_date, end_date, branch_ids, model, type):

        excel_data_dict = DiagnosisController.get_analysis_category_data(start_date, end_date, branch_ids, model,
                                                                         0, maxsize, type)
        data_list = excel_data_dict['data']
        excel_header = ['Category', 'Count']
        excel_rows = [excel_header]

        for data in data_list:
            cat_id, count, percent = data
            rows = [DiagnosisController.__INTER_CATEGORY.get(cat_id), count]
            excel_rows.append(rows)

        return excel_rows
