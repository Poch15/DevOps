SELECT date as dateval, keyword_idx, sum(cnt) as count
FROM v3_keyword
  WHERE
    date >= '{start_date}'::date
  AND
    date < '{end_date}'::date + INTERVAL '1' DAY
  AND
    source = {source}
  AND
    branch_id IN {branch_ids}
  AND
    model {model}
  AND
    keyword_idx IN {keyword_idx_list}
GROUP BY dateval, keyword_idx
ORDER BY dateval