SELECT COUNT(*), SUM(count) as total_count
FROM
(
  SELECT content_id, SUM(cnt) as count, branch_id
  FROM {tbl_name}
  WHERE
    datetime >= '{start_date}'::timestamp
    AND
    datetime < '{end_date}'::timestamp + INTERVAL '1' DAY
    AND
    branch_id IN {branch_ids}
    AND
    model {model}
  GROUP BY content_id, branch_id
) AS A