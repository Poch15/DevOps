SELECT cnty_name, tz, branch_id
FROM svc_cnty
WHERE
  CASE
  WHEN {branch_id} = 1 THEN
    def_cnty = 1
  WHEN {branch_id} = 0 THEN
    def_cnty = 1 AND branch_id IN {branch_ids}
  ELSE
    def_cnty = 1 AND branch_id = {branch_id}
  END
ORDER BY cnty_name