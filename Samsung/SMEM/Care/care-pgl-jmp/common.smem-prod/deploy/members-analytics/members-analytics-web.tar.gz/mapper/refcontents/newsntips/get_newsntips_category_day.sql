SELECT date, category, SUM(cnt) AS cnt
FROM v3_newsntips_category
WHERE
date >= '{start_date}'
AND
date <= '{end_date}'
AND
branch_id IN {branch_ids}
AND
model {model}
GROUP BY date, category
ORDER BY date, category