from common.utils import Utils
from common.dbutils import DBUtils
from common.excel_utils import ExcelUtils
from common.date_utils import DateUtils
from datetime import timedelta


class KeywordController:
    @staticmethod
    def get_count_data(start_date, end_date, branch_ids, model, source, limit, offset):
        sql = DBUtils.load_query('keyword', 'get_keyword_day.sql')
        params = {'start_date': start_date, 'end_date': end_date, 'branch_ids': branch_ids, 'model': model,
                  'source': int(source), 'limit': limit, 'offset': offset}
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)
        return return_rows

    @staticmethod
    def get_chart_data(start_date, end_date, branch_ids, model, source):
        return_rows = KeywordController.get_count_data(start_date, end_date, branch_ids, model, source, 10, 0)
        category = []
        count_list = []
        total_count = 0

        keyword_idx_list = []
        for keyword_idx, _, _, _ in return_rows:
            keyword_idx_list.append(keyword_idx)

        keyword_dict = KeywordController.get_keyword_dict(keyword_idx_list)

        for row in return_rows:
            keyword_idx, count, _, _ = row
            category.append(keyword_dict[keyword_idx])
            count_list.append(count)
            total_count += count

        data = []
        for keyword, count in zip(category, count_list):
            data.append({"name": keyword, "y": round(count / total_count * 100, 2), "real_count": count})

        return dict(data=[{"name": "Keyword", "colorByPoint": True, "data": data}], count=total_count,
                    start_date=start_date, end_date=end_date)

    @staticmethod
    def get_table_data(start_date, end_date, branch_ids, model, source, cur_p, page_size):
        sql = DBUtils.load_query('keyword', 'get_keyword_total_count.sql')
        params = {'start_date': start_date, 'end_date': end_date, 'branch_ids': branch_ids, 'model': model,
                  'source': int(source), "cur_p": cur_p}

        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)
        total_count = return_rows[0][0]

        sql = DBUtils.load_query('keyword', 'get_keyword_day.sql')
        paging_params = Utils.get_paging_params(total_count, cur_p, page_size)
        params.update(paging_params)
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)

        keyword_idx_list = []
        for keyword_idx, _, _, _ in return_rows:
            keyword_idx_list.append(keyword_idx)

        keyword_dict = KeywordController.get_keyword_dict(keyword_idx_list)

        category = []
        count_list = []
        percent_list = []
        rank_list = []
        for row in return_rows:
            keyword_idx, count, percent, rank = row
            category.append(keyword_dict[keyword_idx])
            count_list.append(count)
            percent_list.append(percent)
            rank_list.append(rank)

        data = []
        for keyword, count, percent, rank in zip(category, count_list, percent_list, rank_list):
            data.append({"name": keyword, "count": count, "percent": percent, "rank": rank})

        return dict(data=data, tot_p=paging_params.get('total_page'), cur_p=int(cur_p))

    @staticmethod
    def get_table_excel_data(start_date, end_date, branch_ids, model, source):
        data_list = KeywordController.get_count_data(start_date, end_date, branch_ids, model, source,
                                                     ExcelUtils.KEYWORD_LIMIT_ROW, 0)

        keyword_idx_list = []
        for keyword, count, _, _ in data_list:
            keyword_idx_list.append(keyword)

        keyword_dict = KeywordController.get_keyword_dict(keyword_idx_list)

        excel_rows = [["Keyword", "Count"]]
        for data in data_list:
            keyword_idx, count, _, _ = data
            excel_rows.append([ExcelUtils.remove_escape_string(keyword_dict[keyword_idx]), count])

        file_name = ExcelUtils.get_file_name('keyword')
        excel_data = ExcelUtils.list_to_excel(file_name, excel_rows)
        return excel_data

    @staticmethod
    def get_trend_data(start_date, end_date, branch_ids, model, period, source):
        return_rows = KeywordController.get_count_data(start_date, end_date, branch_ids, model, source, 10, 0)
        keyword_idx_list = []
        for keyword, count, _, _ in return_rows:
            keyword_idx_list.append(keyword)

        sql = DBUtils.load_query('keyword', 'get_keyword_trend_%s.sql' % period)
        params = {'start_date': start_date, 'end_date': end_date, 'branch_ids': branch_ids, 'model': model,
                  'keyword_idx_list': tuple(keyword_idx_list), 'source': int(source)}
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)

        keyword_dict = KeywordController.get_keyword_dict(keyword_idx_list)
        keyword_list = []
        for keyword_idx in keyword_idx_list:
            keyword_list.append(keyword_dict[keyword_idx])

        statistics_dic = {}
        date_set = set()
        for row in return_rows:
            date, keyword, count = row
            date_set.add(date)
            statistics_dic[(keyword_dict[keyword], date)] = int(count)

        date_list = list(date_set)
        date_list.sort(key=DateUtils.get_date_sort_key(period))

        return dict(keyword_list=keyword_list, statistics_dic=statistics_dic, date_list=date_list)

    @staticmethod
    def get_trend_chart_data(start_date, end_date, branch_ids, model, period, source):
        return_dict = KeywordController.get_trend_data(start_date, end_date, branch_ids, model, period, source)
        keyword_list = return_dict['keyword_list']
        statistics_dic = return_dict['statistics_dic']
        date_list = return_dict['date_list']

        chart_data = []
        for keyword in keyword_list:
            tmp_data = []
            for date in date_list:
                value = statistics_dic.get((keyword, date), 0)
                tmp_data.append(value)
            chart_data.append({"name": keyword, "data": tmp_data})

        return dict(category=date_list, data=chart_data)

    @staticmethod
    def get_dashboard_chart_data(start_date, end_date, branch_name, source, period):
        keyword_rank_sql = DBUtils.load_query('keyword', 'get_dashboard_keyword_rank.sql')
        params = {
            'branch_name': branch_name,
            'source': source,
            'limit': 10,
            'period': period
        }

        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, keyword_rank_sql, params)

        keyword_list = []
        for row in return_rows:
            keyword_list.append(row[0])

        count_sql = DBUtils.load_query('keyword', 'get_dashboard_keyword_trend_day.sql')
        params = {
            'start_date': start_date,
            'end_date': end_date,
            'branch_name': branch_name,
            'source': source,
            'period': period
        }

        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, count_sql, params)

        statistics_dic = {}
        date_set = set()
        for row in return_rows:
            date, keyword, count = row
            date_set.add(date)
            statistics_dic[(keyword, date)] = int(count)

        date_list = list(date_set)
        date_list.sort()

        chart_data = []
        for keyword in keyword_list:
            tmp_data = []
            for date in date_list:
                value = statistics_dic.get((keyword, date), 0)
                tmp_data.append(value)

            chart_data.append({"name": keyword, "data": tmp_data})

        if period == "week":
            week_list = []
            for d in date_list:
                d += timedelta(days=1)

                week = str(d.isocalendar()[1])
                year = str(d.isocalendar()[0])

                week_list.append('{} {}W'.format(year, week))

            date_list = week_list

        return dict(category=date_list, data=chart_data)

    @staticmethod
    def get_keyword_cloud_data(start_date, end_date, branch_ids, model, source):
        params = {'start_date': start_date, 'end_date': end_date, 'branch_ids': branch_ids, 'model': model,
                  'source': source}

        sql = DBUtils.load_query('keyword/search', 'search_keyword_list.sql')
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)

        keyword_idx_list = list()
        for keyword_idx, _ in return_rows:
            keyword_idx_list.append(keyword_idx)

        keyword_dict = KeywordController.get_keyword_dict(keyword_idx_list)

        result_list = list()
        for keyword_idx, cnt in return_rows:
            result_list.append({"name": keyword_dict[keyword_idx], "weight": cnt})

        return dict(data=result_list)

    @staticmethod
    def get_dashboard_keyword_cloud_data(branch_name, source, period):
        keyword_rank_sql = DBUtils.load_query('keyword', 'get_dashboard_keyword_rank.sql')
        params = {
            'branch_name': branch_name,
            'source': source,
            'limit': 100,
            'period': period
        }

        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, keyword_rank_sql, params)

        result_list = list()
        for keyword, cnt in return_rows:
            result_list.append({"name": keyword, "weight": cnt})

        return dict(data=result_list)

    @staticmethod
    def get_keyword_dict(keyword_idx_list):
        sql = DBUtils.load_query('keyword', 'keyword_dict_list.sql')
        params = {'keyword_idx_list': tuple(keyword_idx_list)}
        keyword_dict_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)

        keyword_dict = dict()
        for keyword_idx, keyword in keyword_dict_rows:
            keyword_dict[keyword_idx] = keyword

        return keyword_dict

    @staticmethod
    def get_keyword_excel(start_date, end_date, branch_ids, model, source, period):
        sql = DBUtils.load_query('keyword', 'keyword_excel_%s.sql' % period)
        params = {'start_date': start_date,
                  'end_date': end_date,
                  'branch_ids': branch_ids,
                  'model': model,
                  'source': source
                  }

        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)

        file_name = ExcelUtils.get_file_name('keyword')
        excel_data = ExcelUtils.keyword_excel(file_name, return_rows, period)

        return excel_data
