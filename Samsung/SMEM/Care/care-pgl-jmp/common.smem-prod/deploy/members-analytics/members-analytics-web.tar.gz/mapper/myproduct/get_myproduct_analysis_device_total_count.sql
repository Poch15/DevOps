SELECT COUNT(*)
FROM
(
  SELECT model
  FROM v3_myproduct_summary
  WHERE
    datetime >= '{start_date}'::timestamp
    AND
    datetime < '{end_date}'::timestamp + INTERVAL '1' DAY
    AND
    req_type = {request_type}
    AND
    branch_id IN {branch_ids}
  GROUP BY model
) AS A