SELECT count(*)
FROM
(
  SELECT company_cd, SUM(cnt) AS count, ROUND(SUM(cnt) / SUM(SUM(cnt)) OVER() * 100.0, 2) AS percent
  FROM v3_mp_product
  WHERE
	    date >= '{start_date}'::timestamp
  AND
	    date < '{end_date}'::timestamp  + INTERVAL '1' DAY
  AND
      company_cd IN {company_codes}
  GROUP BY company_cd
) AS A