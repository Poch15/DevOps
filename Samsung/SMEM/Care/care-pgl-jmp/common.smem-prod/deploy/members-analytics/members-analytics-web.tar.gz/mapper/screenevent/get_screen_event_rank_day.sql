SELECT A.screen_id, COALESCE(P.screen_name, A.screen_id) as page_name, A.event_id,
 COALESCE(E.event_name, A.event_id) AS event_name, A.cnt, A.percent, P.app_type, P.ux_version
FROM
(
  SELECT screen_id, event_id, sum(cnt) as cnt, ROUND(SUM(cnt) / SUM(SUM(cnt)) OVER() * 100.0, 2) AS percent
  FROM v3_screen_event
  WHERE
      date >= '{start_date}'
  AND
      date <= '{end_date}'
  AND
    CASE
        WHEN '{page_id}' = ''
             THEN branch_id IN {branch_ids}
        ELSE
             branch_id IN {branch_ids} AND screen_id = '{page_id}'
    END
  GROUP BY screen_id, event_id
) AS A
LEFT JOIN tbl_v2_screen_pv_info P
ON A.screen_id = P.screen_id
LEFT JOIN tbl_v2_screen_event_info E
ON A.event_id = E.event_target_id AND A.screen_id = E.screen_id
ORDER BY cnt desc
LIMIT {limit} OFFSET {offset}