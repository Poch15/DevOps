SELECT id, keyword
FROM v3_keyword_dict
WHERE id IN {keyword_idx_list}