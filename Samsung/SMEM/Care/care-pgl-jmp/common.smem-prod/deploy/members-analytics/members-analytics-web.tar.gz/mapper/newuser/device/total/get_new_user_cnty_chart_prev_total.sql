SELECT branch_id, sum(cnt)
FROM {tbl_name}
WHERE
  datetime < '{start_date}'::timestamp - INTERVAL '{interval_hour}' HOUR
AND
  branch_id IN {branch_ids}
AND
  model {model}
GROUP BY branch_id
ORDER BY branch_id