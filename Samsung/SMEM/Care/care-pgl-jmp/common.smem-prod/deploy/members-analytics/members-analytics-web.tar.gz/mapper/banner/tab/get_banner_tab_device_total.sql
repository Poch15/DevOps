SELECT COUNT(*)
FROM
(
  SELECT model
  FROM v3_banner
  WHERE
    date >= '{start_date}'
    AND
    DATE <= '{end_date}'
    AND
    branch_id IN {branch_ids}
    AND
		CASE
    WHEN '{banner_id}' = '0' THEN
      model {model}
    ELSE
      model {model} AND banner_id = '{banner_id}'
    END
  GROUP BY model
) AS A