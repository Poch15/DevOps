SELECT
    type,
    CASE WHEN monthval < 10 THEN yearval || '/0' || monthval
			   ELSE yearval || '/' || monthval
		END as yearmonth,
		sumval
FROM
(
	SELECT type, extract(year from dateval) as yearval, extract(month from dateval) as monthval, sum(count) as sumval
	FROM
	(
	  (
      SELECT 'Total screen views' as type, date as dateval, sum(cnt) as count
      FROM v3_more_svc
        WHERE
            date >= '{start_date}'::date
          AND
            date < '{end_date}'::date + INTERVAL '1' DAY
          AND
            branch_id IN {branch_ids}
          AND
            model {model}
      GROUP BY dateval
      ORDER BY dateval
    ) UNION ALL
    (
      SELECT 'Total clicks' as type, date as dateval, sum(cnt) as count
      FROM v3_more_svc_event
        WHERE
            date >= '{start_date}'::date
          AND
            date < '{end_date}'::date + INTERVAL '1' DAY
          AND
            branch_id IN {branch_ids}
          AND
            model {model}
      GROUP BY dateval
      ORDER BY dateval
    )
	) AS A
	GROUP BY type, yearval, monthval
	ORDER BY type, yearval, monthval
) AS B