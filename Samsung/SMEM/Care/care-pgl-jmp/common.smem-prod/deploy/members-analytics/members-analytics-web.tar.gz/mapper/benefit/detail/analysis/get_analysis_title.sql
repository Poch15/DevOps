SELECT benefit_id, coupon_id, type, branch_id, SUM(cnt) as count, ROUND(SUM(cnt) / SUM(SUM(cnt)) OVER() * 100.0, 2) AS percent
FROM {tbl_name}
  WHERE
    date >= '{start_date}'
  AND
    date <= '{end_date}'
  AND
    timezone = {timezone}
  AND
    branch_id IN {branch_ids}
	AND
    type IN {event_types}
  AND
    CASE
      WHEN '{event_type}' = '5' THEN
        model {model} AND coupon_id = '{coupon_id}'
      WHEN '{event_type}' = '0' THEN
        model {model} AND (benefit_id != '' OR coupon_id != '')
      ELSE
        model {model} AND benefit_id = '{benefit_id}'
    END
GROUP BY benefit_id, coupon_id, type, branch_id
ORDER BY count desc
LIMIT {limit} OFFSET {offset}