SELECT count(*) OVER()
FROM
  (
    SELECT keyword_idx, cnt
    FROM v3_keyword
      WHERE
        date >= '{start_date}'::date
      AND
        date < '{end_date}'::date + INTERVAL '1' DAY
      AND
        source = {source}
      AND
        branch_id IN {branch_ids}
      AND
        model {model}
  ) AS A
GROUP BY keyword_idx
ORDER BY COUNT DESC, keyword_idx
LIMIT 1