SELECT COUNT(*), SUM(imp_cnt) AS tot_imp_cnt, SUM(click_cnt) AS tot_click_cnt
FROM
(
    SELECT banner_id, branch_id, SUM(imp_cnt) as imp_cnt, SUM(click_cnt) as click_cnt
    FROM v3_banner
    WHERE
        date >= '{start_date}'
        AND
        date <= '{end_date}'
        AND
        branch_id IN {branch_ids}
        AND
        model {model}
    GROUP BY banner_id, branch_id
) AS A