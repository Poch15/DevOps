SELECT EXTRACT(isoyear FROM timestamp_with_timezone) || '-' || EXTRACT(week FROM timestamp_with_timezone) || 'W' AS yearweek,
	SUM(battery_cnt)  battery_cnt,
	SUM(application_cnt) application_cnt,
	SUM(system_cnt) system_cnt,
	SUM(pc_cnt) pc_cnt,
	SUM(camera_cnt) camera_cnt,
	SUM(call_cnt) call_cnt,
	SUM(accessory_cnt) accessory_cnt,
	SUM(sensor_cnt) sensor_cnt,
	SUM(network_cnt) network_cnt
FROM
	(
    SELECT distinct (to_timestamp(date||' '||hour,'YYYY-MM-DD HH24') + INTERVAL '1' DAY + INTERVAL '{interval_hour}' HOUR)::timestamp as timestamp_with_timezone,
        model, cnty, lang, branch_id,
        battery_cnt, application_cnt, system_cnt, pc_cnt,
        camera_cnt, call_cnt, accessory_cnt, sensor_cnt, network_cnt
    FROM tbl_category_day
    WHERE
      (to_timestamp(date||' '|| hour,'YYYY-MM-DD HH24') + INTERVAL '{interval_hour}' HOUR)::date
      BETWEEN '{start_date}' AND '{end_date}'
      AND
       branch_id IN {branch_ids}
      AND
       model like '{model}%'
  ) AS A
GROUP BY EXTRACT(isoyear FROM timestamp_with_timezone), EXTRACT(week FROM timestamp_with_timezone)
ORDER BY EXTRACT(isoyear FROM timestamp_with_timezone), EXTRACT(week FROM timestamp_with_timezone)