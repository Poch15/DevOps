from django.shortcuts import render_to_response
from django.template.context import RequestContext
from django.views.decorators.http import require_http_methods
from django.http import JsonResponse
from common.utils import custom_login_required, access_log
from common.exception_handler import ExceptionHandler
from SessionManager.controls import SessionManagerController
from common.params_utils import ParamsUtils
from Banner.controls import BannerController


@ExceptionHandler(return_type=ExceptionHandler.RETURN_JSON)
@custom_login_required
@require_http_methods(["GET"])
@access_log
def view_banner(request):
    template = 'banner/banner_detail.html'
    return render_to_response(template, context_instance=RequestContext(request))


@custom_login_required
@require_http_methods(["GET"])
def get_chart_data(request):
    try:
        return JsonResponse(BannerController.get_chart_data(
            start_date=ParamsUtils.get_param(request, "start_date"),
            end_date=ParamsUtils.get_param(request, "end_date"),
            period=ParamsUtils.get_param(request, "period"),
            model=ParamsUtils.get_param(request, "query_model"),
            branch_ids=SessionManagerController.get_selected_branch_ids(request),
            banner_id=ParamsUtils.get_param(request, "banner_id")
        ))
    except Exception as e:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})


@custom_login_required
@require_http_methods(["GET"])
def get_tab_title_data(request):
    try:
        return JsonResponse(BannerController.get_tab_title_data(
            start_date=ParamsUtils.get_param(request, "start_date"),
            end_date=ParamsUtils.get_param(request, "end_date"),
            branch_ids=SessionManagerController.get_selected_branch_ids(request),
            model=ParamsUtils.get_param(request, "query_model"),
            cur_p=ParamsUtils.get_param(request, "cur_p"),
            page_size=int(ParamsUtils.get_param(request, "page_size")),
            order_type=ParamsUtils.get_param(request, "order_type")
        ))
    except Exception as e:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})


@custom_login_required
@require_http_methods(["GET"])
def get_tab_device_data(request):
    try:
        return JsonResponse(BannerController.get_tab_device_data(
            start_date=ParamsUtils.get_param(request, "start_date"),
            end_date=ParamsUtils.get_param(request, "end_date"),
            branch_ids=SessionManagerController.get_selected_branch_ids(request),
            model=ParamsUtils.get_param(request, "query_model"),
            banner_id=ParamsUtils.get_param(request, "banner_id"),
            cur_p=ParamsUtils.get_param(request, "cur_p"),
            page_size=int(ParamsUtils.get_param(request, "page_size"))
        ))
    except Exception as e:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})


@custom_login_required
@require_http_methods(["GET"])
def export_excel(request):
    try:
        excel_count_data = BannerController.get_excel_data(
            start_date=ParamsUtils.get_param(request, "start_date"),
            end_date=ParamsUtils.get_param(request, "end_date"),
            period=ParamsUtils.get_param(request, "period"),
            branch_ids=SessionManagerController.get_selected_branch_ids(request),
            model=ParamsUtils.get_param(request, "query_model"),
            banner_id=ParamsUtils.get_param(request, "banner_id")
        )
        return excel_count_data
    except Exception as e:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})