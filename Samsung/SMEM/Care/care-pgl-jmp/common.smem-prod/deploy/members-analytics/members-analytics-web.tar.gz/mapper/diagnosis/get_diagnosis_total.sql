SELECT sum(cnt) as total_cnt
FROM {tbl_name}
WHERE
  datetime < '{start_date}'
AND
  model {model}
AND
  branch_id IN {branch_ids}