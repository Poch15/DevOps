SELECT count(*)
FROM
(
  SELECT page_grp_id
  FROM {tbl_name}
  WHERE
      date = '{date}'::timestamp
    AND
      branch_id IN {branch_ids}
    AND
      page_grp_id IN (SELECT id FROM v3_unique_pv_info WHERE is_use = true)
  GROUP BY page_grp_id
) AS A