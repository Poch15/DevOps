SELECT article_id, title
FROM article
WHERE
article_id IN {ids}