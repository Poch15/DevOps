SELECT cat_id, cat_name, prd_category
FROM faq_v2_cat_node
WHERE
  cat_level = 0
AND
  prd_category in (1,3)
ORDER BY cat_id;