from django.http import JsonResponse
from django.shortcuts import render_to_response
from django.template.context import RequestContext
from django.views.decorators.http import require_http_methods
from NewUser.controls import NewUserController
from common.utils import custom_login_required, access_log
from common.params_utils import ParamsUtils
from SessionManager.controls import SessionManagerController
from common.exception_handler import ExceptionHandler


@ExceptionHandler(return_type=ExceptionHandler.RETURN_HTTP)
@custom_login_required
@require_http_methods(["GET"])
@access_log
def view_newuser(request):
    data_type = ParamsUtils.get_param(request, "data_type")
    if data_type is not None and data_type == 'v3_user_before':
        template = 'user/v3_newuser_before.html'
    elif data_type is not None and 'v3' in data_type:
        template = 'user/v3_newuser.html'
    else:
        template = 'user/newuser.html'
    return render_to_response(template, context_instance=RequestContext(request))


@custom_login_required
@require_http_methods(["GET"])
def get_count_chart_data(request):
    try:
        count_chart_data = NewUserController.get_count_chart_data(
            start_date=ParamsUtils.get_param(request, "start_date"),
            end_date=ParamsUtils.get_param(request, "end_date"),
            period=ParamsUtils.get_param(request, "period"),
            branch_ids=SessionManagerController.get_selected_branch_ids(request),
            model=ParamsUtils.get_param(request, "query_model"),
            interval_hour=SessionManagerController.get_selected_time_zone(request),
            data_type=ParamsUtils.get_param(request, "data_type")
        )
        return JsonResponse(count_chart_data)
    except Exception as e:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})


@custom_login_required
@require_http_methods(["GET"])
def get_count_excel_data(request):
    try:
        count_excel_data = NewUserController.get_count_excel_data(
            start_date=ParamsUtils.get_param(request, "start_date"),
            end_date=ParamsUtils.get_param(request, "end_date"),
            period=ParamsUtils.get_param(request, "period"),
            branch_ids=SessionManagerController.get_selected_branch_ids(request),
            model=ParamsUtils.get_param(request, "query_model"),
            interval_hour=SessionManagerController.get_selected_time_zone(request),
            data_type=ParamsUtils.get_param(request, "data_type")
        )
        return count_excel_data
    except Exception as e:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})


@custom_login_required
@require_http_methods(["GET"])
def get_cnty_data(request):
    try:
        cnty_chart_data = NewUserController.get_cnty_chart_data(
            start_date=ParamsUtils.get_param(request, "start_date"),
            end_date=ParamsUtils.get_param(request, "end_date"),
            period=ParamsUtils.get_param(request, "period"),
            branch_ids=SessionManagerController.get_selected_branch_ids(request),
            model=ParamsUtils.get_param(request, "query_model"),
            interval_hour=SessionManagerController.get_selected_time_zone(request),
            data_type=ParamsUtils.get_param(request, "data_type")
        )
        return JsonResponse(cnty_chart_data)
    except Exception as e:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})


@custom_login_required
@require_http_methods(["GET"])
def get_cnty_percentage_data(request):
    try:
        cnty_percentage_data = NewUserController.get_cnty_percentage_chart_data(
            start_date=ParamsUtils.get_param(request, "start_date"),
            end_date=ParamsUtils.get_param(request, "end_date"),
            branch_ids=SessionManagerController.get_selected_branch_ids(request),
            model=ParamsUtils.get_param(request, "query_model"),
            interval_hour=SessionManagerController.get_selected_time_zone(request),
            data_type=ParamsUtils.get_param(request, "data_type")
        )
        return JsonResponse(cnty_percentage_data)
    except Exception as e:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})


@custom_login_required
@require_http_methods(["GET"])
def export_excel_by_cnty(request):
    try:
        return NewUserController.get_cnty_excel_data(
            start_date=ParamsUtils.get_param(request, "start_date"),
            end_date=ParamsUtils.get_param(request, "end_date"),
            period=ParamsUtils.get_param(request, "period"),
            branch_ids=SessionManagerController.get_selected_branch_ids(request),
            model=ParamsUtils.get_param(request, "query_model"),
            interval_hour=SessionManagerController.get_selected_time_zone(request),
            data_type=ParamsUtils.get_param(request, "data_type")
        )

    except Exception as e:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})


@custom_login_required
@require_http_methods(["GET"])
def get_tab_count_data(request):
    try:
        tab_count_data = NewUserController.get_tab_count_data(
            start_date=ParamsUtils.get_param(request, "start_date"),
            end_date=ParamsUtils.get_param(request, "end_date"),
            branch_ids=SessionManagerController.get_selected_branch_ids(request),
            model=ParamsUtils.get_param(request, "query_model"),
            interval_hour=SessionManagerController.get_selected_time_zone(request),
            tab_type=ParamsUtils.get_param(request, "tab_type"),
            cur_p=ParamsUtils.get_param(request, "cur_p"),
            page_size=int(ParamsUtils.get_param(request, "page_size")),
            data_type=ParamsUtils.get_param(request, "data_type")
        )
        return JsonResponse(tab_count_data)

    except Exception as e:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})


@ExceptionHandler(return_type=ExceptionHandler.RETURN_HTTP)
@custom_login_required
@require_http_methods(["GET"])
def get_tab_excel_data(request):
    try:
        tab_excel_data = NewUserController.get_tab_excel_data(
            start_date=ParamsUtils.get_param(request, "start_date"),
            end_date=ParamsUtils.get_param(request, "end_date"),
            branch_ids=SessionManagerController.get_selected_branch_ids(request),
            model=ParamsUtils.get_param(request, "query_model"),
            tab_type=ParamsUtils.get_param(request, "tab_type"),
            data_type=ParamsUtils.get_param(request, "data_type")
        )

        return tab_excel_data
    except Exception as e:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})
