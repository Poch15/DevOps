from Branch.controls import BranchController
from common.models import Branch
from operator import itemgetter
from common.branch_utils import BranchUtils


class SessionManagerController:
    @staticmethod
    def get_selected_branch_ids(request):
        return request.session.get('selected_branch_ids')

    @staticmethod
    def change_selected_branch(request, branch_ids, branch_name, start_dt, end_dt, period, model):
        request.session['filter_start_dt'] = start_dt
        request.session['filter_end_dt'] = end_dt
        request.session['filter_period'] = period
        request.session['filter_model'] = model

        if branch_ids == '1':
            request.session['selected_branch_id'] = int(branch_ids)
            request.session['selected_branch_ids'] = SessionManagerController.get_all_branch_ids(request)
            request.session['selected_branch_name'] = 'All'
        elif branch_ids == 'region':
            request.session['selected_branch_id'] = branch_ids
            request.session['selected_branch_ids'] = list(BranchUtils.get_region_branch_dict(branch_name).keys())
            request.session['selected_branch_name'] = branch_name
        else:
            branch_list = [branch_ids]
            request.session['selected_branch_id'] = int(branch_ids)
            request.session['selected_branch_ids'] = branch_list
            request.session['selected_branch_name'] = branch_name

    @staticmethod
    def save_selected_filter_value(request, start_dt, end_dt, period, model):
        request.session['filter_start_dt'] = start_dt
        request.session['filter_end_dt'] = end_dt
        request.session['filter_period'] = period
        request.session['filter_model'] = model

    @staticmethod
    def get_branch_node_list(request):
        return_data = {}
        if request.session.get('selected_region') == 'HQ':
            branch_list = SessionManagerController.get_all_branch(request)
            for branch in branch_list:
                return_data[branch[0]] = branch[1]  # { branch_id : branch_name }
            return_data[1] = 'HQ'
        elif request.session.get('region') == 'local':
            return_data[request.session.get('branch_id')] = request.session.get('branch_name')
        else:
            return_data = BranchUtils.get_region_branch_dict(request.session.get('selected_region'))
            return_data['region'] = request.session.get('selected_region')
        return return_data

    @staticmethod
    def has_china_branch(request):
        if '3' in request.session['selected_branch_ids']:
            return True
        else:
            return False

    @staticmethod
    def get_selected_branch_name(request):
        return request.session.get('selected_branch_name')

    @staticmethod
    def get_selected_time_zone(request):
        interval_hour = str(request.session.get('selected_time_zone'))
        if interval_hour == '':
            interval_hour = '0'

        return interval_hour

    @staticmethod
    def change_timezone(request, interval_hour):
        request.session['selected_time_zone'] = interval_hour

    @staticmethod
    def init_login_session(request, response):
        if response.get('countryCode') == 'HQ':
            request.session['branch_id'] = '1'
            request.session['branch_name'] = 'HQ'
            request.session['region'] = 'HQ'
        elif 'region' in response:
            request.session['branch_id'] = 'region'
            request.session['branch_name'] = response.get('region')
            request.session['region'] = response.get('region')
        else:
            request.session['branch_id'] = response.get('branchId')
            request.session['branch_name'] = Branch.objects.using("mysql").get(branch_id=int(response.get('branchId'))).branch_name
            request.session['region'] = 'local'

        request.session['login_email'] = response.get('email')
        request.session['login_branch_id'] = response.get('branchId')
        request.session['login_country_code'] = response.get('countryCode')
        request.session['login_region'] = response.get('region')

        SessionManagerController.change_selected_region(request, request.session['region'])
        SessionManagerController.change_selected_branch(request, request.session['branch_id'], request.session['branch_name'], None, None, 'day', None)
        request.session['selected_time_zone'] = BranchUtils.get_default_timezone(response.get('branchId'))

    @staticmethod
    def get_sorted_branch_key_list(request, branch_list):
        sorted_branch_list = sorted(branch_list.items(), key=itemgetter(1))
        sorted_branch_key_list = []

        for key, value in sorted_branch_list:
            sorted_branch_key_list.append(key)

        if request.session.get('selected_region') == 'HQ':
            sorted_branch_key_list.remove(1)
            sorted_branch_key_list.insert(0, 1)
        elif request.session.get('selected_region') != 'local' and request.session.get('region') != 'local':
            sorted_branch_key_list.remove('region')
            sorted_branch_key_list.insert(0, 'region')

        return sorted_branch_key_list

    @staticmethod
    def get_selected_branch_id(request):
        return request.session.get('selected_branch_id')

    @staticmethod
    def change_selected_region(request, region):
        request.session['selected_region'] = region
        if region == 'HQ':
            SessionManagerController.change_selected_branch(request, '1', 'HQ', None, None, 'day', None)
        elif region != 'local':
            SessionManagerController.change_selected_branch(request, 'region', region, None, None, 'day', None)
        else:
            request.session['selected_region'] = Branch.objects.using("mysql").get(
                branch_id=int(request.session.get('branch_id'))).region

    @staticmethod
    def get_region_list(request):
        if request.session.get('region') == 'HQ':
            return_data = SessionManagerController.get_all_region(request)
        elif request.session.get('region') != 'local':
            return_data = request.session.get('region')
        else:
            return_data = Branch.objects.using("mysql").get(branch_id=int(request.session.get('branch_id'))).region
        return return_data

    @staticmethod
    def get_selected_region(request):
        return request.session.get("selected_region")

    @staticmethod
    def get_region(request):
        return request.session.get("region")

    @staticmethod
    def get_all_region(request):
        if 'all_region' in request.session:
            return_data = request.session.get('all_region')
        else:
            return_data = BranchController.get_all_region()
            request.session['all_region'] = return_data
        return return_data

    @staticmethod
    def get_all_branch_ids(request):
        if 'all_branch_ids' in request.session:
            return_data = request.session.get('all_branch_ids')
        else:
            return_data = BranchController.get_all_branch_ids()
            request.session['all_branch_ids'] = return_data
        return return_data

    @staticmethod
    def get_all_branch(request):
        if 'all_branch' in request.session:
            return_data = request.session.get('all_branch')
        else:
            return_data = BranchController.get_all_branch()
            request.session['all_branch'] = return_data
        return return_data
