SELECT count(*)
FROM
(
  SELECT category
  FROM v3_myproduct_summary
  WHERE
    datetime >= '{start_date}'::timestamp
  AND
    datetime < '{end_date}'::timestamp + INTERVAL '1' DAY
  AND
    branch_id IN {branch_ids}
  AND
    req_type  = {request_type}
  GROUP BY category
) AS A