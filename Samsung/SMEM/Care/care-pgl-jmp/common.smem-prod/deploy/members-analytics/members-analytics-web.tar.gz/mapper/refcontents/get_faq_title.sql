SELECT faq_id, title, cat_id, cat_id as parent_id
FROM faq
WHERE
faq_id IN {ids}
UNION ALL
SELECT faq_id, title, f.cat_id, parent_id
FROM faq_v2 f JOIN faq_v2_cat_node c
ON f.cat_id = c.cat_id
WHERE
faq_id IN {ids}