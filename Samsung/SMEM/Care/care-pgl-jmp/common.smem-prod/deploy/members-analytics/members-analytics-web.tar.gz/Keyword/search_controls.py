from common.dbutils import DBUtils
from common.date_utils import DateUtils
import pandas as pd
import numpy as np
from common.chart_utils import ChartUtils


class SearchController:
    SOURCE_TYPE = {
        0: 'Samsung Members',
        1: 'SFinder'
    }

    CONTENTS_TYPE = {
        1: "Notice",
        2: "News&Tips",
        3: "FAQ",
        4: "Community",
        5: "Benefit",
        6: "Coupon",
        7: "User"
    }

    @staticmethod
    def get_trend(start_date, end_date, branch_ids, model, period):
        date_list = DateUtils.create_date_list(start_date, end_date, period)
        date_df = pd.DataFrame(date_list, columns=['date'])
        date_df.date = date_df.date.astype(str)

        params = {'start_date': start_date, 'end_date': end_date, 'branch_ids': branch_ids, 'model': model}
        return_rows = DBUtils.execute_query(
            DBUtils.CONFIG_POSTGRESQL,
            DBUtils.load_query('keyword/search', 'search_trend_%s.sql' % period),
            params)

        df = pd.DataFrame(return_rows, columns=['date', 'source', 'cnt'])

        result_list = list()
        source_list = df['source'].unique()
        for source in source_list:
            temp_df_list = df[df['source'] == source]
            temp_df = temp_df_list[['date', 'cnt']]
            temp_df['date'] = temp_df['date'].astype(str)

            df2 = pd.merge(date_df, temp_df, how='outer', on='date').fillna(0)
            df2['cnt'] = df2['cnt'].astype(int)
            temp_list = df2['cnt'].tolist()

            result_list.append({"name": SearchController.SOURCE_TYPE[source], "data": temp_list})

        ratio_list = []
        if len(result_list) > 0:
            for members_cnt, finder_cnt in zip(result_list[0]['data'], result_list[1]['data']):
                total = members_cnt + finder_cnt
                ratio = members_cnt / total if total != 0 else 0
                ratio_list.append("{0:.2f}".format(ratio * 100))

        summary_list = [
            {"name": "Samsung Members Ratio", "data": ratio_list}
        ]

        return dict(category=date_list, data=result_list, table=summary_list)

    @staticmethod
    def get_click_trend(start_date, end_date, branch_ids, model, period):
        date_list = DateUtils.create_date_list(start_date, end_date, period)
        date_df = pd.DataFrame(date_list, columns=['date'])
        date_df.date = date_df.date.astype(str)

        # total_trend_df
        params = {'start_date': start_date, 'end_date': end_date, 'branch_ids': branch_ids, 'model': model}

        return_rows = DBUtils.execute_query(
            DBUtils.CONFIG_POSTGRESQL,
            DBUtils.load_query('keyword/search', 'search_total_trend_%s.sql' % period),
            params)

        total_trend_df = pd.DataFrame(return_rows, columns=['date', 'total_cnt'])
        total_trend_df.date = total_trend_df.date.astype(str)

        # click_trend_df
        sql = DBUtils.load_query('keyword/search', 'search_click_trend_%s.sql' % period)
        return_rows = DBUtils.execute_query(
            DBUtils.CONFIG_POSTGRESQL,
            sql,
            params)

        click_trend_df = pd.DataFrame(return_rows, columns=['date', 'click_cnt'])
        click_trend_df.date = click_trend_df.date.astype(str)

        # merge date_df, total_trend_df and click_trend_df
        m1_df = pd.merge(date_df, total_trend_df, how='outer', on='date').fillna(0)
        m2_df = pd.merge(m1_df, click_trend_df, how='outer', on='date').fillna(0)

        m2_df.total_cnt = m2_df.total_cnt.astype(int)
        m2_df.click_cnt = m2_df.click_cnt.astype(int)

        result_list = list()
        result_list.append({"name": "samsung members search", "data": m2_df.total_cnt.tolist()})
        result_list.append({"name": "contents click", "data": m2_df.click_cnt.tolist()})

        m2_df['ratio'] = m2_df.click_cnt / m2_df.total_cnt
        m2_df = m2_df.replace([np.inf, -np.inf], 0)
        m2_df = m2_df.replace(np.nan, 0)

        ratio_list = list()
        for value in m2_df.ratio.values:
            val = float(format(round(value, 3) * 100, ".2f"))
            ratio_list.append(val)

        count_chart = {
            "category": date_list,
            "data": result_list
        }
        ratio_chart = {
            "data": [
                {"name": "Click Ratio (%)", "data": ratio_list}
            ]
        }

        chart_data = ChartUtils.wrap_dual_stack_chart_data("Count", "Click Ratio (%)", count_chart, ratio_chart)
        return chart_data

    @staticmethod
    def get_click_ratio(start_date, end_date, branch_ids, model, period):
        params = {'start_date': start_date, 'end_date': end_date, 'branch_ids': branch_ids, 'model': model}

        sql = DBUtils.load_query('keyword/search', 'search_click_trend_by_contents_%s.sql' % period)
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)
        df = pd.DataFrame(return_rows, columns=['date', 'type', 'cnt'])
        search_type_list = df.groupby('type').sum().sort_values(by='cnt', ascending=True).index

        date_list = DateUtils.create_date_list(start_date, end_date, period)
        date_df = pd.DataFrame(date_list, columns=['date'])
        date_df.date = date_df.date.astype(str)

        result_list = list()

        for v in search_type_list:
            temp_df_list = df[df.type == v]
            temp_df = temp_df_list[['date', 'cnt']]

            temp_df['date'] = temp_df['date'].astype(str)

            df2 = pd.merge(date_df, temp_df, how='outer', on='date').fillna(0)
            df2['cnt'] = df2['cnt'].astype(int)
            temp_list = df2['cnt'].tolist()

            result_list.append({"name": SearchController.CONTENTS_TYPE[v], "data": temp_list})

        return dict(category=date_list, data=result_list)
