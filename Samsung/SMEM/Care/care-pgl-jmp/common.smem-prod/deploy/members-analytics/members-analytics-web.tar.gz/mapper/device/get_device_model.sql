SELECT dvc_model
FROM device
WHERE
  mkt_id = {mkt_id}