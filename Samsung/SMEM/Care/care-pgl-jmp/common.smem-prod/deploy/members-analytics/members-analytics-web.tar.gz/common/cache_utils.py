from django.core.cache import cache

DEFAULT_TIMEOUT_SECOND = 60*60*24


class CacheUtils:
    @staticmethod
    def get_cache(key):
        return cache.get(key)

    @staticmethod
    def set_cache(key, value, timeout=DEFAULT_TIMEOUT_SECOND):
        cache.set(key, value, timeout)

    @staticmethod
    def is_cache(key):
        return True if cache.get(key) is not None else False
