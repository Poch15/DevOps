from django.http import HttpResponse
from openpyxl import Workbook

from common.dbutils import DBUtils
from common.date_utils import DateUtils
from common.excel_utils import ExcelUtils
from Branch.controls import BranchController
from common.branch_utils import BranchUtils
import pandas as pd


class RetentionController:
    @staticmethod
    def get_retention(start_date, end_date, branch_ids, branch_name, period):
        chart_data = list()
        cohort_list = list()

        # selected branches
        str_branch_name = branch_name
        if str_branch_name == 'All':
            str_branch_name = 'Global'

        cohort = RetentionController.__get_cohort(start_date, end_date, branch_ids, period)
        cohort_list.append(cohort)
        chart_data.append({"name": str_branch_name, "data": cohort.get('percentage_average')})

        # region
        if not RetentionController.__is_region(branch_name):
            region_name = BranchController.get_region(branch_ids[0])[0][0]

            region_branch_ids = BranchController.get_branch_ids_of_region_by_branch_id(branch_ids[0])
            region_cohort = RetentionController.__get_cohort(start_date, end_date, region_branch_ids, period)
            cohort_list.append(region_cohort)

            chart_data.append(
                {"name": str(region_name), "data": region_cohort.get('percentage_average')})

        # all branches
        all_branch_ids = BranchController.get_all_branch_ids_except_hq_demo_us()

        if len(all_branch_ids) + 1 != len(branch_ids):
            all_branch_cohort = RetentionController.__get_cohort(start_date, end_date, all_branch_ids, period)
            cohort_list.append(all_branch_cohort)
            chart_data.append({"name": "Global", "data": all_branch_cohort.get('percentage_average')})

        date_list = []
        if 'start_date' in cohort:
            date_list = DateUtils.create_date_list(cohort['start_date'], end_date, period)

        str_period = period.capitalize() + ' '
        category_list = [str_period + str(x) for x in range(0, 15)]

        return dict(category=category_list, date=date_list, data=chart_data, cohort=cohort_list)

    @staticmethod
    def get_retention_excel_data(start_date, end_date, branch_ids, period):

        # cohort
        cohort = RetentionController.__get_cohort(start_date, end_date, branch_ids, period)

        date_list = []
        if 'start_date' in cohort:
            date_list = DateUtils.create_date_list(cohort['start_date'], end_date, period)

        excel_list = cohort.get('percentage')

        for idx, row in enumerate(excel_list):
            row.insert(0, date_list[idx])

        average_list = cohort.get('percentage_average')
        average_list.insert(0, 'Average')
        excel_list.append(average_list)

        # raw data
        raw_data = RetentionController.__get_retention_raw_data(start_date, end_date, branch_ids, period)

        wb = Workbook()
        ws = wb.active

        ws.title = "Percentage"
        for obj in excel_list:
            ws.append(obj)

        title = 'RawData'
        ws_data = wb.create_sheet(title=title)
        ws_data.append(['branch', 'base_date', 'ret_date', 'ret_num'])
        for row in raw_data:
            ws_data.append(row)

        response = HttpResponse(
            content_type="application/force-download; application/octet-stream; application/download")
        response['Pragma'] = 'no-cache'
        response['Expires'] = 0
        response['Content-Disposition'] = 'attachment; filename=%s' % ExcelUtils.get_file_name("retention")
        wb.save(response)

        return response

    @staticmethod
    def __get_retention_raw_data(start_date, end_date, branch_ids, period):
        params = {'start_date': start_date, 'end_date': end_date, 'branch_ids': branch_ids}
        return_rows = DBUtils.execute_query(
            DBUtils.CONFIG_POSTGRESQL,
            DBUtils.load_query('retention', 'retention_branch_%s.sql' % period),
            params)

        df = pd.DataFrame(return_rows, columns=['branch', 'base_date', 'ret_date', 'ret_num'])
        branch_dict = BranchUtils.get_all_branch_dict()

        df['branch'] = df['branch'].map(branch_dict)
        raw_list = df.values.tolist()

        return raw_list

    @staticmethod
    def __get_cohort(start_date, end_date, branch_ids, period):
        """
            Returns cohort dictionary.
            key : value (type : 2d array), percentage (2d array), percentage_average (1d array)
        """

        cohort = dict()

        params = {'start_date': start_date, 'end_date': end_date, 'branch_ids': branch_ids}
        return_rows = DBUtils.execute_query(
            DBUtils.CONFIG_POSTGRESQL,
            DBUtils.load_query('retention', 'retention_%s.sql' % period),
            params)

        df = pd.DataFrame(return_rows, columns=['base_date', 'ret_date', 'ret_num'])
        pivot_df = df.pivot(columns='ret_date', index='base_date', values='ret_num')

        value_list = []
        percent_list = []
        for index, row in pivot_df.iterrows():
            temp_list = row.dropna().tolist()
            value_list.append(temp_list)
            percent_list.append([round((num / temp_list[0]) * 100, 2) for num in temp_list])

        percent_df = pd.DataFrame(percent_list)
        average_list = round(percent_df.mean(axis=0, skipna=True), 2).tolist()

        cohort['value'] = value_list
        cohort['percentage'] = percent_df.fillna(0).values.tolist()
        cohort['percentage_average'] = average_list

        if len(pivot_df) > 0:
            cohort['start_date'] = str(pivot_df.index[0])

        return cohort

    @staticmethod
    def __is_region(branch_name):
        result = False

        region_list = BranchController.get_all_region()
        if branch_name in region_list or branch_name == 'All':
            result = True

        return result
