SELECT screen_id, screen_name
FROM tbl_v2_screen_pv_info
WHERE is_use = true