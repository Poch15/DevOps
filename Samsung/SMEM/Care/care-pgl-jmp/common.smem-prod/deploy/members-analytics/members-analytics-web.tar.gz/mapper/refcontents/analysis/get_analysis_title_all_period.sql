SELECT content_id, branch_id, sum(cnt) as cnt
FROM v3_contents_total_count
WHERE
  content_type = {content_type}
  AND
  content_id IN {content_ids}
  AND
  branch_id IN {branch_ids}
  AND
  model {model}
GROUP BY content_id, branch_id