SELECT yearval || ' ' || weekval || 'W' AS yearweek, main_type, prd_cat, cnt
FROM
(
	SELECT
		EXTRACT(isoyear FROM DATE) AS yearval, EXTRACT(week FROM DATE) AS weekval,
		main_type, prd_cat, SUM(cnt) as cnt
	FROM
	(
   SELECT DATE + INTERVAL '1' DAY AS date, main_type, prd_cat, sum(cnt) AS cnt
     FROM v3_dash_feedback_adv
     WHERE
       DATE >= '{start_date}'
     AND
       DATE <= '{end_date}'
     AND
       branch_id IN {branch_ids}
     AND
       main_type IN {main_types}
   	GROUP BY DATE, main_type, prd_cat
	) AS A
	GROUP BY yearval, weekval, main_type, prd_cat
	ORDER BY yearval, weekval, main_type, prd_cat
) AS B