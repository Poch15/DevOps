SELECT EXTRACT(isoyear FROM (date + INTERVAL '1' DAY)) || '-'
        || EXTRACT(week FROM (date + INTERVAL '1' DAY)) ||'W' AS yearweek,
        SUM(cnt) as sumval
FROM {tbl_name}
  WHERE
    date >= '{start_date}'
  AND
    date <= '{end_date}'
  AND
    timezone = {timezone}
  AND
    branch_id IN {branch_ids}
  AND
    model {model}
GROUP BY date
ORDER BY date