SELECT
	CASE WHEN monthval < 10 THEN yearval || '/0' || monthval
			       ELSE yearval || '/' || monthval
			       END as yearmonth,
	round(tot_sec/tot_cnt/3600, 2) as avg, tot_cnt
FROM
(
	SELECT EXTRACT(year from date) as yearval, EXTRACT(month from date) as monthval, SUM(tot_cnt) as tot_cnt, SUM(tot_sec) as tot_sec
	FROM
	(
    SELECT date, sum(cnt) as tot_cnt, sum(tot_sec) as tot_sec
    FROM
    (
      SELECT datetime::DATE as date, cnt, tot_sec
      FROM v3_feedback_tat
      WHERE
        datetime >= '{start_date}'
      AND
        datetime < '{end_date}'::timestamp + INTERVAL '1' DAY
      AND
        branch_id IN {branch_ids}
      AND
        prd_cat IN {prd_cat}
      AND
        model {model}
    ) as a
    GROUP BY date
    ORDER BY date
	) as b
	GROUP BY yearval, monthval
	ORDER BY yearval, monthval
) as c