from common.dbutils import DBUtils
from common.branch_utils import BranchUtils
from common.params_utils import ParamsUtils
from common.excel_utils import ExcelUtils
from common.utils import Utils
from sys import maxsize
from Benefit.utils import BenefitTitle, BenefitNewTitle
from common.date_utils import DateUtils
from Device.controls import DeviceController
from common.chart_utils import ChartUtils
import pandas as pd


class RefContentsController:
    __NOTICE = 1
    __NEWSNTIPS = 2
    __FAQ = 3
    __COMMUNITY = 4
    __BENEFIT = 5
    __COUPON = 6
    __BENEFIT_DETAIL = 7

    __CONTENT_TYPE_NAME = ['none', 'notice', 'newsntips', 'faq', 'community', 'benefit', 'coupon', 'benefit_detail']
    __TYPE = ['none', 'Play', 'Link Button', 'Call', 'Download Coupon', 'View Coupon', 'Event Button']

    __FAQ_DIAGNOSTICS = {'SPC6', 'SPC8'}
    __FAQ_RECENT = {'SFB3', 'SFB4'}

    __WEBLINK_SRC_DICT = {
        "FB": "facebook",
        "IG": "instagram",
        "TW": "twitter",
        "KT": "kakaotalk",
        "TG": "telegram",
        "WA": "What's App",
        "LN": "Line",
        "WC": "WeChat",
        "SC": "Snapchat",
        "EM": "e-mail",
        "SMS": "message",
        "WEB": "Website"

    }

    __GALAXY_GIFT_CONTENT_ID = '-1'

    @staticmethod
    def get_count_chart_data(start_date, end_date, period, branch_ids, model, content_id, content_type):
        tbl_name = 'v3_' + RefContentsController.__CONTENT_TYPE_NAME[int(content_type)]
        params = {'start_date': start_date, 'end_date': end_date, 'content_id': content_id,
                  'branch_ids': branch_ids, 'model': model, 'content_type': int(content_type),
                  'tbl_name': tbl_name}

        result_chart_rows = RefContentsController.get_count_data(params, content_type, period)
        sum_rows = RefContentsController.get_sum_count(result_chart_rows)

        chart_name = ("Results", "Sum")
        chart_data = ChartUtils.wrap_dual_stack_chart_data(chart_name[0], chart_name[1], result_chart_rows, sum_rows)

        return chart_data

    @staticmethod
    def get_weblink_chart_data(start_date, end_date, period, branch_ids, model, contents_id, contents_type):
        chart_name = ("Results", "Sum")

        ret = RefContentsController.get_weblink_data(start_date, end_date, period, branch_ids, model, contents_id,
                                                     contents_type)
        result_chart_rows = ret[0]
        sum_rows = ret[1]

        return ChartUtils.wrap_dual_stack_chart_data(chart_name[0], chart_name[1], result_chart_rows, sum_rows)

    @staticmethod
    def get_weblink_data(start_date, end_date, period, branch_ids, model, contents_id, contents_type):
        date_list = DateUtils.create_date_list(start_date, end_date, period)
        date_df = pd.DataFrame(date_list, columns=['date'])

        params = {
            'start_date': start_date,
            'end_date': end_date,
            'contents_id': contents_id,
            'branch_ids': branch_ids,
            'model': model,
            'contents_type': int(contents_type)
        }

        sql = DBUtils.load_query('refcontents/weblink', 'get_weblink_%s.sql' % period)
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)

        df = pd.DataFrame(return_rows, columns=['date', 'source', 'cnt'])
        last_df = df[df['date'] == date_df.iloc[-1]['date']]
        last_df = last_df.sort_values(by=['cnt'], ascending=False)

        date_df['date'] = date_df['date'].astype(str)

        result_list = list()
        sources_desc_order = last_df['source'].tolist()
        unique_sources = df['source'].unique()

        sources_desc_order.extend([x for x in unique_sources if x not in sources_desc_order])

        for source in sources_desc_order:
            temp_df = df[df['source'] == source][['date', 'cnt']]
            temp_df['date'] = temp_df['date'].astype(str)

            df2 = pd.merge(date_df, temp_df, how='outer', on='date').fillna(0)
            df2['cnt'] = df2['cnt'].astype(int)
            temp_list = df2['cnt'].tolist()

            result_list.append(
                {"name": RefContentsController.__WEBLINK_SRC_DICT.get(source, source), "data": temp_list})

        sum_series = df.groupby(['date'])['cnt'].sum()
        sum_df = sum_series.to_frame().reset_index().rename(columns={"index": "date"})
        sum_df['date'] = sum_df['date'].astype(str)
        sum_df2 = pd.merge(date_df, sum_df, how='outer', on='date').fillna(0)

        sum_list = [{"name": "sum", "data": sum_df2['cnt'].astype(int).tolist()}]

        result_chart_rows = dict(category=date_list, data=result_list)
        sum_rows = dict(category=date_list, data=sum_list)

        ret = [result_chart_rows, sum_rows]

        return ret

    @staticmethod
    def get_faq_category_chart(start_date, end_date, period, branch_ids, model, content_id, content_type):
        tbl_name = 'v3_' + RefContentsController.__CONTENT_TYPE_NAME[int(content_type)]
        params = {'start_date': start_date, 'end_date': end_date, 'content_id': content_id,
                  'branch_ids': branch_ids, 'model': model, 'content_type': int(content_type),
                  'tbl_name': tbl_name}

        result_chart_rows = RefContentsController.get_faq_category_chart_data(params, content_type, period)
        sum_rows = RefContentsController.get_sum_count(result_chart_rows)

        chart_name = ("Results", "Sum")
        chart_data = ChartUtils.wrap_dual_stack_chart_data(chart_name[0], chart_name[1], result_chart_rows, sum_rows)

        return chart_data

    @staticmethod
    def get_sum_count(rows):
        result_list = rows['data']
        date_list = rows['category']

        sum_list = []
        for idx in range(len(date_list)):
            tmp = 0
            for ret in result_list:
                tmp = tmp + int(ret['data'][idx])
            sum_list.append(tmp)

        data = {"name": "Sum", "data": sum_list}
        return dict(category=date_list, data=data)

    @staticmethod
    def wrap_result_chart_data(chart_rows):
        result_list = chart_rows['result_list']
        date_list = chart_rows['date_list']
        statistics_dic = chart_rows['statistics_dic']

        chart_data = []
        for result in result_list:
            if result != -1:
                tmp_data = []
                for _date in date_list:
                    value = statistics_dic.get((result, _date), 0)
                    tmp_data.append(value)
                chart_data.append({"name": result, "data": tmp_data})

        return dict(category=date_list, data=chart_data)

    @staticmethod
    def get_contents_data(params, content_type, period):

        if content_type == '7':
            type_params = {'type': 'type'}
        else:
            type_params = {'type': 'referer'}
        params.update(type_params)

        if content_type == '7':
            type_params = {'default_val': int(0)}
        else:
            type_params = {'default_val': ''}
        params.update(type_params)

        if content_type == '3':
            if params.get('category') is None:
                params.update({'category': 'all'})
            sql = DBUtils.load_query('refcontents', 'get_ref_contents_faq_%s.sql' % period)
        else:
            sql = DBUtils.load_query('refcontents', 'get_ref_contents_%s.sql' % period)

        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)

        return return_rows

    @staticmethod
    def get_count_data(params, content_type, period):

        return_rows = RefContentsController.get_contents_data(params, content_type, period)

        statistics_dic = {}
        date_set = set()
        referer_set = set()

        for row in return_rows:
            if content_type == '3':
                date, referer, cat_id, count = row
            else:
                date, referer, count = row
            date_set.add(date)
            if content_type != '7':
                if referer == '0' or referer == '':
                    referer = 'Other'
                if 'SEP1' in referer and referer != 'SEP1/EEP3' and referer != 'SEP1/EEP19':
                    referer = 'SEP1'
                if referer in RefContentsController.__FAQ_DIAGNOSTICS:
                    referer = 'SPC6/SPC8'
                if referer in RefContentsController.__FAQ_RECENT:
                    referer = 'SFB3/SFB4'
            if (date, referer) in statistics_dic.keys():
                cnt = statistics_dic.get((date, referer))
                statistics_dic[(date, referer)] = int(cnt) + int(count)
            else:
                if content_type != '7' or (content_type == '7' and referer != 0):
                    statistics_dic[(date, referer)] = int(count)
                    referer_set.add(referer)

        date_list = list(date_set)
        date_list.sort(key=DateUtils.get_date_sort_key(period))

        ref_list = list(referer_set)
        type_name = RefContentsController.get_screen_viewname(ref_list, content_type)

        result_list = []
        for ref in ref_list:
            if content_type != '7':
                key = type_name.get(ref)
            else:
                if ref > len(RefContentsController.__TYPE) - 1:
                    key = 'Other'
                else:
                    key = RefContentsController.__TYPE[int(ref)]
            tmp_data = []
            for date in date_list:
                value = statistics_dic.get((date, ref), 0)
                tmp_data.append(value)
            result_list.append({"name": key, "data": tmp_data})

        result_list.sort(key=lambda x: x['data'][-1], reverse=True)
        return dict(category=date_list, data=result_list)

    @staticmethod
    def get_screen_viewname(ref_list, content_type):
        type_name = dict()
        if int(content_type) != RefContentsController.__BENEFIT_DETAIL:
            sql = DBUtils.load_query('refcontents', 'get_screen_pv_name.sql')
            params = {'screen_id': tuple(['0', '0'] + ref_list)}
            return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)

            screen_id_to_name_dict = dict()
            for row in return_rows:
                id, name = row
                screen_id_to_name_dict[id] = name

            for ref in ref_list:
                if ref == 'Other':
                    type_name[ref] = 'Others'
                else:
                    name = screen_id_to_name_dict.get(ref, 'Not Defined(' + ref + ')')
                    type_name[ref] = name

        return type_name

    @staticmethod
    def get_faq_category_chart_data(params, content_type, period):
        params.update({'category': 'old'})
        category_dict = Utils.get_category_dict()

        ret = RefContentsController.get_faq_data_by_category(params, content_type, period, category_dict)

        params.update({'category': 'new'})
        category_dict = Utils.get_faq_v2_category_dict()

        ret2 = RefContentsController.get_faq_data_by_category(params, content_type, period, category_dict)

        ret['data'].extend(ret2['data'])
        ret['data'].sort(key=lambda x: x['data'][-1], reverse=True)

        return ret

    @staticmethod
    def get_faq_data_by_category(params, content_type, period, category_dict):

        return_rows = RefContentsController.get_contents_data(params, content_type, period)

        statistics_dic = {}
        cat_id_dic = {}
        date_set = set()
        for row in return_rows:
            date, referer, cat_id, count = row
            date_set.add(date)
            cat_id_dic[cat_id] = cat_id_dic.get(cat_id, 0) + int(count)
            if (date, cat_id) in statistics_dic.keys():
                cnt = statistics_dic.get((date, cat_id))
                statistics_dic[(date, cat_id)] = int(cnt) + int(count)
            else:
                statistics_dic[(date, cat_id)] = int(count)

        date_list = list(date_set)
        date_list.sort(key=DateUtils.get_date_sort_key(period))

        result = []
        cat_list = sorted(category_dict.keys())

        none_index = 0
        cat_list.append(cat_list.pop(none_index))

        for cat_id in cat_list:
            tmp_data = []
            cat_sum = 0
            for date in date_list:
                value = statistics_dic.get((date, cat_id), 0)
                tmp_data.append(value)
                cat_sum += int(value)

            if cat_sum > 0:
                result.append({"name": category_dict.get(cat_id, 'Unknown'), "data": tmp_data})

        return dict(category=date_list, data=result)

    @staticmethod
    def get_analysis_title_data(start_date, end_date, branch_ids, model,
                                content_type, cur_p, page_size, order_type='count'):
        tbl_name = 'v3_' + RefContentsController.__CONTENT_TYPE_NAME[int(content_type)]
        if order_type == 'content_id':
            order_type = 'cast(content_id as integer)'

        params = {'start_date': start_date, 'end_date': end_date, 'branch_ids': branch_ids,
                  'model': model, 'content_type': int(content_type), 'order_type': order_type, 'tbl_name': tbl_name}
        sql = DBUtils.load_query('refcontents/analysis', 'get_analysis_title_total_count.sql')
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)
        total_page, total_count = return_rows[0]

        paging_params = ParamsUtils.get_paging_params(cur_p, total_page, page_size)
        params.update(paging_params)

        sql = DBUtils.load_query('refcontents/analysis', 'get_analysis_title.sql')
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)

        if int(content_type) == 5 or int(content_type) == 6 or int(content_type) == 7:
            title_list = RefContentsController.get_benefit_title_list(return_rows, content_type, False)
        else:
            title_list = RefContentsController.get_title_list(return_rows, int(content_type), start_date, end_date)
        branch_list = RefContentsController.get_branch_list(return_rows)
        title_all_period_count = RefContentsController.get_title_all_period_count(return_rows, content_type, branch_ids,
                                                                                  model)

        return dict(category=title_list, data=return_rows, tot_p=paging_params['total_page'],
                    total_count=total_count, cur_p=int(cur_p), branch_list=branch_list,
                    title_all_period_count=title_all_period_count)

    @staticmethod
    def get_benefit_title_list(return_rows, content_type, excel):
        legacy_ids = list()
        new_ids = list()
        for row in return_rows:
            if excel is True:
                id, count, percent, branch_id, referer = row
            else:
                id, count, percent, branch_id = row
            if id != '':
                if len(id) == 10:
                    legacy_ids.append((id, branch_id))
                else:
                    new_ids.append(id)

        # legacy
        benefit_title = BenefitTitle()
        if int(content_type) == 5 or int(content_type) == 7:
            title_dict = benefit_title.get_title_dict(BenefitTitle.OFFER, legacy_ids)
        else:
            title_dict = benefit_title.get_title_dict(BenefitTitle.COUPON, legacy_ids)

        # new
        if int(content_type) == 5 or int(content_type) == 7:
            new_title_dict = BenefitNewTitle.get_new_benefit_title_dict(BenefitTitle.OFFER, new_ids)
        else:
            new_title_dict = BenefitNewTitle.get_new_benefit_title_dict(BenefitTitle.COUPON, new_ids)

        title_dict.update(new_title_dict)

        title_list = list()
        for row in return_rows:
            if excel is True:
                id, count, percent, branch_id, referer = row
            else:
                id, count, percent, branch_id = row
            title_tuple = title_dict.get(id, None)
            if title_tuple is None:
                # Galaxy Gift for Thailand
                if id == RefContentsController.__GALAXY_GIFT_CONTENT_ID:
                    title = ('Galaxy Gift', None)
                else:
                    title = ('Unknown' + " [ID:" + id + "]", None)
            else:
                title = title_tuple
            title_list.append(title)

        return title_list

    @staticmethod
    def get_title_list(return_rows, content_type, start_date, end_date):
        content_type_name = RefContentsController.__CONTENT_TYPE_NAME[content_type]
        contents_ids = [0]
        for row in return_rows:
            id = row[0]
            contents_ids.append(int(id))

        title_list_dict = RefContentsController.get_title_info(contents_ids, content_type_name)
        title_list = []
        if content_type_name == 'faq':
            for row in return_rows:
                id = row[0]
                title, category = title_list_dict.get(int(id), ('[Untitled]', 'None'))
                title_list.append((RefContentsController.get_print_title(title), category))
        elif content_type_name == 'notice':
            for row in return_rows:
                id = row[0]
                title, post_dt, exp_dt = title_list_dict.get(int(id), ('[Untitled]', None, None))
                title_list.append((RefContentsController.get_print_title(title), post_dt, exp_dt))
        elif content_type_name == 'newsntips':
            bookmark_dict = RefContentsController.get_newsntips_bookmark_dict(start_date, end_date)
            like_dict = RefContentsController.get_newsntips_like_dict(start_date, end_date)
            for row in return_rows:
                content_id = row[0]
                branch_id = row[3]
                title, category, post_dt, exp_dt = title_list_dict.get(int(content_id),
                                                                       ('[Untitled]', None, None, None))
                bookmark_cnt = bookmark_dict.get((content_id, branch_id), 0)
                like_cnt = like_dict.get((content_id, branch_id), 0)
                title_list.append((RefContentsController.get_print_title(title), category, bookmark_cnt, like_cnt,
                                   post_dt, exp_dt))

        return title_list

    @staticmethod
    def get_title_info(content_ids, content_type):
        sql = DBUtils.load_query('refcontents', 'get_%s_title.sql' % content_type)
        params = {'ids': ParamsUtils.convert_list_to_tuple_params(content_ids)}
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_MYSQL, sql, params)

        contents_title_dict = {}
        if content_type == 'faq':
            faq_v1_category_dict = Utils.get_faq_v1_category_dict()
            faq_v2_category_dict = Utils.get_faq_v2_category_dict()

            for row in return_rows:
                id, title, cat_id, parent_cat_id = row
                if parent_cat_id is None:
                    parent_cat_id = cat_id

                if id > 100000:
                    contents_title_dict[id] = (title, faq_v2_category_dict.get(parent_cat_id, 'Unknown'))
                else:
                    contents_title_dict[id] = (title, faq_v1_category_dict.get(cat_id, 'Unknown'))

            contents_title_dict[0] = ('Unidentified contents', 'None')
        elif content_type == 'notice':
            for row in return_rows:
                id, title, post_dt, exp_dt = row
                contents_title_dict[id] = (title, post_dt, exp_dt)
                contents_title_dict[0] = ('Unidentified contents', None, None)
        elif content_type == 'newsntips':
            article_type_dic = RefContentsController.get_newsntips_category_dict()
            for row in return_rows:
                id, title, post_dt, exp_dt, cat_id = row
                contents_title_dict[id] = (title, article_type_dic.get(cat_id, 'Unknown'), post_dt, exp_dt)
                contents_title_dict[0] = ('Unidentified contents', None, None, None)
        else:
            for row in return_rows:
                id, title = row
                contents_title_dict[id] = title
                contents_title_dict[0] = 'Unidentified contents'

        return contents_title_dict

    @staticmethod
    def get_analysis_device_data(start_date, end_date, branch_ids, model,
                                 content_id, content_type, cur_p, page_size):
        tbl_name = 'v3_' + RefContentsController.__CONTENT_TYPE_NAME[int(content_type)]
        sql = DBUtils.load_query('refcontents/analysis', 'get_analysis_device_total_count.sql')
        params = {'start_date': start_date, 'end_date': end_date, 'branch_ids': branch_ids,
                  'model': model, 'content_id': content_id, 'content_type': content_type, 'tbl_name': tbl_name}
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)
        total_count = return_rows[0][0]

        paging_params = ParamsUtils.get_paging_params(cur_p, total_count, page_size)
        params.update(paging_params)
        params["content_id"] = content_id
        sql = DBUtils.load_query('refcontents/analysis', 'get_analysis_device.sql')
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)

        device_list = []
        device_to_mkt_name_dict = DeviceController.get_device_to_mkt_name_dict()
        for row in return_rows:
            device, cnt, percent = row
            mkt_name = device_to_mkt_name_dict.get(device, "")
            device = device + DeviceController.get_tab_mkt_name(mkt_name)
            device_list.append(device)

        return dict(category=device_list, data=return_rows, tot_p=paging_params['total_page'], cur_p=int(cur_p))

    @staticmethod
    def get_analysis_category_data(start_date, end_date, branch_ids, model,
                                   content_id, content_type, cur_p):
        params = {'start_date': start_date, 'end_date': end_date, 'branch_ids': branch_ids,
                  'model': model, 'content_id': content_id, 'content_type': content_type}
        sql = DBUtils.load_query('refcontents/analysis', 'get_analysis_category.sql')
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)

        faq_category_v1_dict = Utils.get_faq_v1_category_dict()
        faq_category_v2_dict = Utils.get_faq_v2_category_dict()

        category_list = []
        return_list = []
        for cat_id, ver, cnt, percent in return_rows:
            if ver == 'v1':
                category_list.append(faq_category_v1_dict.get(cat_id, 'None'))
            else:
                category_list.append(faq_category_v2_dict.get(cat_id, 'None'))

            return_list.append((cat_id, cnt, percent))

        return dict(category=category_list, data=return_list, tot_p=1, cur_p=int(cur_p))

    @staticmethod
    def get_branch_list(return_rows):
        branch_dict = BranchUtils.get_all_branch_dict()
        branch_list = []
        for row in return_rows:
            branch_id = row[3]
            branch_list.append(branch_dict.get(branch_id, 'Unknown'))
        return branch_list

    @staticmethod
    def get_title_all_period_count(return_rows, content_type, branch_ids, model):
        tbl_name = 'v3_' + RefContentsController.__CONTENT_TYPE_NAME[int(content_type)]
        content_ids = []
        content_branch_ids = []
        for row in return_rows:
            content_id = row[0]
            content_ids.append(content_id)

            branch_id = row[3]
            content_branch_ids.append((content_id, branch_id))

        sql = DBUtils.load_query('refcontents/analysis', 'get_analysis_title_all_period.sql')
        params = {'branch_ids': branch_ids, 'model': model,
                  'content_ids': str(content_ids).replace("[", "(").replace("]", ")"),
                  'content_type': int(content_type), 'tbl_name': tbl_name}

        title_total_counts_list = []

        if len(content_ids) > 0:
            return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)

            title_all_period_counts_dic = {}
            for row in return_rows:
                content_id, branch_id, total_cnt = row
                title_all_period_counts_dic.update({(content_id, branch_id): total_cnt})

            for content_id, branch_id in content_branch_ids:
                title_total_count = title_all_period_counts_dic.get((content_id, branch_id), 0)
                title_total_counts_list.append(title_total_count)

        return title_total_counts_list

    @staticmethod
    def get_count_excel_data(start_date, end_date, period, branch_ids, model, content_id, content_type):
        tbl_name = 'v3_' + RefContentsController.__CONTENT_TYPE_NAME[int(content_type)]
        params = {'start_date': start_date, 'end_date': end_date, 'branch_ids': branch_ids,
                  'model': model, 'content_id': content_id, 'tbl_name': tbl_name}
        return_dict = RefContentsController.get_count_data(params, content_type, period)

        date_list = return_dict['category']
        ret_list = return_dict['data']
        result = []
        excel_rows = []
        header = ["Date"]

        for ret in ret_list:
            data_dict = dict()
            data_dict['name'] = ret['name']
            data_dict['data'] = ret['data']
            result.append(data_dict)

        l = []
        for type in result:
            header.append(type.get('name'))
            l.append(type.get('data'))
        excel_rows.append(header)

        for j in range(len(date_list)):
            row = [date_list[j]]
            for i in range(len(l)):
                row.append(l[i][j])
            excel_rows.append(row)

        title_rows = None
        if int(content_type) != RefContentsController.__COMMUNITY:
            title_rows = RefContentsController.get_title_excel_data(start_date, end_date, branch_ids, model,
                                                                    content_type)
        device_rows = RefContentsController.get_device_excel_data(start_date, end_date, branch_ids, model, content_id,
                                                                  content_type)
        category_rows = None
        if int(content_type) == RefContentsController.__FAQ:
            category_rows = RefContentsController.get_category_excel_data(start_date, end_date, branch_ids, model,
                                                                          content_id, content_type)

        nat_category_rows = None
        if int(content_type) == RefContentsController.__NEWSNTIPS:
            nat_category_rows = RefContentsController.get_newsntips_category_excel_data(start_date, end_date, period,
                                                                                        branch_ids, model)

        weblink_rows = None
        if int(content_type) != RefContentsController.__BENEFIT_DETAIL:
            weblink_rows = RefContentsController.get_weblink_excel_data(start_date, end_date, period, branch_ids, model,
                                                                        content_id, content_type)

        excel_name = ExcelUtils.get_file_name(RefContentsController.__CONTENT_TYPE_NAME[int(content_type)])
        excel_data = ExcelUtils.multi_list_to_ref_contents_excel(excel_name, content_id, start_date, end_date,
                                                                 excel_rows, device_rows, category_rows, title_rows,
                                                                 nat_category_rows, weblink_rows)

        return excel_data

    @staticmethod
    def get_weblink_excel_data(start_date, end_date, period, branch_ids, model, contents_id, contents_type):

        excel_data_dict = RefContentsController.get_weblink_data(start_date, end_date, period, branch_ids, model,
                                                                 contents_id, contents_type)

        data_dict = excel_data_dict[0]
        date_list = data_dict['category']
        data_list = data_dict['data']

        df = pd.DataFrame({'date': date_list})

        for data in data_list:
            source = data['name']
            df[source] = data['data']

        excel_header = df.columns.tolist()
        excel_value_list = df.values.tolist()

        excel_rows = [excel_header]
        for row in excel_value_list:
            excel_rows.append(row)

        return excel_rows

    @staticmethod
    def get_title_excel_data(start_date, end_date, branch_ids, model, content_type):
        excel_data_dict = RefContentsController.get_analysis_title_excel_data(start_date, end_date, branch_ids, model,
                                                                              content_type)
        title_list = excel_data_dict['category']
        data_list = excel_data_dict['data']
        branch_list = excel_data_dict['branch_list']

        if int(content_type) == RefContentsController.__FAQ:
            excel_header = ['ID', 'Category', 'Funnel', 'Title', 'Count']
        elif int(content_type) == RefContentsController.__NOTICE:
            excel_header = ['ID', 'Funnel', 'Title', 'Count', 'Post Date', 'Exp Date']
        elif int(content_type) == RefContentsController.__NEWSNTIPS:
            excel_header = ['ID', 'Funnel', 'Category', 'Title', 'View Count', 'Bookmark Count',
                            'Like Count', 'Post Date', 'Exp Date']
        else:
            # Benefit, Benefit Detail, Coupon
            excel_header = ['ID', 'Type', 'Title', 'Count']

        if len(branch_ids) > 1:
            excel_header.insert(1, 'Branch')

        referer_set = set()
        for data in data_list:
            referer_set.add(data[4])
        ref_list = list(referer_set)

        if int(content_type) != RefContentsController.__BENEFIT_DETAIL:
            type_name = RefContentsController.get_screen_viewname(ref_list, content_type)
        else:
            type_name = dict()
            for ref in ref_list:
                type_name[ref] = RefContentsController.__TYPE[int(ref)]

        excel_rows = [excel_header]
        for data, title_row, branch in zip(data_list, title_list, branch_list):
            id, count, percent, branch_id, referer = data
            rows = [id, type_name.get(referer, "Other"), ExcelUtils.remove_escape_string(title_row[0]), count]
            if int(content_type) == RefContentsController.__FAQ:
                title, category = title_row
                rows.insert(1, category)
            elif int(content_type) == RefContentsController.__NOTICE:
                title, post_dt, exp_dt = title_row
                rows.extend([post_dt, exp_dt])
            elif int(content_type) == RefContentsController.__NEWSNTIPS:
                title, category, bookmark_cnt, like_cnt, post_dt, exp_dt = title_row
                rows.insert(2, category)
                rows.extend([bookmark_cnt, like_cnt, post_dt, exp_dt])

            if len(branch_ids) > 1:
                rows.insert(1, branch)
            excel_rows.append(rows)

        return excel_rows

    @staticmethod
    def get_analysis_title_excel_data(start_date, end_date, branch_ids, model, content_type):
        tbl_name = 'v3_' + RefContentsController.__CONTENT_TYPE_NAME[int(content_type)]
        params = {'start_date': start_date, 'end_date': end_date, 'branch_ids': branch_ids,
                  'model': model, 'content_type': int(content_type), 'tbl_name': tbl_name}

        if content_type == '7':
            type_params = {'type': 'type'}
        else:
            type_params = {'type': 'referer'}
        params.update(type_params)

        sql = DBUtils.load_query('refcontents/analysis', 'get_analysis_title_excel.sql')
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)

        if int(content_type) == 5 or int(content_type) == 6 or int(content_type) == 7:
            title_list = RefContentsController.get_benefit_title_list(return_rows, content_type, True)
        else:
            title_list = list()

            total_len = len(return_rows)
            a, b = total_len // 300, total_len % 300

            start = 0
            for i in range(0, a):
                temp_rows = return_rows[start:start + 300]
                temp_list = RefContentsController.get_title_list(temp_rows, int(content_type), start_date, end_date)
                title_list.extend(temp_list)

                start = start + 300

            temp_rows = return_rows[start:start + b]
            temp_list = RefContentsController.get_title_list(temp_rows, int(content_type), start_date, end_date)
            title_list.extend(temp_list)

        branch_list = RefContentsController.get_branch_list(return_rows)
        return dict(category=title_list, data=return_rows, branch_list=branch_list)

    @staticmethod
    def get_device_excel_data(start_date, end_date, branch_ids, model, content_id, content_type):

        excel_data_dict = RefContentsController.get_analysis_device_data(start_date, end_date, branch_ids, model,
                                                                         content_id, content_type, 0, maxsize)
        data_list = excel_data_dict['data']
        excel_header = ['Device', 'Count']
        excel_rows = [excel_header]

        device_to_mkt_name_dict = DeviceController.get_device_to_mkt_name_dict()
        for data in data_list:
            model, count, percent = data
            mkt_name = device_to_mkt_name_dict.get(model, "")
            model = model + DeviceController.get_tab_mkt_name(mkt_name)
            rows = [model, count]
            excel_rows.append(rows)

        return excel_rows

    @staticmethod
    def get_category_excel_data(start_date, end_date, branch_ids, model, content_id, content_type):
        excel_data_dict = RefContentsController.get_analysis_category_data(start_date, end_date, branch_ids, model,
                                                                           content_id, content_type, 0)

        category_list = excel_data_dict['category']
        data_list = excel_data_dict['data']
        excel_header = ['Category', 'Count']
        excel_rows = [excel_header]

        for category, data in zip(category_list, data_list):
            cat_id, count, percent = data
            rows = [category, count]
            excel_rows.append(rows)

        return excel_rows

    @staticmethod
    def get_print_title(title, def_title='[Untitled]'):
        if not title.strip():
            title = def_title

        return title

    @staticmethod
    def get_newsntips_like_dict(start_date, end_date):
        params = {'start_date': start_date, 'end_date': end_date}
        sql = DBUtils.load_query('refcontents', 'get_newsntips_like.sql')
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)

        article_like_dict = dict()
        for row in return_rows:
            article_id, branch_id, cnt = row
            article_like_dict[(article_id, branch_id)] = cnt

        return article_like_dict

    @staticmethod
    def get_newsntips_bookmark_dict(start_date, end_date):
        params = {'start_date': start_date, 'end_date': end_date}
        sql = DBUtils.load_query('refcontents', 'get_newsntips_bookmark.sql')
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)

        article_bookmark_dict = dict()
        for row in return_rows:
            article_id, branch_id, cnt = row
            article_bookmark_dict[(article_id, branch_id)] = cnt

        return article_bookmark_dict

    @staticmethod
    def get_newsntips_ratio_chart_data(start_date, end_date, period, branch_ids, content_id):
        result_dict = RefContentsController.get_newsntips_ratio_count_data(start_date, end_date, period, branch_ids,
                                                                           content_id)
        count_chart = {
            "category": result_dict['date_list'],
            "data": [
                {"name": "View Count", "data": result_dict['view_cnt_list']},
                {"name": "Like Count", "data": result_dict['like_cnt_list']},
                {"name": "Bookmark Count", "data": result_dict['bookmark_cnt_list']}
            ]
        }

        ratio_chart = {
            "data": [
                {"name": "Like Ratio(%)", "data": result_dict['like_ratio_list']},
                {"name": "Bookmark Ratio(%)", "data": result_dict['bookmark_ratio_list']},
            ]
        }

        chart_data = ChartUtils.wrap_dual_stack_chart_data("Count", "Ratio", count_chart, ratio_chart)
        return chart_data

    @staticmethod
    def get_newsntips_ratio_count_data(start_date, end_date, period, branch_ids, content_id):
        params = {'start_date': start_date, 'end_date': end_date, 'branch_ids': branch_ids, 'content_id': content_id}
        sql = DBUtils.load_query('refcontents/newsntips', 'get_newsntips_view_%s.sql' % period)
        view_return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)
        view_dict = dict(view_return_rows)

        sql = DBUtils.load_query('refcontents/newsntips', 'get_newsntips_like_%s.sql' % period)
        like_return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)
        like_dict = dict(like_return_rows)

        sql = DBUtils.load_query('refcontents/newsntips', 'get_newsntips_bookmark_%s.sql' % period)
        bookmark_return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)
        bookmark_dict = dict(bookmark_return_rows)

        date_list = DateUtils.create_date_list(start_date, end_date, period)
        view_cnt_list = []
        like_cnt_list = []
        bookmark_cnt_list = []
        like_ratio_list = []
        bookmark_ratio_list = []
        for date in date_list:
            view_cnt = int(view_dict.get(date, 0))
            like_cnt = int(like_dict.get(date, 0))
            bookmark_cnt = int(bookmark_dict.get(date, 0))

            view_cnt_list.append(view_cnt)
            like_cnt_list.append(like_cnt)
            like_ratio_list.append(float(0 if like_cnt == 0 else round((like_cnt / view_cnt) * 100, 2)))
            bookmark_cnt_list.append(bookmark_cnt)
            bookmark_ratio_list.append(float(0 if bookmark_cnt == 0 else round((bookmark_cnt / view_cnt) * 100, 2)))

        return dict(date_list=date_list, view_cnt_list=view_cnt_list, like_cnt_list=like_cnt_list,
                    bookmark_cnt_list=bookmark_cnt_list, like_ratio_list=like_ratio_list,
                    bookmark_ratio_list=bookmark_ratio_list)

    @staticmethod
    def get_newsntips_category_count_data(start_date, end_date, period, branch_ids, model):
        params = {'start_date': start_date, 'end_date': end_date, 'branch_ids': branch_ids, 'model': model}
        sql = DBUtils.load_query('refcontents/newsntips', 'get_newsntips_category_%s.sql' % period)
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)

        return return_rows

    @staticmethod
    def get_newsntips_category_excel_data(start_date, end_date, period, branch_ids, model):
        return_rows = RefContentsController.get_newsntips_category_count_data(start_date, end_date, period, branch_ids,
                                                                              model)

        date_set = set()
        category_set = set()
        stat_dict = {}
        for row in return_rows:
            date, category, cnt = row
            date_set.add(date)
            category_set.add(category)
            stat_dict[(date, category)] = int(cnt)

        date_list = list(date_set)
        date_list.sort(key=DateUtils.get_date_sort_key(period))
        category_list = RefContentsController.get_newsntips_category_header_list(list(category_set))

        excel_header = ['Date']
        excel_header.extend(category_list)
        excel_rows = [excel_header]

        for date in date_list:
            count_list = [date]
            for category in category_list:
                count = stat_dict.get((date, category), 0)
                count_list.append(count)
            excel_rows.append(count_list)

        return excel_rows

    @staticmethod
    def get_newsntips_category_dict():
        sql = DBUtils.load_query('refcontents/newsntips', 'get_newsntips_category_code.sql')
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_MYSQL, sql, {})

        cat_dict = {}
        for row in return_rows:
            cat_id, cat_cd = row
            cat_dict[cat_id] = cat_cd

        return cat_dict

    @staticmethod
    def get_newsntips_category_header_list(cat_list):
        all_cat_code_list = RefContentsController.get_newsntips_category_dict().values()
        ret_cat_cd_list = []
        for cat_cd in all_cat_code_list:
            if cat_cd in cat_list:
                ret_cat_cd_list.append(cat_cd)

        return ret_cat_cd_list
