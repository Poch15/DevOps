SELECT yearval ||' '|| weekval ||'W' as yearweek, referer, cat_id, cnt
FROM
  (
    SELECT extract(isoyear from date) as yearval, extract(week from date) as weekval, referer, cat_id, sum(cnt) as cnt
    FROM
    (
          (
             SELECT datetime::date + INTERVAL '1' DAY as date, referer, cat_id, SUM(cnt) as cnt
            FROM
              (
                SELECT datetime, referer, cnt, cat_id
                FROM v3_faq
                WHERE
                  datetime >= '{start_date}'::timestamp
                AND
                  datetime < '{end_date}'::timestamp + INTERVAL '1' DAY
                AND
                  branch_id IN {branch_ids}
                AND
                  CASE
                  WHEN '{content_id}' = '0' THEN
                    model {model}
                  ELSE
                    model {model} AND content_id = '{content_id}'
                  END
              ) AS A
              GROUP BY date, referer, cat_id
              ORDER BY date, referer, cat_id
          )
          UNION ALL
          (
	          SELECT date + interval '1' day, '' as referer, 0 as cat_id, 0 as sum
            FROM
              (
                SELECT C.date
                FROM
                  (
                    SELECT '{start_date}'::date + (100 * aa.a + 10 * bb.a + cc.a) as date
                    FROM (
                            select 0 as a
                            union all select 1
                            union all select 2
                            union all select 3
                            union all select 4
                            union all select 5
                            union all select 6
                            union all select 7
                            union all select 8
                            union all select 9
                          ) as aa cross join
                          (
                            select 0 as a
                            union all select 1
                            union all select 2
                            union all select 3
                            union all select 4
                            union all select 5
                            union all select 6
                            union all select 7
                            union all select 8
                            union all select 9
                          ) as bb cross join
                          (
                            select 0 as a
                            union all select 1
                            union all select 2
                            union all select 3
                            union all select 4
                            union all select 5
                            union all select 6
                            union all select 7
                            union all select 8
                            union all select 9
                          ) as cc
                  ) AS C
                WHERE C.DATE < '{end_date}'::date + interval '1' day
              ) AS D
          )
    ) AS E
    GROUP BY extract(isoyear from date), extract(week from date), referer, cat_id
    ORDER BY extract(isoyear from date), extract(week from date), referer, cat_id
  ) AS F