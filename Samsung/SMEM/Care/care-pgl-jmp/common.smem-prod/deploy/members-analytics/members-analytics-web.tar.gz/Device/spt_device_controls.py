import json

spt_model_list = []


class SupportDeviceController:
    def load_spt_model_list(self):
        print("load spt model list")

        with open('spt_device_list.json') as f:
            _model_list = json.load(f)

        for _model_dict in _model_list:
            global spt_model_list
            spt_model_list.append(
                dict({
                    'mkt_name': _model_dict.get('mkt_name'),
                    'model_name': self.convert_query_param(
                        _model_dict.get('model_name'))
                })
            )

    def get_spt_model_list(self):
        if len(spt_model_list) is 0:
            self.load_spt_model_list()

        return spt_model_list

    def convert_query_param(self, _model_name):
        if ',' in _model_name:
            _model_name = "%\\' AND model ~ \\'^({}).*\\' AND model LIKE \\'".format(
                _model_name.replace(',', '|')
            )
        return _model_name
