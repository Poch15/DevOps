SELECT dateval, sum(cnt) as cnt
FROM
  (
	  SELECT (datetime + INTERVAL '{interval_hour}' HOUR)::date as dateval, branch_id, cnt
	  FROM {tbl_name}
	  WHERE
	    datetime >= '{start_date}'::timestamp - INTERVAL '{interval_hour}' HOUR
	  AND
	    datetime < '{end_date}'::timestamp - INTERVAL '{interval_hour}' HOUR + INTERVAL '1' DAY
	  AND
	    branch_id IN {branch_ids}
	) AS A
GROUP BY dateval
ORDER BY dateval