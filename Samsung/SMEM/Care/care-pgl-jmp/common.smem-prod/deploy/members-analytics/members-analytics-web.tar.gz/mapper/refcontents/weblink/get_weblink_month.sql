SELECT
    CASE WHEN monthval < 10 THEN yearval || '/0' || monthval
			   ELSE yearval || '/' || monthval
		END as yearmonth,
    source,
		cnt
FROM
(
    SELECT extract(year from date) as yearval, extract(MONTH FROM date) AS monthval, source, sum(cnt) as cnt
    FROM v3_contents_weblink
    WHERE
        date >= '{start_date}'::timestamp
      AND
        date < '{end_date}'::timestamp + INTERVAL '1' DAY
      AND
        contents_type = {contents_type}
      AND
        branch_id IN {branch_ids}
      AND
        CASE
        WHEN '{contents_id}' = '0' THEN
          model {model}
        ELSE
          model {model} AND contents_id = '{contents_id}'
        END
    GROUP BY yearval, monthval, source
    ORDER BY yearval, monthval, source
) AS A