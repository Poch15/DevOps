SELECT date, service_id, status, sum(cnt)
FROM v3_more_svc_event
WHERE
    date >= '{start_date}'
AND
    date <= '{end_date}'
AND
    branch_id IN {branch_ids}
AND
    model {model}
GROUP BY date, service_id, status
ORDER BY date, service_id, status