from common.utils import Utils
from common.dbutils import DBUtils
from common.excel_utils import ExcelUtils
from common.chart_utils import ChartUtils
from common.params_utils import ParamsUtils
from common.branch_utils import BranchUtils
from common.date_utils import DateUtils
from datetime import date
from Device.controls import DeviceController
import pandas as pd


class VOCController:
    @staticmethod
    def get_count_data(model, start_date, end_date, period, branch_ids, voc_types, cs_type):
        sql = DBUtils.load_query('vocs', 'get_vocs_%s.sql' % period)
        params = {'start_date': start_date, 'end_date': end_date, 'branch_ids': branch_ids,
                  'model': model, 'voc_types': voc_types, 'prd_cat': Utils.get_product_categories(cs_type)}
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)
        return return_rows

    @staticmethod
    def get_chart_count_data(model, start_date, end_date, period, branch_ids, voc_types, cs_type):
        return_rows = VOCController.get_count_data(model, start_date, end_date, period, branch_ids, voc_types, cs_type)

        chart_rows = ChartUtils.convert_chart_rows(return_rows)
        chart_data = ChartUtils.wrap_chart_data("VOC Detail", chart_rows)

        return chart_data

    @staticmethod
    def get_excel_count_data(model, start_date, end_date, period, branch_ids, voc_type, cs_type):
        return_rows = VOCController.get_count_data(model, start_date, end_date, period, branch_ids, voc_type, cs_type)
        excel_rows = ExcelUtils.convert_excel_rows(return_rows)

        branch_excel_rows = VOCController.get_excel_tab_data(branch_ids, model, start_date, end_date, period,
                                                             voc_type, 'branch', cs_type)
        model_excel_rows = VOCController.get_excel_tab_data(branch_ids, model, start_date, end_date, period,
                                                            voc_type, 'device', cs_type)

        excel_name = ExcelUtils.get_voc_file_name('voc', int(voc_type))
        excel_data = ExcelUtils.multi_list_to_excel(excel_name, 'Date', excel_rows, branch_excel_rows, model_excel_rows)

        return excel_data

    @staticmethod
    def get_analysis_tab_data(start_date, end_date, branch_ids, model, tab_type, voc_type, cur_p, page_size, cs_type):

        # get total count
        sql = DBUtils.load_query('vocs', 'get_vocs_analysis_%s_total_count.sql' % tab_type)
        params = {'start_date': start_date, 'end_date': end_date, 'branch_ids': branch_ids, 'model': model,
                  'voc_type': voc_type, 'prd_cat': Utils.get_product_categories(cs_type)}
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)
        total_count = return_rows[0][0]

        # get tab count
        paging_params = ParamsUtils.get_paging_params(cur_p, total_count, page_size)
        params.update(paging_params)
        sql = DBUtils.load_query('vocs', 'get_vocs_analysis_%s.sql' % tab_type)
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)

        if tab_type == 'app':
            return_rows = ChartUtils.convert_app_id_tab_list(return_rows)

        category = []
        for return_row in return_rows:
            category.append(return_row[0])

        return dict(category=category, data=return_rows, tot_p=paging_params['total_page'], cur_p=int(cur_p))

    @staticmethod
    def get_analysis_data_by_branch(branch_ids, model, start_date, end_date, voc_types, cur_p, page_size, cs_type):

        # get total count
        sql = DBUtils.load_query('vocs', 'get_vocs_analysis_branch_total_count.sql')
        params = {'start_date': start_date, 'end_date': end_date, 'branch_ids': branch_ids, 'model': model,
                  'voc_types': voc_types, 'prd_cat': Utils.get_product_categories(cs_type)}
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)
        total_count = return_rows[0][0]

        # get tab count
        paging_params = ParamsUtils.get_paging_params(cur_p, total_count, page_size)
        params.update(paging_params)
        sql = DBUtils.load_query('vocs', 'get_vocs_analysis_branch.sql')
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)

        category = []
        for return_row in return_rows:
            category.append(return_row[0])

        return dict(category=category, data=return_rows, tot_p=paging_params['total_page'], cur_p=int(cur_p))

    @staticmethod
    def get_analysis_data_by_category(branch_ids, model, start_date, end_date, voc_types, cs_type):
        sql = DBUtils.load_query('vocs', 'get_vocs_analysis_category.sql')
        params = {'start_date': start_date, 'end_date': end_date, 'branch_ids': branch_ids, 'model': model,
                  'voc_types': voc_types, 'prd_cat': Utils.get_product_categories(cs_type)}
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)

        category = []
        cat_dict = Utils.get_category_dict(voc_types)
        for return_row in return_rows:
            category.append(cat_dict.get(return_row[0], 'Unknown'))

        return dict(category=category, data=return_rows, count=len(return_rows), start_date=start_date,
                    end_date=end_date)

    @staticmethod
    def get_analysis_data_by_product(branch_ids, model, start_date, end_date, voc_types, cs_type):
        sql = DBUtils.load_query('vocs', 'get_vocs_analysis_prd_cat.sql')
        params = {'start_date': start_date, 'end_date': end_date, 'branch_ids': branch_ids, 'model': model,
                  'voc_types': voc_types, 'prd_cat': Utils.get_product_categories(cs_type)}
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)

        category = []
        cat_dict = Utils.get_product_category_dict()
        for return_row in return_rows:
            category.append(cat_dict.get(return_row[0], {}).get('name', 'Unknown'))

        return dict(category=category, data=return_rows, count=len(return_rows), start_date=start_date,
                    end_date=end_date)

    @staticmethod
    def get_analysis_data_by_device(branch_ids, model, start_date, end_date, voc_types, cur_p,
                                    page_size, cs_type):
        # get total count
        sql = DBUtils.load_query('vocs', 'get_vocs_analysis_device_total_count.sql')
        params = {'start_date': start_date, 'end_date': end_date, 'branch_ids': branch_ids, 'model': model,
                  'voc_types': voc_types, 'prd_cat': Utils.get_product_categories(cs_type)}
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)
        total_count = return_rows[0][0]

        # get tab count
        paging_params = ParamsUtils.get_paging_params(cur_p, total_count, page_size)
        params.update(paging_params)
        sql = DBUtils.load_query('vocs', 'get_vocs_analysis_device.sql')
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)

        category = []
        device_to_mkt_name_dict = DeviceController.get_device_to_mkt_name_dict()
        for row in return_rows:
            cat_item = row[0]
            mkt_name = device_to_mkt_name_dict.get(cat_item, "")
            cat_item = cat_item + DeviceController.get_tab_mkt_name(mkt_name)
            category.append(cat_item)

        return dict(category=category, data=return_rows, tot_p=paging_params['total_page'], cur_p=int(cur_p))

    @staticmethod
    def get_dashboard_count(branch_ids, interval_hour):
        sql = DBUtils.load_query('vocs', 'get_vocs_dashboard_count.sql')
        today = date.today()
        params = {'end_date': today, 'branch_ids': branch_ids, 'interval_hour': interval_hour}
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)

        voc_count = {"qna_count": return_rows[0][1],
                     "error_rpt_count": return_rows[1][1],
                     "suggestion_count": return_rows[2][1]}

        return voc_count

    @staticmethod
    def get_excel_tab_data(branch_ids, model, start_date, end_date, period, voc_types, tab_type, cs_type):
        sql = DBUtils.load_query('vocs/tab', 'get_vocs_tab_%s_%s.sql' % (tab_type, period))
        params = {'start_date': start_date, 'end_date': end_date, 'branch_ids': branch_ids, 'model': model,
                  'voc_types': voc_types, 'prd_cat': Utils.get_product_categories(cs_type)}

        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)

        dimension_list = []
        date_list = []
        statistics_dic = {}
        for return_row in return_rows:
            branch_id, date, count = return_row
            if branch_id == 'NUL' or branch_id == 0:
                date_list.append(date)
            dimension_list.append(branch_id)
            statistics_dic[(branch_id, date)] = int(count)
        dimension_list = list(set(dimension_list))
        dimension_list.sort()

        branch_dic = BranchUtils.get_all_branch_dict()

        dimension = ["Date"]
        if tab_type == 'branch':
            for _dimension in dimension_list:
                if _dimension != 0:
                    dimension.append(branch_dic[_dimension])
        elif tab_type == 'device':
            for _dimension in dimension_list:
                if _dimension != 'NUL':
                    dimension.append(_dimension)

        excel_rows = [dimension]

        for _date in date_list:
            row = [_date]
            for _dimension in dimension_list:
                if _dimension != 0 and _dimension != 'NUL':
                    value = statistics_dic.get((_dimension, _date), 0)
                    row.append(value)
            excel_rows.append(row)

        return excel_rows
