SELECT type, yearval || ' ' || weekval || 'W' as yearweek, sumval
FROM
(
	SELECT type, EXTRACT(isoyear FROM dateval) as yearval, EXTRACT(week FROM dateval) as weekval, sum(count) as sumval
	FROM
	(
      (
        SELECT 'Total screen views' as type, (date + INTERVAL '1' DAY)::DATE as dateval, sum(cnt) as count
        FROM v3_more_svc
          WHERE
              date >= '{start_date}'::date
            AND
              date < '{end_date}'::date + INTERVAL '1' DAY
            AND
              branch_id IN {branch_ids}
            AND
              model {model}
        GROUP BY dateval
        ORDER BY dateval
      ) UNION ALL
      (
        SELECT 'Total clicks' as type, (date + INTERVAL '1' DAY)::DATE as dateval, sum(cnt) as count
        FROM v3_more_svc_event
          WHERE
              date >= '{start_date}'::date
            AND
              date < '{end_date}'::date + INTERVAL '1' DAY
            AND
              branch_id IN {branch_ids}
            AND
              model {model}
        GROUP BY dateval
        ORDER BY dateval
      )
	) AS A
	GROUP BY type, yearval, weekval
	ORDER BY type, yearval, weekval
) AS B