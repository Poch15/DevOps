SELECT region
FROM branch
WHERE branch_id = {branch_id}