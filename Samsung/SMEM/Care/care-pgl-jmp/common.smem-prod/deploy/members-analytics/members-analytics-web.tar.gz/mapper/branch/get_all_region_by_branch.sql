SELECT branch_id, region
FROM
branch
ORDER BY branch_id;