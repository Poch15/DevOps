SELECT date_with_timezone, sum(cnt) as cnt
FROM
  (
	  SELECT (datetime + INTERVAL '{interval_hour}' HOUR)::DATE as date_with_timezone, cnt
		FROM {tbl_name}
      WHERE
        datetime >= '{start_date}'::timestamp - INTERVAL '{interval_hour}' HOUR
      AND
        datetime < '{end_date}'::timestamp - INTERVAL '{interval_hour}' HOUR + INTERVAL '1' DAY
      AND
        branch_id IN {branch_ids}
      AND
        model {model}
	) AS A
GROUP BY date_with_timezone
ORDER BY date_with_timezone