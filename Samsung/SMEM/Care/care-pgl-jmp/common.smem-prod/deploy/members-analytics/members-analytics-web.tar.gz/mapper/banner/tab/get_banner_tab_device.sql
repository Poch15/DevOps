SELECT model, SUM(imp_cnt) as imp_cnt, SUM(click_cnt) as click_cnt, ROUND(SUM(imp_cnt) / SUM(SUM(imp_cnt)) OVER() * 100.0, 2) AS percent
FROM v3_banner
WHERE
  date >= '{start_date}'
  AND
  DATE <= '{end_date}'
	AND
  branch_id IN {branch_ids}
	AND
		CASE
    WHEN '{banner_id}' = '0' THEN
      model {model}
    ELSE
      model {model} AND banner_id = '{banner_id}'
    END
GROUP BY model
ORDER BY imp_cnt DESC
LIMIT {limit} OFFSET {offset}