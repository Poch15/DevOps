SELECT COUNT(*)
FROM
(
	SELECT branch_id
	FROM tbl_v2_faq
	WHERE
	  datetime >= '{start_date}'::timestamp - INTERVAL '{interval_hour}' HOUR
	  AND
	  datetime < '{end_date}'::timestamp - INTERVAL '{interval_hour}' HOUR + INTERVAL '1' DAY
		AND
		branch_id IN {branch_ids}
		AND
		model like '{model}%'
	GROUP BY branch_id
) AS A