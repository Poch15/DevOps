from django.conf import settings
from django.db import connections
from common.utils import Utils
from common.dbutils import DBUtils
import os


class BranchController:
    @staticmethod
    def get_all_branch():
        sql = open(os.path.join(settings.MAPPER_DIR, os.path.join('branch', 'get_all_branch.sql')), 'r').read()

        cursor = connections['mysql'].cursor()
        cursor.execute(sql)
        return_row = cursor.fetchall()
        return_row = list(return_row)
        for branch in return_row:
            if branch[0] == 20:
                return_row.remove(branch)
        return return_row

    @staticmethod
    def get_all_branch_ids():
        sql = open(os.path.join(settings.MAPPER_DIR, os.path.join('branch', 'get_all_branch.sql')), 'r').read()

        cursor = connections['mysql'].cursor()
        cursor.execute(sql)
        return_row = cursor.fetchall()
        return_row = Utils.row_to_column(return_row)
        branch_id_list = return_row[0]

        for branch_id in branch_id_list:
            if branch_id == '1' or branch_id == '20':
                branch_id_list.remove(branch_id)

        return branch_id_list

    @staticmethod
    def get_all_branch_ids_except_hq_demo_us():
        sql = open(os.path.join(settings.MAPPER_DIR, os.path.join('branch', 'get_all_branch.sql')), 'r').read()

        cursor = connections['mysql'].cursor()
        cursor.execute(sql)
        return_row = cursor.fetchall()
        return_row = Utils.row_to_column(return_row)
        branch_id_list = return_row[0]

        for branch_id in branch_id_list:
            if branch_id == '1' or branch_id == '4' or branch_id == '20':
                branch_id_list.remove(branch_id)

        return branch_id_list

    @staticmethod
    def get_all_community_branch_ids():
        sql = open(os.path.join(settings.MAPPER_DIR, os.path.join('branch', 'get_community_branch.sql')), 'r').read()

        cursor = connections['mysql'].cursor()
        cursor.execute(sql)
        return_row = cursor.fetchall()
        return_row = Utils.row_to_column(return_row)
        branch_id_list = return_row[0]

        for branch_id in branch_id_list:
            if branch_id == '1' or branch_id == '20':
                branch_id_list.remove(branch_id)

        return branch_id_list

    @staticmethod
    def get_local_time_zone(branch_id):
        sql = open(os.path.join(settings.MAPPER_DIR, os.path.join('branch', 'get_def_timezone.sql')), 'r').read()
        sql_param = {"branch_id": branch_id}

        cursor = connections['mysql'].cursor()
        sql = sql.format(**sql_param)
        cursor.execute(sql)
        return_row = cursor.fetchone()

        return return_row[0]

    @staticmethod
    def get_all_region():
        sql = DBUtils.load_query('branch', 'get_all_region.sql')
        return_row = DBUtils.execute_query(DBUtils.CONFIG_MYSQL, sql, {})
        region_list = []
        for row in return_row:
            region_list.append(row[0])
        return region_list

    @staticmethod
    def get_region(branch_id):
        sql = DBUtils.load_query('branch', 'get_region_by_branch.sql')
        return_row = DBUtils.execute_query(DBUtils.CONFIG_MYSQL, sql, {"branch_id": branch_id})

        return return_row

    @staticmethod
    def get_branch_ids_of_region_by_branch_id(branch_id):
        sql = DBUtils.load_query('branch', 'get_branch_ids_of_region.sql')
        return_row = DBUtils.execute_query(DBUtils.CONFIG_MYSQL, sql, {"branch_id": branch_id})
        region_list = []

        for row in return_row:
            region_list.append(row[0])

        return region_list
