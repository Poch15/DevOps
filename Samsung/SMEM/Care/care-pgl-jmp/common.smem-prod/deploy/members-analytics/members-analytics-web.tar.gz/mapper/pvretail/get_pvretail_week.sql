SELECT EXTRACT(isoyear from datetime::date + INTERVAL '1' DAY) || '/W' ||
        EXTRACT(week from datetime::date + INTERVAL '1' DAY) as yesrweek,
        type, page, event_target, branch_id, cnt
FROM tbl_tmp_pv_retail
WHERE
  type = '{type}'
  AND
  datetime >= '{start_date}'
ORDER BY datetime desc, branch_id, page, event_target