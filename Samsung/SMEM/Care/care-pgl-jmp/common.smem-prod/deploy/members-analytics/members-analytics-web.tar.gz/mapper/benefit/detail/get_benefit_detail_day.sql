SELECT date, type, sum(cnt) as cnt
FROM {tbl_name}
  WHERE
    date >= '{start_date}'
  AND
    date <= '{end_date}'
  AND
    timezone = {timezone}
  AND
    branch_id IN {branch_ids}
  AND
    type IN {event_types}
  AND
    CASE
      WHEN '{event_type}' = '5' THEN
        model {model} AND coupon_id = '{coupon_id}'
      WHEN '{event_type}' = '0' THEN
        model {model} AND (benefit_id != '' OR coupon_id != '')
      ELSE
        model {model} AND benefit_id = '{benefit_id}'
    END
GROUP BY date, type
ORDER BY date, type