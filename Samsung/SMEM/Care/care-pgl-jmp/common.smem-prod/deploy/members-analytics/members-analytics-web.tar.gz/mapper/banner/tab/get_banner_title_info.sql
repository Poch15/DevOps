SELECT b.banner_id, b.title, b.start_dt, b.end_dt, d.img_link_url, b.content_type
FROM banner AS b LEFT JOIN banner_detail AS d
ON b.banner_id = d.banner_id
WHERE
b.banner_id IN {banner_ids}