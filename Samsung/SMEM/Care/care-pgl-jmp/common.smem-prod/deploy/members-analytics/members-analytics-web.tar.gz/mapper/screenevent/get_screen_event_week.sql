SELECT yearval ||' '|| weekval ||'W' as yearweek, sumval as sum
FROM
(
  SELECT EXTRACT(isoyear from date) as yearval, EXTRACT(week from date) as weekval, sum(cnt) as sumval
  FROM
  (
    SELECT date + INTERVAL '1' DAY as date, SUM(cnt) as cnt
    FROM v3_screen_event
    WHERE
      date >= '{start_date}'
    AND
      date <= '{end_date}'
    AND
    CASE
        WHEN '{event_id}' != ''
             THEN branch_id IN {branch_ids} AND event_id = '{event_id}'
        WHEN '{page_id}' != ''
             THEN branch_id IN {branch_ids} AND screen_id = '{page_id}'
        ELSE
             branch_id IN {branch_ids}
    END
    GROUP BY date
    ORDER BY date
  ) as A
  GROUP BY yearval, weekval
  ORDER BY yearval, weekval
) as B