from django.conf import settings
from django.contrib.auth import authenticate, login, logout
from django.http import HttpResponseRedirect
from django.shortcuts import redirect
# Create your views here.
from common.models import Branch
from SessionManager.controls import SessionManagerController


def login_check(request):
    try:
        response = check_role(request)
        if response.get('hasRole') == 'True' and response.get('authenticated') == 'True':
            if request.session.get('branch_name') is None:  # 장고 첫 로그인일때는 세션에 country없음
                SessionManagerController.init_login_session(request, response)
                user = authenticate(username='GalaxyCare', password='vocdev!234')  # 마스터계정으로 로그인하며 화면에 보여주는 부분은 세션으로 컨트롤
                login(request, user)
                return HttpResponseRedirect(settings.HOST)
            else:  # 장고 로그인은 되어 있지만 session 확인필요
                if is_check_branch_name(request, response):
                    return HttpResponseRedirect(settings.HOST)
                else:  # 차이가 있다면 로그아웃
                    return analysis_logout(request)
        else:  # admin 로그인 안되어 있을경우 로그아웃
            return analysis_logout(request)
    except Exception:  # 오류가 있다면 로그아웃 후 admin 페이지로
        return analysis_logout(request)


def analysis_logout(request):
    logout(request)
    return redirect(settings.TOMCAT + "/admin/login")


def check_role(request):
    # ADMIN서버에 로그인한 사람의 session이 유효한지 검사
    # settings.TOMCAT의 경로 + /vocadmin/hasrole/dashboard
    import urllib.request

    session_id = request.COOKIES.get("MEMBERSID")
    if session_id is None:
        return analysis_logout(request)

    url = settings.TOMCAT + '/admin/hasrole/dashboard'
    headers = {'Cookie': 'MEMBERSID=' + str(session_id), }
    req = urllib.request.Request(url=url, headers=headers)
    try:
        response = urllib.request.urlopen(req)
        response = response.read()
        response = response.decode('utf8')
        response = response.replace('false', 'False')
        response = response.replace('true', 'True')
        import ast

        response = ast.literal_eval(response)
    except Exception:
        return HttpResponseRedirect(settings.HOST)  # 받아오기 실패시 메인화면으로 리턴
    return response  # 성공시 { hasRole : true, authenticated : true}


def is_check_branch_name(request, response):
    if response.get('countryCode') == 'HQ':
        branch_name = 'HQ'
    elif 'region' in response:
        branch_name = response.get('region')
    else:
        branch_name = Branch.objects.using("mysql").get(branch_id=int(response.get('branchId'))).branch_name

    if request.session.get('branch_name') == branch_name:  # 차이가 없으면 로그인 되어 있는것
        return True
    else:
        return False
