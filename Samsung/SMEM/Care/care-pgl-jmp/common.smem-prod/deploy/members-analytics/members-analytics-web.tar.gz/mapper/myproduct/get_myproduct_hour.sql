(
SELECT date::text ||' '|| hour || ':00' as date, status, sum(cnt) as cnt
FROM
	(
		SELECT datetime::date as date, status, cnt,
	    CASE  WHEN extract(hour from datetime) < 10 THEN '0'||extract(hour from datetime)::text
			      ELSE extract(hour from datetime)::text
			END as hour
    FROM
      (
	      SELECT datetime, status, sum(cnt) as cnt
	      FROM v3_myproduct_summary
          WHERE
	          datetime >= '{start_date}'::timestamp
	        AND
	          datetime < '{end_date}'::timestamp + INTERVAL '1' DAY
          AND
            branch_id IN {branch_ids}
          AND req_type = {request_type}
          GROUP BY datetime, status
      ) AS A
	) AS B
GROUP BY date, hour, status
ORDER BY date, hour, status
)
UNION ALL
(
  SELECT timestamp::date ||' '|| hour || ':00' as date, '' as status, 0 as sum
  FROM
    (
      SELECT C.timestamp,
      		CASE WHEN EXTRACT(hour from timestamp) < 10 THEN '0' || EXTRACT(hour from timestamp)::text
      				ELSE EXTRACT(hour from timestamp)::text
      		END as hour
      FROM
        (
          SELECT (to_timestamp('{start_date}','YYYY-MM-DD') + interval '1 hour' * (100 * aa.a + 10 * bb.a + cc.a)) as timestamp
          FROM (
                  select 0 as a
                  union all select 1
                  union all select 2
                  union all select 3
                  union all select 4
                  union all select 5
                  union all select 6
                  union all select 7
                  union all select 8
                  union all select 9
                ) as aa cross join
                (
                  select 0 as a
                  union all select 1
                  union all select 2
                  union all select 3
                  union all select 4
                  union all select 5
                  union all select 6
                  union all select 7
                  union all select 8
                  union all select 9
                ) as bb cross join
                (
                  select 0 as a
                  union all select 1
                  union all select 2
                  union all select 3
                  union all select 4
                  union all select 5
                  union all select 6
                  union all select 7
                  union all select 8
                  union all select 9
                ) as cc
        ) AS C
      WHERE C.timestamp < '{end_date}'::date + interval '1' day
    ) AS D
)