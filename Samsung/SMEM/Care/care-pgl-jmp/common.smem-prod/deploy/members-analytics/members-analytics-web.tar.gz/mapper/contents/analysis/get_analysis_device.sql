SELECT model, SUM(cnt) as count, ROUND(SUM(cnt) / SUM(SUM(cnt)) OVER() * 100.0, 2) AS percent
FROM tbl_v2_contents
WHERE
  datetime >= '{start_date}'::timestamp - INTERVAL '{interval_hour}' HOUR
  AND
  datetime < '{end_date}'::timestamp - INTERVAL '{interval_hour}' HOUR + INTERVAL '1' DAY
	AND
	contents_type = {contents_type}
	AND
  branch_id IN {branch_ids}
	AND
		CASE
    WHEN '{contents_id}' = '0' THEN
      model {model}
    ELSE
      model {model} AND contents_id = '{contents_id}'
    END
GROUP BY model
ORDER BY count DESC
LIMIT {limit} OFFSET {offset}