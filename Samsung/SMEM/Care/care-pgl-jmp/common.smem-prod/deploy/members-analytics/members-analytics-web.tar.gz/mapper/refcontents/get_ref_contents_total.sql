SELECT sum(cnt) as total_cnt
FROM {tbl_name}
WHERE
  datetime < '{start_date}'
AND
  model {model}
AND
  branch_id IN {branch_ids}
AND
    CASE
    WHEN '{content_id}' = '0' THEN
      model {model}
    ELSE
      model {model} AND content_id = '{content_id}'
    END