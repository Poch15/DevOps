from django.http import JsonResponse
from django.http import HttpResponse
from functools import wraps
import logging


class ExceptionHandler:

    RETURN_JSON = 'JSON'
    RETURN_HTTP = 'HTTP'

    return_type = None

    def __init__(self, return_type=None):
        self.return_type = return_type

    def __call__(self, function):
        @wraps(function)
        def __wrapper(*args, **kwargs):
            try:
                return function(*args, **kwargs)

            except Exception as e:

                # logging
                logger = logging.getLogger(__name__)
                logger.propagate = False
                logger.exception("ExceptionHandler")

                # return data
                message = str(e)

                if self.return_type == self.RETURN_JSON:
                    return JsonResponse({
                        'error_type': type(e).__name__,
                        'message': message
                    })
                elif self.return_type == self.RETURN_HTTP:
                    return HttpResponse(message)
                else:
                    return message

        return __wrapper
