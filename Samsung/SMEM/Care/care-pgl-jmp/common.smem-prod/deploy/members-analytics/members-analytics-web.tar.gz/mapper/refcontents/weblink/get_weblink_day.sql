SELECT date, source, sum(cnt) AS cnt
FROM v3_contents_weblink
WHERE
    date >= '{start_date}'::timestamp
  AND
    date < '{end_date}'::timestamp + INTERVAL '1' DAY
  AND
    contents_type = {contents_type}
  AND
    branch_id IN {branch_ids}
  AND
    CASE
    WHEN '{contents_id}' = '0' THEN
      model {model}
    ELSE
      model {model} AND contents_id = '{contents_id}'
    END
GROUP BY date, source
ORDER BY date, source