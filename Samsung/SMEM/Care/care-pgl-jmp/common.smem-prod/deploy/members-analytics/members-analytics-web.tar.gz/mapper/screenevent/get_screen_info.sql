SELECT screen_id, screen_name
FROM tbl_v2_screen_pv_info
WHERE
ux_version >= 3
ORDER BY screen_name