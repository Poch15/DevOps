SELECT date, sum(cnt)
FROM v3_search_summary
WHERE
  date >= '{start_date}'::date
AND
  date < '{end_date}'::date + INTERVAL '1' DAY
AND
  branch_id IN {branch_ids}
AND
  model {model}
AND
  source = 0
GROUP BY date
ORDER BY date