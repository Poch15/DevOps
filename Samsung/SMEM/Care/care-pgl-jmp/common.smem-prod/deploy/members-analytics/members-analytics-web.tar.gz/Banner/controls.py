from sys import maxsize
from common.excel_utils import ExcelUtils
from common.dbutils import DBUtils
from common.params_utils import ParamsUtils
from common.utils import Utils
from common.branch_utils import BranchUtils
from common.chart_utils import ChartUtils
from datetime import datetime
from Device.controls import DeviceController


class BannerController:
    @staticmethod
    def get_count_data(start_date, end_date, period, branch_ids, model, banner_id):
        params = {'start_date': start_date, 'end_date': end_date, 'branch_ids': branch_ids, 'model': model, 'banner_id': banner_id}
        sql = DBUtils.load_query('banner', 'get_banner_%s.sql' % period)
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)

        return return_rows

    @staticmethod
    def get_chart_data(start_date, end_date, period, branch_ids, model, banner_id):
        result_rows = BannerController.get_count_data(start_date, end_date, period, branch_ids, model, banner_id)

        # Impression
        imp_left_rows = BannerController.convert_chart_rows(result_rows, 'Impression', 1)
        imp_right_rows = BannerController.convert_chart_total_rows(result_rows, 'Total Impression', 1)
        imp_dict = ChartUtils.wrap_dual_stack_chart_data('Impression', 'Total Impression', imp_left_rows, imp_right_rows)

        # Click
        click_left_rows = BannerController.convert_chart_rows(result_rows, 'Click', 2)
        click_right_rows = BannerController.convert_chart_total_rows(result_rows, 'Total Click', 2)
        ctr_list = BannerController.get_chart_ctr_data(result_rows)
        if click_right_rows.get('data', None) is not None:
            click_right_rows['data'].append({'name': 'CTR', 'data': ctr_list})
        click_dict = ChartUtils.wrap_dual_stack_chart_data('Click', 'Total Click', click_left_rows, click_right_rows)

        return dict(impression=imp_dict, click=click_dict)

    @staticmethod
    def get_chart_ctr_data(return_rows):
        ctr_list = []
        for row in return_rows:
            date, imp_cnt, click_cnt = row
            ctr_list.append(BannerController.get_ctr(imp_cnt, click_cnt))

        return ctr_list

    @staticmethod
    def convert_chart_rows(rows, name, cnt_col_idx):
        category = []
        row_list = []
        for row in rows:
            category.append(row[0])
            row_list.append(int(row[cnt_col_idx]))
        convert = ChartUtils.row_to_column(row_list)

        data = [{"name": name, "data": convert}]
        return dict(category=category, data=data)

    @staticmethod
    def convert_chart_total_rows(rows, name, cnt_col_idx):
        prev_tot_cnt = 0
        category = []
        row_list = []
        for row in rows:
            category.append(row[0])
            count = prev_tot_cnt + int(row[cnt_col_idx])
            row_list.append(count)
            prev_tot_cnt = count
        convert = ChartUtils.row_to_column(row_list)

        data = [{"name": name, "data": convert}]
        return dict(category=category, data=data)

    @staticmethod
    def get_tab_title_data(start_date, end_date, branch_ids, model, cur_p, page_size, order_type='imp_cnt'):
        if order_type == 'banner_id':
            order_type = 'cast(banner_id as integer)'

        params = {'start_date': start_date, 'end_date': end_date, 'branch_ids': branch_ids, 'model': model, 'order_type': order_type}
        sql = DBUtils.load_query('banner/tab', 'get_banner_tab_title_total.sql')
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)
        total_page, tot_imp_cnt, tot_click_cnt = return_rows[0]
        total_cnt_dict = {
            'impression': tot_imp_cnt,
            'click': tot_click_cnt,
            'ctr': BannerController.get_ctr(tot_imp_cnt, tot_click_cnt)
        }

        paging_params = ParamsUtils.get_paging_params(cur_p, total_page, page_size)
        params.update(paging_params)

        sql = DBUtils.load_query('banner/tab', 'get_banner_tab_title.sql')
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)

        branch_list = BannerController.get_branch_list(return_rows)
        title_list = BannerController.get_title_list(return_rows)

        return dict(data=title_list, total=total_cnt_dict,
                    tot_p=paging_params['total_page'], cur_p=int(cur_p), branch_list=branch_list)

    @staticmethod
    def get_tab_device_data(start_date, end_date, branch_ids, model, banner_id, cur_p, page_size):
        params = {'start_date': start_date, 'end_date': end_date, 'branch_ids': branch_ids, 'model': model, 'banner_id': banner_id}
        sql = DBUtils.load_query('banner/tab', 'get_banner_tab_device_total.sql')
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)
        total_count = return_rows[0][0]

        paging_params = ParamsUtils.get_paging_params(cur_p, total_count, page_size)
        params.update(paging_params)
        sql = DBUtils.load_query('banner/tab', 'get_banner_tab_device.sql')
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)

        device_list = []
        device_to_mkt_name_dict = DeviceController.get_device_to_mkt_name_dict()
        for row in return_rows:
            device, imp_cnt, click_cnt, percent = row
            mkt_name = device_to_mkt_name_dict.get(device, "")
            device = device + DeviceController.get_tab_mkt_name(mkt_name)
            device_list.append(device)

        return dict(category=device_list, data=return_rows, tot_p=paging_params['total_page'], cur_p=int(cur_p))

    @staticmethod
    def get_title_list(return_rows):
        banner_ids = [0]
        for row in return_rows:
            id = row[0]
            banner_ids.append(int(id))

        sql = DBUtils.load_query('banner/tab', 'get_banner_title_info.sql')
        params = {'banner_ids': ParamsUtils.convert_list_to_tuple_params(banner_ids)}
        title_rows = DBUtils.execute_query(DBUtils.CONFIG_MYSQL, sql, params)

        title_dict = {}
        for row in title_rows:
            id, title, start_dt, end_dt, img_link_url, content_type = row
            title_dict[id] = (title, start_dt, end_dt, img_link_url, content_type)

        title_list = []
        for row in return_rows:
            banner_id, branch_id, imp_cnt, click_cnt, percent = row
            title, start_dt, end_dt, img_link_url, content_type = title_dict.get(int(banner_id), ('[Untitled]', None, None, None, None))
            ctr = BannerController.get_ctr(imp_cnt, click_cnt)
            title_list.append((banner_id, Utils.get_print_title(title), imp_cnt, click_cnt, ctr,
                               BannerController.get_print_date(start_dt), BannerController.get_print_date(end_dt),
                               percent, img_link_url, BannerController.get_content_type_dict().get(content_type, None)))

        return title_list

    @staticmethod
    def get_branch_list(return_rows):
        branch_dict = BranchUtils.get_all_branch_dict()
        branch_list = []
        for row in return_rows:
            branch_id = row[1]
            branch_list.append(branch_dict.get(branch_id, 'Unknown'))
        return branch_list

    @staticmethod
    def get_print_date(date):
        return "" if date is None else datetime.strftime(date, '%Y-%m-%d')

    @staticmethod
    def get_excel_data(start_date, end_date, period, branch_ids, model, banner_id):
        # Count
        count_excel_rows = [['Date', 'Impression', 'Click']]
        ret_rows = BannerController.get_count_data(start_date, end_date, period, branch_ids, model, banner_id)
        for row in ret_rows:
            date, imp_cnt, click_cnt = row
            count_excel_rows.append([date, imp_cnt, click_cnt])

        # title
        title_excel_rows = [['ID', 'Branch', 'Content Type', 'Title', 'Impression', 'Click', 'CTR', 'Start Date', 'End Date', 'Landing URL']]
        title_dict = BannerController.get_tab_title_data(start_date, end_date, branch_ids, model, 0, maxsize)
        title_list = title_dict.get('data', None)
        branch_list = title_dict.get('branch_list', None)

        for title_row, branch in zip(title_list, branch_list):
            id, title, imp_cnt, click_cnt, ctr, post_date, exp_date, percent, img_link_url, content_type = title_row
            title_excel_rows.append([id, branch, content_type, title, imp_cnt, click_cnt, ctr, post_date, exp_date, img_link_url])

        # Device
        device_excel_rows = [['Device', 'Impression', 'Click']]
        device_dict = BannerController.get_tab_device_data(start_date, end_date, branch_ids, model, banner_id, 0, maxsize)
        device_list = device_dict.get('data', None)

        for row in device_list:
            device, imp_cnt, click_cnt, percent = row
            device_excel_rows.append([device, imp_cnt, click_cnt])

        excel_name = ExcelUtils.get_file_name('banner')
        excel_data = ExcelUtils.multi_list_to_banner_excel(excel_name, banner_id, start_date, end_date,
                                                           count_excel_rows, title_excel_rows, device_excel_rows)

        return excel_data

    @staticmethod
    def get_ctr(imp_cnt, click_cnt):
        ctr = 0
        if imp_cnt != 0 and click_cnt != 0 and imp_cnt is not None and click_cnt is not None:
            ctr = float(round((click_cnt / imp_cnt) * 100, 2))

        return ctr

    @staticmethod
    def get_content_type_dict():
        content_type_dict = {
            0: 'JPG/PNG', 1: 'GIF', 2: 'MP4'
        }
        return content_type_dict
