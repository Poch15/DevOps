SELECT
        CASE WHEN month < 10 THEN year || '/0' || month
             ELSE year || '/' || month
             END as yearmonth, 	sumval
FROM
(
  SELECT EXTRACT (year from date) as year, EXTRACT(month from date) as month,  SUM(cnt) as sumval
    FROM v3_screen_event
    WHERE
        date >= '{start_date}'
    AND
        date <= '{end_date}'
    AND
    CASE
        WHEN '{event_id}' != ''
             THEN branch_id IN {branch_ids} AND event_id = '{event_id}'
        WHEN '{page_id}' != ''
             THEN branch_id IN {branch_ids} AND screen_id = '{page_id}'
        ELSE
             branch_id IN {branch_ids}
    END
  GROUP BY year, month
) AS A
ORDER BY yearmonth
