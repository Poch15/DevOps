from django.http import JsonResponse
from django.shortcuts import render_to_response
from django.template.context import RequestContext
from django.views.decorators.http import require_http_methods
from VOC.controls import VOCController
from VOC.overview_controls import VOCOverviewController
from VOC.tat_controls import TaTController
from common.utils import custom_login_required, access_log
from SessionManager.controls import SessionManagerController
from common.params_utils import ParamsUtils


@custom_login_required
@require_http_methods(["GET"])
@access_log
def view_voc_overview(request):
    template = 'voc/voc_overview.html'
    return render_to_response(template, context_instance=RequestContext(request))


@custom_login_required
@require_http_methods(["GET"])
def get_overview_chart_data(request):
    try:
        return JsonResponse(VOCOverviewController.get_overview_chart_data(
                model=ParamsUtils.get_param(request, "query_model"),
                start_date=request.GET.get("start_date"),
                end_date=request.GET.get("end_date"),
                period=request.GET.get("period"),
                branch_ids=SessionManagerController.get_selected_branch_ids(request)
        ))
    except:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})


@custom_login_required
@require_http_methods(['GET'])
def export_voc_excel_overview(request):
    try:
        return VOCOverviewController.get_overview_excel_data(
                    request,
                    model=ParamsUtils.get_param(request, "query_model"),
                    start_date=request.GET.get("start_date"),
                    end_date=request.GET.get("end_date"),
                    period=request.GET.get("period"),
                    branch_ids=SessionManagerController.get_selected_branch_ids(request)
        )
    except:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})


@custom_login_required
@require_http_methods(['GET'])
def export_voc_excel_country(request):
    try:
        return VOCOverviewController.get_overview_cnty_excel_data(
                    request,
                    model=ParamsUtils.get_param(request, "query_model"),
                    start_date=request.GET.get("start_date"),
                    end_date=request.GET.get("end_date"),
                    period=request.GET.get("period"),
                    branch_ids=SessionManagerController.get_selected_branch_ids(request)
        )
    except:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})


@custom_login_required
@require_http_methods(["GET"])
def get_overview_cnty_chart_data(request):
    try:
        return JsonResponse(VOCOverviewController.get_overview_cnty_chart_data(
                model=ParamsUtils.get_param(request, "query_model"),
                start_date=request.GET.get("start_date"),
                end_date=request.GET.get("end_date"),
                period=request.GET.get("period"),
                branch_ids=SessionManagerController.get_selected_branch_ids(request)
        ))
    except:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})


@custom_login_required
@require_http_methods(["GET"])
def get_overview_cnty_percentage_chart_data(request):
    try:
        return JsonResponse(VOCOverviewController.get_overview_cnty_percentage_chart_data(
                model=ParamsUtils.get_param(request, "query_model"),
                start_date=request.GET.get("start_date"),
                end_date=request.GET.get("end_date"),
                branch_ids=SessionManagerController.get_selected_branch_ids(request)
        ))
    except:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})


@custom_login_required
@require_http_methods(["GET"])
def get_overview_data_by_app(request):
    try:
        return JsonResponse(VOCOverviewController.get_overview_app_chart_data(
                model=ParamsUtils.get_param(request, "query_model"),
                start_date=request.GET.get("start_date"),
                end_date=request.GET.get("end_date"),
                period=request.GET.get("period"),
                branch_ids=SessionManagerController.get_selected_branch_ids(request)
        ))
    except Exception as e:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})


@custom_login_required
@require_http_methods(["GET"])
def get_overview_app_percentage_chart_data(request):
     try:
        return JsonResponse(VOCOverviewController.get_overview_app_percentage_chart_data(
                model=ParamsUtils.get_param(request, "query_model"),
                start_date=request.GET.get("start_date"),
                end_date=request.GET.get("end_date"),
                branch_ids=SessionManagerController.get_selected_branch_ids(request)
        ))
     except Exception as e:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})


@custom_login_required
@require_http_methods(["GET"])
def get_overview_app_excel_data(request):
     try:
        return VOCOverviewController.get_overview_app_excel_data(
                model=ParamsUtils.get_param(request, "query_model"),
                start_date=request.GET.get("start_date"),
                end_date=request.GET.get("end_date"),
                period=request.GET.get("period"),
                branch_ids=SessionManagerController.get_selected_branch_ids(request)
        )
     except:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})


@custom_login_required
@require_http_methods(["GET"])
def get_overview_data_by_device(request):
    try:
        return JsonResponse(VOCOverviewController.get_overview_data_by_device(
                model=ParamsUtils.get_param(request, "query_model"),
                start_date=request.GET.get("start_date"),
                end_date=request.GET.get("end_date"),
                branch_ids=SessionManagerController.get_selected_branch_ids(request)
        ))
    except:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})


@custom_login_required
@require_http_methods(["GET"])
def get_overview_data_by_category(request):
    try:
        return JsonResponse(VOCOverviewController.get_overview_data_by_category(
                model=ParamsUtils.get_param(request, "query_model"),
                start_date=request.GET.get("start_date"),
                end_date=request.GET.get("end_date"),
                branch_ids=SessionManagerController.get_selected_branch_ids(request),
                voc_type=request.GET.get("voc_type")
        ))
    except:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})


@custom_login_required
@require_http_methods(["GET"])
@access_log
def view_voc_detail(request, voc_type):
    template = 'voc/voc_detail.html'

    voc_type_dic = {
        'qna_im': [1, 'Q&A - IM', 'IM'],
        'errorreport': [2, 'Error Report', 'All'],
        'suggestion': [3, 'Suggestion', 'All'],
        'inhouse': [4, 'Inhouse', 'All'],
        'system': [5, 'System', 'All'],
        'retail': [6, 'Retail', 'All'],
        'communityerror': [7, 'Community Error', 'All'],
        'qna_ce': [1, 'Q&A - CE', 'CE'],
    }

    return render_to_response(template, {'voc_type': voc_type_dic[voc_type][0],
                                         'voc_type_name' : voc_type_dic[voc_type][1],
                                         'cs_type': voc_type_dic[voc_type][2]},
                              context_instance=RequestContext(request))


@custom_login_required
@require_http_methods(["GET"])
def get_chart_count_data(request):
    try:
        return JsonResponse(VOCController.get_chart_count_data(
            model=ParamsUtils.get_param(request, "query_model"),
            start_date=request.GET.get("start_date"),
            end_date=request.GET.get("end_date"),
            period=request.GET.get("period"),
            branch_ids=SessionManagerController.get_selected_branch_ids(request),
            voc_types=request.GET.get("voc_types"),
            cs_type=request.GET.get("cs_type")
        ))
    except:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})


@custom_login_required
@require_http_methods(['GET'])
def export_voc_excel(request):
    try:
        return VOCController.get_excel_count_data(
            model=ParamsUtils.get_param(request, "query_model"),
            start_date=request.GET.get("start_date"),
            end_date=request.GET.get("end_date"),
            period=request.GET.get("period"),
            branch_ids=SessionManagerController.get_selected_branch_ids(request),
            voc_type=request.GET.get("voc_types"),
            cs_type=request.GET.get("cs_type")
        )
    except:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})


@custom_login_required
@require_http_methods(["GET"])
def get_analysis_tab_data(request):
    try:
        return JsonResponse(VOCController.get_analysis_tab_data(
            start_date=request.GET.get("start_date"),
            end_date=request.GET.get("end_date"),
            branch_ids=SessionManagerController.get_selected_branch_ids(request),
            model=ParamsUtils.get_param(request, "query_model"),
            tab_type=ParamsUtils.get_param(request, "tab_type"),
            voc_type=ParamsUtils.get_param(request, "voc_types"),
            cur_p=ParamsUtils.get_param(request, "cur_p"),
            page_size=int(ParamsUtils.get_param(request, "page_size")),
            cs_type=request.GET.get("cs_type")
        ))
    except Exception as e:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})


@custom_login_required
@require_http_methods(["GET"])
def get_analysis_data_by_branch(request):
    try:
        return JsonResponse(VOCController.get_analysis_data_by_branch(
            model=ParamsUtils.get_param(request, "query_model"),
            start_date=request.GET.get("start_date"),
            end_date=request.GET.get("end_date"),
            branch_ids=SessionManagerController.get_selected_branch_ids(request),
            voc_types=request.GET.get("voc_types"),
            cur_p=request.GET.get("cur_p"),
            page_size=int(ParamsUtils.get_param(request,"page_size")),
            cs_type=request.GET.get("cs_type")
        ))
    except:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})


@custom_login_required
@require_http_methods(["GET"])
def get_analysis_data_by_device(request):
    try:
        return JsonResponse(VOCController.get_analysis_data_by_device(
            model=ParamsUtils.get_param(request, "query_model"),
            start_date=request.GET.get("start_date"),
            end_date=request.GET.get("end_date"),
            branch_ids=SessionManagerController.get_selected_branch_ids(request),
            voc_types=request.GET.get("voc_types"),
            cur_p=request.GET.get("cur_p"),
            page_size=int(ParamsUtils.get_param(request, "page_size")),
            cs_type=request.GET.get("cs_type")
        ))
    except:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})


@custom_login_required
@require_http_methods(["GET"])
def get_analysis_data_by_category(request):
    try:
        return JsonResponse(VOCController.get_analysis_data_by_category(
            model=ParamsUtils.get_param(request, "query_model"),
            start_date=request.GET.get("start_date"),
            end_date=request.GET.get("end_date"),
            branch_ids=SessionManagerController.get_selected_branch_ids(request),
            voc_types=request.GET.get("voc_types"),
            cs_type=request.GET.get("cs_type")
        ))
    except:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})


@custom_login_required
@require_http_methods(["GET"])
def get_analysis_data_by_product(request):
    try:
        return JsonResponse(VOCController.get_analysis_data_by_product(
            model=ParamsUtils.get_param(request, "query_model"),
            start_date=request.GET.get("start_date"),
            end_date=request.GET.get("end_date"),
            branch_ids=SessionManagerController.get_selected_branch_ids(request),
            voc_types=request.GET.get("voc_types"),
            cs_type=request.GET.get("cs_type")
        ))
    except:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})


@custom_login_required
@require_http_methods(["GET"])
def get_qna_tat_data(request):
    try:
        return JsonResponse(TaTController.get_qna_tat_chart_count(
            model=ParamsUtils.get_param(request, "query_model"),
            start_date=request.GET.get("start_date"),
            end_date=request.GET.get("end_date"),
            period=request.GET.get("period"),
            branch_ids=SessionManagerController.get_selected_branch_ids(request),
            cs_type=request.GET.get("cs_type")
        ))
    except:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})


@custom_login_required
@require_http_methods(['GET'])
def export_tat_excel(request):
    try:
        return TaTController.get_qna_tat_excel_count(
            model=ParamsUtils.get_param(request, "query_model"),
            start_date=request.GET.get("start_date"),
            end_date=request.GET.get("end_date"),
            period=request.GET.get("period"),
            branch_ids=SessionManagerController.get_selected_branch_ids(request),
            cs_type=request.GET.get("cs_type")
        )
    except:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})
