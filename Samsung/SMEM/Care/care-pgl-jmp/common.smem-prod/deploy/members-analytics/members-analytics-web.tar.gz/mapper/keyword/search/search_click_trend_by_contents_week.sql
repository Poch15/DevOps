SELECT yearval || ' ' || weekval || 'W' as yearweek, type, cnt
FROM
(
	SELECT EXTRACT(isoyear FROM date) as yearval, EXTRACT(week FROM date) as weekval, type, sum(cnt) as cnt
	FROM
	(
    SELECT date + INTERVAL '1' DAY as date, type, sum(cnt) as cnt
    FROM v3_search_content
    WHERE
      date >= '{start_date}'::date
    AND
      date < '{end_date}'::date + INTERVAL '1' DAY
    AND
      branch_id IN {branch_ids}
    AND
      model {model}
    GROUP BY date, type
    ORDER BY date, type
  ) as A
  GROUP BY yearval, weekval, type
	ORDER BY yearval, weekval, type
) as B
