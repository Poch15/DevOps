SELECT child_list FROM v3_unique_pv_info
WHERE is_total = true
AND is_use = true
AND id = {page_grp_id}