SELECT banner_id, branch_id, SUM(imp_cnt) as imp_cnt, SUM(click_cnt) as click_cnt, ROUND(SUM(imp_cnt) / SUM(SUM(imp_cnt)) OVER() * 100.0, 2) AS percent
FROM v3_banner
WHERE
    date >= '{start_date}'
    AND
    date <= '{end_date}'
    AND
    branch_id IN {branch_ids}
    AND
    model {model}
GROUP BY banner_id, branch_id
ORDER BY {order_type} DESC
LIMIT {limit} OFFSET {offset}