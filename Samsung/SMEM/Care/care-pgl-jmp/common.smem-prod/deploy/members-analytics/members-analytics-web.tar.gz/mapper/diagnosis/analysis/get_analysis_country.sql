SELECT branch_id, SUM(cnt) as count, ROUND(SUM(cnt) / SUM(SUM(cnt)) OVER() * 100.0, 2) AS percent
FROM {tbl_name}
WHERE
  datetime >= '{start_date}'::timestamp
  AND
  datetime < '{end_date}'::timestamp + INTERVAL '1' DAY
	AND
  branch_id IN {branch_ids}
  AND
  model {model}
GROUP BY branch_id
ORDER BY count DESC
LIMIT {limit} OFFSET {offset}