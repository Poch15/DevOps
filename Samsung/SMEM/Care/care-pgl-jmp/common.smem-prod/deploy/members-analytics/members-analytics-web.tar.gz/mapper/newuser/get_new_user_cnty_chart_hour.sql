SELECT branch_id, date::text ||' '|| hour || ':00' as date, sum(cnt) as cnt
FROM
	(
		SELECT timestamp::date as date, cnt, branch_id,
	    CASE  WHEN extract(hour from timestamp) < 10 THEN '0'||extract(hour from timestamp)::text
			      ELSE extract(hour from timestamp)::text
			END as hour
    FROM
      (
	      SELECT (datetime + INTERVAL '{interval_hour}' HOUR) as timestamp, cnt, branch_id
	      FROM {tbl_name}
          WHERE
	          datetime >= '{start_date}'::timestamp - INTERVAL '{interval_hour}' HOUR
          AND
            datetime < '{end_date}'::timestamp - INTERVAL '{interval_hour}' HOUR + INTERVAL '1' DAY
          AND
            branch_id IN {branch_ids}
      ) AS A
	) AS B
GROUP BY branch_id, date, hour
ORDER BY branch_id, date, hour