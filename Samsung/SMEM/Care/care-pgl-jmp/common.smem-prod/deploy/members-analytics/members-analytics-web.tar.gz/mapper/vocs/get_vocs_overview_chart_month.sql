SELECT
	      CASE WHEN monthval < 10 THEN yearval || '/0' || monthval
			       ELSE yearval || '/' || monthval
			       END as yearmonth,
        main_type, prd_cat, cnt
FROM
  (
    SELECT
      extract(year from dateval) as yearval,
      extract(month from dateval) as monthval,
      main_type, prd_cat, SUM(cnt) as cnt
    FROM
      (
        SELECT
          E.date as dateval,
          COALESCE(B.main_type, 0) as main_type,
          COALESCE(B.prd_cat, 0) as prd_cat,
          COALESCE(B.cnt, 0) as cnt
        FROM
          (
            SELECT date, main_type, prd_cat, SUM(cnt) AS cnt
              FROM v3_feedback
              WHERE
                date >= '{start_date}'
              AND
                date <= '{end_date}'
              AND
                branch_id IN {branch_ids}
              AND
                model {model}
              AND
                main_type IN {main_types}
              GROUP BY date, main_type, prd_cat
          ) AS B RIGHT JOIN
          (
            SELECT *
            FROM
              (
                SELECT C.date
                FROM
                  (
                    SELECT '{start_date}'::date + (100 * aa.a + 10 * bb.a + cc.a) as date
                    FROM (
                            select 0 as a
                            union all select 1
                            union all select 2
                            union all select 3
                            union all select 4
                            union all select 5
                            union all select 6
                            union all select 7
                            union all select 8
                            union all select 9
                          ) as aa cross join
                          (
                            select 0 as a
                            union all select 1
                            union all select 2
                            union all select 3
                            union all select 4
                            union all select 5
                            union all select 6
                            union all select 7
                            union all select 8
                            union all select 9
                          ) as bb cross join
                          (
                            select 0 as a
                            union all select 1
                            union all select 2
                            union all select 3
                            union all select 4
                            union all select 5
                            union all select 6
                            union all select 7
                            union all select 8
                            union all select 9
                          ) as cc
                  ) AS C
                WHERE C.DATE < '{end_date}'::date + interval '1' day
              ) AS D
          ) AS E ON E.date=B.date
      ) AS F
    GROUP BY extract(year from dateval), extract(month from dateval), main_type, prd_cat
    ORDER BY extract(year from dateval), extract(month from dateval), main_type, prd_cat
  ) as C