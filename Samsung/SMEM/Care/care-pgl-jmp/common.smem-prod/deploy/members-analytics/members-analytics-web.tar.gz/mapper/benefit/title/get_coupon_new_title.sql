SELECT c.coupon_hash_id, cc.title, c.cnty_cd FROM coupon_content AS cc JOIN coupon AS c
ON cc.coupon_id = c.coupon_id
WHERE c.coupon_hash_id in {coupon_ids}