SELECT sum(cnt) as myproduct_total_cnt
FROM v3_myproduct_summary
WHERE
  datetime < '{start_date}'
AND
  req_type = {request_type}
AND
  branch_id IN {branch_ids}
AND
  model {model}
AND
  status = 'E0000'