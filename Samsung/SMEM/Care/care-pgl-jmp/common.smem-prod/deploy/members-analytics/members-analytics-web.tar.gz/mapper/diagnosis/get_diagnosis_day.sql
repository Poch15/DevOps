(
    SELECT
      datetime :: DATE,
      {result_type},
      sum(cnt) AS cnt
    FROM {tbl_name}
    WHERE
      datetime >= '{start_date}'
      AND
      datetime < '{end_date}' :: TIMESTAMP + INTERVAL '1' DAY
      AND
      branch_id IN {branch_ids}
      AND
      model {model}
    GROUP BY datetime :: DATE, {result_type}
    ORDER BY datetime :: DATE, {result_type}
  )
  UNION ALL
  (
    SELECT
      date,
      -1 as {result_type},
      0 AS sum
    FROM
      (
        SELECT C.date
        FROM
          (
            SELECT '{start_date}' :: DATE + (100 * aa.a + 10 * bb.a + cc.a) AS date
            FROM (
                   SELECT 0 AS a
                   UNION ALL SELECT 1
                   UNION ALL SELECT 2
                   UNION ALL SELECT 3
                   UNION ALL SELECT 4
                   UNION ALL SELECT 5
                   UNION ALL SELECT 6
                   UNION ALL SELECT 7
                   UNION ALL SELECT 8
                   UNION ALL SELECT 9
                 ) AS aa CROSS JOIN
              (
                SELECT 0 AS a
                UNION ALL SELECT 1
                UNION ALL SELECT 2
                UNION ALL SELECT 3
                UNION ALL SELECT 4
                UNION ALL SELECT 5
                UNION ALL SELECT 6
                UNION ALL SELECT 7
                UNION ALL SELECT 8
                UNION ALL SELECT 9
              ) AS bb
              CROSS JOIN
              (
                SELECT 0 AS a
                UNION ALL SELECT 1
                UNION ALL SELECT 2
                UNION ALL SELECT 3
                UNION ALL SELECT 4
                UNION ALL SELECT 5
                UNION ALL SELECT 6
                UNION ALL SELECT 7
                UNION ALL SELECT 8
                UNION ALL SELECT 9
              ) AS cc
          ) AS C
        WHERE C.DATE < '{end_date}' :: DATE + INTERVAL '1' DAY
      ) AS D
  )