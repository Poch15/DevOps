from django.db import connection, connections
import os
from django.conf import settings


class DBUtils(object):

    CONFIG_POSTGRESQL = "postgresql_read"
    CONFIG_MYSQL = "mysql"

    @staticmethod
    def execute_query(config_name, sql, params):

        # set DB cursor
        cursor = connections[config_name].cursor()

        # change params for sql
        params = DBUtils.change_params(params)

        cursor.execute(sql.format(**params))
        return cursor.fetchall()

    @staticmethod
    def change_params(params):
        if "branch_ids" in params:
            params["branch_ids"] = str(params["branch_ids"]).replace("[", "(").replace("]", ")")

        if "event_types" in params:
            params["event_types"] = str(params["event_types"]).replace("[", "(").replace("]", ")")

        if "model" in params:
            if params["model"] == "all":
                params["model"] = "NOT IN ('')"
            else:
                if "IN" in params["model"]:
                    model_query = ""
                else:
                    model_query = "IN "
                model_query += str(params["model"]).replace("[", "(").replace("]", ")")
                params["model"] = model_query

        if "company_codes" in params:
            params["company_codes"] = str(params["company_codes"]).replace("[", "(").replace("]", ")")

        return params

    @staticmethod
    def get_uv_table_name_by_period(period):
        if period == "hour":
            return "tbl_uv_hourly_summary"
        elif period == "day":
            return "tbl_uv_daily_summary"
        elif period == "week":
            return "tbl_uv_weekly_summary"
        elif period == "month":
            return "tbl_uv_monthly_summary"
        else:
            return ""

    @staticmethod
    def load_query(directory, sql_name):
        sql = open(os.path.join(settings.MAPPER_DIR, os.path.join(directory, sql_name)), 'r').read()
        return sql

    @staticmethod
    def execute_sql_branch_id(sql, **kwargs):
        from django.db import connection
        cursor = connection.cursor()
        cursor.execute(sql, [kwargs['branch_ids']])
        return cursor.fetchall()

    @staticmethod
    def execute_dimension_analysis_data(sql, **kwargs):
        from django.db import connection
        cursor = connection.cursor()

        if 'voc_types' in kwargs:
            cursor.execute(sql, [kwargs['branch_ids'], kwargs['model'], kwargs['voc_types'],
                                 kwargs['interval_hour'], kwargs['start_date'], kwargs['end_date']])
        else:
            cursor.execute(sql, [kwargs['branch_ids'], kwargs['model'],
                                 kwargs['interval_hour'], kwargs['start_date'], kwargs['end_date']])
        return cursor.fetchall()

    @staticmethod
    def execute_dimension_analysis_data_with_limit(sql, **kwargs):
        from django.db import connection
        cursor = connection.cursor()
        if 'voc_types' in kwargs:
            cursor.execute(sql, [kwargs['branch_ids'], kwargs['model'], kwargs['voc_types'],
                             kwargs['interval_hour'], kwargs['start_date'], kwargs['end_date'],
                             kwargs['limit'], kwargs['offset']])
        else:
             cursor.execute(sql, [kwargs['branch_ids'], kwargs['model'],
                                 kwargs['interval_hour'], kwargs['start_date'], kwargs['end_date'],
                                kwargs['limit'], kwargs['offset']])
        return cursor.fetchall()

    @staticmethod
    def execute_cnty_chart_data(sql, **kwargs):
        from django.db import connection
        cursor = connection.cursor()
        cursor.execute(sql, [kwargs['interval_hour'], kwargs['model'], kwargs['branch_ids'], kwargs['interval_hour'],
                             kwargs['start_date'], kwargs['end_date'], kwargs['start_date'], kwargs['end_date']])
        return cursor.fetchall()

    @staticmethod
    def execute_cnty_percentage_data(sql, **kwargs):
        from django.db import connection
        cursor = connection.cursor()
        cursor.execute(sql, [kwargs['model'], kwargs['branch_ids'], kwargs['interval_hour'],
                             kwargs['start_date'], kwargs['end_date']])
        return cursor.fetchall()

