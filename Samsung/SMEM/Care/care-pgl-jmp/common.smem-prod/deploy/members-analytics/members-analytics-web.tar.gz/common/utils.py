import logging

from django.db import connections
from django.http import HttpResponse
from datetime import datetime, timedelta, date
from common.dbutils import DBUtils
import re

logger = logging.getLogger(__name__)


def custom_login_required(func):
    """
    모든 REST API에서 사용할 로그인 확인용 펑션
    :param func: decorate할 function
    :return: 확인된 펑션
    """

    def wrapper(request, *args, **kwargs):
        from Auth.views import analysis_logout, check_role, is_check_branch_name

        response = check_role(request)
        if response.get('hasRole') == 'True' and response.get('authenticated') == 'True':
            if is_check_branch_name(request, response):  # 차이가 없으면 로그인 되어 있는것
                return func(request, *args, **kwargs)
            else:  # 차이가 있다면
                return analysis_logout(request)
        else:
            return analysis_logout(request)

    return wrapper


def access_log(func):
    def wrapper(request, *args, **kwargs):
        try:
            with connections['default'].cursor() as cursor:

                session_key = request.session.session_key

                email = request.session['login_email']
                branch_id = request.session['login_branch_id']
                region = request.session['login_region']
                cnty_cd = request.session['login_country_code']

                user_agent = request.META['HTTP_USER_AGENT']
                view_url = request.get_full_path()

                sql = "INSERT INTO dashboard_access_log (view_url, email, branch_id, cnty_cd, region, user_agent, session_key) " \
                      "VALUES( %s , %s, %s, %s, %s, %s, %s)"

                cursor.execute(sql, [view_url, email, branch_id, cnty_cd, region, user_agent, session_key])
        except Exception as e:
            logger.error(str(e))
            return func(request, *args, **kwargs)

        return func(request, *args, **kwargs)

    return wrapper


class Utils(object):
    @staticmethod
    def list_to_excel(sheet_name, list_data, file_name, agent):
        from openpyxl import Workbook

        wb = Workbook()
        ws = wb.active
        # ws.create_sheet(title=sheet_name)
        for obj in list_data:
            ws.append(obj)
        response = HttpResponse(
            # content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet; application/vnd.ms-excel; application/x-msexcel; charset=utf-8')
            content_type="application/force-download; application/octet-stream; application/download")
        response['Pragma'] = 'no-cache'
        response['Expires'] = 0
        response['Content-Disposition'] = 'attachment; filename=%s' % file_name
        wb.save(response)
        # It's usually a good idea to set the 'Content-Length' header too.
        # You can also set any other required headers: Cache-Control, etc.
        return response

    @staticmethod
    def query_execute(sql, **kwargs):
        from django.db import connection

        cursor = connection.cursor()
        if 'category' in kwargs:
            cursor.execute(sql, [kwargs['start_date'], kwargs['end_date'], kwargs['category'], kwargs['query_model'], kwargs['lang']])
        else:
            if 'au_month_model' in kwargs:
                cursor.execute(sql, [kwargs['query_model'], kwargs['lang'], kwargs['start_date'], kwargs['end_date'], kwargs['au_month_model'],
                                     kwargs['au_month_lang']])
            else:
                cursor.execute(sql, [kwargs['query_model'], kwargs['lang'], kwargs['start_date'], kwargs['end_date']])
        return cursor.fetchall()

    @staticmethod
    def query_execute_with_timezone(sql, **kwargs):
        from django.db import connection

        cursor = connection.cursor()
        if 'category' in kwargs:
            if 'limit' in kwargs:
                cursor.execute(sql, [kwargs['query_model'], kwargs['branch_ids'], kwargs['interval_hour'],
                                     kwargs['start_date'], kwargs['end_date'], kwargs['category'],
                                     kwargs['limit'], kwargs['offset']])
            else:
                cursor.execute(sql, [kwargs['query_model'], kwargs['branch_ids'], kwargs['interval_hour'],
                                     kwargs['start_date'], kwargs['end_date'], kwargs['category']])
        elif 'voc_types' in kwargs:
            cursor.execute(sql, [kwargs['interval_hour'], kwargs['query_model'], kwargs['branch_ids'],
                                 kwargs['interval_hour'], kwargs['start_date'], kwargs['end_date'], kwargs['voc_types'],
                                 kwargs['start_date'], kwargs['end_date']])
        else:
            cursor.execute(sql, [kwargs['interval_hour'], kwargs['query_model'], kwargs['branch_ids'],
                                 kwargs['interval_hour'], kwargs['start_date'], kwargs['end_date']])
        return cursor.fetchall()

    @staticmethod
    def query_execute_dashboard(sql, **kwargs):
        from django.db import connection
        cursor = connection.cursor()

        if 'interval_hour' in kwargs:
            cursor.execute(sql, [kwargs['branch_ids'], kwargs['interval_hour'],kwargs['week_start_date']])
        else:
            cursor.execute(sql, [kwargs['branch_ids']])

        return cursor.fetchone()

    @staticmethod
    def row_to_column(rowlist):
        import numpy as np

        x = np.array(rowlist)
        return x.T.tolist()

    @staticmethod
    def get_category_dict(voc_types=1):
        cat_dict = {}
        if voc_types == '4':
            cat_dict = {1: 'Sales', 2: 'Development/Technology', 3: 'Quality/Service', 4: 'Others'}
        elif voc_types == '6':
            cat_dict = {1: 'Out-store display', 2: 'In-store display', 3: 'Product experience',
                        4: 'Product maintenance', 5: 'Customer service', 6: 'Promotion',
                        7: 'Product proposition', 8: 'Other', 9: 'Strengths', 10: 'Weaknesses'}
        else:
            sql = DBUtils.load_query('vocs', 'get_vocs_analysis_category_name.sql')
            params = {}
            return_rows = DBUtils.execute_query(DBUtils.CONFIG_MYSQL, sql, params)
            for row in return_rows:
                cat_id, cat_name = row
                cat_dict[cat_id] = cat_name
            cat_dict[8] = 'Sensor/Touch'
            cat_dict[0] = 'None'

        return cat_dict

    @staticmethod
    def get_faq_v1_category_dict():
        sql = DBUtils.load_query('faq', 'get_faq_v1_category_name.sql')
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_MYSQL, sql, {})
        cat_dict = dict((x, y) for x, y in return_rows)

        return cat_dict

    @staticmethod
    def get_faq_v2_category_dict():
        sql = DBUtils.load_query('faq', 'get_faq_v2_category_name.sql')
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_MYSQL, sql, {})

        ret_dict = {}
        for cat_id, cat_name, prd_category in return_rows:
            if prd_category == 1:
                ret_dict[cat_id] = '(PHONE/TABLET) ' + cat_name
            elif prd_category == 3:
                ret_dict[cat_id] = '(WATCH) ' + cat_name

        return ret_dict

    @staticmethod
    def get_week_start_date():
        week_start_date = datetime.today()
        week_day = week_start_date.isoweekday()
        week_start_date = (week_start_date - timedelta(days=week_day)).date()

        return week_start_date

    @staticmethod
    def get_date_added_today(days):
        added_date = date.today() - timedelta(days=-days)
        return added_date

    @staticmethod
    def get_paging_params(total_count, cur_page, limit=10):
        offset = int(cur_page) * limit
        total_page = int(total_count / limit)
        if total_count % limit != 0:
            total_page += 1

        paging_params = {'limit': limit, 'offset': offset, 'total_page': total_page}
        return paging_params

    @staticmethod
    def get_all_app_info():
        sql = DBUtils.load_query('vocs', 'get_all_app_info.sql')
        params = {}
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_MYSQL, sql, params)

        app_info_dict = {}
        for row in return_rows:
            app_id, app_name = row
            app_info_dict[app_id] = app_name

        return app_info_dict

    @staticmethod
    def alphanum_key(s):
        """ Turn a string into a list of string and number chunks.
            "z23a" -> ["z", 23, "a"]
        """
        atoi = lambda text: int(text) if text.isdigit() else text
        return [atoi(c) for c in re.split('([0-9]+)', s)]

    @staticmethod
    def get_product_categories(cs_type=None):
        if cs_type == 'IM':
            product_categories = (1, 2, 3)
        elif cs_type == 'CE':
            product_categories = (4, 5, 6, 7, 8, 9, 10)
        else:
            product_categories = (1, 2, 3, 4, 5, 6, 7, 8, 9, 10)

        return product_categories

    @staticmethod
    def get_product_category_dict():
        prd_cat_dict = {
            1: {'name': 'Phone', 'cs_type': 'IM'},
            2: {'name': 'Tablet', 'cs_type': 'IM'},
            3: {'name': 'Smart watch', 'cs_type': 'IM'},
            4: {'name': 'TV', 'cs_type': 'CE'},
            5: {'name': 'Refrigerator', 'cs_type': 'CE'},
            6: {'name': 'Washer', 'cs_type': 'CE'},
            7: {'name': 'Air conditioner', 'cs_type': 'CE'},
            8: {'name': 'Other', 'cs_type': 'CE'},
            9: {'name': 'PC', 'cs_type': 'CE'},
            10: {'name': 'Monitor', 'cs_type': 'CE'}
        }
        return prd_cat_dict

    @staticmethod
    def get_article_type_dict():
        article_type_dict = {
            0: 'NEWS', 1: 'TIPS', 2: 'TUTORIAL', 3: 'SPORTS',
            4: 'COOKING', 5: 'TECHNOLOGY', 6: 'HEALTH'
        }
        return article_type_dict

    @staticmethod
    def get_print_title(title, def_title='[Untitled]'):
        if not title.strip():
            title = def_title

        return title
