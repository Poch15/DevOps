SELECT A.screen_id, A.cnt, A.percent, COALESCE(B.screen_name, A.screen_id) as page_name, B.app_type, B.ux_version
FROM
(
  SELECT screen_id, sum(cnt) as cnt, ROUND(SUM(cnt) / SUM(SUM(cnt)) OVER() * 100.0, 2) AS percent
  FROM {tbl_name}
  WHERE
      date >= '{start_date}'
  AND
      date <= '{end_date}'
  AND
      branch_id IN {branch_ids}
    AND
    model {model}
  GROUP BY screen_id
) AS A LEFT JOIN tbl_v2_screen_pv_info B
ON A.screen_id = B.screen_id
ORDER BY cnt desc
LIMIT {limit} OFFSET {offset}