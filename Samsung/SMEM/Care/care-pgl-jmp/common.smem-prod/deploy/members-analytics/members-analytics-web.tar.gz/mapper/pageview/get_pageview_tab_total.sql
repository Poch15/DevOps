SELECT count(*)
FROM
(
  SELECT {tab_type}, sum(cnt) as cnt
	FROM
	(
    SELECT {tab_type}, screen_id, sum(cnt) as cnt
    FROM {tbl_name}
    WHERE
        date >= '{start_date}'
    AND
        date <= '{end_date}'
    AND
        branch_id IN {branch_ids}
    AND
      CASE
        WHEN '{page_id}' = '' THEN
          model {model}
        ELSE
          model {model} AND screen_id = '{page_id}'
      END
    GROUP BY {tab_type}, screen_id
    ) AS A
	GROUP BY {tab_type}
) AS C