SELECT yearval ||' '|| weekval ||'W' as yearweek, sumval as sum
FROM
  (
    SELECT extract(isoyear from dateval) as yearval, extract(week from dateval) as weekval, sum(cnt) as sumval
    FROM
      (
        SELECT date_with_timezone + interval '1' day as dateval, sum(A.cnt) as cnt
        FROM
          (
            SELECT (datetime + INTERVAL '{interval_hour}' HOUR)::DATE as date_with_timezone, cnt
            FROM {tbl_name}
            WHERE
	            datetime >= '{start_date}'::timestamp - INTERVAL '{interval_hour}' HOUR
	          AND
	            datetime < '{end_date}'::timestamp - INTERVAL '{interval_hour}' HOUR + INTERVAL '1' DAY
            AND
              branch_id IN {branch_ids}
          ) as A
        GROUP BY date_with_timezone
        ORDER BY date_with_timezone
      ) as B
    GROUP BY extract(isoyear from dateval), extract(week from dateval)
    ORDER BY extract(isoyear from dateval), extract(week from dateval)
  ) as C