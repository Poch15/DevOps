from common.dbutils import DBUtils
from Rest import datetime_util

MAIN_TYPE_LIST = ['none', 'opinion', 'error', 'qna', 'inhouse', 'system', 'retail',
                  'community_error', 'community_opinion']
SUB_TYPE_LIST = ['none', 'appfeedback', 'appbeta', 'osbeta', 'osbeta_app']


class FeedbackRestController:
    @staticmethod
    def get_fb_recent_month_info(main_type, sub_type, branch_id, beta_prj_id):
        last_hour_dt = FeedbackRestController.get_last_hour_dt()
        closed_count = FeedbackRestController.get_fb_recent_month_closed_count(main_type, sub_type, branch_id,
                                                                               beta_prj_id, last_hour_dt)
        opened_green_count = FeedbackRestController.get_fb_recent_month_opened_count(main_type, sub_type, branch_id,
                                                                                     beta_prj_id, last_hour_dt, 7, 0)
        opened_yellow_count = FeedbackRestController.get_fb_recent_month_opened_count(main_type, sub_type, branch_id,
                                                                                      beta_prj_id, last_hour_dt, 14, 7)
        opened_red_count = FeedbackRestController.get_fb_recent_month_opened_count(main_type, sub_type, branch_id,
                                                                                   beta_prj_id, last_hour_dt, 30, 14)
        all_count = closed_count + opened_green_count + opened_yellow_count + opened_red_count

        try:
            closed_percent = round(closed_count / all_count * 100,  2)
        except ZeroDivisionError as e:
            closed_percent = 0

        fb_recent_month_count_dict = {
            'allCount': all_count,
            'closedCount': closed_count,
            'openedGreenCount': opened_green_count,
            'openedYellowCount': opened_yellow_count,
            'openedRedCount': opened_red_count,
            'closedPercent': closed_percent,
            'lastHourDt': last_hour_dt
        }

        return fb_recent_month_count_dict

    @staticmethod
    def get_last_hour_dt():
        last_hour_result = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL,
                                             "SELECT MAX(crt_dt) FROM tbl_v2_fb_recent_month", {})
        last_hour_dt = datetime_util.get_last_hour_dt(last_hour_result)
        return last_hour_dt

    @staticmethod
    def get_sub_types(sub_type):
        sub_types = SUB_TYPE_LIST.index(sub_type)
        if sub_type == 'none' or sub_type == 'appfeedback':
            sub_types = (SUB_TYPE_LIST.index('none'), SUB_TYPE_LIST.index('appfeedback'))
        elif sub_type == 'appbeta':
            sub_types = (SUB_TYPE_LIST.index('appbeta'), SUB_TYPE_LIST.index('appbeta'))
        elif sub_type == 'osbeta' or sub_type == 'osbeta_app':
            sub_types = (SUB_TYPE_LIST.index('osbeta'), SUB_TYPE_LIST.index('osbeta_app'))

        return sub_types

    @staticmethod
    def get_fb_recent_month_closed_count(main_type, sub_type, branch_id, beta_prj_id, last_hour_dt):
        closed_count_sql = DBUtils.load_query('rest/feedback', 'get_fb_recent_month_closed_count.sql')
        start_date, end_date = datetime_util.get_range_datetime(last_hour_dt, 30, 0)
        sub_types = FeedbackRestController.get_sub_types(sub_type)
        params = {'main_type': MAIN_TYPE_LIST.index(main_type), 'sub_type': sub_types, 'branch_id': branch_id,
                  'beta_prj_id': beta_prj_id, 'start_date': start_date, 'end_date': end_date}
        closed_count = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, closed_count_sql, params)

        return closed_count[0][0]

    @staticmethod
    def get_fb_recent_month_opened_count(main_type, sub_type, branch_id, beta_prj_id,
                                         last_hour_dt, start_delta_days, end_delta_days):
        opened_count_sql = DBUtils.load_query('rest/feedback', 'get_fb_recent_month_opened_count.sql')
        start_date, end_date = datetime_util.get_range_datetime(last_hour_dt, start_delta_days, end_delta_days)
        sub_types = FeedbackRestController.get_sub_types(sub_type)
        params = {'main_type': MAIN_TYPE_LIST.index(main_type), 'sub_type': sub_types, 'branch_id': branch_id,
                  'beta_prj_id': beta_prj_id, 'start_date': start_date, 'end_date': end_date}
        opened_count = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, opened_count_sql, params)

        return opened_count[0][0]