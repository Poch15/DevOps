SELECT
        CASE WHEN month < 10 THEN year || '/0' || month
             ELSE year || '/' || month
             END as yearmonth, 	sumval, home
FROM
(
  SELECT EXTRACT (year from date) as year, EXTRACT(month from date) as month,  SUM(cnt) as sumval, home
  FROM {tbl_name}
    WHERE
      date >= '{start_date}'
    AND
      date <= '{end_date}'
    AND
      timezone = {timezone}
    AND
      branch_id IN {branch_ids}
    AND
      CASE
      WHEN '{benefit_id}' = '0' THEN
        model {model} AND benefit_id != ''
      ELSE
        model {model} AND benefit_id = '{benefit_id}'
      END
  GROUP BY date, home
  ORDER BY date, home
) AS A