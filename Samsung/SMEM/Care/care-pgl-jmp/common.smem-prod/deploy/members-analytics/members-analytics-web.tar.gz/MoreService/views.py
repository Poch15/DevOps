from django.http import JsonResponse
from django.shortcuts import render_to_response
from django.template.context import RequestContext
from django.views.decorators.http import require_http_methods
from MoreService.controls import MoreServiceController
from common.utils import custom_login_required, access_log
from common.params_utils import ParamsUtils
from SessionManager.controls import SessionManagerController
from common.exception_handler import ExceptionHandler


@ExceptionHandler(return_type=ExceptionHandler.RETURN_HTTP)
@custom_login_required
@require_http_methods(["GET"])
@access_log
def view(request):
    template = 'moreservice/moreservice.html'
    return render_to_response(template, context_instance=RequestContext(request))


@custom_login_required
@require_http_methods(["GET"])
def get_pageview(request):
    try:
        chart_data = MoreServiceController.get_total_view(
            start_date=ParamsUtils.get_param(request, "start_date"),
            end_date=ParamsUtils.get_param(request, "end_date"),
            period=ParamsUtils.get_param(request, "period"),
            model=ParamsUtils.get_param(request, "query_model"),
            branch_ids=SessionManagerController.get_selected_branch_ids(request)
        )
        return JsonResponse(chart_data)
    except Exception as e:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})


@custom_login_required
@require_http_methods(["GET"])
def get_clicks_by_service_and_status(request):
    try:
        chart_data = MoreServiceController.get_clicks_by_service_and_status(
            start_date=ParamsUtils.get_param(request, "start_date"),
            end_date=ParamsUtils.get_param(request, "end_date"),
            period=ParamsUtils.get_param(request, "period"),
            model=ParamsUtils.get_param(request, "query_model"),
            branch_ids=SessionManagerController.get_selected_branch_ids(request)
        )
        return JsonResponse(chart_data)
    except Exception as e:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})


@custom_login_required
@require_http_methods(["GET"])
def get_clicks_by_service(request):
    try:
        chart_data = MoreServiceController.get_clicks_by_service(
            start_date=ParamsUtils.get_param(request, "start_date"),
            end_date=ParamsUtils.get_param(request, "end_date"),
            period=ParamsUtils.get_param(request, "period"),
            model=ParamsUtils.get_param(request, "query_model"),
            branch_ids=SessionManagerController.get_selected_branch_ids(request)
        )
        return JsonResponse(chart_data)
    except Exception as e:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})


@custom_login_required
@require_http_methods(["GET"])
def get_excel_data(request):
    try:
        chart_data = MoreServiceController.get_excel_data(
            start_dt=ParamsUtils.get_param(request, "start_date"),
            end_dt=ParamsUtils.get_param(request, "end_date"),
            period=ParamsUtils.get_param(request, "period"),
            model=ParamsUtils.get_param(request, "query_model"),
            branch_ids=SessionManagerController.get_selected_branch_ids(request)
        )
        return chart_data
    except Exception as e:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})
