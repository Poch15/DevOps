SELECT date, keyword, rank, cnt
FROM
  v3_keyword_dict as dict
JOIN
(
  SELECT date, keyword_idx, rank, cnt
  FROM
    (
      SELECT date, keyword_idx, rank() OVER (PARTITION BY date ORDER BY sum(cnt) DESC) as rank, sum(cnt) as cnt
      FROM v3_keyword
      WHERE
        date >= '{start_date}'
      AND
        date < '{end_date}'::timestamp + INTERVAL '1' DAY
      AND
        source = {source}
      AND
        branch_id IN {branch_ids}
      AND
        model {model}
      GROUP BY date, keyword_idx
    ) ranked_scores
  WHERE rank <= 100
  ) as rank_summary
  ON rank_summary.keyword_idx = dict.id
ORDER BY date, rank