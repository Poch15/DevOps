import http.client
import json
from django.conf import settings
from django.db import connections
import os

from common.branch_utils import BranchUtils


class ResponseException(Exception):
    def __init__(self, status):
        self.status = status


class BenefitTitle:
    COUPON = "COUPON"
    OFFER = "OFFER"

    EU = "EU"
    CIS = "CIS"
    LA = "LA"
    NA = "NA"
    AP = "AP"

    DOMAIN = {
        EU: settings.LOYALTY_DOMAIN_EU,
        CIS: settings.LOYALTY_DOMAIN_EU,
        LA: settings.LOYALTY_DOMAIN_US,
        NA: settings.LOYALTY_DOMAIN_US,
        AP: settings.LOYALTY_DOMAIN_AP
    }

    def __init__(self):
        self.headers = {
            "auth": settings.BENEFIT_API_KEY,
            "cache-control": "no-cache",
            "content-type": "application/json"
        }
        self.offer_url = settings.LOYALTY_OFFER_URL
        self.coupon_url = settings.LOYALTY_COUPON_URL

    @staticmethod
    def is_eu_region(region):
        return BenefitTitle.EU == region or BenefitTitle.CIS == region

    @staticmethod
    def is_us_region(region):
        return BenefitTitle.NA == region or BenefitTitle.LA == region

    def get_title_dict(self, obj, object_ids):
        eu_objects = list()
        us_objects = list()
        ap_objects = list()
        region_dict = BranchUtils.get_all_region_dict()

        for row in object_ids:
            obj_id, branch_id = row
            region = region_dict.get(branch_id, None)
            if BenefitTitle.is_eu_region(region):
                eu_objects.append(obj_id)
            elif BenefitTitle.is_us_region(region):
                us_objects.append(obj_id)
            else:
                ap_objects.append(obj_id)

        ret_dict = dict()
        if len(eu_objects) > 0:
            ret_dict.update(self.__get_title_dict(obj, BenefitTitle.DOMAIN[BenefitTitle.EU], eu_objects))
        if len(us_objects) > 0:
            ret_dict.update(self.__get_title_dict(obj, BenefitTitle.DOMAIN[BenefitTitle.LA], us_objects))
        if len(ap_objects) > 0:
            ret_dict.update(self.__get_title_dict(obj, BenefitTitle.DOMAIN[BenefitTitle.AP], ap_objects))

        return ret_dict

    def __get_title_dict(self, obj, host, objects):
        if BenefitTitle.OFFER == obj:
            return self.__get_offer_title_dict(host, objects)
        elif BenefitTitle.COUPON == obj:
            return self.__get_coupon_title_dict(host, objects)

    def __get_offer_title_dict(self, host, body):
        title_dict = dict()
        try:
            if settings.PROXY_HOST is None:
                conn = http.client.HTTPSConnection(host)
            else:
                conn = http.client.HTTPSConnection(settings.PROXY_HOST, settings.PROXY_PORT)
                conn.set_tunnel(host)

            conn.request("POST", self.offer_url, json.dumps(body), self.headers)
            response = conn.getresponse()
            if not 200 <= response.status < 300:
                raise ResponseException(response.status)
            data = json.loads(response.read().decode('utf-8'))

            offers = data['detail']['offerTitleList']
            for offer in offers:
                title_dict[offer['offerId']] = (offer['offerTitle'], offer['countryCode'])

        except ResponseException as e:
            print("get_offer_title_dict() exception")
            print("HTTP Response Status : " + str(e.status))
        except Exception as e:
            print("get_offer_title_dict() exception : " + str(e))

        return title_dict

    def __get_coupon_title_dict(self, host, body):
        title_dict = {}
        try:
            if settings.PROXY_HOST is None:
                conn = http.client.HTTPSConnection(host)
            else:
                conn = http.client.HTTPSConnection(settings.PROXY_HOST, settings.PROXY_PORT)
                conn.set_tunnel(host)

            conn.request("POST", self.coupon_url, json.dumps(body), self.headers)
            response = conn.getresponse()
            if not 200 <= response.status < 300:
                raise ResponseException(response.status)
            data = json.loads(response.read().decode('utf-8'))

            coupons = data['detail']['couponTitleList']
            for coupon in coupons:
                title_dict[coupon['couponId']] = (coupon['couponTitle'], coupon['countryCode'])

        except ResponseException as e:
            print("get_coupon_title_dict() exception")
            print("HTTP Response Status : " + str(e.status))
        except Exception as e:
            print("get_coupon_title_dict() exception : " + str(e))

        return title_dict


class BenefitUtils:
    @staticmethod
    def get_tbl_info(page_type, period):
        tbl_info_dic = {
            'benefit': {
                'day': 'tbl_v2_bnf_daily',
                'week': 'tbl_v2_bnf_weekly',
                'month': 'tbl_v2_bnf_monthly'
            },
            'detail': {
                'day': 'tbl_v2_bnf_detail_daily',
                'week': 'tbl_v2_bnf_detail_weekly',
                'month': 'tbl_v2_bnf_detail_monthly'
            }
        }

        return tbl_info_dic[page_type][period]

    @staticmethod
    def get_event_type_dict():
        event_type_dict = {1: 'Play', 2: 'View Detail', 3: 'Call', 4: 'Download Coupon', 5: 'View Coupon'}
        return event_type_dict


class BenefitNewTitle:
    @staticmethod
    def get_new_benefit_title_dict(obj, object_ids):
        title_dict = dict()

        if object_ids is not None and len(object_ids) > 0:

            cursor = connections["mysql_benefit"].cursor()

            object_ids = str(object_ids).replace("[", "(").replace("]", ")")

            if BenefitTitle.OFFER == obj:
                sql_param = {"campaign_ids": object_ids}
                sql = open(os.path.join(settings.MAPPER_DIR, os.path.join('benefit', 'title/get_benefit_new_title.sql')), 'r').read()
            elif BenefitTitle.COUPON == obj:
                sql_param = {"coupon_ids": object_ids}
                sql = open(os.path.join(settings.MAPPER_DIR, os.path.join('benefit', 'title/get_coupon_new_title.sql')), 'r').read()

            sql = sql.format(**sql_param)
            cursor.execute(sql)
            return_row = cursor.fetchall()

            for row in return_row:
                title_dict[row[0]] = (row[1], row[2])

        return title_dict
