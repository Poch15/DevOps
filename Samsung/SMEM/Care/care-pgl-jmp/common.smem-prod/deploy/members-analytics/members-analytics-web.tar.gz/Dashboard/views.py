from django.http import JsonResponse
from django.views.decorators.http import require_http_methods
from NewUser.controls import NewUserController
from UniqueVisitor.controls import UniqueVisitorController
from VOC.controls import VOCController
from common.utils import custom_login_required
from SessionManager.controls import SessionManagerController
from VOC.overview_controls import VOCOverviewController
from Keyword.controls import KeywordController


@custom_login_required
@require_http_methods(["GET"])
def get_dashboard_weekly_newuser_count(request):
    try:
        selected_branch_ids = SessionManagerController.get_selected_branch_ids(request)
        selected_time_zone = SessionManagerController.get_selected_time_zone(request)

        newuser_weekly_count = NewUserController.get_dashboard_weekly_data(selected_branch_ids, selected_time_zone)
        return JsonResponse(dict(newuser_weekly_count= newuser_weekly_count))
    except Exception as e:
        return JsonResponse({'status': 'fail', 'message': '%s' % e})


@custom_login_required
@require_http_methods(["GET"])
def get_dashboard_total_newuser_count(request):
    try:
        selected_branch_ids = SessionManagerController.get_selected_branch_ids(request)
        selected_time_zone = SessionManagerController.get_selected_time_zone(request)

        newuser_total_count = NewUserController.get_dashboard_total_data(selected_branch_ids, selected_time_zone)
        return JsonResponse(dict(newuser_total_count=newuser_total_count))
    except Exception as e:
        return JsonResponse({'status': 'fail', 'message': '%s' % e})


@custom_login_required
@require_http_methods(["GET"])
def get_dashboard_weekly_uniquevisitor_count(request):
    try:
        selected_branch_ids = SessionManagerController.get_selected_branch_ids(request)
        selected_time_zone = SessionManagerController.get_selected_time_zone(request)

        uv_weekly_count = UniqueVisitorController.get_dashboard_count_data(selected_branch_ids, selected_time_zone)
        return JsonResponse(dict(uv_weekly_count=uv_weekly_count))
    except Exception as e:
        return JsonResponse({'status': 'fail', 'message': '%s' % e})


@custom_login_required
@require_http_methods(["GET"])
def get_dashboard_voc_total_count(request):
    try:
        selected_branch_ids = SessionManagerController.get_selected_branch_ids(request)
        selected_time_zone = SessionManagerController.get_selected_time_zone(request)
        voc_count_list = VOCController.get_dashboard_count(selected_branch_ids, selected_time_zone)
        return JsonResponse(dict(qna_count=voc_count_list['qna_count'],
                                 error_rpt_count=voc_count_list['error_rpt_count'],
                                 suggestion_count=voc_count_list['suggestion_count']))
    except Exception as e:
        return JsonResponse({'status': 'fail', 'message': '%s' % e})


@custom_login_required
@require_http_methods(["GET"])
def get_dashboard_overview_voc_count(request):
    try:
        return JsonResponse(VOCOverviewController.get_overview_dashboard_chart_data(
            branch_ids=SessionManagerController.get_selected_branch_ids(request),
            start_date=request.GET.get("start_date"),
            end_date=request.GET.get("end_date")
        ))
    except Exception as e:
        return JsonResponse({'status': 'fail', 'message': '%s' % e})


@custom_login_required
@require_http_methods(["GET"])
def get_dashboard_keyword_count(request):
    try:
        return JsonResponse(KeywordController.get_dashboard_chart_data(
            start_date=request.GET.get("start_date"),
            end_date=request.GET.get("end_date"),
            branch_name=SessionManagerController.get_selected_branch_name(request),
            source=0,
            period="day"
        ))
    except Exception as e:
        return JsonResponse({'status': 'fail', 'message': '%s' % e})
