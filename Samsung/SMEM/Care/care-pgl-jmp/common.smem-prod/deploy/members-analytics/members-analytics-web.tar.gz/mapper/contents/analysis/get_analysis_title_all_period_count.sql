SELECT contents_id, branch_id, sum(cnt) as cnt
FROM tbl_v2_contents_total_count
WHERE
  contents_type = {contents_type}
  AND
  contents_id IN {contents_ids}
  AND
  branch_id IN {branch_ids}
  AND
  model {model}
GROUP BY contents_id, branch_id