SELECT
    cat_id,
    CASE WHEN monthval < 10 THEN yearval || '/0' || monthval
			   ELSE yearval || '/' || monthval
		END as yearmonth,
		cnt
FROM
  (
    SELECT cat_id, extract(year from dateval) as yearval, extract(month from dateval) as monthval, sum(cnt) as cnt
    FROM
      (
          (
            SELECT cat_id, date as dateval, sum(cnt) as cnt
            FROM
              (
                SELECT cat_id, datetime::DATE as date, cnt
                FROM v3_diagnosis_auto_detail
                WHERE
                  datetime >= '{start_date}'::timestamp
                AND
                  datetime < '{end_date}'::timestamp + INTERVAL '1' DAY
                AND
                  result = 0
                AND
                  model {model}
                AND
                  branch_id IN {branch_ids}
              ) AS A
            GROUP BY cat_id, date
            ORDER BY cat_id, date
          )
          UNION ALL
          (
	          SELECT 0 as cat_id, date, 0 as sum
            FROM
              (
                SELECT C.date
                FROM
                  (
                    SELECT '{start_date}'::date + (100 * aa.a + 10 * bb.a + cc.a) as date
                    FROM (
                            select 0 as a
                            union all select 1
                            union all select 2
                            union all select 3
                            union all select 4
                            union all select 5
                            union all select 6
                            union all select 7
                            union all select 8
                            union all select 9
                          ) as aa cross join
                          (
                            select 0 as a
                            union all select 1
                            union all select 2
                            union all select 3
                            union all select 4
                            union all select 5
                            union all select 6
                            union all select 7
                            union all select 8
                            union all select 9
                          ) as bb cross join
                          (
                            select 0 as a
                            union all select 1
                            union all select 2
                            union all select 3
                            union all select 4
                            union all select 5
                            union all select 6
                            union all select 7
                            union all select 8
                            union all select 9
                          ) as cc
                  ) AS C
                WHERE C.DATE < '{end_date}'::date + interval '1' day
              ) AS D
          )
      ) AS F
    GROUP BY cat_id, extract(year from dateval), extract(month from dateval)
    ORDER BY cat_id, extract(year from dateval), extract(month from dateval)
  ) AS G