SELECT extract(year from date) || '/' || LPAD(extract(month from date)::TEXT, 2, '0' ) as yearmonth, app_id, sum(cnt)
FROM
  (
    SELECT date, app_id, cnt
    FROM v3_feedback
    WHERE
      date >= '{start_date}'
    AND
      date <= '{end_date}'
    AND
      branch_id IN {branch_ids}
    AND
      model {model}
    AND
      main_type IN {main_types}
  ) AS A
GROUP BY yearmonth, app_id
ORDER BY yearmonth, app_id
