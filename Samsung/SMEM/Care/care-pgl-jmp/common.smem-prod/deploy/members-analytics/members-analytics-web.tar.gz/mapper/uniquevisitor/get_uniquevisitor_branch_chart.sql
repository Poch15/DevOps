SELECT branch_id, sum(cnt) as count, ROUND(SUM(cnt) / SUM(SUM(cnt)) OVER() * 100.0, 2) AS percent
FROM {tbl_name}
WHERE
      date = '{date} '::timestamp - INTERVAL '{interval_hour}' HOUR
    AND
      timezone = '{timezone}'
    AND
      branch_id IN {branch_ids}
GROUP BY branch_id
ORDER BY count DESC