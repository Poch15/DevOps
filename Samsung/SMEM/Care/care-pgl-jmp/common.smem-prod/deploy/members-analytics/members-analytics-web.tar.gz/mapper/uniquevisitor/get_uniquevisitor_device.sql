SELECT model, sum(cnt) as count, ROUND(SUM(cnt) / SUM(SUM(cnt)) OVER() * 100.0, 2) AS percent
FROM {tbl_name}
WHERE
      date = '{date} '::timestamp - INTERVAL '{interval_hour}' HOUR
    AND
      timezone = '{timezone}'
    AND
      branch_id IN {branch_ids}
    AND
      model {model}
GROUP BY model
ORDER BY count DESC
LIMIT {limit} OFFSET {offset}