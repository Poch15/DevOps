SELECT branch_id, SUM(cnt) AS COUNT, ROUND(SUM(cnt) / SUM(SUM(cnt)) OVER() * 100.0, 2) AS percent
FROM {tbl_name}
  WHERE
    datetime >= '{start_date}'::timestamp - INTERVAL '{interval_hour}' HOUR
  AND
    datetime < '{end_date}'::timestamp - INTERVAL '{interval_hour}' HOUR + INTERVAL '1' DAY
  AND
    branch_id IN {branch_ids}
  AND
    model {model}
GROUP BY branch_id
ORDER BY SUM(cnt) DESC