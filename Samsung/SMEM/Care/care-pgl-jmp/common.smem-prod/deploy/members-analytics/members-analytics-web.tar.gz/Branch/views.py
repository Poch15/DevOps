from django.http import JsonResponse
from django.views.decorators.http import require_http_methods
from common.utils import Utils, custom_login_required
from Branch.controls import BranchController
from django.http import HttpResponse
import json


@custom_login_required
@require_http_methods(["GET"])
def get_all_branch(request):
    try:
        response_data = []

        branch_list = BranchController.get_all_branch()
        for branch in branch_list:
            response_record = {'branch_id': branch[0], 'branch_name': branch[1]}
            response_data.append(response_record)

        return HttpResponse(json.dumps(response_data), content_type='application/json')
    except Exception:
        return JsonResponse(dict(status='fail', message='parameter error'))
