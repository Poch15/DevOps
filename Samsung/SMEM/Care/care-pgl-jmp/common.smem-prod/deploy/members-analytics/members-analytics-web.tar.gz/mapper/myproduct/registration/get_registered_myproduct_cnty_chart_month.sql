select yearmonth, company_cd, sum(cnt) as cnt
  from
(
  SELECT
    CASE WHEN monthval < 10
      THEN yearval || '/0' || monthval
    ELSE yearval || '/' || monthval
    END AS yearmonth,
    company_cd,
    cnt
  FROM
    (
      SELECT
        extract(YEAR FROM dateval)  AS yearval,
        extract(MONTH FROM dateval) AS monthval,
        company_cd,
        sum(cnt)                    AS cnt
      FROM
        (
          (
            SELECT
              date     AS dateval,
              company_cd,
              sum(cnt) AS cnt
            FROM
              (
                SELECT date, company_cd, cnt
                FROM  v3_mp_product
                WHERE
                  date >= '{start_date}' :: TIMESTAMP
                AND
                  date < '{end_date}' :: TIMESTAMP + INTERVAL '1' DAY
                AND
                  company_cd IN {company_codes}
              ) AS A
            GROUP BY date, company_cd
            ORDER BY date, company_cd
          )
          UNION ALL
          (
            SELECT
              date,
              '' as company_cd,
              0  AS sum
            FROM
              (
                SELECT C.date
                FROM
                  (
                    SELECT '{start_date}' :: DATE + (100 * aa.a + 10 * bb.a + cc.a) AS date
                    FROM (
                           SELECT 0 AS a
                           UNION ALL SELECT 1
                           UNION ALL SELECT 2
                           UNION ALL SELECT 3
                           UNION ALL SELECT 4
                           UNION ALL SELECT 5
                           UNION ALL SELECT 6
                           UNION ALL SELECT 7
                           UNION ALL SELECT 8
                           UNION ALL SELECT 9
                         ) AS aa CROSS JOIN
                      (
                        SELECT 0 AS a
                        UNION ALL SELECT 1
                        UNION ALL SELECT 2
                        UNION ALL SELECT 3
                        UNION ALL SELECT 4
                        UNION ALL SELECT 5
                        UNION ALL SELECT 6
                        UNION ALL SELECT 7
                        UNION ALL SELECT 8
                        UNION ALL SELECT 9
                      ) AS bb
                      CROSS JOIN
                      (
                        SELECT 0 AS a
                        UNION ALL SELECT 1
                        UNION ALL SELECT 2
                        UNION ALL SELECT 3
                        UNION ALL SELECT 4
                        UNION ALL SELECT 5
                        UNION ALL SELECT 6
                        UNION ALL SELECT 7
                        UNION ALL SELECT 8
                        UNION ALL SELECT 9
                      ) AS cc
                  ) AS C
                WHERE C.DATE < '{end_date}' :: DATE + INTERVAL '1' DAY
              ) AS D
          )
        ) AS F
      GROUP BY extract(YEAR FROM dateval), extract(MONTH FROM dateval), company_cd
      ORDER BY extract(YEAR FROM dateval), extract(MONTH FROM dateval), company_cd
    ) AS G
) AS F
group by yearmonth, company_cd
order by yearmonth, company_cd