SELECT yearval ||' '|| weekval ||'W' as yearweek, beta_prj, sumval as sum
FROM
  (
    SELECT extract(isoyear from dateval) as yearval , extract(week from dateval) as weekval, beta_prj, sum(cnt) as sumval
    FROM
      (
        SELECT date + interval '1' day as dateval,
               case
                when beta_prj_id > 0 then 1
                else 0 end
               as beta_prj,
               sum(cnt) as cnt
        FROM v3_feedback
        WHERE
          date >= '{start_date}'
        AND
          date <= '{end_date}'
        AND
          branch_id IN {branch_ids}
        AND
          model {model}
        AND
          main_type  = {voc_types}
        GROUP BY date, beta_prj
        ORDER BY date, beta_prj
      ) AS A
    GROUP BY extract(isoyear from dateval), extract(week from dateval), beta_prj
    ORDER BY extract(isoyear from dateval), extract(week from dateval), beta_prj
  ) as B