from django.shortcuts import render_to_response
from django.template.context import RequestContext
from common.utils import custom_login_required, access_log


@custom_login_required
@access_log
def view_main(request):
    return render_to_response('index.html', '', context_instance=RequestContext(request))
