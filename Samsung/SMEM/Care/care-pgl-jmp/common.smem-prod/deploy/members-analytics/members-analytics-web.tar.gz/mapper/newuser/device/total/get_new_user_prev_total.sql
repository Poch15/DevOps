SELECT sum(cnt) as prev_total_cnt
FROM {tbl_name}
WHERE
  datetime < '{start_date}'::timestamp - INTERVAL '{interval_hour}' HOUR
AND
  branch_id IN {branch_ids}
AND
  model {model}