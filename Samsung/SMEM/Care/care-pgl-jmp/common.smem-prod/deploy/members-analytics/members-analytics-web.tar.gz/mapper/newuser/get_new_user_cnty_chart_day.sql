SELECT branch_id, date_with_timezone, sum(cnt)
FROM
  (
    SELECT (datetime + INTERVAL '{interval_hour}' HOUR)::DATE as date_with_timezone, cnt, branch_id
    FROM {tbl_name}
    WHERE
      datetime >= '{start_date}'::timestamp - INTERVAL '{interval_hour}' HOUR
    AND
      datetime < '{end_date}'::timestamp - INTERVAL '{interval_hour}' HOUR + INTERVAL '1' DAY
    AND
      branch_id IN {branch_ids}
  ) AS A
GROUP BY branch_id, date_with_timezone
ORDER BY branch_id, date_with_timezone