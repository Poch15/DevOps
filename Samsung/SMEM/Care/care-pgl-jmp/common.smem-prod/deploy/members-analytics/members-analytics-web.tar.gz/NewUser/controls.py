from common.utils import Utils
from common.dbutils import DBUtils
from common.chart_utils import ChartUtils
from common.excel_utils import ExcelUtils
from common.params_utils import ParamsUtils
from datetime import date
from common.branch_utils import BranchUtils
from NewUser.utils import NewUserUtils
from Device.controls import DeviceController


class NewUserController:
    @staticmethod
    def get_dashboard_weekly_data(branch_ids, interval_hour):
        sql = DBUtils.load_query('newuser', 'get_new_user_dashboard_weekly.sql')
        week_start_date = Utils.get_week_start_date()
        today = date.today()
        params = {'start_date': week_start_date, 'end_date': today,
                  'branch_ids': branch_ids, 'interval_hour': interval_hour}

        return_row = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)

        return return_row[0]

    @staticmethod
    def get_dashboard_total_data(branch_ids, interval_hour):
        sql = DBUtils.load_query('newuser', 'get_new_user_dashboard_total.sql')
        today = date.today()
        params = {'end_date': today, 'branch_ids': branch_ids, 'interval_hour': interval_hour}
        return_row = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)
        return return_row[0]

    @staticmethod
    def get_count_data(start_date, end_date, period, branch_ids, model, interval_hour, data_type):
        sql_info = NewUserUtils.get_sql_info(data_type, model)
        sql = DBUtils.load_query(sql_info[0], 'get_new_user_%s.sql' % period)
        params = {'start_date': start_date, 'end_date': end_date, 'branch_ids': branch_ids, 'model': model,
                  'interval_hour': interval_hour, 'tbl_name': sql_info[1]}
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)
        return return_rows

    @staticmethod
    def get_count_chart_data(start_date, end_date, period, branch_ids, model, interval_hour, data_type):
        return_rows = NewUserController.get_count_data(start_date, end_date, period, branch_ids, model, interval_hour,
                                                       data_type)
        chart_rows = ChartUtils.convert_chart_rows(return_rows)
        prev_total_cnt = NewUserController.get_count_data_prev_total(start_date, branch_ids, model, interval_hour,
                                                                     data_type)

        cumulative_rows = NewUserUtils.convert_chart_rows(return_rows, prev_total_cnt)
        if data_type == 'newdevice' or data_type == 'nd' or data_type == 'v3_device':
            chart_name = ("New Devices", "Total Devices")
        else:
            chart_name = ("New Members", "Total Members")
        chart_data = NewUserUtils.wrap_dual_chart_data(chart_name[0], chart_name[1], chart_rows, cumulative_rows)
        return chart_data

    @staticmethod
    def get_count_excel_data(start_date, end_date, period, branch_ids, model, interval_hour, data_type):
        return_rows = NewUserController.get_count_data(start_date, end_date, period, branch_ids, model, interval_hour,
                                                       data_type)
        prev_total_cnt = NewUserController.get_count_data_prev_total(start_date, branch_ids, model, interval_hour,
                                                                     data_type)
        file_name = 'new_members'
        if data_type == 'newdevice' or data_type == 'nd' or data_type == 'v3_device':
            file_name = 'new_devices'

        file_name = ExcelUtils.get_file_name(file_name)
        excel_rows = NewUserUtils.convert_excel_rows(return_rows, prev_total_cnt)
        excel_data = ExcelUtils.list_to_excel(file_name, excel_rows)
        return excel_data

    @staticmethod
    def get_cnty_data(start_date, end_date, period, branch_ids, model, interval_hour, data_type):
        sql_info = NewUserUtils.get_sql_info(data_type, model)
        sql = DBUtils.load_query(sql_info[0], 'get_new_user_cnty_chart_%s.sql' % period)
        params = {'start_date': start_date, 'end_date': end_date, 'branch_ids': branch_ids, 'model': model,
                  'interval_hour': interval_hour, 'tbl_name': sql_info[1]}
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)
        return return_rows

    @staticmethod
    def get_cnty_chart_data(start_date, end_date, period, branch_ids, model, interval_hour, data_type):
        return_rows = NewUserController.get_cnty_data(start_date, end_date, period, branch_ids, model, interval_hour,
                                                      data_type)
        cnty_chart_rows = ChartUtils.convert_country_chart_rows_except_zero(return_rows, period)
        cnty_chart_data = ChartUtils.wrap_country_chart_data(cnty_chart_rows)
        return cnty_chart_data

    @staticmethod
    def get_cnty_excel_data(start_date, end_date, period, branch_ids, model, interval_hour, data_type):
        return_rows = NewUserController.get_cnty_data(start_date, end_date, period, branch_ids, model, interval_hour,
                                                      data_type)

        cnty_prev_tot_dict = NewUserController.get_cnty_date_prev_total(start_date, branch_ids, model, interval_hour,
                                                                        data_type)

        file_name = 'new_devices_cnty' if data_type == 'newdevice' or data_type == 'nd' else 'new_members_cnty'
        file_name = ExcelUtils.get_file_name(file_name)

        cnty_excel_rows = ExcelUtils.convert_user_cnty_excel_rows(return_rows, False)
        cnty_cumulative_excel_rows = ExcelUtils.convert_user_cnty_excel_rows(return_rows, True, cnty_prev_tot_dict)

        cnty_excel_data = NewUserUtils.cnty_list_to_excel(file_name, (cnty_excel_rows, cnty_cumulative_excel_rows))

        return cnty_excel_data

    @staticmethod
    def get_cnty_percentage_chart_data(start_date, end_date, branch_ids, model, interval_hour, data_type):
        sql_info = NewUserUtils.get_sql_info(data_type, model)
        sql = DBUtils.load_query(sql_info[0], 'get_new_user_cnty_percentage.sql')
        params = {'start_date': start_date, 'end_date': end_date, 'branch_ids': branch_ids, 'model': model,
                  'interval_hour': interval_hour, 'tbl_name': sql_info[1]}
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)

        branch_dic = BranchUtils.get_all_branch_dict()
        data = []
        total_count = 0
        for return_row in return_rows:
            branch_id, real_count, percentage = return_row
            total_count += real_count
            data.append({"name": branch_dic[branch_id], "y": percentage,
                         "real_count": real_count})

        return dict(data=[{"name": "Percentage of count by country", "colorByPoint": True, "data": data}],
                    count=total_count)

    @staticmethod
    def get_tab_count_data(start_date, end_date, branch_ids, model, interval_hour, tab_type, cur_p, page_size,
                           data_type):
        sql_info = NewUserUtils.get_sql_info(data_type, model, 'branch')

        # get total count
        sql = DBUtils.load_query(sql_info[0], 'get_new_user_analysis_%s_total_count.sql' % tab_type)
        params = {'start_date': start_date, 'end_date': end_date, 'branch_ids': branch_ids,
                  'model': model, 'interval_hour': interval_hour, 'cur_p': cur_p, 'tbl_name': sql_info[1]}
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)
        total_count = return_rows[0][0]

        # get paging data
        paging_params = ParamsUtils.get_paging_params(cur_p, total_count, page_size)
        params.update(paging_params)
        sql = DBUtils.load_query(sql_info[0], 'get_new_user_analysis_%s.sql' % tab_type)
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)

        category = []
        device_to_mkt_name_dict = DeviceController.get_device_to_mkt_name_dict()
        for row in return_rows:
            cat_item = row[0]
            if tab_type == 'device':
                mkt_name = device_to_mkt_name_dict.get(cat_item, "")
                cat_item = cat_item + DeviceController.get_tab_mkt_name(mkt_name)
            category.append(cat_item)

        return dict(category=category, data=return_rows, count=len(return_rows),
                    tot_p=paging_params['total_page'], cur_p=int(cur_p))

    @staticmethod
    def get_tab_excel_data(start_date, end_date, branch_ids, model, tab_type, data_type):

        sql_info = NewUserUtils.get_sql_info(data_type, model, 'branch')

        params = {
            'start_date': start_date,
            'end_date': end_date,
            'branch_ids': branch_ids,
            'model': model,
            'tab_type': tab_type,
            'limit': 'ALL',
            'offset': 0,
            'interval_hour': 0,
            'tbl_name': sql_info[1]}

        sql = DBUtils.load_query(sql_info[0], 'get_new_user_analysis_%s.sql' % tab_type)
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)

        excel_name = ExcelUtils.get_file_name('new_user_' + tab_type)
        excel_rows = ExcelUtils.convert_tab_excel_rows('tab_' + tab_type, return_rows)
        excel_data = ExcelUtils.list_to_excel(excel_name, excel_rows)

        return excel_data

    @staticmethod
    def get_count_data_prev_total(start_date, branch_ids, model, interval_hour, data_type):
        sql_info = NewUserUtils.get_sql_info(data_type, model)
        sql_dir = sql_info[0] + '/total'
        sql = DBUtils.load_query(sql_dir, 'get_new_user_prev_total.sql')
        params = {'start_date': start_date, 'branch_ids': branch_ids, 'model': model,
                  'interval_hour': interval_hour, 'tbl_name': sql_info[1]}
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)
        prev_tot_cnt = return_rows[0][0]
        if prev_tot_cnt is None:
            prev_tot_cnt = 0
        return prev_tot_cnt

    @staticmethod
    def get_cnty_date_prev_total(start_date, branch_ids, model, interval_hour, data_type):
        sql_info = NewUserUtils.get_sql_info(data_type, model)
        sql_dir = sql_info[0] + '/total'
        sql = DBUtils.load_query(sql_dir, 'get_new_user_cnty_chart_prev_total.sql')
        params = {'start_date': start_date, 'branch_ids': branch_ids, 'model': model,
                  'interval_hour': interval_hour, 'tbl_name': sql_info[1]}
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)
        prev_tot_dict = {}
        for row in return_rows:
            branch_id, cnt = row
            prev_tot_dict[branch_id] = cnt
        return prev_tot_dict
