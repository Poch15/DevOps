SELECT f.branch_id
FROM home_feat f JOIN cmn_feat c
ON f.feat_id = c.feat_id
WHERE feat_name='LITHIUM_SHARE'