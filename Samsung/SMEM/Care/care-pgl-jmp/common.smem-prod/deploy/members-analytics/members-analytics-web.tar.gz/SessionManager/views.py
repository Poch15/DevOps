# Create your views here.
from django.http import JsonResponse
from django.http import HttpResponse
from django.views.decorators.csrf import csrf_protect
from django.views.decorators.http import require_http_methods
from common.utils import custom_login_required, Utils
from SessionManager.controls import SessionManagerController
from common.branch_utils import BranchUtils


@custom_login_required
@require_http_methods(["POST"])
@csrf_protect
def change_selected_branch(request):
    SessionManagerController.change_selected_branch(
        request,
        request.POST.get('branch_id'),
        request.POST.get('branch_name'),
        request.POST.get('start_dt'),
        request.POST.get('end_dt'),
        request.POST.get('period'),
        request.POST.get('model')
    )
    return HttpResponse()


@custom_login_required
@require_http_methods(["POST"])
@csrf_protect
def save_selected_filter_value(request):
    SessionManagerController.save_selected_filter_value(
        request,
        request.POST.get('start_dt'),
        request.POST.get('end_dt'),
        request.POST.get('period'),
        request.POST.get('model')
    )
    return HttpResponse()


@custom_login_required
@require_http_methods(["GET"])
def get_selected_branch_name(request):
    try:
        response = SessionManagerController.get_selected_branch_name(request)
        return HttpResponse(response)
    except Exception:
        return JsonResponse(dict(status='fail', message='parameter error'))


@custom_login_required
@require_http_methods(["GET"])
def get_branch_node_list(request):
    try:
        selected_branch_name = SessionManagerController.get_selected_branch_name(request)
        branch_list = SessionManagerController.get_branch_node_list(request)
        sorted_branch_key_list = SessionManagerController.get_sorted_branch_key_list(request, branch_list)

        if request.session.get('selected_region') == 'HQ':
            branch_list['regions'] = SessionManagerController.get_all_region(request)
            sorted_branch_key_list.insert(1, 'regions')

        return JsonResponse(dict(selected_branch_name=selected_branch_name, branch_list=branch_list,
                                 branch_key_list=sorted_branch_key_list))
    except Exception:
        return JsonResponse(dict(status='fail', message='parameter error'))


@custom_login_required
@require_http_methods(["POST"])
@csrf_protect
def change_timezone(request):
    SessionManagerController.change_timezone(request, request.POST.get('selected_time_zone'))
    return HttpResponse()


@custom_login_required
@require_http_methods(["GET"])
def get_time_zone_list(request):
    try:
        selected_tz_name = SessionManagerController.get_selected_time_zone(request)
        tz_list = BranchUtils.get_timezone_list(request)
        tz_key_list = list(tz_list.keys())
        tz_key_list.sort()
        return JsonResponse(dict(selected_tz_name=selected_tz_name, tz_list=tz_list, tz_key_list=tz_key_list))
    except Exception:
        return JsonResponse(dict(status='fail', message='parameter error'))


@custom_login_required
@require_http_methods(["GET"])
def get_region_list(request):
    try:
        def_region = SessionManagerController.get_region(request)
        selected_region = SessionManagerController.get_selected_region(request)
        region_list = SessionManagerController.get_region_list(request)
        return JsonResponse(dict(def_region=def_region, selected_region=selected_region, region_list=region_list))
    except Exception:
        return JsonResponse(dict(status='fail', message='parameter error'))


@custom_login_required
@require_http_methods(["POST"])
@csrf_protect
def change_region(request):
    SessionManagerController.change_selected_region(request, request.POST.get('selected_region'))
    return HttpResponse()
