SELECT
    CASE WHEN month < 10 THEN year || '/0' || month
         ELSE year || '/' || month
         END as yearmonth, category, cnt
FROM
(
	SELECT EXTRACT(YEAR FROM DATE) AS YEAR, EXTRACT(MONTH FROM DATE) AS MONTH, category, SUM(cnt) AS cnt
	FROM v3_newsntips_category
	WHERE
    date >= '{start_date}'
    AND
    date <= '{end_date}'
    AND
    branch_id IN {branch_ids}
    AND
    model {model}
	GROUP BY YEAR, MONTH, category
) AS A
ORDER BY yearmonth, category