SELECT status, sum(cnt) as count
FROM tbl_v2_feedback
WHERE
  datetime >= '{start_date}'::timestamp - INTERVAL '{interval_hour}' HOUR
AND
  datetime < '{end_date}'::timestamp - INTERVAL '{interval_hour}' HOUR + INTERVAL '1' DAY
AND
	branch_id IN %s
AND
model ~* %s
AND
main_type = %s
GROUP BY status
ORDER BY status