SELECT
        CASE WHEN month < 10 THEN year || '/0' || month
             ELSE year || '/' || month
             END as yearmonth, 	sumval
FROM
(
  SELECT EXTRACT (year from date) as year, EXTRACT(month from date) as month,  SUM(cnt) as sumval
    FROM v3_screenview_monthly
    WHERE
        date >= '{start_date}'
    AND
        date <= '{end_date}'
    AND
        branch_id IN {branch_ids}
    AND
    CASE
        WHEN '{page_id}' = ''
             THEN  model {model}
        ELSE
             model {model} AND screen_id = '{page_id}'
    END
  GROUP BY year, month
) AS A
ORDER BY yearmonth
