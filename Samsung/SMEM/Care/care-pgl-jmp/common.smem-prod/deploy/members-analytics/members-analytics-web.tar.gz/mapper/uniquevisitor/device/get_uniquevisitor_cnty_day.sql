SELECT branch_id, date, sum(cnt) as cnt
FROM {tbl_name}
  WHERE
    date >= '{start_date}'
  AND
    date <= '{end_date}'
  AND
    timezone = {timezone}
  AND
    branch_id IN {branch_ids}
  AND
    model {model}
GROUP BY branch_id, date
ORDER BY branch_id, date