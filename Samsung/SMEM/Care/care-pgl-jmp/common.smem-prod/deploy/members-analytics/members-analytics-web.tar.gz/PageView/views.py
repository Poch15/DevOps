from django.shortcuts import render_to_response
from django.template.context import RequestContext
from django.views.decorators.http import require_http_methods
from django.http import JsonResponse
from common.utils import custom_login_required, access_log
from PageView.controls import PageViewController
from common.exception_handler import ExceptionHandler
from common.params_utils import ParamsUtils
from SessionManager.controls import SessionManagerController
from django.views.decorators.cache import cache_page


@ExceptionHandler(return_type=ExceptionHandler.RETURN_JSON)
@custom_login_required
@require_http_methods(["GET"])
@access_log
def view_pageview(request):
    template = 'pageview/pv_overview.html'
    return render_to_response(template, context_instance=RequestContext(request))


@cache_page(60 * 15)
@ExceptionHandler(return_type=ExceptionHandler.RETURN_JSON)
@custom_login_required
@require_http_methods(["GET"])
@access_log
def view_pageview_info(request):
    template = 'pageview/pv_screen_info.html'
    screen_info_dict = PageViewController.get_pv_mapping_info()
    ctx = {
        'pv_info_list': screen_info_dict['pv_info_list'],
        'event_info_list': screen_info_dict['event_info_list']
    }
    return render_to_response(template, ctx, context_instance=RequestContext(request))


@ExceptionHandler(return_type=ExceptionHandler.RETURN_JSON)
@custom_login_required
@require_http_methods(["GET"])
def get_chart_data(request):
    try:
        chart_data = PageViewController.get_count_chart_data(
            start_date=ParamsUtils.get_param(request, "start_date"),
            end_date=ParamsUtils.get_param(request, "end_date"),
            period=ParamsUtils.get_param(request, "period"),
            branch_ids=SessionManagerController.get_selected_branch_ids(request),
            model=ParamsUtils.get_param(request, "query_model"),
            page_id=ParamsUtils.get_param(request, "page_id")
        )
        return JsonResponse(chart_data)
    except Exception as e:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})


@ExceptionHandler(return_type=ExceptionHandler.RETURN_HTTP)
@custom_login_required
@require_http_methods(["GET"])
def get_excel_data(request):
    try:
        excel_data = PageViewController.get_count_excel_data(
            start_date=ParamsUtils.get_param(request, "start_date"),
            end_date=ParamsUtils.get_param(request, "end_date"),
            period=ParamsUtils.get_param(request, "period"),
            branch_ids=SessionManagerController.get_selected_branch_ids(request),
            model=ParamsUtils.get_param(request, "query_model"),
            page_id=ParamsUtils.get_param(request, "page_id")
        )
        return excel_data
    except Exception as e:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})


@ExceptionHandler(return_type=ExceptionHandler.RETURN_JSON)
@custom_login_required
@require_http_methods(["GET"])
def get_cnty_chart_data(request):
    try:
        cnty_chart_data = PageViewController.get_country_count_chart_data(
            start_date=ParamsUtils.get_param(request, "start_date"),
            end_date=ParamsUtils.get_param(request, "end_date"),
            period=ParamsUtils.get_param(request, "period"),
            branch_ids=SessionManagerController.get_selected_branch_ids(request),
            model=ParamsUtils.get_param(request, "query_model"),
            page_id=ParamsUtils.get_param(request, "page_id")
        )
        return JsonResponse(cnty_chart_data)
    except Exception as e:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})


@ExceptionHandler(return_type=ExceptionHandler.RETURN_HTTP)
@custom_login_required
@require_http_methods(["GET"])
def get_cnty_excel_data(request):
    try:
        cnty_excel_data = PageViewController.get_country_excel_data(
            start_date=ParamsUtils.get_param(request, "start_date"),
            end_date=ParamsUtils.get_param(request, "end_date"),
            period=ParamsUtils.get_param(request, "period"),
            branch_ids=SessionManagerController.get_selected_branch_ids(request),
            model=ParamsUtils.get_param(request, "query_model"),
            page_id=ParamsUtils.get_param(request, "page_id")
        )
        return cnty_excel_data
    except Exception as e:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})


@ExceptionHandler(return_type=ExceptionHandler.RETURN_JSON)
@custom_login_required
@require_http_methods(["GET"])
def get_tab_count_data(request):
    try:
        tab_type = ParamsUtils.get_param(request, "tab_type")

        if tab_type == 'page_id':
            tab_count_data = PageViewController.get_pagerank_count_data(
                start_date=ParamsUtils.get_param(request, "start_date"),
                end_date=ParamsUtils.get_param(request, "end_date"),
                branch_ids=SessionManagerController.get_selected_branch_ids(request),
                model=ParamsUtils.get_param(request, "query_model"),
                page_id=ParamsUtils.get_param(request, "page_id"),
                cur_p=int(ParamsUtils.get_param(request, "cur_p")),
                page_size=int(ParamsUtils.get_param(request, "page_size")),
                period=ParamsUtils.get_param(request, "period")
            )

        else:
            tab_count_data = PageViewController.get_tab_count_data(
                start_date=ParamsUtils.get_param(request, "start_date"),
                end_date=ParamsUtils.get_param(request, "end_date"),
                branch_ids=SessionManagerController.get_selected_branch_ids(request),
                model=ParamsUtils.get_param(request, "query_model"),
                page_id=ParamsUtils.get_param(request, "page_id"),
                cur_p=int(ParamsUtils.get_param(request, "cur_p")),
                page_size=int(ParamsUtils.get_param(request, "page_size")),
                tab_type=tab_type,
                period=ParamsUtils.get_param(request, "period")
            )
        return JsonResponse(tab_count_data)
    except Exception as e:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})


@ExceptionHandler(return_type=ExceptionHandler.RETURN_HTTP)
@custom_login_required
@require_http_methods(["GET"])
def get_tab_excel_data(request):
    try:
        tab_excel_data = PageViewController.get_tab_excel_data(
                start_date=ParamsUtils.get_param(request, "start_date"),
                end_date=ParamsUtils.get_param(request, "end_date"),
                branch_ids=SessionManagerController.get_selected_branch_ids(request),
                model=ParamsUtils.get_param(request, "query_model"),
                page_id=ParamsUtils.get_param(request, "page_id"),
                tab_type=ParamsUtils.get_param(request, "tab_type"),
                period=ParamsUtils.get_param(request, "period")
        )

        return tab_excel_data
    except Exception as e:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})
