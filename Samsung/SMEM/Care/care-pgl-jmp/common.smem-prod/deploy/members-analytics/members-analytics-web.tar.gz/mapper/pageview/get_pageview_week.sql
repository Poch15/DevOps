SELECT EXTRACT(isoyear FROM (date + INTERVAL '1' DAY)) || '-'
        || EXTRACT(week FROM (date + INTERVAL '1' DAY)) ||'W' AS yearweek,
        cnt
FROM
(
  SELECT date, SUM(cnt) as cnt
  FROM v3_screenview_weekly
  WHERE
      date >= '{start_date}'
  AND
      date <= '{end_date}'
  AND
      branch_id IN {branch_ids}
  AND
      CASE
          WHEN '{page_id}' = ''
               THEN  model {model}
          ELSE
               model {model} AND screen_id = '{page_id}'
      END
  GROUP BY date
) AS A
ORDER BY date
