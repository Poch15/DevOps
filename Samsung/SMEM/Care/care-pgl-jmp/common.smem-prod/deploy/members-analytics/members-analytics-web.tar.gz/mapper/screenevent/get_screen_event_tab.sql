SELECT branch_id, sum(cnt) as cnt, ROUND(SUM(cnt) / SUM(SUM(cnt)) OVER() * 100.0, 2) AS percent
FROM v3_screen_event
WHERE
   date >= '{start_date}'
AND
   date <= '{end_date}'
AND
    CASE
        WHEN '{event_id}' != ''
             THEN branch_id IN {branch_ids} AND event_id = '{event_id}'
        WHEN '{page_id}' != ''
             THEN branch_id IN {branch_ids} AND screen_id = '{page_id}'
        ELSE
             branch_id IN {branch_ids}
    END
GROUP BY branch_id
ORDER BY cnt desc
LIMIT {limit} OFFSET {offset}