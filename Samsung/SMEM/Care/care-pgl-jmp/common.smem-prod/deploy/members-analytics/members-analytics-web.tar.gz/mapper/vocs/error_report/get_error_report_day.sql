SELECT date, beta_prj, sum(cnt) as cnt
FROM
  (
    SELECT date,
           case
               when beta_prj_id > 0 then 1
               else 0 end
           as beta_prj,
           cnt
    FROM v3_feedback
    WHERE
      date >= '{start_date}'
    AND
      date <= '{end_date}'
    AND
      branch_id IN {branch_ids}
    AND
      model {model}
    AND
      main_type  = {voc_types}
    AND
      prd_cat IN {prd_cat}
  ) AS A
GROUP BY date, beta_prj
ORDER BY date, beta_prj