from common.dbutils import DBUtils
from common.chart_utils import ChartUtils
from common.excel_utils import ExcelUtils
from common.branch_utils import BranchUtils


class UniqueVisitorDrillDownController:

    @staticmethod
    def get_drilldown_count_data(start_date, end_date, period, branch_ids, model, data_type):
        sql_dir, tbl_name = UniqueVisitorDrillDownController.get_drilldown_sql_info(data_type, period, model)
        sql = DBUtils.load_query(sql_dir, 'get_uniquevisitor_drilldown.sql')
        params = {'start_date': start_date, 'end_date': end_date, 'branch_ids': branch_ids, 'model': model,
                  'tbl_name': tbl_name}
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)

        return return_rows

    @staticmethod
    def get_drilldown_country_count_data(start_date, end_date, period, branch_ids, model, data_type):
        sql_dir, tbl_name = UniqueVisitorDrillDownController.get_drilldown_sql_info(data_type, period, model)
        sql = DBUtils.load_query(sql_dir, 'get_uniquevisitor_drilldown_cnty.sql')
        params = {'start_date': start_date, 'end_date': end_date, 'branch_ids': branch_ids, 'model': model,
                  'tbl_name': tbl_name}
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)

        return return_rows

    @staticmethod
    def get_drilldown_chart_data(start_date, end_date, period, branch_ids, model, data_type):
        return_rows = UniqueVisitorDrillDownController.get_drilldown_count_data(start_date, end_date, period,
                                                                                branch_ids, model, data_type)
        chart_type = 'active devices' if data_type == 'v3_uv_dvc' else 'active users'
        accumulative_chart_name = 'Accumulative ' + chart_type + ' within period'
        daily_new_chart_name = 'Daily new ' + chart_type + ' within period'
        chart_rows = ChartUtils.convert_chart_rows(return_rows)
        prev_diff_chart_rows = ChartUtils.convert_prev_diff_chart_rows(return_rows)
        chart_data = ChartUtils.wrap_dual_stack_chart_data(accumulative_chart_name, daily_new_chart_name,
                                                           chart_rows, prev_diff_chart_rows)
        return chart_data

    @staticmethod
    def get_drilldown_excel_count_data(start_date, end_date, period, branch_ids, model, data_type):
        return_rows = UniqueVisitorDrillDownController.get_drilldown_country_count_data(start_date, end_date, period,
                                                                                        branch_ids, model, data_type)
        file_name = 'accumulative_active_devices' if data_type == 'v3_uv_dvc' else 'accumulative_active_users'
        file_name = ExcelUtils.get_file_name(file_name)
        excel_dict = ExcelUtils.convert_uv_drilldown_cnty_excel_rows(return_rows, branch_ids, 'day')
        accumulative_excel_rows = excel_dict['accumulative_excel_rows']
        daily_new_excel_rows = excel_dict['daily_new_excel_rows']
        excel_data = ExcelUtils.multi_list_to_uv_drilldown_excel(file_name, accumulative_excel_rows, daily_new_excel_rows)
        return excel_data

    @staticmethod
    def get_drilldown_sql_info(data_type, period, model):
        sql_dir_dic = {'uv': 'uniquevisitor/drilldown', 'uv_dvc': 'uniquevisitor/drilldown/device'}
        sql_tbl_dic = {
            'v3_uv': {
                'week': 'v3_wuv_dd', 'month': 'v3_muv_dd'
            },
            'v3_uv_dvc': {
                'week': 'v3_wuv_dvc_dd', 'month': 'v3_muv_dvc_dd'
            }
        }

        sql_info = None
        if data_type is not None and 'v3' in data_type:
            if data_type == 'v3_uv_dvc' or model != 'all':
                sql_info = (sql_dir_dic['uv_dvc'], sql_tbl_dic['v3_uv_dvc'][period])
            elif data_type == 'v3_uv':
                sql_info = (sql_dir_dic['uv'], sql_tbl_dic['v3_uv'][period])

        return sql_info
