from django.http import HttpResponse
from datetime import datetime
from common.utils import Utils
from openpyxl import Workbook
from openpyxl.cell import get_column_letter
from openpyxl.styles import PatternFill, Alignment, Border, Side
from common.branch_utils import BranchUtils
from common.date_utils import DateUtils
from Device.controls import DeviceController
import re
import pandas as pd


class ExcelUtils:
    KEYWORD_LIMIT_ROW = 1000

    @staticmethod
    def convert_excel_rows(rows):
        excel_rows = [["Date", "Count"]]
        for row in rows:
            excel_rows.append([row[0], row[1]])

        return excel_rows

    @staticmethod
    def convert_cnty_excel_rows(rows, branch_ids):
        date_list = []
        statistics_dic = {}
        for row in rows:
            branch_id, date, cnt = row
            if branch_id == 0:
                date_list.append(date)
            statistics_dic[(branch_id, date)] = int(cnt)

        branch_dic = BranchUtils.get_all_branch_dict()
        branch_list = list(map(int, branch_ids))

        cnty = ["Date"]
        for branch in branch_list:
            if branch != 0:
                cnty.append(branch_dic[branch])
        excel_rows = [cnty]

        for _date in date_list:
            row = [_date]
            for branch in branch_list:
                if branch != 0:
                    value = statistics_dic.get((branch, _date), 0)
                    row.append(value)
            excel_rows.append(row)

        return excel_rows

    @staticmethod
    def convert_cnty_excel_rows_except_zero(rows, branch_ids, period):
        date_set = set()
        statistics_dic = {}
        for row in rows:
            branch_id, date, cnt = row
            date_set.add(date)
            statistics_dic[(branch_id, date)] = int(cnt)

        branch_dic = BranchUtils.get_all_branch_dict()
        branch_list = list(map(int, branch_ids))

        date_list = list(date_set)
        date_list.sort(key=DateUtils.get_date_sort_key(period))

        cnty = ["Date"]
        for branch in branch_list:
            if branch != 0:
                cnty.append(branch_dic[branch])
        excel_rows = [cnty]

        for _date in date_list:
            row = [_date]
            for branch in branch_list:
                if branch != 0:
                    value = statistics_dic.get((branch, _date), 0)
                    row.append(value)
            excel_rows.append(row)

        return excel_rows

    @staticmethod
    def convert_user_cnty_excel_rows(rows, cumulative, init_dict=None):
        branch_dic = BranchUtils.get_all_branch_dict()

        df = pd.DataFrame(rows, columns=['branch_id', 'date', 'cnt'])
        data_pivot = df.pivot(index='date', columns='branch_id', values='cnt')
        data_pivot = data_pivot.fillna(0)
        data_pivot = data_pivot.reindex(index=df['date'].unique())
        data_pivot = data_pivot.astype('float')

        if cumulative is True:
            data_pivot = data_pivot.cumsum(axis=0)
            for _cnty in data_pivot.columns.values:
                data_pivot[_cnty] = data_pivot[_cnty] + init_dict.get(_cnty, 0)

        data_pivot.rename(columns=branch_dic, inplace=True)

        total_sum = data_pivot.sum(axis=1)
        total_avg = data_pivot.mean(axis=1)

        data_pivot['Total Sum'] = round(total_sum, 2)
        data_pivot['Total Average'] = round(total_avg, 2)

        diff_df = data_pivot.diff(axis=0, periods=1)
        diff_df = diff_df.fillna(0)
        diff_df = diff_df[1:]

        pct_change_df = data_pivot.pct_change(axis=0, periods=1)
        pct_change_df = pct_change_df.fillna(0)
        pct_change_df = pct_change_df[1:]

        data_pivot.loc['Average'] = round(data_pivot.mean(axis=0), 2)

        pct_change_df = pct_change_df.applymap(lambda x: x * 100).applymap("{0:.2f}%".format)

        execl_rows = []

        first_row = ["Date"]
        first_row.extend(data_pivot.columns.values.tolist())
        execl_rows.append(first_row)

        for _date in data_pivot.index.values:
            row = [_date]
            row.extend(data_pivot.loc[_date].tolist())
            execl_rows.append(row)

        execl_rows.append([])
        execl_rows.append(['Difference'])

        for _date in diff_df.index.values:
            row = [_date]
            row.extend(diff_df.loc[_date].tolist())
            execl_rows.append(row)

        execl_rows.append([])
        execl_rows.append(['The percentage change'])

        for _date in pct_change_df.index.values:
            row = [_date]
            row.extend(pct_change_df.loc[_date].tolist())
            execl_rows.append(row)

        return execl_rows

    @staticmethod
    def convert_appid_excel_rows(rows, period):
        statistics_dic = {}
        app_id_set = set()
        date_set = set()
        for return_row in rows:
            date, app_id, count = return_row
            app_id_set.add(app_id)
            date_set.add(date)
            statistics_dic[(date, app_id)] = int(count)

        app_id_list = list(app_id_set)
        app_id_list.sort()
        date_list = list(date_set)
        date_list.sort(key=DateUtils.get_date_sort_key(period))

        app_dic = Utils.get_all_app_info()
        excel_header = ["Date"]
        for app_id in app_id_list:
            excel_header.append(app_dic.get(app_id, 'NOT_FOUND'))

        excel_rows = [excel_header]
        for _date in date_list:
            row = [_date]
            for app_id in app_id_list:
                value = statistics_dic.get((_date, app_id,), 0)
                row.append(value)
            excel_rows.append(row)

        return excel_rows

    @staticmethod
    def convert_tab_excel_rows(excel_type, rows):
        excel_rows = ExcelUtils.get_excel_headers(excel_type)

        if excel_type == 'tab_branch_id' or excel_type == 'tab_branch':
            branch_dic = BranchUtils.get_all_branch_dict()
            for row in rows:
                branch_id, cnt, percent = row
                excel_rows.append([branch_dic.get(branch_id), cnt, percent])

        elif excel_type == 'tab_page_id':
            for row in rows:
                page_name, cnt, percent, ux_version = row
                if ux_version == 1:
                    page_name += ' (V1)'
                elif ux_version == 2:
                    page_name += ' (OLD)'
                elif ux_version == 3:
                    page_name += ' (NEW)'
                excel_rows.append([page_name, cnt, percent])

        elif excel_type == 'tab_model' or excel_type == 'tab_device':
            device_to_mkt_name_dict = DeviceController.get_device_to_mkt_name_dict()
            for row in rows:
                model, cnt, percent = row
                mkt_name = device_to_mkt_name_dict.get(model, "")
                model = model + DeviceController.get_tab_mkt_name(mkt_name)
                excel_rows.append([model, cnt, percent])

        elif excel_type == 'tab_event':
            for row in rows:
                page_name, event_name, cnt, percent, ux_version = row
                if ux_version == 1:
                    page_name += ' (V1)'
                elif ux_version == 2:
                    page_name += ' (OLD)'
                elif ux_version == 3:
                    page_name += ' (NEW)'
                excel_rows.append([page_name, event_name, cnt, percent])

        else:
            for row in rows:
                excel_rows.append(list(row))

        return excel_rows

    @staticmethod
    def list_to_excel(file_name, list_data, use_sum_row=False):

        wb = Workbook()
        ws = wb.active

        for obj in list_data:
            ws.append(obj)

        if use_sum_row:
            row_index = len(list_data) + 1
            col_count = len(list_data[0]) + 1
            ExcelUtils.set_sum_row(ws, row_index, col_count)

        response = HttpResponse(
            content_type="application/force-download; application/octet-stream; application/download")
        response['Pragma'] = 'no-cache'
        response['Expires'] = 0
        response['Content-Disposition'] = 'attachment; filename=%s' % file_name
        wb.save(response)

        return response

    @staticmethod
    def convert_faq_excel_rows(tab_type, date_list, count_dict, group_list):

        excel_header = []
        # branch_id => branch_name
        if tab_type is 'branch_id':
            branch_dic = BranchUtils.get_all_branch_dict()
            for branch_id in group_list:
                excel_header.append(branch_dic.get(branch_id, ""))
        else:
            excel_header = group_list

        excel_rows = [['Date'] + excel_header]

        for _date in date_list:
            rows = [_date]
            for group in group_list:
                rows.append(count_dict.get((_date, group), 0))
            excel_rows.append(rows)

        return excel_rows

    @staticmethod
    def multi_general_list_to_excel(file_name, sheet_names, data_list):
        """
        :param file_name: file name
        :param sheet_names: 1d array of sheet_name
        :param data_list: 1d array of tuple
        :return: excel response
        """

        wb = Workbook()
        ws = wb.active

        ws.title = sheet_names[0]
        for row in data_list[0]:
            ws.append(row)

        for sheet_name, rows in zip(sheet_names[1:], data_list[1:]):
            temp_ws = wb.create_sheet(title=sheet_name)
            for row in rows:
                temp_ws.append(row)

        response = HttpResponse(
            content_type="application/force-download; application/octet-stream; application/download")
        response['Pragma'] = 'no-cache'
        response['Expires'] = 0
        response['Content-Disposition'] = 'attachment; filename=%s' % file_name
        wb.save(response)

        return response

    @staticmethod
    def multi_list_to_excel(file_name, sheet_name, count_list, branch_excel_rows, model_excel_rows):

        wb = Workbook()
        ws = wb.active
        ws.title = sheet_name

        for count in count_list:
            ws.append(count)

        # Branch Sheet
        ws_branch = wb.create_sheet(title="Country")
        for row in branch_excel_rows:
            ws_branch.append(row)
        ExcelUtils.set_sum_row(ws=ws_branch, row_index=len(branch_excel_rows) + 1,
                               col_count=len(branch_excel_rows[0]) + 1)

        # Device Sheet
        ws_model = wb.create_sheet(title="Device")
        for row in model_excel_rows:
            ws_model.append(row)
        ExcelUtils.set_sum_row(ws=ws_model, row_index=len(model_excel_rows) + 1, col_count=len(model_excel_rows[0]) + 1)

        response = HttpResponse(
            content_type="application/force-download; application/octet-stream; application/download")
        response['Pragma'] = 'no-cache'
        response['Expires'] = 0
        response['Content-Disposition'] = 'attachment; filename=%s' % file_name
        wb.save(response)

        return response

    @staticmethod
    def get_file_name(title):
        file_name = '%s_%s.xlsx' % (title, datetime.now().date())
        return file_name

    @staticmethod
    def get_voc_file_name(title, voc_type=0):
        voc_type_str_list = ["total", "qna", "error", "suggestion", "inhouse", "system", "retail", "community_error"]
        file_name = '%s_%s_%s.xlsx' % (title, voc_type_str_list[voc_type], datetime.now().date())
        return file_name

    @staticmethod
    def get_excel_headers(excel_type=None):
        if excel_type is None:
            return [["Date", "Count"]]
        elif excel_type == 'cnty':
            return []  # to do
        elif excel_type == 'tab_branch_id' or excel_type == 'tab_branch':
            return [["Country", "Count", "Percent(%)"]]
        elif excel_type == 'tab_model' or excel_type == 'tab_device':
            return [["Device", "Count", "Percent(%)"]]
        elif excel_type == 'tab_page_id':
            return [["PageName", "Count", "Percent(%)"]]
        elif excel_type == 'tab_event':
            return [["ScreenName", "EventName", "Count", "Percent(%)"]]

    @staticmethod
    def set_sum_row(ws, row_index, col_count):
        first_cell = ws["A" + str(row_index)]

        default_cell_font = first_cell.font.copy(bold=True)
        default_cell_fill = PatternFill(start_color='95CEFF', end_color='95CEFF', fill_type="solid")
        default_cell_border = Border(left=Side(style='thin'), right=Side(style='thin'),
                                     top=Side(style='thin'), bottom=Side(style='thin'))

        first_cell.font = default_cell_font
        first_cell.border = default_cell_border
        first_cell.alignment = Alignment(horizontal='center')
        first_cell.value = "TOTAL"

        for i in range(2, col_count):
            cell_name = get_column_letter(i)
            insert_cell_name = cell_name + str(row_index)
            cell = ws[insert_cell_name]

            cell.font = default_cell_font
            cell.fill = default_cell_fill
            cell.border = default_cell_border

            str_sum_function = "=SUM(" + cell_name + "1:" + cell_name + str(row_index - 1) + ")"
            cell.value = str_sum_function

    @staticmethod
    def multi_list_to_contents_excel(file_name, contents_id, start_date, end_date, list_data, title_rows, device_rows,
                                     category_rows=None):
        wb = Workbook()

        # Count Sheet
        ws = wb.active
        ws.title = "Count"
        for obj in list_data:
            ws.append(obj)

        # Title Sheet
        title = 'Title(' + start_date + '~' + end_date + ')'
        ws_title = wb.create_sheet(title=title)
        for row in title_rows:
            ws_title.append(row)

        # Device Sheet
        if contents_id == '0':
            contents_id = 'Total'
        title = 'Device(ID=' + contents_id + ')'
        ws_device = wb.create_sheet(title=title)
        for row in device_rows:
            ws_device.append(row)

        # Category Sheet
        if category_rows is not None:
            if contents_id == '0':
                contents_id = 'Total'
            title = 'Category(ID=' + contents_id + ')'
            ws_category = wb.create_sheet(title=title)
            for row in category_rows:
                ws_category.append(row)

        response = HttpResponse(
            content_type="application/force-download; application/octet-stream; application/download")
        response['Pragma'] = 'no-cache'
        response['Expires'] = 0
        response['Content-Disposition'] = 'attachment; filename=%s' % file_name
        wb.save(response)

        return response

    @staticmethod
    def multi_list_to_ref_contents_excel(excel_name, content_id, start_date, end_date, excel_rows, device_rows,
                                         category_rows, title_rows, nat_category_rows, weblink_rows):

        wb = Workbook()

        # Count Sheet
        ws = wb.active
        ws.title = "Count"
        for obj in excel_rows:
            ws.append(obj)

        # News&Tips Category Count Sheet
        if nat_category_rows is not None:
            title = 'Category Count'
            ws_nat_category = wb.create_sheet(title=title)
            for row in nat_category_rows:
                ws_nat_category.append(row)

        # Title Sheet
        if title_rows is not None:
            title = 'Title(' + start_date + '~' + end_date + ')'
            ws_title = wb.create_sheet(title=title)
            for row in title_rows:
                ws_title.append(row)

        # Device Sheet
        if content_id == '0':
            content_id = 'Total'
        title = 'Device(ID=' + content_id + ')'
        ws_device = wb.create_sheet(title=title)
        for row in device_rows:
            ws_device.append(row)

        # Category Sheet
        if category_rows is not None:
            if content_id == '0':
                content_id = 'Total'
            title = 'Category(ID=' + content_id + ')'
            ws_category = wb.create_sheet(title=title)
            for row in category_rows:
                ws_category.append(row)

        # Weblink Sheet
        if weblink_rows is not None:
            if content_id == '0':
                content_id = 'Total'
            title = 'Social(ID=' + content_id + ')'
            ws_category = wb.create_sheet(title=title)
            for row in weblink_rows:
                ws_category.append(row)

        response = HttpResponse(
            content_type="application/force-download; application/octet-stream; application/download")
        response['Pragma'] = 'no-cache'
        response['Expires'] = 0
        response['Content-Disposition'] = 'attachment; filename=%s' % excel_name
        wb.save(response)

        return response

    @staticmethod
    def multi_list_to_diagnosis_excel(excel_name,
                                      excel_rows, device_rows, country_rows, category_rows):

        wb = Workbook()

        # Count Sheet
        ws = wb.active
        ws.title = "Count"
        for obj in excel_rows:
            ws.append(obj)

        # Device Sheet
        title = 'Device'
        ws_device = wb.create_sheet(title=title)
        for row in device_rows:
            ws_device.append(row)

        # Country Sheet
        if country_rows is not None:
            title = 'Branch'
            ws_title = wb.create_sheet(title=title)
            for row in country_rows:
                ws_title.append(row)

        # Category Sheet
        if category_rows is not None:
            title = 'Category'
            ws_category = wb.create_sheet(title=title)
            for row in category_rows:
                ws_category.append(row)

        response = HttpResponse(
            content_type="application/force-download; application/octet-stream; application/download")
        response['Pragma'] = 'no-cache'
        response['Expires'] = 0
        response['Content-Disposition'] = 'attachment; filename=%s' % excel_name
        wb.save(response)

        return response

    @staticmethod
    def multi_list_to_diagnosis_excel_detail(excel_name,
                                             excel_rows, detail_2_rows=None):

        wb = Workbook()

        if detail_2_rows is None:
            # Detail Sheet
            ws = wb.active
            ws.title = "Detail"
            for obj in excel_rows:
                ws.append(obj)
        else:
            # Detail Sheet
            ws = wb.active
            ws.title = "Detail(bad)"
            for obj in excel_rows:
                ws.append(obj)
            # Detail Sheet 2 (for battery)
            title = 'Detail(weak)'
            ws_title = wb.create_sheet(title=title)
            for row in detail_2_rows:
                ws_title.append(row)

        response = HttpResponse(
            content_type="application/force-download; application/octet-stream; application/download")
        response['Pragma'] = 'no-cache'
        response['Expires'] = 0
        response['Content-Disposition'] = 'attachment; filename=%s' % excel_name
        wb.save(response)

        return response

    @staticmethod
    def remove_escape_string(string):
        # remove BOM Characters
        string = string.replace('\ufffe', '')
        string = string.replace('\ufeff', '')

        # remove excel illegal characters
        ILLEGAL_CHARACTERS_RE = re.compile(r'[\000-\010]|[\013-\014]|[\016-\037]')
        string = ILLEGAL_CHARACTERS_RE.sub('', string)

        return string

    @staticmethod
    def convert_uv_drilldown_cnty_excel_rows(rows, branch_ids, period):
        date_set = set()
        statistics_dic = {}
        for row in rows:
            branch_id, date, cnt = row
            date_set.add(date)
            statistics_dic[(branch_id, date)] = int(cnt)

        branch_dic = BranchUtils.get_all_branch_dict()
        branch_list = list(map(int, branch_ids))

        date_list = list(date_set)
        date_list.sort(key=DateUtils.get_date_sort_key(period))

        cnty = ["Date"]
        for branch in branch_list:
            if branch != 0:
                cnty.append(branch_dic[branch])
        accumulative_excel_rows = [cnty]
        daily_new_excel_rows = [cnty]

        for idx, _date in enumerate(date_list):
            accumulative_row = [_date]
            daily_new_row = [_date]
            for branch in branch_list:
                if branch != 0:
                    value = statistics_dic.get((branch, _date), 0)
                    accumulative_row.append(value)
                    if idx > 0:
                        value = statistics_dic.get((branch, date_list[idx]), 0) - \
                                statistics_dic.get((branch, date_list[idx - 1]), 0)
                    daily_new_row.append(value)

            accumulative_excel_rows.append(accumulative_row)
            daily_new_excel_rows.append(daily_new_row)

        return dict(accumulative_excel_rows=accumulative_excel_rows, daily_new_excel_rows=daily_new_excel_rows)

    @staticmethod
    def multi_list_to_uv_drilldown_excel(excel_name, accumulative_excel_rows, new_excel_rows):

        wb = Workbook()

        # Accumulative AU Sheet
        ws = wb.active
        ws.title = "Accumulative"
        for obj in accumulative_excel_rows:
            ws.append(obj)

        # Daily New AU Sheet
        title = 'Daily New'
        ws_new = wb.create_sheet(title=title)
        for row in new_excel_rows:
            ws_new.append(row)

        response = HttpResponse(
            content_type="application/force-download; application/octet-stream; application/download")
        response['Pragma'] = 'no-cache'
        response['Expires'] = 0
        response['Content-Disposition'] = 'attachment; filename=%s' % excel_name
        wb.save(response)

        return response

    @staticmethod
    def keyword_excel(excel_name, keyword_rows, period):
        wb = Workbook()
        ws = wb.active

        if len(keyword_rows) > 0:
            temp_date = None
            header = ['Date', 'Keyword', 'Rank', 'Count']

            for idx, row in enumerate(keyword_rows):
                date, keyword, rank, cnt = row

                title = date.strftime("%Y-%m-%d") if period == "day" else date
                temp_row = [date, keyword, rank, int(cnt)]

                if idx == 0:
                    temp_date = date
                    ws.title = title
                    ws.append(header)
                    ws.append(temp_row)
                else:
                    if temp_date != date:
                        ws = wb.create_sheet(title=title)
                        ws.append(header)
                        temp_date = date

                    ws.append(temp_row)

        response = HttpResponse(
            content_type="application/force-download; application/octet-stream; application/download")
        response['Pragma'] = 'no-cache'
        response['Expires'] = 0
        response['Content-Disposition'] = 'attachment; filename=%s' % excel_name
        wb.save(response)

        return response

    @staticmethod
    def multi_list_to_banner_excel(excel_name, banner_id, start_date, end_date,
                                   count_rows, title_rows, device_rows):
        wb = Workbook()

        # Count Sheet
        ws = wb.active
        ws.title = "Count"
        for obj in count_rows:
            ws.append(obj)

        # Title Sheet
        if title_rows is not None:
            title = 'Title(' + start_date + '~' + end_date + ')'
            ws_title = wb.create_sheet(title=title)
            for row in title_rows:
                ws_title.append(row)

        # Device Sheet
        if banner_id == '0':
            banner_id = 'Total'
        title = 'Device(ID=' + banner_id + ')'
        ws_device = wb.create_sheet(title=title)
        for row in device_rows:
            ws_device.append(row)

        response = HttpResponse(
            content_type="application/force-download; application/octet-stream; application/download")
        response['Pragma'] = 'no-cache'
        response['Expires'] = 0
        response['Content-Disposition'] = 'attachment; filename=%s' % excel_name
        wb.save(response)

        return response
