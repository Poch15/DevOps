SELECT branch_id, date::text ||' '|| hour || ':00' as date, sum(cnt) as cnt
FROM
	(
		SELECT timestamp::date as date, cnt, branch_id,
	    CASE  WHEN extract(hour from timestamp) < 10 THEN '0'||extract(hour from timestamp)::text
			      ELSE extract(hour from timestamp)::text
			END as hour
    FROM
      (
	      SELECT date + INTERVAL '{interval_hour}' HOUR as timestamp, branch_id, sum(cnt) as cnt
	      FROM {tbl_name}
          WHERE
            date  >= '{start_date}'::DATE - INTERVAL '{interval_hour}' HOUR
            AND
            date < '{end_date}'::DATE - INTERVAL '{interval_hour}' HOUR + INTERVAL '1' DAY
            AND
            branch_id IN {branch_ids}
            AND
            model {model}
          GROUP BY timestamp, branch_id
      ) AS A
	) AS B
GROUP BY branch_id, date, hour
ORDER BY branch_id, date, hour