SELECT date, (SUM(add_cnt) - SUM(del_cnt)) AS cnt
FROM v3_newsntips_like
WHERE
  date >= '{start_date}'
  AND
  date <= '{end_date}'
  AND
    CASE
    WHEN '{content_id}' = '0' THEN
        branch_id IN {branch_ids}
    ELSE
        branch_id IN {branch_ids} AND content_id = '{content_id}'
    END
GROUP BY date
ORDER BY date