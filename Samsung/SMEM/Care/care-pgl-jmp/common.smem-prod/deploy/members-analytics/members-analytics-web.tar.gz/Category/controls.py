import os
from common.utils import Utils
from datetime import datetime
from common.dbutils import DBUtils
from common.excel_utils import ExcelUtils
from common.branch_utils import BranchUtils

__author__ = 'sunggeun.han'


class CategoryController:
    @staticmethod
    def get_count_data(start_date, end_date, period, branch_ids, model, interval_hour):

        sql = DBUtils.load_query('category', 'get_category_%s.sql' % period)
        params = {'start_date': start_date, 'end_date': end_date,
                  'branch_ids': branch_ids, 'model': model, 'interval_hour': interval_hour}
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)

        category = []
        faq_count_list = []
        for row in return_rows:
            date, faq_count = row[0], row[1:]
            category.append(date)
            faq_count_list.append(faq_count)
        convert_faq_count_list = Utils.row_to_column(faq_count_list)

        faq_name_list = ['Battery', 'Application', 'System/Setting', 'Data transfer', 'Camera/Picture',
                         'Call/Message', 'Accessory', 'Sensor/Touch', 'Network']

        return dict(category=category, faq_name_list=faq_name_list, faq_count_list=faq_count_list,
                    convert_faq_count_list=convert_faq_count_list)

    @staticmethod
    def get_count_chart_data(start_date, end_date, period, branch_ids, model, interval_hour):
        return_dict = CategoryController.get_count_data(start_date, end_date, period, branch_ids, model, interval_hour)
        category = return_dict['category']
        faq_name_list = return_dict['faq_name_list']
        faq_count_list = return_dict['convert_faq_count_list']

        data = []
        for name, counts in zip(faq_name_list, faq_count_list):
            data.append({"name": name, "data": counts})
        return dict(category=category, data=data, count=len(category))

    @staticmethod
    def get_count_excel_data(start_date, end_date, period, branch_ids, model, interval_hour):
        return_dict = CategoryController.get_count_data(start_date, end_date, period, branch_ids, model, interval_hour)
        date_list = return_dict['category']
        faq_name_list = return_dict['faq_name_list']
        faq_count_list = return_dict['faq_count_list']

        category_cell = ["Date"]
        count_rows = [category_cell + faq_name_list]

        for date, faq_counts in zip(date_list, faq_count_list):
            row = [date] + list(faq_counts)
            count_rows.append(row)

        branch_excel_rows = CategoryController.get_tab_excel_data('branch_id', start_date, end_date, period, branch_ids,
                                                                  model, interval_hour, date_list)

        model_excel_rows = CategoryController.get_tab_excel_data('model', start_date, end_date, period, branch_ids,
                                                                 model, interval_hour, date_list)

        file_name = 'FAQ_%s.xlsx' % datetime.now().date()
        return ExcelUtils.multi_list_to_excel(file_name, "Category", count_rows, branch_excel_rows, model_excel_rows)

    @staticmethod
    def get_tab_count_data(tab_type, start_date, end_date, period, branch_ids, model, interval_hour):

        sql = DBUtils.load_query('category', 'get_faq_tab_%s.sql' % period)
        params = {'start_date': start_date, 'end_date': end_date, 'tab_type': tab_type,
                  'branch_ids': branch_ids, 'model': model, 'interval_hour': interval_hour}
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)

        group_list = set()
        faq_count_list = {}

        for row in return_rows:
            date, group, count = row
            group_list.add(group)
            faq_count_list[(date, group)] = count

        group_list = list(group_list)
        group_list.sort()

        return dict(group_list=group_list, faq_count_list=faq_count_list)

    @staticmethod
    def get_tab_excel_data(tab_type, start_date, end_date, period, branch_ids, model, interval_hour, date_list):

        excel_data_dict = CategoryController.get_tab_count_data(tab_type, start_date, end_date, period, branch_ids,
                                                                model, interval_hour)
        count_dict = excel_data_dict['faq_count_list']
        group_list = excel_data_dict['group_list']

        excel_header = []

        # branch_id => branch_name
        if tab_type is 'branch_id':
            branch_dic = BranchUtils.get_all_branch_dict()
            for branch_id in group_list:
                excel_header.append(branch_dic.get(branch_id, ""))
        else:
            excel_header = group_list

        excel_rows = [['Date'] + excel_header]

        for _date in date_list:
            rows = [_date]
            for group in group_list:
                rows.append(count_dict.get((_date, group), 0))
            excel_rows.append(rows)

        return excel_rows
