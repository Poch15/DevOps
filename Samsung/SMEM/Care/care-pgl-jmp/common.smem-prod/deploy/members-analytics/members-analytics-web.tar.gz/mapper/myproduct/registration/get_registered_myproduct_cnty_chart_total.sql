SELECT company_cd, sum(cnt)
FROM v3_mp_product
WHERE
    date < '{start_date}'
  AND
    company_cd IN {company_codes}
GROUP BY company_cd
ORDER BY company_cd