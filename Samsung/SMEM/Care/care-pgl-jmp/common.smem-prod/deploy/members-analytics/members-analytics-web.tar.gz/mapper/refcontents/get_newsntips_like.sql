SELECT content_id, branch_id, (SUM(add_cnt) - SUM(del_cnt)) AS cnt
FROM v3_newsntips_like
WHERE
date >= '{start_date}'
AND
date <= '{end_date}'
GROUP BY content_id, branch_id