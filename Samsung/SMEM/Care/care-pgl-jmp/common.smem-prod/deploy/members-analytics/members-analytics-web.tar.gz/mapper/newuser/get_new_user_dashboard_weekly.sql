SELECT
 SUM(cnt) as count
FROM v3_new_user
  WHERE
	  datetime >= '{start_date}'::timestamp
  AND
	  datetime < '{end_date}'::timestamp
  AND
    branch_id IN {branch_ids}