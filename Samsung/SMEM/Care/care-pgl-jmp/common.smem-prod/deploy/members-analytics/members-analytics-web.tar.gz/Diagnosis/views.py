from django.http import JsonResponse
from django.shortcuts import render_to_response
from django.template.context import RequestContext
from django.views.decorators.http import require_http_methods
from Diagnosis.controls import DiagnosisController
from common.utils import custom_login_required, access_log
from common.params_utils import ParamsUtils
from SessionManager.controls import SessionManagerController
from common.exception_handler import ExceptionHandler


@ExceptionHandler(return_type=ExceptionHandler.RETURN_HTTP)
@custom_login_required
@require_http_methods(["GET"])
@access_log
def view_auto(request):
    template = 'diagnosis/diagnosis_detail.html'
    return render_to_response(template, {'diagnosis_type': 1, 'diagnosis_name': 'Automatic Checks',
                                         'detail_chart_name': 'Automatic Checks detail chart (only count failed result)'},
                              context_instance=RequestContext(request))


@ExceptionHandler(return_type=ExceptionHandler.RETURN_HTTP)
@custom_login_required
@require_http_methods(["GET"])
@access_log
def view_inter(request):
    template = 'diagnosis/diagnosis_detail.html'
    return render_to_response(template, {'diagnosis_type': 2, 'diagnosis_name': 'Interactive Checks',
                                         'detail_chart_name': 'Interactive Checks country chart'},
                              context_instance=RequestContext(request))


@ExceptionHandler(return_type=ExceptionHandler.RETURN_HTTP)
@custom_login_required
@require_http_methods(["GET"])
@access_log
def view_battery(request):
    template = 'diagnosis/diagnosis_detail.html'
    return render_to_response(template, {'diagnosis_type': 3, 'diagnosis_name': 'Battery',
                                         'detail_chart_name': 'Battery detail chart (only count WEAK status)'},
                              context_instance=RequestContext(request))


@custom_login_required
@require_http_methods(["GET"])
def get_count_chart_data(request):
    try:
        count_chart_data = DiagnosisController.get_count_chart_data(
            start_date=ParamsUtils.get_param(request, "start_date"),
            end_date=ParamsUtils.get_param(request, "end_date"),
            branch_ids=SessionManagerController.get_selected_branch_ids(request),
            model=ParamsUtils.get_param(request, "query_model"),
            period=ParamsUtils.get_param(request, "period"),
            type=ParamsUtils.get_param(request, "type")
        )
        return JsonResponse(count_chart_data)
    except Exception as e:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})


@custom_login_required
@require_http_methods(["GET"])
def get_detail_chart_data(request):
    try:
        count_chart_data = DiagnosisController.get_detail_chart_data(
            start_date=ParamsUtils.get_param(request, "start_date"),
            end_date=ParamsUtils.get_param(request, "end_date"),
            branch_ids=SessionManagerController.get_selected_branch_ids(request),
            model=ParamsUtils.get_param(request, "query_model"),
            period=ParamsUtils.get_param(request, "period"),
            type=ParamsUtils.get_param(request, "type"),
            result=ParamsUtils.get_param(request, "result")
        )
        return JsonResponse(count_chart_data)
    except Exception as e:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})


@custom_login_required
@require_http_methods(["GET"])
def get_analysis_category_data(request):
    try:
        count_chart_data = DiagnosisController.get_analysis_category_data(
            start_date=request.GET.get("start_date"),
            end_date=request.GET.get("end_date"),
            branch_ids=SessionManagerController.get_selected_branch_ids(request),
            model=ParamsUtils.get_param(request, "query_model"),
            cur_p=ParamsUtils.get_param(request, "cur_p"),
            page_size=int(ParamsUtils.get_param(request, "page_size")),
            type=ParamsUtils.get_param(request, "type")
        )
        return JsonResponse(count_chart_data)
    except Exception as e:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})


@custom_login_required
@require_http_methods(["GET"])
def get_analysis_device_data(request):
    try:
        count_chart_data = DiagnosisController.get_analysis_device_data(
            start_date=request.GET.get("start_date"),
            end_date=request.GET.get("end_date"),
            branch_ids=SessionManagerController.get_selected_branch_ids(request),
            model=ParamsUtils.get_param(request, "query_model"),
            cur_p=ParamsUtils.get_param(request, "cur_p"),
            page_size=int(ParamsUtils.get_param(request, "page_size")),
            type=ParamsUtils.get_param(request, "type")
        )
        return JsonResponse(count_chart_data)
    except Exception as e:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})


@custom_login_required
@require_http_methods(["GET"])
def get_analysis_country_data(request):
    try:
        count_chart_data = DiagnosisController.get_analysis_country_data(
            start_date=request.GET.get("start_date"),
            end_date=request.GET.get("end_date"),
            branch_ids=SessionManagerController.get_selected_branch_ids(request),
            model=ParamsUtils.get_param(request, "query_model"),
            cur_p=ParamsUtils.get_param(request, "cur_p"),
            page_size=int(ParamsUtils.get_param(request, "page_size")),
            type=ParamsUtils.get_param(request, "type")
        )
        return JsonResponse(count_chart_data)
    except Exception as e:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})


@custom_login_required
@require_http_methods(["GET"])
def export_excel(request):
    try:
        excel_count_data = DiagnosisController.get_count_excel_data(
            start_date=ParamsUtils.get_param(request, "start_date"),
            end_date=ParamsUtils.get_param(request, "end_date"),
            period=ParamsUtils.get_param(request, "period"),
            branch_ids=SessionManagerController.get_selected_branch_ids(request),
            model=ParamsUtils.get_param(request, "query_model"),
            type=ParamsUtils.get_param(request, "type")
        )
        return excel_count_data
    except Exception as e:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})


@custom_login_required
@require_http_methods(["GET"])
def export_excel_detail(request):
    try:
        excel_count_data = DiagnosisController.get_count_excel_data_detail(
            start_date=ParamsUtils.get_param(request, "start_date"),
            end_date=ParamsUtils.get_param(request, "end_date"),
            period=ParamsUtils.get_param(request, "period"),
            branch_ids=SessionManagerController.get_selected_branch_ids(request),
            model=ParamsUtils.get_param(request, "query_model"),
            type=ParamsUtils.get_param(request, "type")
        )
        return excel_count_data
    except Exception as e:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})

