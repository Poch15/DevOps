SELECT
    CASE WHEN monthval < 10 THEN yearval || '/0' || monthval
			   ELSE yearval || '/' || monthval
		END as yearmonth,
		service_id,
		sumval
FROM
(
	SELECT extract(year from dateval) as yearval, extract(month from dateval) as monthval, service_id, sum(count) as sumval
	FROM
	(
		SELECT date as dateval, service_id, sum(cnt) as count
		FROM v3_more_svc_event
		  WHERE
		      date >= '{start_date}'::date
		    AND
		      date < '{end_date}'::date + INTERVAL '1' DAY
		    AND
		      branch_id IN {branch_ids}
		    AND
		      model {model}
		GROUP BY dateval, service_id
		ORDER BY dateval
	) AS A
	GROUP BY yearval, monthval, service_id
	ORDER BY yearval, monthval
) AS B