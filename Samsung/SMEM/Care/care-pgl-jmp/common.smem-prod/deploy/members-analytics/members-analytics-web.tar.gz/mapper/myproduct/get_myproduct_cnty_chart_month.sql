select branch_id, yearmonth, sum(cnt) as cnt
  from
(
  SELECT
    branch_id,
    CASE WHEN monthval < 10
      THEN yearval || '/0' || monthval
    ELSE yearval || '/' || monthval
    END AS yearmonth,
    cnt
  FROM
    (
      SELECT
        branch_id,
        extract(YEAR FROM dateval)  AS yearval,
        extract(MONTH FROM dateval) AS monthval,
        sum(cnt)                    AS cnt
      FROM
        (
          (
            SELECT
              branch_id,
              date     AS dateval,
              sum(cnt) AS cnt
            FROM
              (
                SELECT datetime::DATE as date, cnt, branch_id
                FROM  v3_myproduct_summary
                WHERE
                  datetime >= '{start_date}' :: TIMESTAMP
                  AND
                  datetime < '{end_date}' :: TIMESTAMP + INTERVAL '1' DAY
                AND
                  req_type = {request_type}
                AND
                  branch_id IN {branch_ids}
                AND
                  status = 'E0000'
              ) AS A
            GROUP BY branch_id, date
            ORDER BY branch_id, date
          )
          UNION ALL
          (
            SELECT
              0 as branch_id,
              date,
              0  AS sum
            FROM
              (
                SELECT C.date
                FROM
                  (
                    SELECT '{start_date}' :: DATE + (100 * aa.a + 10 * bb.a + cc.a) AS date
                    FROM (
                           SELECT 0 AS a
                           UNION ALL SELECT 1
                           UNION ALL SELECT 2
                           UNION ALL SELECT 3
                           UNION ALL SELECT 4
                           UNION ALL SELECT 5
                           UNION ALL SELECT 6
                           UNION ALL SELECT 7
                           UNION ALL SELECT 8
                           UNION ALL SELECT 9
                         ) AS aa CROSS JOIN
                      (
                        SELECT 0 AS a
                        UNION ALL SELECT 1
                        UNION ALL SELECT 2
                        UNION ALL SELECT 3
                        UNION ALL SELECT 4
                        UNION ALL SELECT 5
                        UNION ALL SELECT 6
                        UNION ALL SELECT 7
                        UNION ALL SELECT 8
                        UNION ALL SELECT 9
                      ) AS bb
                      CROSS JOIN
                      (
                        SELECT 0 AS a
                        UNION ALL SELECT 1
                        UNION ALL SELECT 2
                        UNION ALL SELECT 3
                        UNION ALL SELECT 4
                        UNION ALL SELECT 5
                        UNION ALL SELECT 6
                        UNION ALL SELECT 7
                        UNION ALL SELECT 8
                        UNION ALL SELECT 9
                      ) AS cc
                  ) AS C
                WHERE C.DATE < '{end_date}' :: DATE + INTERVAL '1' DAY
              ) AS D
          )
        ) AS F
      GROUP BY branch_id, extract(YEAR FROM dateval), extract(MONTH FROM dateval)
      ORDER BY branch_id, extract(YEAR FROM dateval), extract(MONTH FROM dateval)
    ) AS G
) AS F
group by branch_id, yearmonth
order by branch_id, yearmonth