from django.http.response import JsonResponse
from django.shortcuts import render_to_response
from django.template.context import RequestContext
from django.views.decorators.http import require_http_methods
from Keyword.controls import KeywordController
from common.utils import custom_login_required, access_log
from SessionManager.controls import SessionManagerController
from common.params_utils import ParamsUtils
from common.date_utils import DateUtils


@custom_login_required
@require_http_methods(["GET"])
@access_log
def view_keyword_day(request):
    template = 'search/keyword.html'
    source = ParamsUtils.get_param(request, "source")

    source_str = 'Samsung Members'
    if source == '1':
        source_str = 'SFinder'

    return render_to_response(template,
                              context_instance=RequestContext(request),
                              dictionary={
                                  "source": source,
                                  "source_str": source_str
                              })


@custom_login_required
@require_http_methods(["GET"])
def get_chart_data(request):
    try:
        chart_data = KeywordController.get_chart_data(
            start_date=ParamsUtils.get_param(request, "start_date"),
            end_date=ParamsUtils.get_param(request, "end_date"),
            branch_ids=SessionManagerController.get_selected_branch_ids(request),
            model=ParamsUtils.get_param(request, "query_model"),
            source=ParamsUtils.get_param(request, "source"),
        )
        return JsonResponse(chart_data)

    except Exception as e:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})


@custom_login_required
@require_http_methods(["GET"])
def get_table_data(request):
    try:
        table_data = KeywordController.get_table_data(
            start_date=ParamsUtils.get_param(request, "start_date"),
            end_date=ParamsUtils.get_param(request, "end_date"),
            branch_ids=SessionManagerController.get_selected_branch_ids(request),
            model=ParamsUtils.get_param(request, "query_model"),
            source=ParamsUtils.get_param(request, "source"),
            cur_p=ParamsUtils.get_param(request, "cur_p"),
            page_size=int(ParamsUtils.get_param(request, "page_size"))
        )

        return JsonResponse(table_data)
    except Exception:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})


@custom_login_required
@require_http_methods(["GET"])
def get_table_excel_data(request):
    try:
        table_excel_data = KeywordController.get_keyword_excel(
            start_date=ParamsUtils.get_param(request, "start_date"),
            end_date=ParamsUtils.get_param(request, "end_date"),
            branch_ids=SessionManagerController.get_selected_branch_ids(request),
            model=ParamsUtils.get_param(request, "query_model"),
            source=ParamsUtils.get_param(request, "source"),
            period=ParamsUtils.get_param(request, "period")
        )

        return table_excel_data
    except Exception as e:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})


@custom_login_required
@require_http_methods(["GET"])
def get_trend_chart_data(request):
    try:
        start_date = ParamsUtils.get_param(request, "start_date")
        end_date = ParamsUtils.get_param(request, "end_date")
        model = ParamsUtils.get_param(request, "query_model")
        period = ParamsUtils.get_param(request, "period")

        if (period == 'day' and DateUtils.is_default_date_range(start_date, end_date, 10, 'day') and model == 'all') or \
                (period == 'week' and DateUtils.is_default_date_range(start_date, end_date, 49, 'week') and model == 'all'):
            chart_data = KeywordController.get_dashboard_chart_data(
                start_date=start_date,
                end_date=end_date,
                branch_name=SessionManagerController.get_selected_branch_name(request),
                source=ParamsUtils.get_param(request, "source"),
                period=ParamsUtils.get_param(request, "period")
            )
        else:
            chart_data = KeywordController.get_trend_chart_data(
                start_date=start_date,
                end_date=end_date,
                branch_ids=SessionManagerController.get_selected_branch_ids(request),
                model=model,
                period=ParamsUtils.get_param(request, "period"),
                source=ParamsUtils.get_param(request, "source")
            )
        return JsonResponse(chart_data)

    except Exception as e:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})


@custom_login_required
@require_http_methods(["GET"])
def get_keyword_cloud(request):
    try:
        start_date = ParamsUtils.get_param(request, "start_date")
        end_date = ParamsUtils.get_param(request, "end_date")
        model = ParamsUtils.get_param(request, "query_model")
        period = ParamsUtils.get_param(request, "period")

        if (period == 'day' and DateUtils.is_default_date_range(start_date, end_date, 10, 'day') and model == 'all') or \
                (period == 'week' and DateUtils.is_default_date_range(start_date, end_date, 49, 'week') and model == 'all'):
            chart_data = KeywordController.get_dashboard_keyword_cloud_data(
                branch_name=SessionManagerController.get_selected_branch_name(request),
                source=ParamsUtils.get_param(request, "source"),
                period=ParamsUtils.get_param(request, "period")
            )
        else:
            chart_data = KeywordController.get_keyword_cloud_data(
                start_date=start_date,
                end_date=end_date,
                branch_ids=SessionManagerController.get_selected_branch_ids(request),
                model=model,
                source=ParamsUtils.get_param(request, "source")
            )
        return JsonResponse(chart_data)
    except Exception as e:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})
