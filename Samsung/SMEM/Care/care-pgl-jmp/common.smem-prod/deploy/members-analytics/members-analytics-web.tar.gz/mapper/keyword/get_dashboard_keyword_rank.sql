SELECT keyword, cnt
FROM v3_dash_keyword_adv_rank
WHERE
  branch_name = '{branch_name}'
AND
  source = {source}
AND
  period = '{period}'
ORDER BY rank
LIMIT {limit}