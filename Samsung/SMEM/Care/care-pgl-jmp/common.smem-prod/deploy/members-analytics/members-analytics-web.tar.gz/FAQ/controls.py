from common.dbutils import DBUtils
from common.utils import Utils
from common.params_utils import ParamsUtils
from common.excel_utils import ExcelUtils
from datetime import datetime
from operator import itemgetter
from common.branch_utils import BranchUtils


class FAQController:
    @staticmethod
    def get_count_data(start_date, end_date, period, branch_ids, model, interval_hour):
        sql = DBUtils.load_query('faq', 'get_faq_%s.sql' % period)
        params = {'start_date': start_date, 'end_date': end_date,
                  'branch_ids': branch_ids, 'model': model, 'interval_hour': interval_hour}
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)

        date_list = set()
        faq_category_dict = Utils.get_category_dict()
        faq_count_dict = {}
        for row in return_rows:
            date, cat_id, count = row
            date_list.add(date)
            faq_count_dict[(date, cat_id)] = count

        date_list = list(date_list)
        date_list.sort()

        return dict(date_list=date_list, faq_category_dict=faq_category_dict, faq_count_dict=faq_count_dict)

    @staticmethod
    def get_count_chart_data(start_date, end_date, period, branch_ids, model, interval_hour):
        return_dict = FAQController.get_count_data(start_date, end_date, period, branch_ids, model, interval_hour)
        date_list = return_dict['date_list']
        faq_category_dict = return_dict['faq_category_dict']
        faq_count_dict = return_dict['faq_count_dict']

        data = []
        for cat_id in sorted(faq_category_dict.keys()):
            counts = []
            for date in date_list:
                counts.append(faq_count_dict.get((date, cat_id), 0))
            data.append({"name": faq_category_dict[cat_id], "data": counts})

        return dict(category=date_list, data=data)

    @staticmethod
    def get_analysis_tab_data(start_date, end_date, branch_ids, model, interval_hour,
                              tab_type, cur_p, page_size):
        # get total count
        sql = DBUtils.load_query('faq', 'get_faq_analysis_%s_total_count.sql' % tab_type)
        params = {'start_date': start_date, 'end_date': end_date, 'branch_ids': branch_ids,
                  'model': model, 'interval_hour': interval_hour}
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)
        total_count = return_rows[0][0]

        # get tab count
        paging_params = ParamsUtils.get_paging_params(cur_p, total_count, page_size)
        params.update(paging_params)
        sql = DBUtils.load_query('faq', 'get_faq_analysis_%s.sql' % tab_type)
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)

        category = []
        for return_row in return_rows:
            category.append(return_row[0])

        return dict(category=category, data=return_rows, tot_p=paging_params['total_page'], cur_p=int(cur_p))

    @staticmethod
    def get_analysis_category_data(start_date, end_date, branch_ids, model, interval_hour):
        sql = DBUtils.load_query('faq', 'get_faq_analysis_category.sql')
        params = {'start_date': start_date, 'end_date': end_date, 'branch_ids': branch_ids,
                  'model': model, 'interval_hour': interval_hour}
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)

        category = []
        cat_dict = Utils.get_category_dict()
        for row in return_rows:
            cat_id, count, percent = row
            category.append(cat_dict.get(cat_id, 'Unknown'))

        return dict(category=category, data=return_rows)

    @staticmethod
    def get_count_excel_data(start_date, end_date, period, branch_ids, model, interval_hour):
        return_dict = FAQController.get_count_data(start_date, end_date, period, branch_ids, model, interval_hour)
        date_list = return_dict['date_list']
        faq_name_dict = return_dict['faq_category_dict']
        faq_count_dict = return_dict['faq_count_dict']

        category_cell = ["Date"]
        faq_name_list = sorted(faq_name_dict.items(), key=itemgetter(0))
        sorted_faq_name_list = []
        for key, value in faq_name_list:
            sorted_faq_name_list.append(value)
        count_rows = [category_cell + sorted_faq_name_list]

        for date in date_list:
            faq_counts = []
            for key, value in faq_name_list:
                faq_counts.append(faq_count_dict.get((date, key), 0))
            row = [date] + faq_counts
            count_rows.append(row)

        branch_excel_rows = FAQController.get_tab_excel_data('branch_id', start_date, end_date, period, branch_ids,
                                                             model, interval_hour, date_list)

        model_excel_rows = FAQController.get_tab_excel_data('model', start_date, end_date, period, branch_ids,
                                                            model, interval_hour, date_list)

        file_name = 'FAQ_%s.xlsx' % datetime.now().date()
        return ExcelUtils.multi_list_to_excel(file_name, "Category", count_rows, branch_excel_rows, model_excel_rows)

    @staticmethod
    def get_tab_count_data(tab_type, start_date, end_date, period, branch_ids, model, interval_hour):

        sql = DBUtils.load_query('faq', 'get_faq_tab_%s.sql' % period)
        params = {'start_date': start_date, 'end_date': end_date, 'tab_type': tab_type,
                  'branch_ids': branch_ids, 'model': model, 'interval_hour': interval_hour}
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)

        group_list = set()
        faq_count_list = {}

        for row in return_rows:
            date, group, count = row
            group_list.add(group)
            faq_count_list[(date, group)] = count

        group_list = list(group_list)
        group_list.sort()

        return dict(group_list=group_list, faq_count_list=faq_count_list)

    @staticmethod
    def get_tab_excel_data(tab_type, start_date, end_date, period, branch_ids, model, interval_hour, date_list):

        excel_data_dict = FAQController.get_tab_count_data(tab_type, start_date, end_date, period, branch_ids,
                                                           model, interval_hour)
        count_dict = excel_data_dict['faq_count_list']
        group_list = excel_data_dict['group_list']

        excel_header = []

        # branch_id => branch_name
        if tab_type is 'branch_id':
            branch_dic = BranchUtils.get_all_branch_dict()
            for branch_id in group_list:
                excel_header.append(branch_dic.get(branch_id, ""))
        else:
            excel_header = group_list

        excel_rows = [['Date'] + excel_header]

        for _date in date_list:
            rows = [_date]
            for group in group_list:
                rows.append(count_dict.get((_date, group), 0))
            excel_rows.append(rows)

        return excel_rows
