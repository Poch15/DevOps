from django.http.response import JsonResponse
from django.shortcuts import render_to_response
from django.template.context import RequestContext
from django.views.decorators.http import require_http_methods
from Keyword.search_controls import SearchController
from Keyword.controls import KeywordController
from common.utils import custom_login_required, access_log
from SessionManager.controls import SessionManagerController
from common.params_utils import ParamsUtils


@custom_login_required
@require_http_methods(["GET"])
@access_log
def view(request):
    template = 'search/search.html'
    return render_to_response(template, context_instance=RequestContext(request))


@custom_login_required
@require_http_methods(["GET"])
def get_trend(request):
    try:
        chart_data = SearchController.get_trend(
            start_date=ParamsUtils.get_param(request, "start_date"),
            end_date=ParamsUtils.get_param(request, "end_date"),
            branch_ids=SessionManagerController.get_selected_branch_ids(request),
            model=ParamsUtils.get_param(request, "query_model"),
            period=ParamsUtils.get_param(request, "period")
        )
        return JsonResponse(chart_data)
    except Exception:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})


@custom_login_required
@require_http_methods(["GET"])
def get_click_trend(request):
    try:
        chart_data = SearchController.get_click_trend(
            start_date=ParamsUtils.get_param(request, "start_date"),
            end_date=ParamsUtils.get_param(request, "end_date"),
            branch_ids=SessionManagerController.get_selected_branch_ids(request),
            model=ParamsUtils.get_param(request, "query_model"),
            period=ParamsUtils.get_param(request, "period")
        )
        return JsonResponse(chart_data)
    except Exception:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})


@custom_login_required
@require_http_methods(["GET"])
def get_click_ratio_trend(request):
    try:
        chart_data = SearchController.get_click_ratio(
            start_date=ParamsUtils.get_param(request, "start_date"),
            end_date=ParamsUtils.get_param(request, "end_date"),
            branch_ids=SessionManagerController.get_selected_branch_ids(request),
            model=ParamsUtils.get_param(request, "query_model"),
            period=ParamsUtils.get_param(request, "period")
        )
        return JsonResponse(chart_data)
    except Exception as e:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})
