SELECT
	CASE
		WHEN EXTRACT(month FROM timestamp_with_timezone) < 10
			THEN EXTRACT(year FROM timestamp_with_timezone) || '/0' || EXTRACT(month FROM timestamp_with_timezone)
		ELSE EXTRACT(year FROM timestamp_with_timezone) || '/' || EXTRACT(month FROM timestamp_with_timezone)
		END AS yearmonth,
	 {tab_type}, SUM(battery_cnt + application_cnt + system_cnt + pc_cnt + camera_cnt + call_cnt + accessory_cnt + sensor_cnt + network_cnt)
FROM
  (
    SELECT distinct (to_timestamp(date||' '||hour,'YYYY-MM-DD HH24') + INTERVAL '{interval_hour}' HOUR)::timestamp as timestamp_with_timezone,
      model, cnty, lang, branch_id,
      battery_cnt, application_cnt, system_cnt, pc_cnt,
      camera_cnt, call_cnt, accessory_cnt, sensor_cnt, network_cnt
    FROM tbl_category_day
    WHERE
       (to_timestamp(date||' '|| hour,'YYYY-MM-DD HH24') + INTERVAL '{interval_hour}' HOUR)::date
      BETWEEN '{start_date}' AND '{end_date}'
      AND
       branch_id IN {branch_ids}
      AND
       model like '{model}%'
  ) AS A
GROUP BY EXTRACT(year FROM timestamp_with_timezone), EXTRACT(month FROM timestamp_with_timezone), {tab_type}