SELECT datetime::date as date, sum(cnt) AS cnt
FROM v3_newsntips
WHERE
  datetime >= '{start_date}'::timestamp
  AND
  datetime < '{end_date}'::timestamp + INTERVAL '1' DAY
  AND
    CASE
    WHEN '{content_id}' = '0' THEN
        branch_id IN {branch_ids}
    ELSE
        branch_id IN {branch_ids} AND content_id = '{content_id}'
    END
GROUP BY date
ORDER BY date