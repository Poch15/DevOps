	SELECT branch_id, yearvalue ||'-'|| weekvalue ||'W' as yearweek, sum(cnt) as cnt
  FROM
  (
    SELECT EXTRACT(isoyear from date) as yearvalue, EXTRACT(week from date) as weekvalue, branch_id, sum(cnt) as cnt
    FROM
    (
      SELECT date + INTERVAL '1' DAY as date, branch_id, sum(cnt) as cnt
    FROM v3_screenview_weekly
    WHERE
        date >= '{start_date}'
    AND
        date <= '{end_date}'
    AND
        branch_id IN {branch_ids}
    AND
        CASE
            WHEN '{page_id}' = ''
                 THEN  model {model}
            ELSE
                 model {model} AND screen_id = '{page_id}'
        END
    GROUP BY date, branch_id
    ) as K
    GROUP BY yearvalue, weekvalue, branch_id
  ) AS A
  GROUP BY branch_id, yearvalue, weekvalue
  ORDER BY branch_id, yearvalue, weekvalue