SELECT COUNT(*), SUM(cnt) as total_cnt
FROM
(
	SELECT screen_id, event_id, SUM(cnt) as cnt
  FROM v3_screen_event
  WHERE
      date >= '{start_date}'
  AND
      date <= '{end_date}'
  AND
    CASE
        WHEN '{page_id}' = ''
             THEN branch_id IN {branch_ids}
        ELSE
             branch_id IN {branch_ids} AND screen_id = '{page_id}'
    END
	GROUP BY screen_id, event_id
) AS A