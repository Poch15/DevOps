SELECT yearval ||' '|| weekval ||'W' as yearweek, source, cnt
FROM
(
  SELECT extract(isoyear from date) as yearval, extract(week from date) as weekval, source, sum(cnt) as cnt
  FROM
  (
    SELECT date + INTERVAL '1' DAY as date, source, sum(cnt) as cnt
    FROM v3_search_summary
    WHERE
      date >= '{start_date}'::date
    AND
      date < '{end_date}'::date + INTERVAL '1' DAY
    AND
      branch_id IN {branch_ids}
    AND
      model {model}
    GROUP BY date, source
    ORDER BY date, source
  ) as A
  GROUP BY extract(isoyear from date), extract(week from date), source
  ORDER BY extract(isoyear from date), extract(week from date), source
) as B