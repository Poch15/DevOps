SELECT branch_id, date, SUM(cnt) AS cnt
FROM {tbl_name}
WHERE
    date >= '{start_date}'
  AND
    date <= '{end_date}'
  AND
    branch_id IN {branch_ids}
  AND
    model {model}
GROUP BY branch_id, date
ORDER BY branch_id, date