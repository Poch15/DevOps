from common.dbutils import DBUtils
from common.chart_utils import ChartUtils
from common.excel_utils import ExcelUtils
from common.params_utils import ParamsUtils
from common.cache_utils import CacheUtils


class ScreenEventController:

    @staticmethod
    def get_count_data(start_date, end_date, period, branch_ids, model, interval_hour, page_id, event_id):
        sql = DBUtils.load_query('screenevent', 'get_screen_event_%s.sql' % period)
        params = {'start_date': start_date, 'end_date': end_date, 'branch_ids': branch_ids,
                  'model': model, 'page_id': page_id, 'event_id': event_id, 'interval_hour': interval_hour}
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)
        return return_rows

    @staticmethod
    def get_count_chart_data(start_date, end_date, period, branch_ids, model, interval_hour, page_id, event_id):
        return_rows = ScreenEventController.get_count_data(start_date, end_date, period, branch_ids,
                                                           model, interval_hour, page_id, event_id)
        chart_rows = ChartUtils.convert_chart_rows(return_rows)
        chart_data = ChartUtils.wrap_chart_data('Screen Event', chart_rows)
        return chart_data

    @staticmethod
    def get_count_excel_data(start_date, end_date, period, branch_ids, model, interval_hour, page_id, event_id):
        return_rows = ScreenEventController.get_count_data(start_date, end_date, period, branch_ids,
                                                           model, interval_hour, page_id, event_id)
        excel_name = ExcelUtils.get_file_name('screen_event')
        excel_rows = ExcelUtils.convert_excel_rows(return_rows)
        excel_data = ExcelUtils.list_to_excel(excel_name, excel_rows)
        return excel_data

    @staticmethod
    def get_country_count_data(start_date, end_date, period, branch_ids, model, interval_hour, page_id, event_id):
        sql = DBUtils.load_query('screenevent', 'get_screen_event_cnty_%s.sql' % period)
        params = {'start_date': start_date, 'end_date': end_date, 'branch_ids': branch_ids,
                  'model': model, 'page_id': page_id, 'event_id': event_id, 'interval_hour': interval_hour}
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)
        return return_rows

    @staticmethod
    def get_country_count_chart_data(start_date, end_date, period, branch_ids, model, interval_hour, page_id, event_id):
        return_rows = ScreenEventController.get_country_count_data(start_date, end_date, period, branch_ids,
                                                                   model, interval_hour, page_id, event_id)
        chart_rows = ChartUtils.convert_country_chart_rows_except_zero(return_rows, period)
        chart_data = ChartUtils.wrap_country_chart_data(chart_rows)
        return chart_data

    @staticmethod
    def get_country_excel_data(start_date, end_date, period, branch_ids, model, interval_hour, page_id, event_id):
        return_rows = ScreenEventController.get_country_count_data(start_date, end_date, period, branch_ids,
                                                                   model, interval_hour, page_id, event_id)
        excel_name = ExcelUtils.get_file_name('screen_event_cnty')
        excel_rows = ExcelUtils.convert_cnty_excel_rows_except_zero(return_rows, branch_ids, period)
        excel_data = ExcelUtils.list_to_excel(excel_name, excel_rows)
        return excel_data

    @staticmethod
    def get_event_rank_count_data(start_date, end_date, branch_ids, model, page_id, cur_p, page_size):
        # get total count
        sql = DBUtils.load_query('screenevent', 'get_screen_event_rank_total.sql')
        params = {'start_date': start_date, 'end_date': end_date, 'branch_ids': branch_ids,
                  'page_id': page_id, 'cur_p': cur_p}
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)
        total_page, total_count = return_rows[0]

        # get page count rank
        paging_params = ParamsUtils.get_paging_params(cur_p, total_page, page_size)
        params.update(paging_params)
        sql = DBUtils.load_query('screenevent', 'get_screen_event_rank_day.sql')
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)

        data_list = []
        for row in return_rows:
            page_id, page_name, event_id, event_name, cnt, percent, app_type, ux_version = row
            data_list.append({
                "page_id": page_id, "page_name": page_name, "event_id": event_id, "event_name": event_name,
                "count": cnt, "percent": percent, "app_type": app_type, "ux_version": ux_version
            })

        return dict(data=data_list, limit=paging_params['limit'],
                    total_count=total_count, tot_p=paging_params['total_page'], cur_p=int(cur_p))

    @staticmethod
    def get_tab_count_data(start_date, end_date, branch_ids, model, page_id, event_id, cur_p, page_size, tab_type):
        # get total count
        sql = DBUtils.load_query('screenevent', 'get_screen_event_tab_total.sql')
        params = {'start_date': start_date, 'end_date': end_date, 'branch_ids': branch_ids, 'model': model,
                  'page_id': page_id, 'event_id': event_id, 'cur_p': cur_p, 'tab_type': tab_type}
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)
        total_count = return_rows[0][0]

        # get tab count
        paging_params = ParamsUtils.get_paging_params(cur_p, total_count, page_size)
        params.update(paging_params)
        params["model"] = model
        sql = DBUtils.load_query('screenevent', 'get_screen_event_tab.sql')
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)

        data_list = []
        for row in return_rows:
            category, cnt, percent = row
            data_list.append({"category": category, "count": cnt, "percent": percent})

        return dict(data=data_list, tot_p=paging_params['total_page'], cur_p=int(cur_p), limit=paging_params['limit'])

    @staticmethod
    def get_tab_excel_data(start_date, end_date, branch_ids, model, interval_hour, page_id, event_id, tab_type, period):
        params = {'start_date': start_date, 'end_date': end_date, 'branch_ids': branch_ids,
                  'model': model, 'page_id': page_id, 'event_id': event_id, 'interval_hour': interval_hour,
                  'tab_type': tab_type, 'limit': 'ALL', 'offset': 0}

        if tab_type == 'event':
            sql = DBUtils.load_query('screenevent', 'get_screen_event_rank_day.sql')
            return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)

            # remove unused column
            for idx, row in enumerate(return_rows):
                page_id, page_name, event_id, event_name, cnt, percent, app_type, ux_version = row
                return_rows[idx] = [page_name, event_name, cnt, percent, ux_version]

        else:
            sql = DBUtils.load_query('screenevent', 'get_screen_event_tab.sql')
            return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, params)

        excel_name = ExcelUtils.get_file_name('screen_event_' + tab_type)
        excel_rows = ExcelUtils.convert_tab_excel_rows('tab_'+tab_type, return_rows)
        excel_data = ExcelUtils.list_to_excel(excel_name, excel_rows)

        return excel_data

    @staticmethod
    def get_screen_info_list():
        cache_key = 'screen_info_list'
        screen_info_list = []
        if CacheUtils.is_cache(cache_key):
            screen_info_list = CacheUtils.get_cache(cache_key)
        else:
            sql = DBUtils.load_query('screenevent', 'get_screen_info.sql')
            return_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, sql, {})

            for row in return_rows:
                screen_id, screen_name = row
                screen_info_list.append({"id": screen_id, "name": screen_name})

            CacheUtils.set_cache(cache_key, screen_info_list)

        return screen_info_list
