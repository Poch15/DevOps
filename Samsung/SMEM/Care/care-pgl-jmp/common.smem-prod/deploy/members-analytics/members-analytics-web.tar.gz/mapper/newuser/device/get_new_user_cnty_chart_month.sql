SELECT
    branch_id,
    CASE WHEN monthval < 10 THEN yearval || '/0' || monthval
			   ELSE yearval || '/' || monthval
		END as yearmonth,
		cnt
FROM
  (
    SELECT extract(year from dateval) as yearval, extract(month from dateval) as monthval, branch_id, sum(cnt) as cnt
    FROM
      (
          (
            SELECT branch_id, date_with_timezone as dateval, sum(cnt) as cnt
            FROM
              (
                SELECT (datetime + INTERVAL '{interval_hour}' HOUR)::DATE as date_with_timezone, cnt, model, branch_id
                FROM {tbl_name}
                WHERE
                  datetime >= '{start_date}'::timestamp - INTERVAL '{interval_hour}' HOUR
                AND
                  datetime < '{end_date}'::timestamp - INTERVAL '{interval_hour}' HOUR + INTERVAL '1' DAY
                AND
                  branch_id IN {branch_ids}
                AND
                  model {model}
              ) AS A
            GROUP BY branch_id, date_with_timezone
            ORDER BY branch_id, date_with_timezone
          )
      ) AS F
    GROUP BY branch_id, extract(year from dateval), extract(month from dateval)
    ORDER BY branch_id, extract(year from dateval), extract(month from dateval)
  ) AS G