from common.chart_utils import ChartUtils
from common.branch_utils import BranchUtils
from django.http import HttpResponse
from openpyxl import Workbook
from common.date_utils import DateUtils


class NewUserUtils:
    @staticmethod
    def get_sql_info(data_type, model, tab_type=None):
        user_path = 'newuser'
        device_path = 'newuser/device'

        if data_type is not None and 'v3' in data_type:
            if 'before' in data_type:
                sql_info = (user_path, 'v3b4_20190801_new_user')
            else:
                if data_type == 'v3_device':
                    sql_info = (device_path, 'v3_new_user_device')
                elif data_type == 'v3_newdevice':
                    sql_info = (device_path, 'tbl_v2_newdevice')
                else:
                    if model != 'all' or tab_type == 'device':
                        sql_info = (device_path, 'v3_new_user_device')
                    else:
                        sql_info = (user_path, 'v3_new_user')
        else:
            if data_type == 'nd':
                sql_info = (device_path, 'tbl_v2_adv_newuser_device')
            elif data_type == 'newdevice':
                sql_info = (device_path, 'tbl_v2_newdevice')
            else:
                if model != 'all' or tab_type == 'device':
                    sql_info = (device_path, 'tbl_v2_adv_newuser_device')
                else:
                    sql_info = (user_path, 'tbl_v2_adv_newuser')
        return sql_info

    @staticmethod
    def convert_chart_rows(rows, prev_tot_cnt):
        category = []
        row_list = []
        for row in rows:
            category.append(row[0])
            count = prev_tot_cnt + int(row[1])
            row_list.append(count)
            prev_tot_cnt = count
        convert = ChartUtils.row_to_column(row_list)

        return dict(category=category, data=convert)

    @staticmethod
    def convert_excel_rows(rows, prev_tot_cnt):
        excel_rows = [["Date", "Count(New)", "Count(Cumulative)"]]
        for row in rows:
            count = prev_tot_cnt + int(row[1])
            excel_rows.append([row[0], int(row[1]), count])
            prev_tot_cnt = count
        return excel_rows

    @staticmethod
    def convert_country_chart_rows(rows):
        date_list = []
        statistics_dic = {}
        for row in rows:
            branch_id, date, cnt = row
            if branch_id == 0:
                date_list.append(date)
            statistics_dic[(branch_id, date)] = int(cnt)

        return dict(date_list=date_list, statistics_dic=statistics_dic)

    @staticmethod
    def wrap_country_chart_data(chart_rows, prev_tot_dict, branch_ids):
        date_list = chart_rows['date_list']
        statistics_dic = chart_rows['statistics_dic']

        branch_dic = BranchUtils.get_all_branch_dict()
        branch_list = list(map(int, branch_ids))

        chart_data = []
        for branch in branch_list:
            if branch != 0:
                tmp_data = []
                prev_tot_cnt = prev_tot_dict.get(branch, 0)
                for _date in date_list:
                    value = statistics_dic.get((branch, _date), 0) + prev_tot_cnt
                    prev_tot_cnt = value
                    tmp_data.append(value)
                chart_data.append({"name": branch_dic[branch], "data": tmp_data})

        return dict(category=date_list, data=chart_data)

    @staticmethod
    def convert_cnty_excel_rows(rows, prev_tot_dict, branch_ids, period):
        date_set = set()
        statistics_dic = {}
        for row in rows:
            branch_id, date, cnt = row
            date_set.add(date)
            statistics_dic[(branch_id, date)] = int(cnt)

        branch_dic = BranchUtils.get_all_branch_dict()
        branch_list = list(map(int, branch_ids))

        date_list = list(date_set)
        date_list.sort(key=DateUtils.get_date_sort_key(period))

        cnty = ["Date"]
        for branch in branch_list:
            if branch != 0:
                cnty.append(branch_dic[branch])
        excel_rows = [cnty]
        cumulative_excel_rows = [cnty]

        for _date in date_list:
            row = [_date]
            cumulative_row = [_date]
            for branch in branch_list:
                if branch != 0:
                    prev_tot_cnt = prev_tot_dict.get(branch, 0)
                    value = statistics_dic.get((branch, _date), 0)
                    cumulative_value = value + prev_tot_cnt
                    prev_tot_dict[branch] = cumulative_value
                    row.append(value)
                    cumulative_row.append(cumulative_value)
            excel_rows.append(row)
            cumulative_excel_rows.append(cumulative_row)

        return excel_rows, cumulative_excel_rows

    @staticmethod
    def cnty_list_to_excel(file_name, cnty_excel_rows):

        new_excel_rows, cumulative_excel_rows = cnty_excel_rows

        wb = Workbook()
        # New Members Sheet
        ws_new = wb.active
        ws_new.title = "New"
        for row in new_excel_rows:
            ws_new.append(row)

        # Cumulative New Members Sheet
        ws_cumulative = wb.create_sheet(title="Cumulative")
        for row in cumulative_excel_rows:
            ws_cumulative.append(row)

        response = HttpResponse(
            content_type="application/force-download; application/octet-stream; application/download")
        response['Pragma'] = 'no-cache'
        response['Expires'] = 0
        response['Content-Disposition'] = 'attachment; filename=%s' % file_name
        wb.save(response)

        return response

    @staticmethod
    def wrap_dual_chart_data(left_chart_name, right_chart_name, chart_rows, cumulative_rows):
        category = chart_rows["category"]
        data = chart_rows["data"]

        chart_data = [
            {
                "name": left_chart_name,
                "data": data
            },
            {
                "name": right_chart_name,
                "data": cumulative_rows["data"]
            }
        ]

        return dict(category=category, data=chart_data)
