from common.dbutils import DBUtils
from common.cache_utils import CacheUtils
from common.utils import Utils


class DeviceController:
    @staticmethod
    def get_all_mkt_name():
        sql = DBUtils.load_query('device', 'get_mkt_name.sql')
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_MYSQL, sql, {})
        mkt_name_list = []
        for row in return_rows:
            mkt_id, name = row
            mkt_name_list.append({"mkt_id": mkt_id, "name": name})
        return dict(mkt_name_list=mkt_name_list)

    @staticmethod
    def get_device_model_list(mkt_id):
        if mkt_id == 'all':
            ret_model = 'all'
        else:
            sql = DBUtils.load_query('device', 'get_device_model.sql')
            params = {"mkt_id": int(mkt_id)}
            return_rows = DBUtils.execute_query(DBUtils.CONFIG_MYSQL, sql, params)
            dvc_model_list = ['']
            for row in return_rows:
                dvc_model_name = row[0]
                dvc_model_list.append(dvc_model_name)
            ret_model = str(tuple(dvc_model_list))
        return ret_model

    @staticmethod
    def get_device_to_mkt_name_dict():
        device_to_mkt_name_dict = DeviceController.get_device_cache_dict().get('device_to_mkt_name_dict')
        return device_to_mkt_name_dict

    @staticmethod
    def get_device_list(mkt_name):
        mkt_name_to_device_list_dict = DeviceController.get_device_cache_dict().get('mkt_name_to_device_list_dict')
        device_list = mkt_name_to_device_list_dict.get(mkt_name, 'all')
        return device_list

    @staticmethod
    def get_device_cache_dict():
        cache_key = 'device_cache_dict'
        if CacheUtils.is_cache(cache_key):
            device_cache_dict = CacheUtils.get_cache(cache_key)
        else:
            return_rows = DeviceController._get_mkt_name_device()
            mkt_name_to_device_list_dict = DeviceController._get_mkt_name_to_device_list_dict(return_rows)
            device_to_mkt_name_dict = DeviceController._get_device_to_mkt_name_dict(return_rows)
            mkt_name_list = DeviceController._get_mkt_name_list(mkt_name_to_device_list_dict)

            device_cache_dict = {
                'mkt_name_list': mkt_name_list,
                'mkt_name_to_device_list_dict': mkt_name_to_device_list_dict,
                'device_to_mkt_name_dict': device_to_mkt_name_dict
            }

            CacheUtils.set_cache(cache_key, device_cache_dict)
        return device_cache_dict

    @staticmethod
    def _get_mkt_name_device():
        sql = DBUtils.load_query('device', 'get_mkt_name_device.sql')
        return_rows = DBUtils.execute_query(DBUtils.CONFIG_MYSQL, sql, {})
        return return_rows

    @staticmethod
    def _get_mkt_name_to_device_list_dict(return_rows):
        mkt_name_to_device_list_dict = dict()
        for row in return_rows:
            mkt_name, device = row
            mkt_name = mkt_name.strip()
            device = device.strip()
            if mkt_name in mkt_name_to_device_list_dict:
                device_list = mkt_name_to_device_list_dict.get(mkt_name)
                device_list.append(device)
                mkt_name_to_device_list_dict[mkt_name] = device_list
            else:
                mkt_name_to_device_list_dict[mkt_name] = [device]

        return mkt_name_to_device_list_dict

    @staticmethod
    def _get_device_to_mkt_name_dict(return_rows):
        device_to_mkt_name_dict = dict()
        for row in return_rows:
            mkt_name, device = row
            mkt_name = mkt_name.strip()
            device = device.strip()
            device_to_mkt_name_dict[device] = mkt_name

        return device_to_mkt_name_dict

    @staticmethod
    def _get_mkt_name_list(mkt_name_to_device_list_dict):
        mkt_name_list = list(mkt_name_to_device_list_dict.keys())
        mkt_name_list.sort(key=Utils.alphanum_key)
        return mkt_name_list

    @staticmethod
    def get_tab_mkt_name(mkt_name):
        if mkt_name == "":
            ret_mkt_name = ""
        else:
            ret_mkt_name = " (" + mkt_name + ")"
        return ret_mkt_name
