SELECT page_grp_id, date, sum(cnt) as cnt
FROM v3_unique_pv_daily
WHERE
    date >= '{start_date}'
AND
    date < '{end_date}'::date + INTERVAL '1' DAY
AND
    branch_id IN {branch_ids}
AND
    page_grp_id IN {page_grp_id}
GROUP BY page_grp_id, date
ORDER BY page_grp_id, date
