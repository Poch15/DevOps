SELECT
	      CASE WHEN monthval < 10 THEN yearval || '/0' || monthval
			       ELSE yearval || '/' || monthval
			       END as yearmonth,
			  beta_prj,
        sumval AS sum
FROM
  (
    SELECT extract(year from dateval) as yearval, extract(month from dateval) as monthval, beta_prj, sum(cnt) as sumval
    FROM
      (
              SELECT date as dateval,
                     case
                      when beta_prj_id > 0 then 1
                      else 0 end
                     as beta_prj,
                     sum(cnt) as cnt
              FROM v3_feedback
              WHERE
                date >= '{start_date}'
              AND
                date <= '{end_date}'
              AND
                branch_id IN {branch_ids}
              AND
                model {model}
              AND
                main_type  = {voc_types}
              AND
                prd_cat IN {prd_cat}
              GROUP BY date, beta_prj
              ORDER BY date, beta_prj
      ) AS A
    GROUP BY extract(year from dateval), extract(month from dateval), beta_prj
    ORDER BY extract(year from dateval), extract(month from dateval), beta_prj
  ) asB