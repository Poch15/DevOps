SELECT keyword_idx, sum(cnt) as count, ROUND(SUM(cnt) / SUM(SUM(cnt)) OVER() * 100.0, 2) AS percent, RANK() OVER(ORDER BY sum(cnt) DESC) AS rank
FROM
  (
    SELECT keyword_idx, cnt
    FROM v3_keyword
      WHERE
        date >= '{start_date}'::date
      AND
        date < '{end_date}'::date + INTERVAL '1' DAY
      AND
        source = {source}
      AND
        branch_id IN {branch_ids}
      AND
        model {model}
  ) AS A
GROUP BY keyword_idx
ORDER BY count DESC, keyword_idx
LIMIT {limit} OFFSET {offset}