SELECT branch_id, date, sum(cnt)
FROM v3_screenview_daily
WHERE
    date >= '{start_date}'
AND
    date <= '{end_date}'
AND
    branch_id IN {branch_ids}
AND
    CASE
        WHEN '{page_id}' = '' THEN
            model {model}
        ELSE
            model {model} AND screen_id = '{page_id}'
    END
GROUP BY branch_id, date
ORDER BY branch_id, date
