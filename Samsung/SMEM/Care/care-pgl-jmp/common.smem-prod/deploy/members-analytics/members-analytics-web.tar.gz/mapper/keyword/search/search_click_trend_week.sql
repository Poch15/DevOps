SELECT yearval ||' '|| weekval ||'W' as yearweek, cnt
FROM
(
  SELECT extract(isoyear from date) as yearval, extract(week from date) as weekval, sum(cnt) as cnt
  FROM
  (
    SELECT date + INTERVAL '1' DAY as date, sum(cnt) as cnt
    FROM v3_search_content
    WHERE
      date >= '{start_date}'::date
    AND
      date < '{end_date}'::date + INTERVAL '1' DAY
    AND
      branch_id IN {branch_ids}
    AND
      model {model}
    GROUP BY date
    ORDER BY date
  ) AS A
  GROUP BY yearval, weekval
	ORDER BY yearval, weekval
) AS B