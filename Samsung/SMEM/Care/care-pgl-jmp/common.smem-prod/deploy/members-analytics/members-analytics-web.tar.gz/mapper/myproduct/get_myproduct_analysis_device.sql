SELECT model, SUM(cnt) as count, ROUND(SUM(cnt) / SUM(SUM(cnt)) OVER() * 100.0, 2) AS percent
FROM v3_myproduct_summary
WHERE
  datetime >= '{start_date}'::timestamp
  AND
  datetime < '{end_date}'::timestamp + INTERVAL '1' DAY
	AND
	req_type = {request_type}
	AND
  branch_id IN {branch_ids}
GROUP BY model
ORDER BY count DESC
LIMIT {limit} OFFSET {offset}