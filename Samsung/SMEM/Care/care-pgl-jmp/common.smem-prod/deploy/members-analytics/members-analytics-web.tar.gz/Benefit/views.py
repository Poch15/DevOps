from django.shortcuts import render_to_response
from django.template.context import RequestContext
from django.views.decorators.http import require_http_methods
from django.http import JsonResponse
from common.utils import custom_login_required
from SessionManager.controls import SessionManagerController
from Benefit.controls import BenefitController
from Benefit.detail_controls import BenefitDetailController
from common.params_utils import ParamsUtils


@custom_login_required
@require_http_methods(["GET"])
def view_benefit(request):
    template = 'benefit/benefit.html'
    return render_to_response(template, context_instance=RequestContext(request))


@custom_login_required
@require_http_methods(["GET"])
def view_benefit_detail(request):
    template = 'benefit/benefit_detail.html'
    return render_to_response(template, context_instance=RequestContext(request))


@custom_login_required
@require_http_methods(["GET"])
def get_count_chart_data(request):
    try:
        return JsonResponse(BenefitController.get_chart_count_data(
            start_date=ParamsUtils.get_param(request, "start_date"),
            end_date=ParamsUtils.get_param(request, "end_date"),
            period=ParamsUtils.get_param(request, "period"),
            model=ParamsUtils.get_param(request, "query_model"),
            timezone=SessionManagerController.get_selected_time_zone(request),
            branch_ids=SessionManagerController.get_selected_branch_ids(request),
            benefit_id=ParamsUtils.get_param(request, "benefit_id"),
            branch_id=ParamsUtils.get_param(request, "branch_id")))
    except Exception as e:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})


@custom_login_required
@require_http_methods(["GET"])
def get_analysis_title_data(request):
    try:
        return JsonResponse(BenefitController.get_analysis_title_data(
            start_dt=request.GET.get("start_date"),
            end_dt=request.GET.get("end_date"),
            period=ParamsUtils.get_param(request, "period"),
            branch_ids=SessionManagerController.get_selected_branch_ids(request),
            model=ParamsUtils.get_param(request, "query_model"),
            tz=SessionManagerController.get_selected_time_zone(request),
            cur_p=ParamsUtils.get_param(request, "cur_p"),
            pg_size=int(ParamsUtils.get_param(request, "page_size")),
            benefit_id='0',
            branch_id='-1'))
    except Exception as e:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})


@custom_login_required
@require_http_methods(["GET"])
def get_analysis_device_data(request):
    try:
        return JsonResponse(BenefitController.get_analysis_device_data(
            start_dt=request.GET.get("start_date"),
            end_dt=request.GET.get("end_date"),
            period=ParamsUtils.get_param(request, "period"),
            branch_ids=SessionManagerController.get_selected_branch_ids(request),
            model=ParamsUtils.get_param(request, "query_model"),
            tz=SessionManagerController.get_selected_time_zone(request),
            cur_p=ParamsUtils.get_param(request, "cur_p"),
            pg_size=int(ParamsUtils.get_param(request, "page_size")),
            benefit_id=ParamsUtils.get_param(request, "benefit_id"),
            branch_id=ParamsUtils.get_param(request, "branch_id")))
    except Exception as e:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})


@custom_login_required
@require_http_methods(["GET"])
def export_excel(request):
    try:
        excel_count_data = BenefitController.get_count_excel_data(
            start_date=ParamsUtils.get_param(request, "start_date"),
            end_date=ParamsUtils.get_param(request, "end_date"),
            period=ParamsUtils.get_param(request, "period"),
            branch_ids=SessionManagerController.get_selected_branch_ids(request),
            model=ParamsUtils.get_param(request, "query_model"),
            timezone=SessionManagerController.get_selected_time_zone(request),
            benefit_id=ParamsUtils.get_param(request, "benefit_id"),
            branch_id=ParamsUtils.get_param(request, "branch_id"))
        return excel_count_data
    except Exception as e:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})


@custom_login_required
@require_http_methods(["GET"])
def get_detail_count_chart_data(request):
    try:
        return JsonResponse(BenefitDetailController.get_chart_count_data(
            start_dt=ParamsUtils.get_param(request, "start_date"),
            end_dt=ParamsUtils.get_param(request, "end_date"),
            period=ParamsUtils.get_param(request, "period"),
            model=ParamsUtils.get_param(request, "query_model"),
            tz=SessionManagerController.get_selected_time_zone(request),
            branch_ids=SessionManagerController.get_selected_branch_ids(request),
            benefit_id=ParamsUtils.get_param(request, "benefit_id"),
            coupon_id=ParamsUtils.get_param(request, "coupon_id"),
            event_type=ParamsUtils.get_param(request, "event_type"),
            branch_id=ParamsUtils.get_param(request, "branch_id")))
    except Exception as e:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})


@custom_login_required
@require_http_methods(["GET"])
def get_detail_analysis_title_data(request):
    try:
        return JsonResponse(BenefitDetailController.get_analysis_title_data(
            start_date=request.GET.get("start_date"),
            end_date=request.GET.get("end_date"),
            period=ParamsUtils.get_param(request, "period"),
            branch_ids=SessionManagerController.get_selected_branch_ids(request),
            model=ParamsUtils.get_param(request, "query_model"),
            timezone=SessionManagerController.get_selected_time_zone(request),
            cur_p=ParamsUtils.get_param(request, "cur_p"),
            benefit_id=ParamsUtils.get_param(request, "benefit_id"),
            coupon_id=ParamsUtils.get_param(request, "coupon_id"),
            event_type='0',
            branch_id='-1',
            page_size=int(ParamsUtils.get_param(request, "page_size"))))
    except Exception as e:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})


@custom_login_required
@require_http_methods(["GET"])
def get_detail_analysis_device_data(request):
    try:
        return JsonResponse(BenefitDetailController.get_analysis_device_data(
            start_date=request.GET.get("start_date"),
            end_date=request.GET.get("end_date"),
            period=ParamsUtils.get_param(request, "period"),
            branch_ids=SessionManagerController.get_selected_branch_ids(request),
            model=ParamsUtils.get_param(request, "query_model"),
            timezone=SessionManagerController.get_selected_time_zone(request),
            cur_p=ParamsUtils.get_param(request, "cur_p"),
            page_size=int(ParamsUtils.get_param(request, "page_size")),
            benefit_id=ParamsUtils.get_param(request, "benefit_id"),
            coupon_id=ParamsUtils.get_param(request, "coupon_id"),
            event_type=ParamsUtils.get_param(request, "event_type"),
            branch_id=ParamsUtils.get_param(request, "branch_id")))
    except Exception as e:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})


@custom_login_required
@require_http_methods(["GET"])
def detail_export_excel(request):
    try:
        return BenefitDetailController.get_count_excel_data(
            start_date=ParamsUtils.get_param(request, "start_date"),
            end_date=ParamsUtils.get_param(request, "end_date"),
            period=ParamsUtils.get_param(request, "period"),
            branch_ids=SessionManagerController.get_selected_branch_ids(request),
            model=ParamsUtils.get_param(request, "query_model"),
            tz=SessionManagerController.get_selected_time_zone(request),
            benefit_id=ParamsUtils.get_param(request, "benefit_id"),
            coupon_id=ParamsUtils.get_param(request, "coupon_id"),
            event_type=ParamsUtils.get_param(request, "event_type"),
            branch_id=ParamsUtils.get_param(request, "branch_id"))
    except Exception as e:
        return JsonResponse({'status': 'fail', 'message': 'parameter error'})
