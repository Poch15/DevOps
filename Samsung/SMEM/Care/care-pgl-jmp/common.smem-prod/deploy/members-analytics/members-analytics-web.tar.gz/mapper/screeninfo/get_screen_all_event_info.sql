SELECT screen_id, event_target_id, event_name
FROM tbl_v2_screen_event_info
ORDER BY screen_id, event_target_id