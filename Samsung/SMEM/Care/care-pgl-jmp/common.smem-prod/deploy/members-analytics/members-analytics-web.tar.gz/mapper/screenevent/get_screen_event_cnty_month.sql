SELECT
  branch_id,
  CASE WHEN monthval < 10 THEN yearval || '/0' || monthval
      ELSE yearval || '/' || monthval
      END as yearmonth, sum(cnt) as cnt
FROM
(
  SELECT EXTRACT(year from date) as yearval, EXTRACT(month from date) as monthval, branch_id, sum(cnt) as cnt
  FROM
  (
     SELECT date, branch_id, sum(cnt) as cnt
      FROM v3_screen_event
      WHERE
          date >= '{start_date}'
      AND
          date <= '{end_date}'
      AND
      CASE
          WHEN '{event_id}' != ''
               THEN branch_id IN {branch_ids} AND event_id = '{event_id}'
          WHEN '{page_id}' != ''
               THEN branch_id IN {branch_ids} AND screen_id = '{page_id}'
          ELSE
               branch_id IN {branch_ids}
      END
      GROUP BY date, branch_id
  ) as K
  GROUP BY yearval, monthval, branch_id
) AS A
GROUP BY branch_id, yearval, monthval
ORDER BY branch_id, yearval, monthval
