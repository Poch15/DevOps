SELECT (datetime + INTERVAL '{interval_hour}' HOUR)::date as date, category_id, SUM(cnt) as cnt
FROM tbl_v2_faq
WHERE
  datetime >= '{start_date}'::timestamp - INTERVAL '{interval_hour}' HOUR
	AND
	datetime < '{end_date}'::timestamp - INTERVAL '{interval_hour}' HOUR + INTERVAL '1' DAY
	AND
	branch_id IN {branch_ids}
	AND
	model like '{model}%'
GROUP BY date, category_id
ORDER BY date, category_id