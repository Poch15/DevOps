from common.dbutils import DBUtils


class ScreenInfoController:
    @staticmethod
    def get_all_screen_info():
        pv_sql = DBUtils.load_query('screeninfo', 'get_screen_all_pv_info.sql')
        pv_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, pv_sql, {})

        event_sql = DBUtils.load_query('screeninfo', 'get_screen_all_event_info.sql')
        event_rows = DBUtils.execute_query(DBUtils.CONFIG_POSTGRESQL, event_sql, {})

        screen_info_list = []
        event_dict = {}
        for row in event_rows:
            screen_id, event_target_id, event_name = row
            screen_event_dict = event_dict.get(screen_id, {})
            screen_event_dict[event_target_id] = event_name
            event_dict[screen_id] = screen_event_dict

        for row in pv_rows:
            screen_id, screen_name, ux_version = row
            screen_info = {"screenId": screen_id, "screenName": screen_name, "uxVersion": ux_version}

            events = []
            screen_event_dict = event_dict.get(screen_id, None)
            if screen_event_dict:
                for event_target_id in screen_event_dict.keys():
                    events.append({"eventTargetId": event_target_id,
                                   "eventName": screen_event_dict.get(event_target_id, "Unknown")})
                screen_info["events"] = events

            screen_info_list.append(screen_info)
        return screen_info_list
