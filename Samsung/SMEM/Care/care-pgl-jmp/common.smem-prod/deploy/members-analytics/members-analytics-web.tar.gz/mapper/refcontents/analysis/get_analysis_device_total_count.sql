SELECT COUNT(*)
FROM
(
  SELECT model
  FROM {tbl_name}
  WHERE
    datetime >= '{start_date}'::timestamp
    AND
    datetime < '{end_date}'::timestamp + INTERVAL '1' DAY
    AND
    branch_id IN {branch_ids}
    AND
		CASE
    WHEN '{content_id}' = '0' THEN
      model {model}
    ELSE
      model {model} AND content_id = '{content_id}'
    END
  GROUP BY model
) AS A