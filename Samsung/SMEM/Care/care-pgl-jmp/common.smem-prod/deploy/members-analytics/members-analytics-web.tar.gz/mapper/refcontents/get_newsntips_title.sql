SELECT article_id, title, post_start_dt, post_end_dt, cat_id
FROM article
WHERE
article_id IN {ids}