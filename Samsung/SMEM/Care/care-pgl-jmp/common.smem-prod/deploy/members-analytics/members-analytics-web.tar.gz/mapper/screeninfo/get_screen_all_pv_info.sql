SELECT screen_id, screen_name, ux_version
FROM tbl_v2_screen_pv_info
WHERE
is_use = true
ORDER BY ux_version DESC, screen_id