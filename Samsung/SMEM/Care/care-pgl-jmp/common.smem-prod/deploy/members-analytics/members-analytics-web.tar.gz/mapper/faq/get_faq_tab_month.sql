SELECT
	CASE
		WHEN EXTRACT(month FROM date) < 10
		THEN EXTRACT(year FROM date) || '/0' || EXTRACT(month FROM date)
		ELSE EXTRACT(year FROM date) || '/' || EXTRACT(month FROM date)
	END AS yearmonth,
	{tab_type}, sum(cnt) as cnt
FROM
	(
		SELECT (datetime + INTERVAL '{interval_hour}' HOUR)::date as date,
				 model, branch_id, cnt
		FROM tbl_v2_faq
		WHERE
	    datetime >= '{start_date}'::timestamp - INTERVAL '{interval_hour}' HOUR
	  AND
	    datetime < '{end_date}'::timestamp - INTERVAL '{interval_hour}' HOUR + INTERVAL '1' DAY
   	AND
      branch_id IN {branch_ids}
     AND
      model like '{model}%'
	) AS A
GROUP BY EXTRACT(year FROM date), EXTRACT(month FROM date), {tab_type}
ORDER BY EXTRACT(year FROM date), EXTRACT(month FROM date), {tab_type}