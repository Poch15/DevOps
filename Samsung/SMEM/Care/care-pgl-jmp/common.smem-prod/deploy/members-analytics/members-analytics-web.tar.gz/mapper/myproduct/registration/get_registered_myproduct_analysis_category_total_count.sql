SELECT count(*)
FROM
(
  SELECT category
  FROM v3_mp_product
  WHERE
    date >= '{start_date}'::timestamp
  AND
    date < '{end_date}'::timestamp + INTERVAL '1' DAY
  AND
    company_cd IN {company_codes}
  GROUP BY category
) AS A