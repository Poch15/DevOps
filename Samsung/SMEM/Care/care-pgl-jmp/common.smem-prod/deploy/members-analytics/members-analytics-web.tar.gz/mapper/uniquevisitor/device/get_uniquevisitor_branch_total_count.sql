SELECT count(*)
FROM
(
  SELECT branch_id
  FROM {tbl_name}
  WHERE
      date = '{date}'::timestamp - INTERVAL '{interval_hour}' HOUR
    AND
      timezone = '{timezone}'
    AND
      branch_id IN {branch_ids}
    AND
      model {model}
  GROUP BY branch_id
) AS A