SELECT SUM(imp_cnt) AS tot_imp_cnt, SUM(click_cnt) AS tot_click_cnt
FROM v3_banner
WHERE
  date < '{start_date}'
AND
  branch_id IN {branch_ids}
AND
    CASE
    WHEN '{banner_id}' = '0' THEN
      model {model}
    ELSE
      model {model} AND banner_id = '{banner_id}'
    END