import boto3
from botocore.credentials import InstanceMetadataProvider
from botocore.utils import InstanceMetadataFetcher
import json


class Credential:
    def __init__(self, profile):
        if profile == 'local':
            with open(".credential.json") as f:
                self.secrets = json.loads(f.read())
        else:
            secret_name = '/secret/dev/analytics'
            if profile == 'prd':
                secret_name = '/secret/prd/analytics'

            provider = InstanceMetadataProvider(iam_role_fetcher=InstanceMetadataFetcher(timeout=1000, num_attempts=2))
            credentials = provider.load().get_frozen_credentials()
            aws_access_key_id = credentials.access_key
            aws_secret_access_key = credentials.secret_key
            aws_session_token = credentials.token

            secret_client = boto3.client(service_name='secretsmanager',
                                         aws_access_key_id=aws_access_key_id,
                                         aws_secret_access_key=aws_secret_access_key,
                                         aws_session_token=aws_session_token,
                                         verify=None, config=None, region_name='ap-northeast-2')

            response = secret_client.get_secret_value(SecretId=secret_name)
            self.secrets = json.loads(response['SecretString'])

    def get_django_secret_key(self):
        return self.secrets['django.secret-key']

    def get_django_auth_user(self):
        return self.secrets['django.auth.user']

    def get_django_auth_password(self):
        return self.secrets['django.auth.password']

    def get_benefit_api_key(self):
        return self.secrets['benefit-api-key']

    def get_postgresql_user(self):
        return self.secrets['postgresql.user']

    def get_postgresql_password(self):
        return self.secrets['postgresql.password']

    def get_mysql_user(self):
        return self.secrets['mysql.user']

    def get_mysql_password(self):
        return self.secrets['mysql.password']

    def get_mysql_benefit_user(self):
        return self.secrets['mysql-benefit.user']

    def get_mysql_benefit_password(self):
        return self.secrets['mysql-benefit.password']