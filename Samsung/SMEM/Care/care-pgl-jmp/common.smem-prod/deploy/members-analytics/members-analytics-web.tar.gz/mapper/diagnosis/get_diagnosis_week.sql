SELECT yearval ||' '|| weekval ||'W' as yearweek, {result_type}, cnt
FROM
  (
    SELECT extract(isoyear from dateval) as yearval, extract(week from dateval) as weekval, {result_type}, sum(cnt) as cnt
    FROM
    (
          (
            SELECT datetime + interval '1' day as dateval, {result_type}, sum(cnt) as cnt
            FROM
              (
                SELECT datetime, {result_type}, cnt
                FROM {tbl_name}
                WHERE
                  datetime >= '{start_date}'::timestamp
                AND
                  datetime < '{end_date}'::timestamp + INTERVAL '1' DAY
                AND
                  model {model}
                AND
                  branch_id IN {branch_ids}
              ) AS A
            GROUP BY dateval, {result_type}
            ORDER BY dateval, {result_type}
          )
          UNION ALL
          (
	          SELECT date + interval '1' day, -1 as {result_type}, 0 as sum
            FROM
              (
                SELECT C.date
                FROM
                  (
                    SELECT '{start_date}'::date + (100 * aa.a + 10 * bb.a + cc.a) as date
                    FROM (
                            select 0 as a
                            union all select 1
                            union all select 2
                            union all select 3
                            union all select 4
                            union all select 5
                            union all select 6
                            union all select 7
                            union all select 8
                            union all select 9
                          ) as aa cross join
                          (
                            select 0 as a
                            union all select 1
                            union all select 2
                            union all select 3
                            union all select 4
                            union all select 5
                            union all select 6
                            union all select 7
                            union all select 8
                            union all select 9
                          ) as bb cross join
                          (
                            select 0 as a
                            union all select 1
                            union all select 2
                            union all select 3
                            union all select 4
                            union all select 5
                            union all select 6
                            union all select 7
                            union all select 8
                            union all select 9
                          ) as cc
                  ) AS C
                WHERE C.DATE < '{end_date}'::date + interval '1' day
              ) AS D
          )
    ) AS E
    GROUP BY extract(isoyear from dateval), extract(week from dateval), {result_type}
    ORDER BY extract(isoyear from dateval), extract(week from dateval), {result_type}
  ) AS F;