SELECT
        branch_id,
        CASE WHEN month < 10 THEN year || '/0' || month
             ELSE year || '/' || month
             END as yearmonth,
        sumval
FROM
(
  SELECT branch_id, EXTRACT (year from date) as year, EXTRACT(month from date) as month,  SUM(cnt) as sumval
  FROM {tbl_name}
  WHERE
    date >= '{start_date}'
      AND
    date <= '{end_date}'
      AND
    timezone = {timezone}
      AND
    branch_id IN {branch_ids}
      AND
    model {model}
  GROUP BY branch_id, date
  ORDER BY branch_id, date
)AS A