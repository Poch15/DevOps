SELECT p.screen_id, p.screen_name, e.event_target_id, e.event_name, p.ux_version
FROM tbl_v2_screen_pv_info AS p
LEFT JOIN tbl_v2_screen_event_info AS e
ON p.screen_id = e.screen_id
WHERE
p.is_use = true
ORDER BY ux_version DESC, screen_id