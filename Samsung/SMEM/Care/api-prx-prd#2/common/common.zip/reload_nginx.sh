#!/bin/bash

docker exec nginx nginx -s reload
