import os
import boto3
import sys

client = boto3.client('ec2')
#st_list_vpc1 = open('C:\\Users\\kbajao\\PycharmProjects\\Tutorials\\Automation\\\STSchedulerTool\\single_tenant_list.txt').read().splitlines()
#st_list_vpc2 = open('C:\\Users\\kbajao\\PycharmProjects\\Tutorials\\Automation\\\STSchedulerTool\\single_tenant_list_vpc2.txt').read().splitlines()
#st_type = open('C:\\Users\\kbajao\\PycharmProjects\\Tutorials\\Automation\\\STSchedulerTool\\single_tenant_type.txt').read().splitlines()
#st_time = open('C:\\Users\\kbajao\\PycharmProjects\\Tutorials\\Automation\\\STSchedulerTool\\single_tenant_time.txt').read().splitlines()

st_list_vpc1 = open('C:\\STSchedulerTool\\single_tenant_list.txt').read().splitlines()
st_list_vpc2 = open('C:\\STSchedulerTool\\single_tenant_list_vpc2.txt').read().splitlines()
st_type = open('C:\\STSchedulerTool\\single_tenant_type.txt').read().splitlines()
st_time = open('C:\\STSchedulerTool\\single_tenant_time.txt').read().splitlines()

def getinstanceidvpc1(st_leaseenv_vpc1,request_type):
    print('Executing the function')
    for type_request in request_type:
        print('Add schedule for ' + st_leaseenv_vpc1 + '-' + type_request)
        os.system(
            'aws ec2 describe-instances --filters Name=tag:Name,Values=' + st_leaseenv_vpc1 + '-' + type_request + ' | grep InstanceId >> getinstanceid_vpc1.txt'
        )


def main():
    try:
        st_leaseenv_vpc1 = sys.argv[1].upper()
        st_leaseenv_vpc2 = sys.argv[2].upper()
        st_leasetype = sys.argv[3].upper()
        st_leasetime = sys.argv[4]

        print(st_leaseenv_vpc1)
        print(st_leaseenv_vpc2)
        print(st_leasetype)
        print(st_leasetime)

        if st_leaseenv_vpc1 not in st_list_vpc1:
            print('Environment '+st_leaseenv_vpc1+' not exist in ST.')
            print('Please check the list of available VPC1 environments in ST.')
            print(st_list_vpc1)
        elif st_leaseenv_vpc2 not in st_list_vpc2:
            print('Environment '+st_leaseenv_vpc2+' not exist in ST.')
            print('Please check the list of available VPC2 environments in ST')
            print(st_list_vpc2)
        elif st_leasetype not in st_type:
            print('Lease Type '+st_leasetype+' is not available in our list.')
            print('Please check the list of available lease type in ST.')
            print(st_type)
        elif st_leasetime not in st_time:
            print('Lease Schedule '+st_leasetime+' is not available in our list.')
            print('Please check the list of available lease schedule in ST.')
            print(st_time)
        else:
            print('Parameters are ok')
            try:
                #os.remove('C:\\Users\\kbajao\\PycharmProjects\\Tutorials\\Automation\\\STSchedulerTool\\getinstanceid_vpc1.txt')
                #os.remove('C:\\Users\\kbajao\\PycharmProjects\\Tutorials\\Automation\\\STSchedulerTool\\getinstanceid_vpc2.txt')

                os.remove('C:\\STSchedulerTool\\getinstanceid_vpc1.txt')
                os.remove('C:\\STSchedulerTool\\getinstanceid_vpc2.txt')
            except FileNotFoundError:
                print('Create getinstanceid_vpc1.txt and getinstanceid_vpc2.txt')

            ### Checking the Lease Type and instance id
            if st_leasetype == 'LSF':
                #request_type = open('C:\\Users\\kbajao\\PycharmProjects\\Tutorials\\Automation\\\STSchedulerTool\\lsf_lease.txt').read().splitlines()
                request_type = open('C:\\STSchedulerTool\\lsf_lease.txt').read().splitlines()
                getinstanceidvpc1(st_leaseenv_vpc1,request_type)
            elif st_leasetype == '4GL_CONNECTORS':
                #request_type = open(
                #    'C:\\Users\\kbajao\\PycharmProjects\\Tutorials\\Automation\\\STSchedulerTool\\4gl_lease.txt').read().splitlines()
                request_type = open('C:\\STSchedulerTool\\4gl_lease.txt').read().splitlines()
                getinstanceidvpc1(st_leaseenv_vpc1, request_type)
            elif st_leasetype == 'WEBAPPS':
                #request_type = open(
                #    'C:\\Users\\kbajao\\PycharmProjects\\Tutorials\\Automation\\\STSchedulerTool\\webapps_lease.txt').read().splitlines()
                request_type = open('C:\\STSchedulerTool\\webapps_lease.txt').read().splitlines()
                getinstanceidvpc1(st_leaseenv_vpc1, request_type)
            elif st_leasetype == 'MSCM':
                #request_type = open(
                #    'C:\\Users\\kbajao\\PycharmProjects\\Tutorials\\Automation\\\STSchedulerTool\\mscm_lease.txt').read().splitlines()
                request_type = open('C:\\STSchedulerTool\\mscm_lease.txt').read().splitlines()
                getinstanceidvpc1(st_leaseenv_vpc1, request_type)
            elif st_leasetype == 'LANDMARK':
                #request_type = open(
                #    'C:\\Users\\kbajao\\PycharmProjects\\Tutorials\\Automation\\\STSchedulerTool\\landmark_lease.txt').read().splitlines()
                request_type = open('C:\\STSchedulerTool\\landmark_lease.txt').read().splitlines()
                getinstanceidvpc1(st_leaseenv_vpc1, request_type)
            elif st_leasetype == 'SHIFTLEFT':
                #request_type = open(
                #    'C:\\Users\\kbajao\\PycharmProjects\\Tutorials\\Automation\\\STSchedulerTool\\shiftleft_lease.txt').read().splitlines()
                request_type = open('C:\\STSchedulerTool\\shiftleft_lease.txt').read().splitlines()
                getinstanceidvpc1(st_leaseenv_vpc1, request_type)
            elif st_leasetype == 'HYBRID':
                #request_type = open(
                #    'C:\\Users\\kbajao\\PycharmProjects\\Tutorials\\Automation\\\STSchedulerTool\\hybrid_lease.txt').read().splitlines()
                request_type = open('C:\\STSchedulerTool\\hybrid_lease.txt').read().splitlines()
                getinstanceidvpc1(st_leaseenv_vpc1, request_type)
            elif st_leasetype == 'BIRST':
                #request_type = open(
                #    'C:\\Users\\kbajao\\PycharmProjects\\Tutorials\\Automation\\\STSchedulerTool\\birst_lease.txt').read().splitlines()
                request_type = open('C:\\STSchedulerTool\\birst_lease.txt').read().splitlines()
                getinstanceidvpc1(st_leaseenv_vpc1, request_type)

            ### Add Schedule VPC1
            #instanceid_vpc1 = open('C:\\Users\\kbajao\\PycharmProjects\\Tutorials\\Automation\\\STSchedulerTool\\getinstanceid_vpc1.txt').read().splitlines()
            instanceid_vpc1 = open('C:\\STSchedulerTool\\getinstanceid_vpc1.txt').read().splitlines()
            for addschedule_vpc1 in instanceid_vpc1:
                schedulevpc1 = addschedule_vpc1.replace('"InstanceId": "', '').replace('",', '').replace('                    ', '')
                print(schedulevpc1)

                response = client.create_tags(
                    Resources=[
                        schedulevpc1
                    ],
                    Tags=[
                        {
                            'Key': 'Schedule',
                            'Value': st_leasetime
                        },
                    ]
                )
                print(response)

            ### Get instance id for VPC2
            #list_vpc2 = open('C:\\Users\\kbajao\\PycharmProjects\\Tutorials\\Automation\\\STSchedulerTool\\vpc2_lease.txt').read().splitlines()
            list_vpc2 = open('C:\\STSchedulerTool\\vpc2_lease.txt').read().splitlines()
            for vpc2_list in list_vpc2:
                print('Adding Schedule for '+st_leaseenv_vpc2+'-'+vpc2_list)
                os.system(
                    'aws ec2 describe-instances --filters Name=tag:Name,Values=' + st_leaseenv_vpc2 + '-' + vpc2_list + ' | grep InstanceId >> getinstanceid_vpc2.txt'
                )

            ### Add Schedule VPC2
            #instanceid_vpc2 = open('C:\\Users\\kbajao\\PycharmProjects\\Tutorials\\Automation\\\STSchedulerTool\\getinstanceid_vpc2.txt').read().splitlines()
            instanceid_vpc2 = open('C:\\STSchedulerTool\\getinstanceid_vpc2.txt').read().splitlines()
            for addschedule_vpc2 in instanceid_vpc2:
                schedulevpc2 = addschedule_vpc2.replace('"InstanceId": "', '').replace('",', '').replace(
                    '                    ', '')
                print(schedulevpc2)
                response_vpc2 = client.create_tags(
                    Resources=[
                        schedulevpc2
                    ],
                    Tags=[
                        {
                            'Key': 'Schedule',
                            'Value': st_leasetime
                        },
                    ]
                )
                print(response_vpc2)

    except IndexError:
        missingparam_addsched()


def missingparam_addsched():
    print('Missing parameters. Please check the correct format to run the tool for adding schedule. "python stschedulertool.py <ENVIRONMENT_VPC1> <ENVIRONMENT_VPC2> <TYPE> <TIME>\n"')
    print('where ENVIRONMENT_VPC1 is equal to:')
    for envlist_vpc1 in st_list_vpc1:
        print(envlist_vpc1)

    print('\nwhere ENVIRONMENT_VPC2 is equal to:')
    for envlist_vpc2 in st_list_vpc2:
        print(envlist_vpc2)

    print('\nwhere TYPE is equal to:')
    for typelist in st_type:
        print(typelist)

    print('\nwhere TIME is equal to:')
    for timelist in st_time:
        print(timelist)

    print('\nIf you want to delete the schedule, please follow the correct format. "python stschedulertool.py DEL_SCHED <ENVIRONMENT_VPC1> <ENVIRONMENT_VPC2>\n"')
    print('where ENVIRONMENT_VPC1 is equal to:')
    for envlist_vpc1 in st_list_vpc1:
        print(envlist_vpc1)

    print('\nwhere ENVIRONMENT_VPC2 is equal to:')
    for envlist_vpc2 in st_list_vpc2:
        print(envlist_vpc2)

def missingparam_delsched():
    print('Missing parameters. Please check the correct format to run the tool. "python stschedulertool.py DEL_SCHED <ENVIRONMENT_VPC1> <ENVIRONMENT_VPC2>\n"')
    print('where ENVIRONMENT_VPC1 is equal to:')
    for envlist_vpc1 in st_list_vpc1:
        print(envlist_vpc1)

    print('\nwhere ENVIRONMENT_VPC2 is equal to:')
    for envlist_vpc2 in st_list_vpc2:
        print(envlist_vpc2)


def deleteschedule():
    try:
        stdel_vpc1 = sys.argv[2].upper()
        stdel_vpc2 = sys.argv[3].upper()

        if stdel_vpc1 not in st_list_vpc1:
            print('Environment ' + stdel_vpc1 + ' not exist in ST.')
            print('Please check the list of available VPC1 environments in ST.')
            print(st_list_vpc1)
        elif stdel_vpc2 not in st_list_vpc2:
            print('Environment ' + stdel_vpc2 + ' not exist in ST.')
            print('Please check the list of available VPC1 environments in ST.')
            print(st_list_vpc2)
        else:
            print('Proceed with delete')
            ## Delete Tags in VPC1
            try:
                os.remove('C:\\Users\\kbajao\\PycharmProjects\\Tutorials\\Automation\\\STSchedulerTool\\ToBeDelete_vpc1.txt')
                os.remove('C:\\Users\\kbajao\\PycharmProjects\\Tutorials\\Automation\\\STSchedulerTool\\ToBeDelete_vpc2.txt')

                #os.remove('C:\\STSchedulerTool\\ToBeDelete_vpc1.txt')
                #os.remove('C:\\STSchedulerTool\\ToBeDelete_vpc2.txt')
            except FileNotFoundError:
                print('Proceed with creation of ToBeDelete_vpc1.txt and ToBeDelete_vpc2.txt')

            os.system('aws ec2 describe-instances --filters Name=tag:customerPrefix,Values='+stdel_vpc1+' | grep InstanceId >> ToBeDelete_vpc1.txt')
            os.system('aws ec2 describe-instances --filters Name=tag:customerPrefix,Values='+stdel_vpc2+' | grep InstanceId >> ToBeDelete_vpc2.txt')

            #del_vpc1tag = open('C:\\Users\\kbajao\\PycharmProjects\\Tutorials\\Automation\\\STSchedulerTool\\ToBeDelete_vpc1.txt').read().splitlines()
            #del_vpc2tag = open('C:\\Users\\kbajao\\PycharmProjects\\Tutorials\\Automation\\\STSchedulerTool\\ToBeDelete_vpc2.txt').read().splitlines()

            del_vpc1tag = open('C:\\STSchedulerTool\\ToBeDelete_vpc1.txt').read().splitlines()
            del_vpc2tag = open('C:\\STSchedulerTool\\ToBeDelete_vpc2.txt').read().splitlines()

            print('Deleting Tags for VPC1')
            for vpc1tag_del in del_vpc1tag:
                vpc1todeletetag = vpc1tag_del.replace('"InstanceId": "', '').replace('",', '').replace(
                    '                    ', '')
                print(vpc1todeletetag)
                os.system('aws ec2 delete-tags --resources '+vpc1todeletetag+' --tags Key=Schedule')


            print('Deleting Tags for VPC2')
            for vpc2tag_del in del_vpc2tag:
                vpc2todeletetag = vpc2tag_del.replace('"InstanceId": "', '').replace('",', '').replace(
                    '                    ', '')
                print(vpc2todeletetag)
                os.system('aws ec2 delete-tags --resources ' + vpc2todeletetag + ' --tags Key=Schedule')
    except IndexError:
        missingparam_delsched()


#if st_env in st_list:
#    print(st_env)
#else:
#    print('Environment ' + st_leaseenv + ' not exist in ST. Please check the only available environments in ST / Hybrid: \n')
#    for current_st in st_list:
#        print(current_st)

### Main
if __name__ == '__main__':

    try:
        if sys.argv[1] == 'DEL_SCHED':
            deleteschedule()
        else:
            main()
    except IndexError:
        missingparam_addsched()

