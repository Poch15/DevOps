# Fargate integration into EKS

## create new EKS cluster, Fargate enabled

## add Fargate support to existing EKS cluster

```bash
eksctl create fargateprofile -f ./fargate-profile.yaml
```
